#!/usr/bin/env bash
#
# Constrói a imagem golden LXD "wsrta-base" com o stack do cliente
# (nginx + php-fpm + mariadb + cron). Roda NO HOST Ubuntu, que precisa ter LXD.
# O provision_client lança os containers dos clientes a partir desta imagem.
#
# Uso:  ./scripts/build-base-image.sh
# Vars: BASE_IMAGE (default ubuntu:24.04), IMAGE_ALIAS (default wsrta-base)
set -euo pipefail

BASE_IMAGE="${BASE_IMAGE:-ubuntu:24.04}"
IMAGE_ALIAS="${IMAGE_ALIAS:-wsrta-base}"
BUILD_NAME="wsrta-base-build"

echo ">> Limpando build anterior, se houver"
lxc delete -f "$BUILD_NAME" 2>/dev/null || true
lxc image delete "$IMAGE_ALIAS" 2>/dev/null || true

echo ">> Lançando container temporário a partir de $BASE_IMAGE"
lxc launch "$BASE_IMAGE" "$BUILD_NAME"

echo ">> Aguardando cloud-init / rede"
lxc exec "$BUILD_NAME" -- cloud-init status --wait || true

echo ">> Instalando o stack (nginx + php-fpm + mariadb + cron)"
lxc exec "$BUILD_NAME" -- env DEBIAN_FRONTEND=noninteractive bash -c '
  set -e
  apt-get update
  # Multi-PHP: repositório ondrej/php para instalar QUALQUER versão (8.1-8.4) sob demanda — o
  # painel troca a versão de PHP por domínio (ação set_domain_php). software-properties-common
  # traz o add-apt-repository. Assim os containers NOVOS já vêm com o PPA (troca de versão rápida);
  # nos containers existentes o daemon adiciona o PPA na 1ª troca.
  apt-get install -y software-properties-common
  add-apt-repository -y ppa:ondrej/php
  apt-get update
  apt-get install -y nginx php-fpm php-cli php-mysql mariadb-server cron curl openssh-server bzip2 unzip
  # Docker (Fase 5b): instalado mas DESLIGADO por padrão; o painel habilita por cliente (opt-in,
  # liga security.nesting no LXD + inicia o dockerd). Mantém o isolamento por padrão.
  apt-get install -y docker.io
  systemctl disable docker 2>/dev/null || true
  # Remove o site default do nginx (tem "listen 80 default_server" → colide com os vhosts
  # do WSRTA, que também escutam :80 → "duplicate default server" no nginx -t).
  rm -f /etc/nginx/sites-enabled/default
  # Habilita login por senha no sshd (as imagens cloud do Ubuntu desabilitam num drop-in) —
  # necessário para o SFTP por senha funcionar.
  printf "PasswordAuthentication yes\n" > /etc/ssh/sshd_config.d/99-wsrta-sftp.conf
  systemctl enable nginx mariadb cron ssh
  systemctl enable "$(systemctl list-unit-files | grep -o "php[0-9.]*-fpm.service" | head -n1)" || true
  # wp-cli (para install_wordpress)
  curl -fsSL https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar -o /usr/local/bin/wp
  chmod +x /usr/local/bin/wp
  # cloudflared (túnel Cloudflare por cliente)
  arch="$(dpkg --print-architecture)"
  curl -fsSL "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${arch}" -o /usr/local/bin/cloudflared
  chmod +x /usr/local/bin/cloudflared
  apt-get clean
  rm -rf /var/lib/apt/lists/*
'

echo ">> Parando e publicando como imagem '$IMAGE_ALIAS'"
lxc stop "$BUILD_NAME"
lxc publish "$BUILD_NAME" --alias "$IMAGE_ALIAS" \
  description="WSRTA base: nginx + php-fpm + mariadb + cron"

echo ">> Removendo container de build"
lxc delete "$BUILD_NAME"

echo ">> Pronto. Imagem golden '$IMAGE_ALIAS' criada."
