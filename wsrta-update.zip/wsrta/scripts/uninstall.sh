#!/usr/bin/env bash
# Desinstalador do WSRTA — devolve o servidor ao estado anterior à instalação.
#
# Remove TUDO que o install.sh criou: os serviços systemd, o app, os bancos/roles do
# Postgres, os containers de clientes e a imagem golden do LXD, phpMyAdmin/phpPgAdmin, o
# nginx do painel, o Go, o acme.sh, o ufw e os pacotes do stack.
#
# MANTÉM (a pedido): os utilitários básicos (nano, iputils-ping, net-tools, htop, byobu,
# screen) e o sudo SEM SENHA (/etc/sudoers.d/wsrta-nopasswd).
#
# Uso:
#   sudo bash scripts/uninstall.sh           # pede confirmação (digite "APAGAR TUDO")
#   sudo bash scripts/uninstall.sh --yes      # sem confirmação
#   sudo bash scripts/install.sh --uninstall  # atalho pelo instalador
#
# É best-effort: NÃO usa "set -e" — segue removendo o resto mesmo se um passo falhar.
set -uo pipefail

log()  { printf '\033[1;36m[wsrta-uninstall]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[wsrta-uninstall][aviso]\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m[wsrta-uninstall][erro]\033[0m %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "rode como root (sudo)."

# Caminhos — espelham o install.sh.
PREFIX=/opt/wsrta
ETC_DIR=/etc/wsrta
DATA_DIR=/var/lib/wsrta
PANEL_ROOT=/var/www/wsrta-panel
ACME_WEBROOT=/var/www/acme
RUN_DIR=/run/wsrta
PMA_DIR=/usr/share/phpmyadmin
PMA_CONFD=/etc/phpmyadmin/wsrta.d
PPA_DIR=/usr/share/phppgadmin
PPA_CONFD=/etc/phppgadmin/wsrta.d

# purge: remove um conjunto de pacotes de forma independente (uma falha não bloqueia o resto).
purge() { apt-get purge -y "$@" >/dev/null 2>&1 || true; }

if [ "${1:-}" != "--yes" ]; then
  cat <<'EOF'
=================================================================
  ATENÇÃO — isto vai REMOVER por completo o WSRTA deste servidor:
    - serviços wsrta-api e wsrta-daemon
    - TODOS os containers de clientes (cli-*) e a imagem golden
    - os bancos do painel e do PowerDNS (DADOS PERDIDOS)
    - phpMyAdmin, phpPgAdmin, nginx do painel, Go, acme.sh
    - os pacotes do stack (postgresql, nginx, php*, lxd, nodejs, ufw)
    - o usuário 'wsrta' e os diretórios /opt/wsrta, /etc/wsrta, etc.

  SERÁ MANTIDO:
    - os utilitários: nano iputils-ping net-tools htop byobu screen
    - o sudo SEM SENHA (/etc/sudoers.d/wsrta-nopasswd)

  Esta ação é IRREVERSÍVEL.
=================================================================
EOF
  printf "Digite 'APAGAR TUDO' para confirmar: "
  read -r ans
  [ "$ans" = "APAGAR TUDO" ] || die "cancelado."
fi

# 1. Serviços systemd
log "parando e removendo os serviços systemd…"
systemctl disable --now wsrta-api.service    >/dev/null 2>&1 || true
systemctl disable --now wsrta-daemon.service >/dev/null 2>&1 || true
rm -f /etc/systemd/system/wsrta-api.service /etc/systemd/system/wsrta-daemon.service
systemctl daemon-reload >/dev/null 2>&1 || true

# 2. Containers de clientes + imagem golden (antes de remover o LXD)
if command -v lxc >/dev/null 2>&1; then
  log "removendo containers de clientes (cli-*) e a imagem golden…"
  while IFS= read -r c; do
    [ -n "$c" ] && lxc delete -f "$c" >/dev/null 2>&1 || true
  done < <(lxc list -c n --format csv 2>/dev/null | grep '^cli-' || true)
  lxc image delete wsrta-base >/dev/null 2>&1 || true
fi

# 3. Bancos + roles do Postgres (enquanto o serviço ainda roda)
if command -v psql >/dev/null 2>&1; then
  systemctl start postgresql >/dev/null 2>&1 || true
  log "removendo bancos e roles do Postgres (wsrta, pdns)…"
  sudo -u postgres psql -c "DROP DATABASE IF EXISTS wsrta;" >/dev/null 2>&1 || true
  sudo -u postgres psql -c "DROP DATABASE IF EXISTS pdns;"  >/dev/null 2>&1 || true
  sudo -u postgres psql -c "DROP ROLE IF EXISTS wsrta;"     >/dev/null 2>&1 || true
  sudo -u postgres psql -c "DROP ROLE IF EXISTS pdns;"      >/dev/null 2>&1 || true
fi

# 4. nginx do painel
log "removendo o site do painel do nginx…"
rm -f /etc/nginx/sites-enabled/wsrta-panel /etc/nginx/sites-available/wsrta-panel
rm -rf /etc/nginx/wsrta-preview.d /etc/nginx/wsrta-forwards.d
systemctl reload nginx >/dev/null 2>&1 || true

# 5. phpMyAdmin / phpPgAdmin (no host)
log "removendo phpMyAdmin e phpPgAdmin…"
rm -rf "$PMA_DIR" "$PMA_CONFD" "$PPA_CONFD"
rm -f "$PPA_DIR/wsrta-login.php"

# 6. acme.sh (instalado no home do root)
log "removendo o acme.sh…"
[ -x /root/.acme.sh/acme.sh ] && /root/.acme.sh/acme.sh --uninstall >/dev/null 2>&1 || true
rm -rf /root/.acme.sh

# 7. ufw (devolve ao padrão e desliga)
if command -v ufw >/dev/null 2>&1; then
  log "resetando o firewall (ufw)…"
  ufw --force reset   >/dev/null 2>&1 || true
  ufw --force disable >/dev/null 2>&1 || true
fi

# 8. Pacotes do stack (purge) — MANTÉM os utilitários básicos
log "removendo os pacotes do stack (purge)…"
purge postgresql postgresql-contrib
purge nginx
purge phppgadmin php-fpm php-mysql php-mbstring php-zip php-gd php-curl php-xml php-pgsql
purge nodejs
purge ufw
apt-get autoremove --purge -y >/dev/null 2>&1 || true
rm -f /etc/apt/sources.list.d/nodesource.list /etc/apt/keyrings/nodesource.gpg 2>/dev/null || true
# LXD (snap) — remove o snap leva junto storage/rede que o "lxd init --auto" criou.
if command -v snap >/dev/null 2>&1; then
  log "removendo o LXD (snap)…"
  snap remove lxd >/dev/null 2>&1 || true
fi

# 9. Go
log "removendo o Go…"
rm -rf /usr/local/go
rm -f /usr/local/bin/go /usr/local/bin/gofmt

# 10. Usuário 'wsrta' + diretórios do app
log "removendo o usuário 'wsrta' e os diretórios…"
rm -rf "$PREFIX" "$ETC_DIR" "$DATA_DIR" "$PANEL_ROOT" "$ACME_WEBROOT" "$RUN_DIR"
rm -rf /etc/phpmyadmin /etc/phppgadmin
id wsrta >/dev/null 2>&1 && userdel wsrta >/dev/null 2>&1 || true

cat <<'EOF'

================================================================
  WSRTA removido. O servidor voltou ao estado anterior.

  MANTIDOS: nano iputils-ping net-tools htop byobu screen
            + sudo SEM SENHA (/etc/sudoers.d/wsrta-nopasswd)

  Obs.: o diretório do código (este repositório descompactado) NÃO
  foi apagado — remova-o manualmente se quiser.
================================================================
EOF
