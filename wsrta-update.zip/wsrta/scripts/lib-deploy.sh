# shellcheck shell=bash
# Funções compartilhadas por install.sh e update.sh.
# O chamador deve definir log()/warn()/die() ANTES de dar source neste arquivo.
# Migrations são RASTREADAS (tabela schema_migrations) para atualizar sem apagar dados.

# apply_migrations <database_url> <migrations_dir>
# Aplica só as migrations ainda não registradas. Idempotente — não toca em dados.
apply_migrations() {
  local url="$1" dir="$2" f base applied
  psql "$url" -v ON_ERROR_STOP=1 -q -c \
    "CREATE TABLE IF NOT EXISTS schema_migrations (filename TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT now());"
  for f in "$dir"/*.up.sql; do
    base="$(basename "$f")"
    applied="$(psql "$url" -tA -c "SELECT 1 FROM schema_migrations WHERE filename='$base'")"
    if [ "$applied" = "1" ]; then
      log "migration já aplicada: $base"
      continue
    fi
    log "aplicando migration: $base"
    psql "$url" -v ON_ERROR_STOP=1 -q -f "$f"
    psql "$url" -v ON_ERROR_STOP=1 -q -c "INSERT INTO schema_migrations (filename) VALUES ('$base');"
  done
}

# apply_pdns_schema <pdns_database_url> <schema.sql>
# Aplica o schema do PowerDNS só se ainda não existir (idempotente).
apply_pdns_schema() {
  local url="$1" schema="$2" exists
  exists="$(psql "$url" -tA -c "SELECT to_regclass('public.domains')" 2>/dev/null || true)"
  if [ -n "$exists" ]; then
    log "schema PowerDNS já presente"
    return
  fi
  log "aplicando schema do PowerDNS…"
  psql "$url" -v ON_ERROR_STOP=1 -q -f "$schema"
}

# build_app <repo_dir> <bin_dir> <panel_root>
# Compila api/daemon + utilitários e builda o frontend. Roda NO SERVIDOR — assim a
# atualização sempre recompila o código novo (vale também se um dia for em container).
build_app() {
  local repo="$1" bindir="$2" panelroot="$3" ver date ldflags
  # Versão vem do arquivo VERSION (carimbada no build → página Sobre). Tolerante à ausência:
  # sob `set -e`, um redirecionamento `< VERSION` de arquivo inexistente ABORTA o script, então
  # só lê se existir; senão, "dev".
  ver="dev"
  [ -f "$repo/VERSION" ] && ver="$(tr -d '[:space:]' < "$repo/VERSION")"
  [ -n "$ver" ] || ver="dev"
  date="$(date +%F)"
  # injeta versão + data da atualização (controle de versão na página Sobre)
  ldflags="-X github.com/jdobrito/wsrta/internal/core.Version=$ver -X github.com/jdobrito/wsrta/internal/core.BuildDate=$date"
  log "compilando api/daemon + utilitários (Go) — v$ver ($date)…"
  install -d "$bindir"
  ( cd "$repo" || exit 1
    go build -ldflags "$ldflags" -o "$bindir/api" ./api/cmd/api
    go build -ldflags "$ldflags" -o "$bindir/daemon" ./daemon/cmd/daemon
    go build -o "$bindir/create-admin" ./api/cmd/create-admin
    go build -o "$bindir/create-client" ./api/cmd/create-client
    go build -o "$bindir/wsrta-migrate" ./api/cmd/wsrta-migrate
  )
  log "buildando o frontend (npm)…"
  ( cd "$repo/web" && npm ci && npm run build )
  install -d "$panelroot"
  rm -rf "${panelroot:?}/"*
  cp -r "$repo/web/dist/." "$panelroot/"
}
