





package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

type lang struct {
	line         string 
	block        bool   
	backtick     byte   
	regex        bool   
	goDirectives bool   
	tsDirectives bool   
}

func langFor(ext string) (lang, bool) {
	switch ext {
	case ".go":
		return lang{line: "//", block: true, backtick: 'r', goDirectives: true}, true
	case ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs":
		return lang{line: "//", block: true, backtick: 't', regex: true, tsDirectives: true}, true
	case ".scss":
		return lang{line: "//", block: true}, true
	case ".css":
		return lang{block: true}, true
	case ".sql":
		return lang{line: "--", block: true}, true
	}
	return lang{}, false
}

var skipDirs = map[string]bool{
	"node_modules": true, ".git": true, "dist": true, "release": true, "vendor": true, "backups": true,
}

func main() {
	if len(os.Args) != 2 {
		fmt.Fprintln(os.Stderr, "uso: strip-comments <diretório>")
		os.Exit(2)
	}
	root := os.Args[1]
	var files int
	var saved int64

	err := filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() {
			if skipDirs[d.Name()] {
				return filepath.SkipDir
			}
			return nil
		}
		l, ok := langFor(strings.ToLower(filepath.Ext(path)))
		if !ok {
			return nil
		}
		src, err := os.ReadFile(path)
		if err != nil {
			return err
		}
		out := strip(src, l)
		if len(out) != len(src) {
			if err := os.WriteFile(path, out, 0o644); err != nil {
				return err
			}
			files++
			saved += int64(len(src) - len(out))
		}
		return nil
	})
	if err != nil {
		fmt.Fprintln(os.Stderr, "strip-comments:", err)
		os.Exit(1)
	}
	fmt.Printf("strip-comments: %d arquivos, %d bytes de comentários removidos\n", files, saved)
}

func isIdent(b byte) bool {
	return b == '_' || b == '$' || (b >= 'a' && b <= 'z') || (b >= 'A' && b <= 'Z') || (b >= '0' && b <= '9')
}


var regexKeywords = map[string]bool{
	"return": true, "typeof": true, "instanceof": true, "in": true, "of": true, "new": true,
	"delete": true, "void": true, "do": true, "else": true, "yield": true, "await": true, "case": true,
}



func strip(src []byte, l lang) []byte {
	out := make([]byte, 0, len(src))
	n := len(src)
	i := 0
	var lastSig byte 
	lastWord := ""
	curWord := strings.Builder{}

	flushWord := func() {
		if curWord.Len() > 0 {
			lastWord = curWord.String()
			curWord.Reset()
		}
	}
	emit := func(b byte) {
		out = append(out, b)
		if b == ' ' || b == '\t' || b == '\n' || b == '\r' {
			flushWord()
		} else {
			lastSig = b
			if isIdent(b) {
				curWord.WriteByte(b)
			} else {
				flushWord()
			}
		}
	}

	copyQuoted := func(q byte, escapes bool) {
		emit(q)
		i++
		for i < n {
			c := src[i]
			if escapes && c == '\\' && i+1 < n {
				out = append(out, c, src[i+1])
				i += 2
				continue
			}
			out = append(out, c)
			i++
			if c == q {
				break
			}
		}
		lastSig = q
	}

	regexAllowed := func() bool {
		if lastSig == 0 {
			return true
		}
		if isIdent(lastSig) {
			return regexKeywords[lastWord] 
		}
		switch lastSig {
		case ')', ']', '}', '`', '\'', '"':
			return false 
		}
		return true
	}

	for i < n {
		c := src[i]

		
		if l.line != "" && i+len(l.line) <= n && string(src[i:i+len(l.line)]) == l.line {
			j := i
			for j < n && src[j] != '\n' {
				j++
			}
			cmt := string(src[i:j])
			preserve := false
			if l.goDirectives && (strings.HasPrefix(cmt, "//go:") || strings.HasPrefix(cmt, "// +build")) {
				preserve = true 
			}
			if l.tsDirectives && (strings.HasPrefix(cmt, "///") || strings.Contains(cmt, "@ts-")) {
				preserve = true 
			}
			if preserve {
				out = append(out, src[i:j]...) 
				i = j
				continue
			}
			i = j 
			continue
		}

		
		if l.block && c == '/' && i+1 < n && src[i+1] == '*' {
			i += 2
			for i < n && !(src[i] == '*' && i+1 < n && src[i+1] == '/') {
				if src[i] == '\n' {
					out = append(out, '\n')
				}
				i++
			}
			i += 2 
			continue
		}

		
		if c == '\'' || c == '"' {
			copyQuoted(c, true)
			continue
		}

		
		if c == '`' && l.backtick != 0 {
			if l.backtick == 'r' {
				copyQuoted('`', false) 
			} else {
				i = scanTemplate(src, i, &out) 
				lastSig = '`'
			}
			continue
		}

		
		if l.regex && c == '/' && regexAllowed() {
			emit(c)
			i++
			inClass := false
			for i < n {
				ch := src[i]
				if ch == '\\' && i+1 < n {
					out = append(out, ch, src[i+1])
					i += 2
					continue
				}
				out = append(out, ch)
				i++
				if ch == '\n' {
					break 
				}
				if ch == '[' {
					inClass = true
				} else if ch == ']' {
					inClass = false
				} else if ch == '/' && !inClass {
					break
				}
			}
			for i < n && (isIdent(src[i]) && !(src[i] >= '0' && src[i] <= '9')) { 
				out = append(out, src[i])
				i++
			}
			lastSig = '/'
			continue
		}

		emit(c)
		i++
	}
	return out
}



func scanTemplate(src []byte, i int, out *[]byte) int {
	n := len(src)
	*out = append(*out, src[i]) 
	i++
	for i < n {
		c := src[i]
		if c == '\\' && i+1 < n {
			*out = append(*out, c, src[i+1])
			i += 2
			continue
		}
		if c == '`' {
			*out = append(*out, c)
			return i + 1
		}
		if c == '$' && i+1 < n && src[i+1] == '{' {
			*out = append(*out, '$', '{')
			i += 2
			depth := 1
			for i < n && depth > 0 {
				d := src[i]
				if d == '\\' && i+1 < n {
					*out = append(*out, d, src[i+1])
					i += 2
					continue
				}
				if d == '\'' || d == '"' {
					i = copyExprString(src, i, d, out)
					continue
				}
				if d == '`' {
					i = scanTemplate(src, i, out) 
					continue
				}
				if d == '{' {
					depth++
				} else if d == '}' {
					depth--
				}
				*out = append(*out, d)
				i++
			}
			continue
		}
		*out = append(*out, c)
		i++
	}
	return i
}

func copyExprString(src []byte, i int, q byte, out *[]byte) int {
	n := len(src)
	*out = append(*out, q)
	i++
	for i < n {
		c := src[i]
		if c == '\\' && i+1 < n {
			*out = append(*out, c, src[i+1])
			i += 2
			continue
		}
		*out = append(*out, c)
		i++
		if c == q {
			break
		}
	}
	return i
}
