#!/usr/bin/env bash
# Gera os dois zips de distribuição em dist/:
#   wsrta-install.zip — instalação nova   (sudo bash scripts/install.sh)
#   wsrta-update.zip  — atualização       (sudo bash scripts/update.sh) — não apaga dados
#
# Os dois trazem o CÓDIGO-FONTE COMPLETO; a compilação acontece no servidor (assim a
# atualização sempre recompila o código novo). Cada zip descompacta em "wsrta/".
#
# Regra do projeto: rode isto SEMPRE que o código mudar, para manter os zips atuais.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/dist"
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
DEST="$STAGE/wsrta"
mkdir -p "$DEST" "$OUT"

command -v zip >/dev/null 2>&1 || { echo "instale o utilitário 'zip'"; exit 1; }

# Conteúdo necessário para instalar/compilar no servidor (sem cruft).
for item in api daemon internal migrations deploy docs scripts web \
            go.mod go.sum Makefile README.md CLAUDE.md VERSION .env.example docker-compose.dev.yml; do
  [ -e "$ROOT/$item" ] && cp -r "$ROOT/$item" "$DEST/"
done
# Remove o que é gerado/pesado (o servidor refaz: npm ci + build).
rm -rf "$DEST/web/node_modules" "$DEST/web/dist" "$DEST/scripts/release"
# Garante +x nos scripts: o git no Windows costuma gravar 100644, e o pacote precisa deles
# executáveis ao descompactar (o instalador é chamado por `bash`, mas mantém o hábito de +x).
chmod +x "$DEST"/scripts/*.sh 2>/dev/null || true

# PRODUÇÃO: remove os comentários do código antes de empacotar. Roda SOMENTE sobre a cópia
# de release ($DEST) — o código de desenvolvimento ($ROOT) permanece com os comentários.
if command -v go >/dev/null 2>&1; then
  ( cd "$ROOT" && go run ./scripts/strip-comments "$DEST" )
  # Gate de segurança: o código stripado tem de compilar (nunca empacotar algo quebrado).
  echo "verificando build do código stripado (Go)…"
  ( cd "$DEST" && go build ./... ) || { echo "ERRO: código stripado não compila — abortando"; exit 1; }
  if command -v npm >/dev/null 2>&1; then
    echo "verificando build do código stripado (web)…"
    ( cd "$DEST/web" && npm ci --silent && npm run build >/dev/null ) \
      || { echo "ERRO: web stripado não compila — abortando"; exit 1; }
    rm -rf "$DEST/web/node_modules" "$DEST/web/dist"
  fi
else
  echo "AVISO: 'go' não encontrado — comentários NÃO removidos do pacote." >&2
fi

make_zip() { # <arquivo-zip> <readme>
  cp "$2" "$DEST/LEIA-PRIMEIRO.txt"
  ( cd "$STAGE" && rm -f "$OUT/$1" && zip -rq "$OUT/$1" wsrta -x '*/.git/*' )
  echo "gerado: $OUT/$1"
}

make_zip wsrta-install.zip "$ROOT/scripts/release/README-install.txt"

# Pacote de UPDATE com a DATA no nome (wsrta-AAAA-MM-DD-update.zip): o auto-update do painel
# procura em dist/ no GitHub e baixa o de data mais alta. Mantém só o mais recente.
rm -f "$OUT"/wsrta-*-update.zip
make_zip "wsrta-$(date +%F)-update.zip" "$ROOT/scripts/release/README-update.txt"
