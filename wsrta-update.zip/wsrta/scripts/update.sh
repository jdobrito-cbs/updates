#!/usr/bin/env bash
# Atualiza uma instalação WSRTA existente SEM apagar o banco nem as configurações.
#
# O que faz: recompila api/daemon + frontend a partir deste código, aplica apenas as
# migrations NOVAS (rastreadas em schema_migrations) e reinicia os serviços systemd.
# NÃO toca em /etc/wsrta/wsrta.env (segredos/config) nem nos dados do Postgres.
#
# Uso (na raiz do código novo, já descompactado):
#   sudo bash scripts/update.sh            # atualização normal (código)
#   sudo bash scripts/update.sh --golden   # também reconstrói a imagem golden LXD
set -euo pipefail

log()  { printf '\033[1;36m[wsrta-update]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[wsrta-update][aviso]\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m[wsrta-update][erro]\033[0m %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "rode como root (sudo)."

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck source=scripts/lib-deploy.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib-deploy.sh"

ENV_FILE=/etc/wsrta/wsrta.env
[ -f "$ENV_FILE" ] || die "instalação não encontrada ($ENV_FILE). Para o 1º setup use scripts/install.sh."

# Carrega a config existente (DB URLs, segredos) — preservada, não regravada.
# NÃO usa `source`: valores com espaço sem aspas (ex.: WSRTA_NGINX_RELOAD_CMD=nginx -s reload)
# fariam o bash tentar EXECUTAR a 2ª palavra ("-s: command not found"). Parse linha a linha,
# tomando tudo após o 1º "=" como valor literal (sem executar nada).
while IFS='=' read -r _k _v; do
  case "$_k" in '' | \#*) continue ;; esac
  _v="${_v%$'\r'}"            # tolera CRLF
  _v="${_v%\"}"; _v="${_v#\"}" # remove aspas duplas ao redor (se houver)
  _v="${_v%\'}"; _v="${_v#\'}" # remove aspas simples ao redor (se houver)
  export "$_k=$_v"
done < "$ENV_FILE"

command -v go  >/dev/null 2>&1 || die "Go não encontrado — rode o instalador antes."
command -v npm >/dev/null 2>&1 || die "Node/npm não encontrado — rode o instalador antes."

BIN_DIR=/opt/wsrta/bin
PANEL_ROOT=/var/www/wsrta-panel

log "recompilando a partir de: $REPO_DIR"
build_app "$REPO_DIR" "$BIN_DIR" "$PANEL_ROOT"

log "aplicando migrations novas (preserva os dados)…"
apply_migrations "$WSRTA_DATABASE_URL" "$REPO_DIR/migrations"

if [ "${1:-}" = "--golden" ]; then
  log "reconstruindo a imagem golden LXD…"
  bash "$REPO_DIR/scripts/build-base-image.sh" || warn "falha ao reconstruir a golden (containers atuais seguem inalterados)"
fi

log "reiniciando serviços…"
systemctl daemon-reload
# Quando o update roda a partir do próprio daemon (auto-update pelo menu), reiniciar o
# wsrta-daemon mataria este script. Usa systemd-run (unidade transitória, fora do cgroup
# do daemon) para o restart sobreviver. Sem systemd-run, faz o restart direto.
if command -v systemd-run >/dev/null 2>&1; then
  systemd-run --no-block --collect --unit=wsrta-restart /bin/sh -c 'sleep 1; systemctl restart wsrta-daemon wsrta-api'
  log "restart agendado em background (wsrta-restart)."
else
  systemctl restart wsrta-daemon wsrta-api
  systemctl --no-pager --lines=4 status wsrta-api wsrta-daemon || true
fi

cat <<EOF

================================================================
  WSRTA atualizado.
  Banco e ${ENV_FILE} preservados.
  Logs: journalctl -u wsrta-daemon -u wsrta-api -f
================================================================
EOF
