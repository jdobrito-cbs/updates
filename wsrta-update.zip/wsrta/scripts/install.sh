#!/usr/bin/env bash
# Instalador do WSRTA para Ubuntu Server (rodar como root).
#
# Prepara as DEPENDÊNCIAS e sobe o painel para que a INSTALAÇÃO seja concluída pela WEB:
# PostgreSQL (painel + PowerDNS), LXD + imagem golden, nginx (HTTPS-only + redirect
# 80→443), acme.sh, builda api/daemon + frontend, instala os serviços systemd e roda as
# migrations. NÃO cria o admin — isso é feito no instalador WEB (admin + empresa + domínio).
#
# Acesso ao painel: https://<IP-do-servidor> (certificado self-signed — o navegador vai
# avisar; é esperado). Qualquer acesso por HTTP é redirecionado para HTTPS.
#
# Uso:
#   sudo bash scripts/install.sh
#
# No terminal, pergunta 2 coisas (Enter aceita o padrão, então é rápido):
#   1) Edição: 1) VPS Simples [padrão]  2) VPS Completo (revendas/vendas/apps/e-mail)
#   2) (só no Completo) instalar o webmail/e-mail (mailcow)? [s/N]
# Para automação, passe por env e os prompts são pulados:
#   WSRTA_EDITION=complete INSTALL_MAILCOW=yes MAILCOW_HOSTNAME=mail.x.com sudo -E bash scripts/install.sh
#
# Variáveis (todas opcionais, com defaults):
#   PANEL_PORT=443            porta HTTPS do painel
#   ACME_EMAIL                email de registro do acme.sh (SSL dos sites)
#   WSRTA_DB_PASS / PDNS_DB_PASS    senhas do Postgres (geradas se ausentes)
#   GO_VERSION=1.26.4         versão do Go a instalar se faltar
#   NODE_MAJOR=20             versão major do Node para buildar o frontend
set -euo pipefail

# ----------------------------------------------------------------------------- helpers
log()  { printf '\033[1;36m[wsrta]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[wsrta][aviso]\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m[wsrta][erro]\033[0m %s\n' "$*" >&2; exit 1; }
gen()  { openssl rand -hex 24; }

[ "$(id -u)" -eq 0 ] || die "rode como root (sudo)."

# Opção de DESINSTALAÇÃO: ./install.sh --uninstall [--yes] → delega ao uninstall.sh
# (remove tudo, mantendo os utilitários básicos e o sudo sem senha).
if [ "${1:-}" = "--uninstall" ]; then
  exec bash "$(dirname "${BASH_SOURCE[0]}")/uninstall.sh" "${@:2}"
fi

REPO_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
log "repositório: $REPO_DIR"

# shellcheck source=scripts/lib-deploy.sh
. "$(dirname "${BASH_SOURCE[0]}")/lib-deploy.sh"

# ----------------------------------------------------------------------------- config
PANEL_PORT="${PANEL_PORT:-443}"
GO_VERSION="${GO_VERSION:-1.26.4}"
NODE_MAJOR="${NODE_MAJOR:-20}"
# Edição do painel: "simple" (VPS Simples) ou "complete" (VPS Completo: revendedores, vendas,
# apps, e-mail). Se a var já veio no ambiente, respeita (automação). Senão, PERGUNTA no terminal
# — é só apertar Enter para o padrão (Simples). Sem terminal (pipe), assume Simples.
if [ -n "${WSRTA_EDITION:-}" ]; then
  EDITION="$WSRTA_EDITION"
elif [ -t 0 ]; then
  printf '\n\033[1;36mQual edição do painel?\033[0m\n'
  printf '  1) VPS Simples   — hospedagem: sites, DNS, bancos, WordPress…   [padrão]\n'
  printf '  2) VPS Completo  — tudo do Simples + revendedores, vendas, apps e e-mail\n'
  read -rp 'Escolha [1]: ' _ed_choice || true
  case "${_ed_choice}" in 2) EDITION=complete ;; *) EDITION=simple ;; esac
else
  EDITION=simple
fi
case "$EDITION" in simple | complete) ;; *) die "WSRTA_EDITION inválido: use simple|complete" ;; esac

# Webmail/e-mail próprio (mailcow) — só faz sentido no VPS Completo (o painel só expõe e-mail lá).
# Se a var já veio no ambiente, respeita. Senão, e sendo Completo com terminal, PERGUNTA (Enter = não).
INSTALL_MAILCOW="${INSTALL_MAILCOW:-}"
MAILCOW_HOSTNAME="${MAILCOW_HOSTNAME:-}"
if [ -z "$INSTALL_MAILCOW" ]; then
  if [ "$EDITION" = "complete" ] && [ -t 0 ]; then
    printf '\n\033[1;36mInstalar o sistema de e-mail/webmail (mailcow) neste servidor?\033[0m\n'
    printf '  Pesado; precisa de um hostname dedicado (ex.: mail.seudominio.com) com DNS apontado.\n'
    read -rp 'Instalar mailcow? [s/N]: ' _mc_choice || true
    case "${_mc_choice}" in [sSyY]*) INSTALL_MAILCOW=yes ;; *) INSTALL_MAILCOW=no ;; esac
  else
    INSTALL_MAILCOW=no
  fi
fi
# Se vai instalar o mailcow e falta o hostname, pergunta (interativo) ou aborta (automação).
if [ "$INSTALL_MAILCOW" = "yes" ] && [ -z "$MAILCOW_HOSTNAME" ]; then
  if [ -t 0 ]; then
    read -rp 'Hostname do mailcow (ex.: mail.seudominio.com): ' MAILCOW_HOSTNAME || true
  fi
  [ -n "$MAILCOW_HOSTNAME" ] || die "mailcow escolhido mas sem MAILCOW_HOSTNAME — informe o hostname."
fi
log "edição: ${EDITION} · mailcow: ${INSTALL_MAILCOW}${MAILCOW_HOSTNAME:+ (${MAILCOW_HOSTNAME})}"

WSRTA_DB_PASS="${WSRTA_DB_PASS:-$(gen)}"
PDNS_DB_PASS="${PDNS_DB_PASS:-$(gen)}"
JWT_SECRET="$(gen)$(gen)"
FILEAPI_TOKEN="$(gen)$(gen)"
SECRETS_KEY="$(openssl rand -hex 32)" # AES-256 p/ cifrar segredos em repouso (token MercadoPago)

# Email de registro do acme.sh (SSL Let's Encrypt dos sites dos clientes).
ACME_EMAIL="${ACME_EMAIL:-admin@wsrta.local}"

# IP público/primário do host (mostrado ao cliente p/ SFTP e usado para acessar o painel).
SERVER_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
SERVER_IP="${SERVER_IP:-127.0.0.1}"

# Caminhos
PREFIX=/opt/wsrta
BIN_DIR="$PREFIX/bin"
ETC_DIR=/etc/wsrta
TLS_DIR="$ETC_DIR/tls"
ENV_FILE="$ETC_DIR/wsrta.env"
DATA_DIR=/var/lib/wsrta
PANEL_ROOT=/var/www/wsrta-panel
ACME_WEBROOT=/var/www/acme
RUN_DIR=/run/wsrta
SOCKET="$RUN_DIR/daemon.sock"
PMA_DIR=/usr/share/phpmyadmin
PMA_CONFD=/etc/phpmyadmin/wsrta.d
PPA_DIR=/usr/share/phppgadmin
PPA_CONFD=/etc/phppgadmin/wsrta.d

export DEBIAN_FRONTEND=noninteractive

# ----------------------------------------------------------------------------- 1. pacotes
install_packages() {
  log "instalando pacotes base (apt)…"
  apt-get update -y
  apt-get install -y \
    ca-certificates curl git openssl build-essential \
    postgresql postgresql-contrib nginx snapd \
    nano iputils-ping net-tools htop byobu screen
  # Node (para buildar o frontend)
  if ! command -v node >/dev/null 2>&1 || [ "$(node -v | sed 's/v\([0-9]*\).*/\1/')" -lt 18 ]; then
    log "instalando Node.js $NODE_MAJOR (NodeSource)…"
    curl -fsSL "https://deb.nodesource.com/setup_${NODE_MAJOR}.x" | bash -
    apt-get install -y nodejs
  fi
}

# ----------------------------------------------------------------------------- 2. Go
install_go() {
  local need="$GO_VERSION" cur=""
  if command -v go >/dev/null 2>&1; then cur="$(go version | awk '{print $3}' | sed 's/go//')"; fi
  # pula a instalação se o Go presente já é >= need (menor dos dois ordenados == need).
  if [ -n "$cur" ] && [ "$(printf '%s\n%s\n' "$need" "$cur" | sort -V | head -1)" = "$need" ]; then
    log "Go já presente ($cur >= $need)"; return
  fi
  log "instalando Go $need…"
  local arch tar; arch="$(dpkg --print-architecture)"
  case "$arch" in amd64) arch=amd64;; arm64) arch=arm64;; *) die "arch não suportada: $arch";; esac
  tar="go${need}.linux-${arch}.tar.gz"
  curl -fsSLo "/tmp/$tar" "https://go.dev/dl/$tar"
  rm -rf /usr/local/go && tar -C /usr/local -xzf "/tmp/$tar"
  ln -sf /usr/local/go/bin/go /usr/local/bin/go
  ln -sf /usr/local/go/bin/gofmt /usr/local/bin/gofmt
  log "Go instalado: $(go version)"
}

# ----------------------------------------------------------------------------- 3. LXD
setup_lxd() {
  if ! command -v lxd >/dev/null 2>&1; then
    log "instalando LXD (snap)…"
    snap install lxd
  fi
  if ! lxc storage list >/dev/null 2>&1 || ! lxc storage show default >/dev/null 2>&1; then
    log "inicializando LXD (lxd init --auto)…"
    lxd init --auto
  else
    log "LXD já inicializado"
  fi
}

# ----------------------------------------------------------------------------- 4. golden image
build_golden_image() {
  if lxc image alias list 2>/dev/null | grep -q wsrta-base; then
    log "imagem golden wsrta-base já existe"; return
  fi
  log "construindo a imagem golden wsrta-base…"
  bash "$REPO_DIR/scripts/build-base-image.sh"
}

# ----------------------------------------------------------------------------- 5. Postgres
psql_super() { sudo -u postgres psql -v ON_ERROR_STOP=1 "$@"; }

setup_postgres() {
  log "configurando PostgreSQL…"
  systemctl enable --now postgresql
  # roles + DBs (idempotente)
  psql_super -tc "SELECT 1 FROM pg_roles WHERE rolname='wsrta'" | grep -q 1 || \
    psql_super -c "CREATE ROLE wsrta LOGIN PASSWORD '${WSRTA_DB_PASS}'"
  psql_super -tc "SELECT 1 FROM pg_database WHERE datname='wsrta'" | grep -q 1 || \
    psql_super -c "CREATE DATABASE wsrta OWNER wsrta"
  psql_super -tc "SELECT 1 FROM pg_roles WHERE rolname='pdns'" | grep -q 1 || \
    psql_super -c "CREATE ROLE pdns LOGIN PASSWORD '${PDNS_DB_PASS}'"
  psql_super -tc "SELECT 1 FROM pg_database WHERE datname='pdns'" | grep -q 1 || \
    psql_super -c "CREATE DATABASE pdns OWNER pdns"
}

# run_migrations usa o aplicador rastreado da lib (schema_migrations) — assim a
# atualização aplica só as migrations novas, sem apagar dados.
run_migrations() {
  apply_migrations "postgres://wsrta:${WSRTA_DB_PASS}@127.0.0.1:5432/wsrta?sslmode=disable" "$REPO_DIR/migrations"
  apply_pdns_schema "postgres://pdns:${PDNS_DB_PASS}@127.0.0.1:5432/pdns?sslmode=disable" "$REPO_DIR/deploy/powerdns/schema.sql"
  # Proteções LIGADAS POR PADRÃO: enfileira UMA aplicação de segurança (o daemon instala/liga
  # ModSecurity + CSF + fail2ban + renovação de SSL). Só se ainda não houver — idempotente em
  # re-runs do instalador. No fresh install não há containers e o daemon novo é quem processa,
  # então não há corrida nem risco de derrubar sites. O CSF já sobe ciente do bridge do LXD.
  psql_super -d wsrta -tc "SELECT 1 FROM actions WHERE type='apply_security' LIMIT 1" | grep -q 1 || \
    psql_super -d wsrta -c "INSERT INTO actions (type, payload, status) VALUES ('apply_security', '{\"modsecurity\":true,\"csf\":true,\"fail2ban\":true,\"ssl_autorenew\":true}'::jsonb, 'pending')"
}

# build_app vem de scripts/lib-deploy.sh (compartilhado com update.sh).

# ----------------------------------------------------------------------------- 7. usuário, dirs, env
setup_user_dirs() {
  id wsrta >/dev/null 2>&1 || useradd --system --home "$DATA_DIR" --shell /usr/sbin/nologin wsrta
  install -d "$ETC_DIR" "$TLS_DIR" "$DATA_DIR" "$ACME_WEBROOT" \
    "$DATA_DIR/backups" "$DATA_DIR/cyberpanel" "$DATA_DIR/migrate" "$RUN_DIR"
  chown -R wsrta:wsrta "$DATA_DIR" "$RUN_DIR"
}

write_env() {
  log "gravando $ENV_FILE…"
  cat > "$ENV_FILE" <<EOF
# Gerado por scripts/install.sh — contém segredos. Permissão restrita.
WSRTA_DATABASE_URL=postgres://wsrta:${WSRTA_DB_PASS}@127.0.0.1:5432/wsrta?sslmode=disable
WSRTA_PDNS_DATABASE_URL=postgres://pdns:${PDNS_DB_PASS}@127.0.0.1:5432/pdns?sslmode=disable
WSRTA_API_ADDR=127.0.0.1:8080
WSRTA_PANEL_PORT=${PANEL_PORT}
WSRTA_JWT_SECRET=${JWT_SECRET}
WSRTA_SECRETS_KEY=${SECRETS_KEY}
WSRTA_DAEMON_SOCKET=${SOCKET}
WSRTA_FILEAPI_SOCKET=${RUN_DIR}/fileapi.sock
WSRTA_FILEAPI_TOKEN=${FILEAPI_TOKEN}
WSRTA_TOTP_ISSUER=WSRTA
WSRTA_EDITION=${EDITION}
# Repo do GitHub onde fica SOMENTE o último pacote de atualização (wsrta-update.zip). O botão
# "Atualizar painel" baixa esse arquivo. Troque se usar um fork.
WSRTA_UPDATE_REPO=jdobrito-cbs/updates

WSRTA_LXD_DRIVER=real
WSRTA_LXD_SOCKET=/var/snap/lxd/common/lxd/unix.socket
WSRTA_LXD_IMAGE=wsrta-base
WSRTA_LXD_STORAGE_POOL=default
WSRTA_LXD_NETWORK=lxdbr0

WSRTA_NGINX_SITES_DIR=/etc/nginx/sites-enabled
WSRTA_NGINX_RELOAD_CMD="nginx -s reload"
WSRTA_ACME_SH=/root/.acme.sh/acme.sh
WSRTA_ACME_EMAIL=${ACME_EMAIL}
WSRTA_ACME_WEBROOT=${ACME_WEBROOT}
WSRTA_ACME_STAGING=false
WSRTA_DOMAIN_DOCROOT_BASE=/var/www

WSRTA_PDNS_PRIMARY_NS=ns1.${SERVER_IP}.nip.io
WSRTA_PDNS_HOSTMASTER=hostmaster.${SERVER_IP}.nip.io
WSRTA_CRON_USER=www-data

WSRTA_SFTP_HOST=${SERVER_IP}
WSRTA_SFTP_BASE_PORT=30000

WSRTA_BACKUP_DIR=${DATA_DIR}/cyberpanel
WSRTA_MIGRATE_STAGING=${DATA_DIR}/migrate
WSRTA_CLIENT_BACKUP_DIR=${DATA_DIR}/backups

WSRTA_PMA_BASE_PORT=33000
WSRTA_PMA_CONFD=/etc/phpmyadmin/wsrta.d
WSRTA_PMA_URL=/phpmyadmin/

WSRTA_PPA_BASE_PORT=34000
WSRTA_PPA_CONFD=/etc/phppgadmin/wsrta.d
WSRTA_PPA_URL=/phppgadmin/

WSRTA_REPO_DIR=${PREFIX}/src
EOF
  chgrp wsrta "$ENV_FILE"
  chmod 640 "$ENV_FILE"
}

# install_source copia o código para ${PREFIX}/src (WSRTA_REPO_DIR), de onde o botão
# "Atualizar painel" roda o scripts/update.sh.
install_source() {
  log "instalando o código-fonte em ${PREFIX}/src…"
  mkdir -p "${PREFIX}/src"
  if command -v rsync >/dev/null 2>&1; then
    rsync -a --delete --exclude node_modules --exclude .git "$REPO_DIR"/ "${PREFIX}/src"/
  else
    cp -a "$REPO_DIR"/. "${PREFIX}/src"/
  fi
}

# ----------------------------------------------------------------------------- 8. acme.sh
setup_acme() {
  if [ ! -f /root/.acme.sh/acme.sh ]; then
    log "instalando acme.sh…"
    curl -fsSL https://get.acme.sh | sh -s email="$ACME_EMAIL" || warn "acme.sh: instale manualmente se falhar"
  fi
}

# ----------------------------------------------------------------------------- 8c. phpMyAdmin (host)
setup_phpmyadmin() {
  log "instalando phpMyAdmin + php-fpm…"
  apt-get install -y php-fpm php-mysql php-mbstring php-zip php-gd php-curl php-xml
  if [ ! -f "$PMA_DIR/index.php" ]; then
    curl -fsSL -o /tmp/pma.tgz https://www.phpmyadmin.net/downloads/phpMyAdmin-latest-all-languages.tar.gz
    rm -rf "$PMA_DIR"; mkdir -p "$PMA_DIR"
    tar -xzf /tmp/pma.tgz -C "$PMA_DIR" --strip-components=1
  fi
  install -d -o www-data -g www-data /var/lib/phpmyadmin/tmp
  install -d "$PMA_CONFD"
  local blowfish; blowfish="$(openssl rand -hex 16)"
  cat > "$PMA_DIR/config.inc.php" <<PHP
<?php
\$cfg['blowfish_secret'] = '${blowfish}';
\$cfg['TempDir'] = '/var/lib/phpmyadmin/tmp';
\$cfg['AllowArbitraryServer'] = false;
\$i = 0;
// Um servidor por cliente (gerado pelo daemon ao habilitar o phpMyAdmin).
foreach (glob('${PMA_CONFD}/*.php') as \$f) { include \$f; }
PHP
}

# ----------------------------------------------------------------------------- 8d. phpPgAdmin (host)
# Espelha o phpMyAdmin: phpPgAdmin no host; o daemon escreve 1 server + credenciais por
# cliente em PPA_CONFD; o launcher wsrta-login.php faz o auto-login sem senha pelo painel.
setup_phppgadmin() {
  log "instalando phpPgAdmin + php-pgsql…"
  apt-get install -y phppgadmin php-pgsql || log "phppgadmin não disponível no apt — instale manualmente"
  install -d "$PPA_CONFD"
  local cfg=/etc/phppgadmin/config.inc.php
  if [ -f "$cfg" ] && ! grep -q 'WSRTA phppgadmin' "$cfg"; then
    cat >> "$cfg" <<PHP

// --- WSRTA phppgadmin: 1 server por cliente + auto-login pelo painel ---
\$conf['extra_login_security'] = false;
\$conf['owned_only'] = false;
foreach (glob('${PPA_CONFD}/*.php') as \$f) { include \$f; }
PHP
  fi
  # Launcher de auto-login: lê as credenciais geradas pelo daemon e submete o login.
  cat > "$PPA_DIR/wsrta-login.php" <<'PHP'
<?php
// Auto-login do WSRTA para o phpPgAdmin (chamado pelo botão do painel). Lê as credenciais
// que o daemon escreveu em wsrta.d e submete o formulário de login do phpPgAdmin.
foreach (glob('/etc/phppgadmin/wsrta.d/*.php') as $f) { include $f; }
$server = isset($_GET['server']) ? (int) $_GET['server'] : 0;
$creds = isset($GLOBALS['WSRTA_PPA_CREDS'][$server]) ? $GLOBALS['WSRTA_PPA_CREDS'][$server] : null;
if (!$creds) { header('Location: index.php'); exit; }
$u = htmlspecialchars($creds['user'], ENT_QUOTES);
$p = htmlspecialchars($creds['pass'], ENT_QUOTES);
?><!doctype html><meta charset="utf-8"><title>WSRTA → phpPgAdmin</title>
<form id="f" method="post" action="redirect.php?subject=server">
  <input type="hidden" name="server" value="<?php echo $server; ?>">
  <input type="hidden" name="loginServer" value="<?php echo $server; ?>">
  <input type="hidden" name="loginUsername" value="<?php echo $u; ?>">
  <input type="hidden" name="loginPassword" value="<?php echo $p; ?>">
  <input type="hidden" name="loginPassword_<?php echo $server; ?>" value="<?php echo $p; ?>">
</form>
<script>document.getElementById('f').submit();</script>
PHP
}

# ----------------------------------------------------------------------------- 9. TLS self-signed
setup_tls() {
  if [ -f "$TLS_DIR/cert.pem" ]; then log "certificado do painel já existe"; return; fi
  log "gerando certificado self-signed do painel…"
  openssl req -x509 -newkey rsa:2048 -nodes -days 3650 \
    -keyout "$TLS_DIR/key.pem" -out "$TLS_DIR/cert.pem" \
    -subj "/CN=${SERVER_IP}" -addext "subjectAltName=IP:${SERVER_IP}"
  chmod 600 "$TLS_DIR/key.pem"
}

# ----------------------------------------------------------------------------- 10. nginx do painel
setup_nginx() {
  log "configurando o nginx do painel (HTTPS-only na porta ${PANEL_PORT}, com redirect 80→HTTPS)…"
  local sock=""; for s in /run/php/php*-fpm.sock; do [ -S "$s" ] && { sock="$s"; break; }; done; sock="${sock:-/run/php/php-fpm.sock}"
  cat > /etc/nginx/sites-available/wsrta-panel <<EOF
# HTTP → HTTPS: qualquer acesso ao IP/domínio do painel por HTTP é redirecionado.
# Os sites dos clientes têm seus próprios vhosts :80 (server_name fqdn) e tratam o
# desafio ACME — só o que NÃO casa um fqdn de cliente (o painel/IP) cai aqui.
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;
    location /.well-known/acme-challenge/ { root ${ACME_WEBROOT}; default_type "text/plain"; }
    location / { return 301 https://\$host\$request_uri; }
}

server {
    listen ${PANEL_PORT} ssl default_server;
    listen [::]:${PANEL_PORT} ssl default_server;
    server_name _;

    ssl_certificate     ${TLS_DIR}/cert.pem;
    ssl_certificate_key ${TLS_DIR}/key.pem;

    root ${PANEL_ROOT};
    index index.html;
    client_max_body_size 2048m;   # uploads de restore (backups grandes)

    # Cabeçalhos de segurança (defesa em profundidade).
    add_header X-Content-Type-Options nosniff always;
    add_header X-Frame-Options DENY always;
    add_header Referrer-Policy no-referrer always;
    add_header Content-Security-Policy "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; font-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'self'" always;

    location /api/ {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_read_timeout 600s;
        proxy_request_buffering off;
    }
    location = /healthz { proxy_pass http://127.0.0.1:8080; }

    # phpMyAdmin (host). CSP própria (a do painel é restrita demais para o phpMyAdmin).
    location ^~ /phpmyadmin/ {
        alias ${PMA_DIR}/;
        index index.php;
        add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:;" always;
        location ~ ^/phpmyadmin/(.+\.php)\$ {
            alias ${PMA_DIR}/\$1;
            fastcgi_pass unix:${sock};
            include fastcgi_params;
            fastcgi_param SCRIPT_FILENAME \$request_filename;
        }
    }

    # phpPgAdmin (host) — mesma receita do phpMyAdmin.
    location ^~ /phppgadmin/ {
        alias ${PPA_DIR}/;
        index index.php;
        add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:;" always;
        location ~ ^/phppgadmin/(.+\.php)\$ {
            alias ${PPA_DIR}/\$1;
            fastcgi_pass unix:${sock};
            include fastcgi_params;
            fastcgi_param SCRIPT_FILENAME \$request_filename;
        }
    }

    # Preview "pelo servidor" por domínio: /_preview/<fqdn>/ → site do container
    # (snippets escritos pelo daemon ao adicionar/remover domínios).
    include /etc/nginx/wsrta-preview.d/*.conf;

    location / { try_files \$uri \$uri/ /index.html; }
}
EOF
  mkdir -p /etc/nginx/wsrta-preview.d /etc/nginx/wsrta-forwards.d
  # Remove o site default do nginx (tem 'listen 80 default_server' e conflitaria).
  rm -f /etc/nginx/sites-enabled/default
  ln -sf /etc/nginx/sites-available/wsrta-panel /etc/nginx/sites-enabled/wsrta-panel
  nginx -t
  systemctl enable --now nginx
  systemctl reload nginx
}

# ----------------------------------------------------------------------------- 11. systemd
install_systemd() {
  log "instalando serviços systemd…"
  cat > /etc/systemd/system/wsrta-daemon.service <<EOF
[Unit]
Description=WSRTA daemon (orquestrador, root)
After=network-online.target postgresql.service snap.lxd.daemon.service
Wants=network-online.target postgresql.service

[Service]
Type=simple
User=root
Group=wsrta
RuntimeDirectory=wsrta
RuntimeDirectoryMode=0770
EnvironmentFile=${ENV_FILE}
ExecStart=${BIN_DIR}/daemon
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

  cat > /etc/systemd/system/wsrta-api.service <<EOF
[Unit]
Description=WSRTA API web (sem root)
After=network-online.target postgresql.service wsrta-daemon.service
Wants=network-online.target postgresql.service

[Service]
Type=simple
User=wsrta
EnvironmentFile=${ENV_FILE}
ExecStart=${BIN_DIR}/api
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

  systemctl daemon-reload
  systemctl enable --now wsrta-daemon.service
  systemctl enable --now wsrta-api.service
}

# ----------------------------------------------------------------------------- 11b. firewall
setup_firewall() {
  command -v ufw >/dev/null 2>&1 || apt-get install -y ufw || { warn "ufw indisponível; configure o firewall manualmente"; return; }
  log "configurando firewall (ufw)…"
  ufw allow 22/tcp                     # SSH
  ufw allow "${PANEL_PORT}/tcp"        # painel (HTTPS local)
  ufw allow 80/tcp                     # sites dos clientes (HTTP/ACME)
  ufw allow 443/tcp                    # sites dos clientes (HTTPS)
  ufw allow 30000:30999/tcp            # SFTP por cliente (WSRTA_SFTP_BASE_PORT + id)
  # LXD: libera a bridge dos containers no ufw. SEM ISTO, o ufw (deny incoming) derruba o
  # DHCP do dnsmasq da bridge e os containers NÃO pegam IPv4 (só IPv6 via SLAAC) — aí o
  # reverse-proxy do host não acha o container (Address() precisa de IPv4) e nenhum site
  # responde. 'allow in' libera DHCP/DNS host↔container; as 'route allow' liberam a saída
  # dos containers para a internet (apt, plugins do WordPress).
  local br="${WSRTA_LXD_NETWORK:-lxdbr0}"
  ufw allow in on "$br"
  ufw route allow in on "$br"
  ufw route allow out on "$br"
  ufw --force enable
  # A API (127.0.0.1:8080) e o Postgres não ficam expostos — só o nginx fala com eles.
}

# ----------------------------------------------------------------------------- 11c. sudo sem senha
# Dispensa a senha do sudo para o usuário que rodou a instalação (SUDO_USER). É uma
# conveniência pedida pelo operador; reduz a barreira do sudo (servidor de admin único).
setup_sudo_nopasswd() {
  local u="${SUDO_USER:-}"
  if [ -z "$u" ] || [ "$u" = "root" ]; then
    log "sudo sem senha: rodando como root (sem SUDO_USER) — nada a configurar"
    return
  fi
  log "configurando sudo SEM SENHA para o usuário '$u'…"
  local f="/etc/sudoers.d/wsrta-nopasswd"
  printf '%s ALL=(ALL) NOPASSWD:ALL\n' "$u" > "$f"
  chmod 440 "$f"
  # valida; se a sintaxe ficar inválida, remove para não travar o sudo do sistema.
  if ! visudo -cf "$f" >/dev/null 2>&1; then
    rm -f "$f"; warn "sudoers inválido para '$u' — sudo sem senha NÃO aplicado"
  fi
}

# ----------------------------------------------------------------------------- run
# install_mailcow instala e sobe o mailcow (servidor de e-mail próprio) NO HOST, via Docker.
# OPCIONAL: só roda com INSTALL_MAILCOW=yes e MAILCOW_HOSTNAME definido. A web do mailcow sobe em
# 8080/8443 (as 80/443 do host são do painel WSRTA); as portas de SMTP/IMAP são as padrão do mailcow.
# Depois, no painel (Configurações → E-mail), o admin cola a URL e uma API key criada no mailcow.
install_mailcow() {
  [ "${INSTALL_MAILCOW}" = "yes" ] || { log "mailcow: pulado (use INSTALL_MAILCOW=yes MAILCOW_HOSTNAME=mail.seu.dominio)"; return 0; }
  [ -n "${MAILCOW_HOSTNAME}" ] || { warn "INSTALL_MAILCOW=yes mas MAILCOW_HOSTNAME vazio — pulando o mailcow"; return 0; }
  log "mailcow: instalando Docker no host + mailcow-dockerized (hostname ${MAILCOW_HOSTNAME})"
  warn "mailcow: Docker no host pode conflitar com a rede do LXD (regras de iptables). Se os"
  warn "         containers dos clientes perderem rede, ajuste o firewall do Docker/LXD."
  # Docker no HOST (o mailcow é Docker Compose; o Docker dos clientes roda DENTRO do LXC, à parte).
  apt-get install -y docker.io docker-compose-plugin git || { warn "Docker/git indisponíveis — pulando o mailcow"; return 0; }
  systemctl enable --now docker || true
  local dir=/opt/mailcow-dockerized
  [ -d "$dir" ] || git clone --depth 1 https://github.com/mailcow/mailcow-dockerized "$dir" \
    || { warn "falha ao clonar o mailcow"; return 0; }
  if [ ! -f "$dir/mailcow.conf" ]; then
    # generate_config.sh roda sem prompts quando MAILCOW_HOSTNAME e MAILCOW_TZ vêm do ambiente.
    ( cd "$dir" && MAILCOW_HOSTNAME="${MAILCOW_HOSTNAME}" MAILCOW_TZ="$(cat /etc/timezone 2>/dev/null || echo UTC)" \
        ./generate_config.sh < /dev/null ) || { warn "falha ao gerar a config do mailcow (rode ./generate_config.sh em $dir)"; return 0; }
    # Evita colidir com o nginx do painel (80/443): a web do mailcow vai para 8080/8443.
    sed -i 's/^HTTP_PORT=.*/HTTP_PORT=8080/; s/^HTTPS_PORT=.*/HTTPS_PORT=8443/' "$dir/mailcow.conf"
  fi
  ( cd "$dir" && docker compose pull && docker compose up -d ) \
    || { warn "falha ao subir o mailcow (rode 'cd $dir && docker compose up -d')"; return 0; }
  log "mailcow no ar: https://${MAILCOW_HOSTNAME}:8443 (admin padrão admin/moohoo — TROQUE já)"
}

main() {
  install_packages
  install_go
  setup_lxd
  build_golden_image
  setup_postgres
  setup_user_dirs
  write_env
  run_migrations
  build_app "$REPO_DIR" "$BIN_DIR" "$PANEL_ROOT"
  install_source
  setup_acme
  setup_phpmyadmin
  setup_phppgadmin
  setup_tls
  setup_nginx
  install_systemd
  setup_firewall
  setup_sudo_nopasswd
  install_mailcow

  # Sufixo do painel só quando NÃO é a porta 443 (HTTPS padrão).
  local url="https://${SERVER_IP}"
  [ "${PANEL_PORT}" = "443" ] || url="https://${SERVER_IP}:${PANEL_PORT}"

  cat <<EOF

================================================================
  WSRTA — dependências instaladas. Conclua a instalação pela WEB.

  Acesse:  ${url}
           (certificado self-signed — aceite o aviso do navegador;
            HTTP é redirecionado para HTTPS automaticamente)

  Na primeira tela você cria o ADMINISTRADOR e define o NOME DA
  EMPRESA e o DOMÍNIO do painel. Depois, o 2FA é configurado no
  1º login.

  Serviços: systemctl status wsrta-api wsrta-daemon
  Config:   ${ENV_FILE}
  Logs:     journalctl -u wsrta-daemon -f
================================================================
EOF

  if [ "${INSTALL_MAILCOW}" = "yes" ] && [ -n "${MAILCOW_HOSTNAME}" ]; then
    cat <<EOF
  E-MAIL (mailcow): abra https://${MAILCOW_HOSTNAME}:8443 (admin/moohoo — troque),
  crie uma API key (read-write) em Configurações → API, e no painel WSRTA vá em
  Configurações → Servidor de e-mail e cole a URL https://${MAILCOW_HOSTNAME}:8443
  + a API key. Garanta DNS/PTR do hostname e as portas SMTP/IMAP abertas no firewall.
================================================================
EOF
  fi
}

main "$@"
