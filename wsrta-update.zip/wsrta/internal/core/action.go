



package core

import (
	"encoding/json"
	"time"
)


type ActionStatus string

const (
	ActionPending ActionStatus = "pending"
	ActionRunning ActionStatus = "running"
	ActionDone    ActionStatus = "done"
	ActionFailed  ActionStatus = "failed"
)


type ActionType string

const (
	ActionProvisionClient   ActionType = "provision_client"
	ActionDeprovisionClient ActionType = "deprovision_client"
	ActionAddDomain         ActionType = "add_domain"
	ActionRemoveDomain      ActionType = "remove_domain"
	ActionSetDomainForwards ActionType = "set_domain_forwards"
	ActionSetDomainPHP      ActionType = "set_domain_php"
	ActionSetDomainOffline  ActionType = "set_domain_offline"
	ActionIssueSSL          ActionType = "issue_ssl"
	ActionCreateDatabase    ActionType = "create_database"
	ActionDropDatabase      ActionType = "drop_database"
	ActionResetDBPassword   ActionType = "reset_db_password"
	ActionSetDNSRecord      ActionType = "set_dns_record"
	ActionDeleteDNSRecord   ActionType = "delete_dns_record"
	ActionSetCron           ActionType = "set_cron"
	ActionRemoveCron        ActionType = "remove_cron"
	ActionSetRuntimes       ActionType = "set_runtimes"
	ActionSetPostgres       ActionType = "set_postgres"
	ActionSetPhpPgAdmin     ActionType = "set_phppgadmin"
	
	ActionSuspendClient ActionType = "suspend_client"
	ActionResumeClient  ActionType = "resume_client"
	
	ActionPowerClient ActionType = "power_client"
	
	ActionApplyLimits ActionType = "apply_limits"
	
	ActionInstallWordPress ActionType = "install_wordpress"
	ActionRemoveWordPress  ActionType = "remove_wordpress"
	
	ActionEnableSFTP  ActionType = "enable_sftp"
	ActionDisableSFTP ActionType = "disable_sftp"
	
	ActionBackupClient ActionType = "backup_client"
	
	ActionSetCloudflare     ActionType = "set_cloudflare"
	ActionControlCloudflare ActionType = "control_cloudflare"
	
	ActionApplySecurity ActionType = "apply_security"
	
	ActionSetPhpMyAdmin ActionType = "set_phpmyadmin"
	
	ActionApplySiteRules ActionType = "apply_site_rules"
	
	ActionSetFastNginx ActionType = "set_fast_nginx"
	
	ActionSystemUpdate   ActionType = "system_update"
	ActionPanelUpdate    ActionType = "panel_update"
	ActionRestartService ActionType = "restart_service"
	
	ActionRestoreDatabase ActionType = "restore_database"
	ActionRestoreFiles    ActionType = "restore_files"
	
	ActionInstallPhpBB ActionType = "install_phpbb"
	ActionRemovePhpBB  ActionType = "remove_phpbb"
	ActionUpdatePhpBB  ActionType = "update_phpbb"
	
	ActionEnableDocker     ActionType = "enable_docker"
	ActionDisableDocker    ActionType = "disable_docker"
	ActionInstallDockerApp ActionType = "install_docker_app"
	ActionRemoveDockerApp  ActionType = "remove_docker_app"
	ActionUpdateDockerApp  ActionType = "update_docker_app"
	
	ActionScanVulnerabilities ActionType = "scan_vulnerabilities"
	
	ActionHardenWordPress ActionType = "harden_wordpress"
	
	ActionUpdateClientPackages ActionType = "update_client_packages"
)



func AllActionTypes() []ActionType {
	return []ActionType{
		ActionProvisionClient,
		ActionDeprovisionClient,
		ActionAddDomain,
		ActionRemoveDomain,
		ActionSetDomainForwards,
		ActionSetDomainPHP,
		ActionSetDomainOffline,
		ActionIssueSSL,
		ActionCreateDatabase,
		ActionDropDatabase,
		ActionResetDBPassword,
		ActionSetDNSRecord,
		ActionDeleteDNSRecord,
		ActionSetCron,
		ActionRemoveCron,
		ActionSetRuntimes,
		ActionSetPostgres,
		ActionSetPhpPgAdmin,
		ActionSuspendClient,
		ActionResumeClient,
		ActionPowerClient,
		ActionApplyLimits,
		ActionInstallWordPress,
		ActionRemoveWordPress,
		ActionEnableSFTP,
		ActionDisableSFTP,
		ActionBackupClient,
		ActionSetCloudflare,
		ActionControlCloudflare,
		ActionApplySecurity,
		ActionSetPhpMyAdmin,
		ActionApplySiteRules,
		ActionSetFastNginx,
		ActionSystemUpdate,
		ActionPanelUpdate,
		ActionRestartService,
		ActionRestoreDatabase,
		ActionRestoreFiles,
		ActionInstallPhpBB,
		ActionRemovePhpBB,
		ActionUpdatePhpBB,
		ActionEnableDocker,
		ActionDisableDocker,
		ActionInstallDockerApp,
		ActionRemoveDockerApp,
		ActionUpdateDockerApp,
		ActionScanVulnerabilities,
		ActionHardenWordPress,
		ActionUpdateClientPackages,
	}
}


func (t ActionType) Valid() bool {
	for _, k := range AllActionTypes() {
		if k == t {
			return true
		}
	}
	return false
}


type Action struct {
	ID          int64           `json:"id"`
	Type        ActionType      `json:"type"`
	Payload     json.RawMessage `json:"payload"`
	Status      ActionStatus    `json:"status"`
	Result      *string         `json:"result,omitempty"`
	RequestedBy *int64          `json:"requested_by,omitempty"`
	CreatedAt   time.Time       `json:"created_at"`
	StartedAt   *time.Time      `json:"started_at,omitempty"`
	FinishedAt  *time.Time      `json:"finished_at,omitempty"`
	
	
	Progress      int    `json:"progress"`
	ProgressStage string `json:"progress_stage,omitempty"`
}
