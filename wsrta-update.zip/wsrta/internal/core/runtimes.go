package core

import "strings"


type WebRuntime struct {
	Key      string   `json:"key"`
	Label    string   `json:"label"`
	Packages []string `json:"-"` 
}



var WebRuntimes = []WebRuntime{
	{Key: "nodejs", Label: "Node.js", Packages: []string{"nodejs", "npm"}},
	{Key: "python", Label: "Python", Packages: []string{"python3", "python3-pip", "python3-venv"}},
	{Key: "ruby", Label: "Ruby", Packages: []string{"ruby-full"}},
	{Key: "perl", Label: "Perl (CGI)", Packages: []string{"perl", "fcgiwrap"}},
	{Key: "go", Label: "Go", Packages: []string{"golang-go"}},
	{Key: "java", Label: "Java", Packages: []string{"default-jdk"}},
}


func RuntimeByKey(key string) *WebRuntime {
	for i := range WebRuntimes {
		if WebRuntimes[i].Key == key {
			return &WebRuntimes[i]
		}
	}
	return nil
}



func ParseRuntimes(s string) []string {
	set := map[string]bool{}
	for _, k := range strings.Split(s, ",") {
		k = strings.TrimSpace(k)
		if k != "" && RuntimeByKey(k) != nil {
			set[k] = true
		}
	}
	var out []string
	for _, r := range WebRuntimes {
		if set[r.Key] {
			out = append(out, r.Key)
		}
	}
	return out
}
