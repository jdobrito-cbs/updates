package core

import "time"


type Role string

const (
	RoleAdmin    Role = "admin"
	RoleReseller Role = "reseller" 
	RoleClient   Role = "client"
)



const (
	EditionSimple   = "simple"
	EditionComplete = "complete"
)



type Package struct {
	ID               int64     `json:"id"`
	ResellerID       *int64    `json:"reseller_id,omitempty"`
	Name             string    `json:"name"`
	PriceCents       int64     `json:"price_cents"`
	CPULimit         float64   `json:"cpu_limit"`
	RAMLimitMB       int       `json:"ram_limit_mb"`
	DiskQuotaMB      int       `json:"disk_quota_mb"`
	MaxDomains       int       `json:"max_domains"`
	MaxDatabases     int       `json:"max_databases"`
	MaxMailboxes     int       `json:"max_mailboxes"`
	BandwidthLimitMB int64     `json:"bandwidth_limit_mb"`
	DurationDays     int       `json:"duration_days"`
	CreatedAt        time.Time `json:"created_at"`
}


type Order struct {
	ID             int64     `json:"id"`
	ResellerID     *int64    `json:"reseller_id,omitempty"`
	PackageID      *int64    `json:"package_id,omitempty"`
	BuyerEmail     string    `json:"buyer_email"`
	AmountCents    int64     `json:"amount_cents"`
	Status         string    `json:"status"` 
	MPPreferenceID string    `json:"-"`
	MPPaymentID    string    `json:"mp_payment_id"`
	CreatedAt      time.Time `json:"created_at"`
	PackageName    string    `json:"package_name"` 
}



type Reseller struct {
	ID        int64      `json:"id"`
	UserID    int64      `json:"user_id"`
	Email     string     `json:"email"` 
	Name      string     `json:"name"`
	Status    string     `json:"status"` 
	ExpiresAt *time.Time `json:"expires_at,omitempty"`
	CreatedAt time.Time  `json:"created_at"`
	Online    bool       `json:"online"`
	Clients   int        `json:"clients"` 
	
	Slug            string `json:"slug"`
	LandingTemplate string `json:"landing_template"`
	LandingHeadline string `json:"landing_headline"`
	LandingSubtitle string `json:"landing_subtitle"`
	ExternalSiteURL string `json:"external_site_url"`
	
	MaxClients int `json:"max_clients"`
}


const (
	ClientProvisioning   = "provisioning"
	ClientActive         = "active"
	ClientSuspended      = "suspended"
	ClientDeprovisioning = "deprovisioning"
	ClientDeleted        = "deleted"
)


type User struct {
	ID                    int64     `json:"id"`
	Email                 string    `json:"email"`
	PasswordHash          string    `json:"-"`
	Role                  Role      `json:"role"`
	Status                string    `json:"status"`
	TOTPSecret            *string   `json:"-"`
	TOTPEnabled           bool      `json:"-"`
	CreatedAt             time.Time `json:"created_at"`
	SessionTimeoutMinutes int       `json:"session_timeout_minutes"` 
}


type Client struct {
	ID                    int64      `json:"id"`
	UserID                int64      `json:"user_id"`
	ResellerID            *int64     `json:"reseller_id,omitempty"` 
	Name                  string     `json:"name"`
	LXCContainerName      string     `json:"lxc_container_name"`
	CPULimit              float64    `json:"cpu_limit"`
	RAMLimitMB            int        `json:"ram_limit_mb"`
	DiskQuotaMB           int        `json:"disk_quota_mb"`
	Status                string     `json:"status"`
	SFTPEnabled           bool       `json:"sftp_enabled"`
	SFTPPort              int        `json:"sftp_port"`
	SFTPUser              string     `json:"sftp_user"`
	MaxDomains            int        `json:"max_domains"`   
	MaxDatabases          int        `json:"max_databases"` 
	MaxMailboxes          int        `json:"max_mailboxes"` 
	PhpMyAdminEnabled     bool       `json:"phpmyadmin_enabled"`
	FastNginxEnabled      bool       `json:"fast_nginx_enabled"`
	CreatedAt             time.Time  `json:"created_at"`
	Online                bool       `json:"online"`                  
	LastSeen              *time.Time `json:"last_seen,omitempty"`     
	SessionTimeoutMinutes int        `json:"session_timeout_minutes"` 
	Runtimes              string     `json:"runtimes"`                
	PostgresEnabled       bool       `json:"postgres_enabled"`
	PhpPgAdminEnabled     bool       `json:"phppgadmin_enabled"`
	BandwidthLimitMB      int64      `json:"bandwidth_limit_mb"` 
	
	
	PhpMyAdminPassword string `json:"-"`
	PhpPgAdminPassword string `json:"-"`
	
	PackageID *int64     `json:"package_id,omitempty"`
	ExpiresAt *time.Time `json:"expires_at,omitempty"`
	
	
	OwnerUserID *int64 `json:"owner_user_id,omitempty"`
	
	DockerEnabled bool `json:"docker_enabled"`
	
	VulnSchedule string `json:"vuln_schedule"`
}


type Domain struct {
	ID         int64     `json:"id"`
	ClientID   int64     `json:"client_id"`
	FQDN       string    `json:"fqdn"`
	Docroot    string    `json:"docroot"`
	PHPVersion string    `json:"php_version"`
	SSLEnabled bool      `json:"ssl_enabled"`
	CreatedAt  time.Time `json:"created_at"`
	
	
	
	
	UpstreamIP   string `json:"upstream_ip"`
	UpstreamPort int    `json:"upstream_port"`
	UpstreamPath string `json:"upstream_path"`
	
	EmailEnabled bool `json:"email_enabled"`
	
	
	OfflineMode string `json:"offline_mode"`
}





type DomainForward struct {
	ID             int64     `json:"id"`
	DomainID       int64     `json:"domain_id"`
	Path           string    `json:"path"`
	Target         string    `json:"target"`
	TargetDomainID int64     `json:"target_domain_id"` 
	TargetFQDN     string    `json:"target_fqdn"`      
	CreatedAt      time.Time `json:"created_at"`
}


type Database struct {
	ID        int64     `json:"id"`
	ClientID  int64     `json:"client_id"`
	DBName    string    `json:"db_name"`
	DBUser    string    `json:"db_user"`
	Engine    string    `json:"engine"`
	CreatedAt time.Time `json:"created_at"`
}



type Settings struct {
	SessionTimeoutMinutes int    `json:"session_timeout_minutes"`
	PanelDomain           string `json:"panel_domain"`
	CompanyName           string `json:"company_name"`
	MaxDomainsPerClient   int    `json:"max_domains_per_client"`
	MaxDatabasesPerClient int    `json:"max_databases_per_client"`
	
	MaxLoginAttempts int `json:"max_login_attempts"`
	LockoutMinutes   int `json:"lockout_minutes"`
	
	SecModSecurity  bool `json:"sec_modsecurity"`
	SecCSF          bool `json:"sec_csf"`
	SecFail2ban     bool `json:"sec_fail2ban"`
	SecSSLAutoRenew bool `json:"sec_ssl_autorenew"`
}


type Backup struct {
	ID         int64      `json:"id"`
	ClientID   int64      `json:"client_id"`
	Filename   string     `json:"filename"`
	SizeBytes  int64      `json:"size_bytes"`
	Status     string     `json:"status"`
	Note       string     `json:"note"`
	CreatedAt  time.Time  `json:"created_at"`
	FinishedAt *time.Time `json:"finished_at,omitempty"`
}



type BackupManifest struct {
	ClientID   int64              `json:"client_id"`
	ClientName string             `json:"client_name"`
	CreatedAt  time.Time          `json:"created_at"`
	Domains    []ManifestDomain   `json:"domains"`
	Databases  []ManifestDatabase `json:"databases"`
}


type ManifestDomain struct {
	FQDN    string `json:"fqdn"`
	Docroot string `json:"docroot"`
	PHP     string `json:"php"`
}


type ManifestDatabase struct {
	Name         string `json:"name"`
	User         string `json:"user"`
	PasswordHash string `json:"password_hash"`
}


type DNSRecord struct {
	ID        int64     `json:"id"`
	DomainID  int64     `json:"domain_id"`
	Type      string    `json:"type"`
	Name      string    `json:"name"`
	Content   string    `json:"content"`
	TTL       int       `json:"ttl"`
	Prio      *int      `json:"prio,omitempty"`
	CreatedAt time.Time `json:"created_at"`
}


type CronJob struct {
	ID        int64     `json:"id"`
	ClientID  int64     `json:"client_id"`
	Schedule  string    `json:"schedule"`
	Command   string    `json:"command"`
	Enabled   bool      `json:"enabled"`
	CreatedAt time.Time `json:"created_at"`
}


type SSLCert struct {
	ID        int64      `json:"id"`
	DomainID  int64      `json:"domain_id"`
	Issuer    *string    `json:"issuer,omitempty"`
	ExpiresAt *time.Time `json:"expires_at,omitempty"`
	Status    string     `json:"status"`
	CreatedAt time.Time  `json:"created_at"`
}


const (
	VulnHigh   = "high"
	VulnMedium = "medium"
	VulnLow    = "low"
	VulnInfo   = "info"
)


type VulnScan struct {
	ID         int64      `json:"id"`
	ClientID   int64      `json:"client_id"`
	Status     string     `json:"status"`
	High       int        `json:"high"`
	Medium     int        `json:"medium"`
	Low        int        `json:"low"`
	Info       int        `json:"info"`
	Summary    string     `json:"summary"`
	CreatedAt  time.Time  `json:"created_at"`
	FinishedAt *time.Time `json:"finished_at,omitempty"`
}


type SecurityEvent struct {
	ID        int64     `json:"id"`
	EventType string    `json:"event_type"`
	Severity  string    `json:"severity"`
	IP        string    `json:"ip"`
	Email     string    `json:"email"`
	UserAgent string    `json:"user_agent"`
	Detail    string    `json:"detail"`
	Blocked   bool      `json:"blocked"`
	CreatedAt time.Time `json:"created_at"`
}


type VulnFinding struct {
	ID          int64  `json:"id"`
	ScanID      int64  `json:"scan_id"`
	FQDN        string `json:"fqdn"`
	Severity    string `json:"severity"`
	Category    string `json:"category"`
	Title       string `json:"title"`
	Detail      string `json:"detail"`
	Remediation string `json:"remediation"`
}
