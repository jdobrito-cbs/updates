package core







const (
	AppKindPHP    = "php"
	AppKindDocker = "docker"
)


type CatalogApp struct {
	Slug        string `json:"slug"`
	Name        string `json:"name"`
	Kind        string `json:"kind"` 
	Description string `json:"description"`
	
	DockerImage string `json:"docker_image,omitempty"`
	DockerPort  int    `json:"docker_port,omitempty"`
}


var AppCatalog = []CatalogApp{
	{
		Slug:        "phpbb",
		Name:        "phpBB",
		Kind:        AppKindPHP,
		Description: "Fórum/comunidade em PHP. Instala no domínio escolhido (conclua o assistente em /install).",
	},
	{
		Slug:        "n8n",
		Name:        "n8n",
		Kind:        AppKindDocker,
		Description: "Automação de fluxos de trabalho (low-code). Roda como container Docker.",
		DockerImage: "docker.n8n.io/n8nio/n8n",
		DockerPort:  5678,
	},
	{
		Slug:        "evolution",
		Name:        "Evolution API",
		Kind:        AppKindDocker,
		Description: "API de mensageria (WhatsApp). Roda como container Docker.",
		DockerImage: "atendai/evolution-api:latest",
		DockerPort:  8080,
	},
}



func AppBySlug(slug string) (CatalogApp, bool) {
	for _, a := range AppCatalog {
		if a.Slug == slug {
			return a, true
		}
	}
	return CatalogApp{}, false
}


func AppSlugValid(slug string) bool {
	_, ok := AppBySlug(slug)
	return ok
}


const (
	AppAudienceResellers       = "resellers"        
	AppAudienceAdminClients    = "admin_clients"    
	AppAudienceResellerClients = "reseller_clients" 
)
