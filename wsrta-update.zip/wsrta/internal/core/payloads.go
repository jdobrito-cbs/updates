package core

import (
	"fmt"
	"strings"
)





type ProvisionClientPayload struct {
	ClientID int64 `json:"client_id"`
}


func (p ProvisionClientPayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("provision_client: client_id inválido: %d", p.ClientID)
	}
	return nil
}


type DeprovisionClientPayload struct {
	ClientID int64 `json:"client_id"`
}


func (p DeprovisionClientPayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("deprovision_client: client_id inválido: %d", p.ClientID)
	}
	return nil
}


type AddDomainPayload struct {
	DomainID int64 `json:"domain_id"`
}


func (p AddDomainPayload) Validate() error {
	if p.DomainID <= 0 {
		return fmt.Errorf("add_domain: domain_id inválido: %d", p.DomainID)
	}
	return nil
}



type SetDomainForwardsPayload struct {
	DomainID int64 `json:"domain_id"`
}


func (p SetDomainForwardsPayload) Validate() error {
	if p.DomainID <= 0 {
		return fmt.Errorf("set_domain_forwards: domain_id inválido: %d", p.DomainID)
	}
	return nil
}


type RemoveDomainPayload struct {
	DomainID int64 `json:"domain_id"`
	
	
	DeleteFiles bool `json:"delete_files"`
}


func (p RemoveDomainPayload) Validate() error {
	if p.DomainID <= 0 {
		return fmt.Errorf("remove_domain: domain_id inválido: %d", p.DomainID)
	}
	return nil
}



var PHPVersions = []string{"8.1", "8.2", "8.3", "8.4"}


func ValidPHPVersion(v string) bool {
	for _, x := range PHPVersions {
		if x == v {
			return true
		}
	}
	return false
}


type SetDomainPHPPayload struct {
	DomainID   int64  `json:"domain_id"`
	PHPVersion string `json:"php_version"`
}


func (p SetDomainPHPPayload) Validate() error {
	if p.DomainID <= 0 {
		return fmt.Errorf("set_domain_php: domain_id inválido: %d", p.DomainID)
	}
	if !ValidPHPVersion(p.PHPVersion) {
		return fmt.Errorf("set_domain_php: versão de PHP inválida: %q", p.PHPVersion)
	}
	return nil
}


var OfflineModes = []string{"", "maintenance", "suspended"}


func ValidOfflineMode(m string) bool {
	for _, x := range OfflineModes {
		if x == m {
			return true
		}
	}
	return false
}


type SetDomainOfflinePayload struct {
	DomainID int64  `json:"domain_id"`
	Mode     string `json:"mode"` 
}


func (p SetDomainOfflinePayload) Validate() error {
	if p.DomainID <= 0 {
		return fmt.Errorf("set_domain_offline: domain_id inválido: %d", p.DomainID)
	}
	if !ValidOfflineMode(p.Mode) {
		return fmt.Errorf("set_domain_offline: modo inválido: %q", p.Mode)
	}
	return nil
}


type IssueSSLPayload struct {
	DomainID int64 `json:"domain_id"`
}


func (p IssueSSLPayload) Validate() error {
	if p.DomainID <= 0 {
		return fmt.Errorf("issue_ssl: domain_id inválido: %d", p.DomainID)
	}
	return nil
}



type CreateDatabasePayload struct {
	DatabaseID int64  `json:"database_id"`
	Password   string `json:"password,omitempty"`
}


func (p CreateDatabasePayload) Validate() error {
	if p.DatabaseID <= 0 {
		return fmt.Errorf("create_database: database_id inválido: %d", p.DatabaseID)
	}
	return nil
}


type ResetDBPasswordPayload struct {
	DatabaseID int64  `json:"database_id"`
	Password   string `json:"password"`
}


func (p ResetDBPasswordPayload) Validate() error {
	if p.DatabaseID <= 0 {
		return fmt.Errorf("reset_db_password: database_id inválido: %d", p.DatabaseID)
	}
	if len(p.Password) < 8 || len(p.Password) > 128 {
		return fmt.Errorf("reset_db_password: senha deve ter de 8 a 128 caracteres")
	}
	return nil
}


type DropDatabasePayload struct {
	DatabaseID int64 `json:"database_id"`
}


func (p DropDatabasePayload) Validate() error {
	if p.DatabaseID <= 0 {
		return fmt.Errorf("drop_database: database_id inválido: %d", p.DatabaseID)
	}
	return nil
}


type SetDNSRecordPayload struct {
	DNSRecordID int64 `json:"dns_record_id"`
}


func (p SetDNSRecordPayload) Validate() error {
	if p.DNSRecordID <= 0 {
		return fmt.Errorf("set_dns_record: dns_record_id inválido: %d", p.DNSRecordID)
	}
	return nil
}


type DeleteDNSRecordPayload struct {
	DNSRecordID int64 `json:"dns_record_id"`
}


func (p DeleteDNSRecordPayload) Validate() error {
	if p.DNSRecordID <= 0 {
		return fmt.Errorf("delete_dns_record: dns_record_id inválido: %d", p.DNSRecordID)
	}
	return nil
}


type SetCronPayload struct {
	CronJobID int64 `json:"cron_job_id"`
}


func (p SetCronPayload) Validate() error {
	if p.CronJobID <= 0 {
		return fmt.Errorf("set_cron: cron_job_id inválido: %d", p.CronJobID)
	}
	return nil
}


type RemoveCronPayload struct {
	CronJobID int64 `json:"cron_job_id"`
}


func (p RemoveCronPayload) Validate() error {
	if p.CronJobID <= 0 {
		return fmt.Errorf("remove_cron: cron_job_id inválido: %d", p.CronJobID)
	}
	return nil
}



var RestartableServices = map[string]bool{
	"nginx":        true,
	"wsrta-api":    true,
	"wsrta-daemon": true,
	"postgresql":   true,
	"pdns":         true,
}


type RestartServicePayload struct {
	Service string `json:"service"`
}


func (p RestartServicePayload) Validate() error {
	if !RestartableServices[p.Service] {
		return fmt.Errorf("restart_service: serviço não permitido: %q", p.Service)
	}
	return nil
}



type SystemUpdatePayload struct{}


type PanelUpdatePayload struct{}


type SetFastNginxPayload struct {
	ClientID int64 `json:"client_id"`
	Enabled  bool  `json:"enabled"`
}


func (p SetFastNginxPayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("set_fast_nginx: client_id inválido: %d", p.ClientID)
	}
	return nil
}


type SetPostgresPayload struct {
	ClientID int64 `json:"client_id"`
	Enabled  bool  `json:"enabled"`
}


func (p SetPostgresPayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("set_postgres: client_id inválido: %d", p.ClientID)
	}
	return nil
}



type SetPhpPgAdminPayload struct {
	ClientID int64 `json:"client_id"`
	Enabled  bool  `json:"enabled"`
	Port     int   `json:"port"`
}


func (p SetPhpPgAdminPayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("set_phppgadmin: client_id inválido: %d", p.ClientID)
	}
	if p.Enabled && (p.Port < 1 || p.Port > 65535) {
		return fmt.Errorf("set_phppgadmin: porta inválida: %d", p.Port)
	}
	return nil
}


type SetRuntimesPayload struct {
	ClientID int64    `json:"client_id"`
	Runtimes []string `json:"runtimes"`
}


func (p SetRuntimesPayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("set_runtimes: client_id inválido: %d", p.ClientID)
	}
	for _, k := range p.Runtimes {
		if RuntimeByKey(k) == nil {
			return fmt.Errorf("set_runtimes: runtime desconhecido: %q", k)
		}
	}
	return nil
}




type ApplySiteRulesPayload struct {
	DomainID   int64  `json:"domain_id"`
	UserINI    string `json:"user_ini"`
	VHostExtra string `json:"vhost_extra"`
}


func (p ApplySiteRulesPayload) Validate() error {
	if p.DomainID <= 0 {
		return fmt.Errorf("apply_site_rules: domain_id inválido: %d", p.DomainID)
	}
	return nil
}


type SetPhpMyAdminPayload struct {
	ClientID int64 `json:"client_id"`
	Enabled  bool  `json:"enabled"`
	Port     int   `json:"port"`
}


func (p SetPhpMyAdminPayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("set_phpmyadmin: client_id inválido: %d", p.ClientID)
	}
	if p.Enabled && p.Port <= 0 {
		return fmt.Errorf("set_phpmyadmin: porta obrigatória")
	}
	return nil
}



type ApplySecurityPayload struct {
	ModSecurity  bool `json:"modsecurity"`
	CSF          bool `json:"csf"`
	Fail2ban     bool `json:"fail2ban"`
	SSLAutoRenew bool `json:"ssl_autorenew"`
}


func (p ApplySecurityPayload) Validate() error { return nil }




type ScanVulnerabilitiesPayload struct {
	ClientID int64 `json:"client_id"` 
	ScanID   int64 `json:"scan_id"`
	
	
	Nikto bool `json:"nikto,omitempty"`
}


func (p ScanVulnerabilitiesPayload) Validate() error {
	if p.ClientID < 0 || p.ScanID <= 0 {
		return fmt.Errorf("client_id/scan_id inválidos")
	}
	return nil
}


type HardenWordPressPayload struct {
	DomainID int64  `json:"domain_id"`
	Path     string `json:"path"`
}


func (p HardenWordPressPayload) Validate() error {
	if p.DomainID <= 0 {
		return fmt.Errorf("harden_wordpress: domain_id inválido: %d", p.DomainID)
	}
	return nil
}




type UpdatePhpBBPayload struct {
	DomainID int64  `json:"domain_id"`
	Path     string `json:"path"`
}


func (p UpdatePhpBBPayload) Validate() error {
	if p.DomainID <= 0 {
		return fmt.Errorf("update_phpbb: domain_id inválido: %d", p.DomainID)
	}
	return nil
}


type UpdateClientPackagesPayload struct {
	ClientID int64 `json:"client_id"`
}


func (p UpdateClientPackagesPayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("update_client_packages: client_id inválido: %d", p.ClientID)
	}
	return nil
}


type SetCloudflarePayload struct {
	ClientID int64  `json:"client_id"`
	Token    string `json:"token"`
}


func (p SetCloudflarePayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("set_cloudflare: client_id inválido: %d", p.ClientID)
	}
	
	
	if len(p.Token) < 20 || len(p.Token) > 4000 {
		return fmt.Errorf("set_cloudflare: token inválido")
	}
	return nil
}


type ControlCloudflarePayload struct {
	ClientID int64  `json:"client_id"`
	Op       string `json:"op"` 
}


func (p ControlCloudflarePayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("control_cloudflare: client_id inválido: %d", p.ClientID)
	}
	switch p.Op {
	case "start", "stop", "restart":
		return nil
	}
	return fmt.Errorf("control_cloudflare: op inválida: %q", p.Op)
}



type BackupClientPayload struct {
	ClientID int64 `json:"client_id"`
	BackupID int64 `json:"backup_id"`
}


func (p BackupClientPayload) Validate() error {
	if p.ClientID <= 0 || p.BackupID <= 0 {
		return fmt.Errorf("backup_client: client_id e backup_id são obrigatórios")
	}
	return nil
}


type EnableSFTPPayload struct {
	ClientID int64  `json:"client_id"`
	User     string `json:"user"`
	Password string `json:"password"`
	HostPort int    `json:"host_port"`
}


func (p EnableSFTPPayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("enable_sftp: client_id inválido: %d", p.ClientID)
	}
	if p.User == "" || p.Password == "" || p.HostPort <= 0 {
		return fmt.Errorf("enable_sftp: user, password e host_port são obrigatórios")
	}
	return nil
}


type DisableSFTPPayload struct {
	ClientID int64  `json:"client_id"`
	User     string `json:"user"`
}


func (p DisableSFTPPayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("disable_sftp: client_id inválido: %d", p.ClientID)
	}
	return nil
}




type InstallWordPressPayload struct {
	DomainID      int64  `json:"domain_id"`
	Path          string `json:"path"` 
	AdminUser     string `json:"admin_user"`
	AdminEmail    string `json:"admin_email"`
	AdminPassword string `json:"admin_password"`
	Title         string `json:"title"`
	DBName        string `json:"db_name"`
}


func (p InstallWordPressPayload) Validate() error {
	if p.DomainID <= 0 {
		return fmt.Errorf("install_wordpress: domain_id inválido: %d", p.DomainID)
	}
	if p.AdminUser == "" || p.AdminEmail == "" || p.AdminPassword == "" || p.DBName == "" {
		return fmt.Errorf("install_wordpress: admin_user, admin_email, admin_password e db_name são obrigatórios")
	}
	return nil
}


type RemoveWordPressPayload struct {
	DomainID int64  `json:"domain_id"`
	Path     string `json:"path"`
	DBName   string `json:"db_name"`
}


func (p RemoveWordPressPayload) Validate() error {
	if p.DomainID <= 0 {
		return fmt.Errorf("remove_wordpress: domain_id inválido: %d", p.DomainID)
	}
	if p.DBName == "" {
		return fmt.Errorf("remove_wordpress: db_name é obrigatório")
	}
	return nil
}




type InstallPhpBBPayload struct {
	DomainID int64  `json:"domain_id"`
	Path     string `json:"path"` 
	DBName   string `json:"db_name"`
}


func (p InstallPhpBBPayload) Validate() error {
	if p.DomainID <= 0 {
		return fmt.Errorf("install_phpbb: domain_id inválido: %d", p.DomainID)
	}
	if p.DBName == "" {
		return fmt.Errorf("install_phpbb: db_name é obrigatório")
	}
	if !safeSubPath(p.Path) {
		return fmt.Errorf("install_phpbb: path inválido: %q", p.Path)
	}
	return nil
}


func safeSubPath(p string) bool {
	if p == "" {
		return true
	}
	if strings.ContainsAny(p, "/\\\x00") || strings.Contains(p, "..") || len(p) > 60 {
		return false
	}
	return true
}


type RemovePhpBBPayload struct {
	DomainID int64  `json:"domain_id"`
	Path     string `json:"path"`
	DBName   string `json:"db_name"`
}


func (p RemovePhpBBPayload) Validate() error {
	if p.DomainID <= 0 {
		return fmt.Errorf("remove_phpbb: domain_id inválido: %d", p.DomainID)
	}
	if p.DBName == "" {
		return fmt.Errorf("remove_phpbb: db_name é obrigatório")
	}
	return nil
}


type DockerTogglePayload struct {
	ClientID int64 `json:"client_id"`
}


func (p DockerTogglePayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("docker toggle: client_id inválido: %d", p.ClientID)
	}
	return nil
}




type InstallDockerAppPayload struct {
	ClientID      int64  `json:"client_id"`
	AppInstallID  int64  `json:"app_install_id"`
	Slug          string `json:"slug"`
	ContainerName string `json:"container_name"` 
	HostPort      int    `json:"host_port"`      
}


func (p InstallDockerAppPayload) Validate() error {
	if p.ClientID <= 0 || p.AppInstallID <= 0 {
		return fmt.Errorf("install_docker_app: ids inválidos")
	}
	if !AppSlugValid(p.Slug) {
		return fmt.Errorf("install_docker_app: slug inválido: %q", p.Slug)
	}
	if !validDockerName(p.ContainerName) {
		return fmt.Errorf("install_docker_app: container_name inválido: %q", p.ContainerName)
	}
	if p.HostPort < 1024 || p.HostPort > 65535 {
		return fmt.Errorf("install_docker_app: host_port inválido: %d", p.HostPort)
	}
	return nil
}


type RemoveDockerAppPayload struct {
	ClientID      int64  `json:"client_id"`
	ContainerName string `json:"container_name"`
	DeviceName    string `json:"device_name"`
}


func (p RemoveDockerAppPayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("remove_docker_app: client_id inválido: %d", p.ClientID)
	}
	if !validDockerName(p.ContainerName) {
		return fmt.Errorf("remove_docker_app: container_name inválido: %q", p.ContainerName)
	}
	return nil
}


func validDockerName(s string) bool {
	if s == "" || len(s) > 64 {
		return false
	}
	for _, c := range s {
		if !(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '-' || c == '_' || c == '.') {
			return false
		}
	}
	return true
}


type SuspendClientPayload struct {
	ClientID int64 `json:"client_id"`
}


func (p SuspendClientPayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("suspend_client: client_id inválido: %d", p.ClientID)
	}
	return nil
}


type PowerClientPayload struct {
	ClientID int64  `json:"client_id"`
	Op       string `json:"op"` 
}


func (p PowerClientPayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("power_client: client_id inválido: %d", p.ClientID)
	}
	switch p.Op {
	case "start", "stop", "restart":
		return nil
	default:
		return fmt.Errorf("power_client: op inválida: %q", p.Op)
	}
}


type ApplyLimitsPayload struct {
	ClientID    int64   `json:"client_id"`
	CPULimit    float64 `json:"cpu_limit"`
	RAMLimitMB  int     `json:"ram_limit_mb"`
	DiskQuotaMB int     `json:"disk_quota_mb"`
}


func (p ApplyLimitsPayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("apply_limits: client_id inválido: %d", p.ClientID)
	}
	if p.CPULimit <= 0 || p.RAMLimitMB <= 0 || p.DiskQuotaMB <= 0 {
		return fmt.Errorf("apply_limits: limites inválidos (cpu=%v ram=%d disco=%d)", p.CPULimit, p.RAMLimitMB, p.DiskQuotaMB)
	}
	return nil
}


type ResumeClientPayload struct {
	ClientID int64 `json:"client_id"`
}


func (p ResumeClientPayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("resume_client: client_id inválido: %d", p.ClientID)
	}
	return nil
}



type RestoreDatabasePayload struct {
	ClientID int64  `json:"client_id"`
	DBName   string `json:"db_name"`
	DBUser   string `json:"db_user"`
	
	
	DBPasswordHash string `json:"db_password_hash"`
	DumpPath       string `json:"dump_path"` 
}


func (p RestoreDatabasePayload) Validate() error {
	if p.ClientID <= 0 {
		return fmt.Errorf("restore_database: client_id inválido: %d", p.ClientID)
	}
	if p.DBName == "" || p.DBUser == "" || p.DumpPath == "" {
		return fmt.Errorf("restore_database: db_name, db_user e dump_path são obrigatórios")
	}
	return nil
}


type RestoreFilesPayload struct {
	DomainID    int64  `json:"domain_id"`
	ArchivePath string `json:"archive_path"` 
}


func (p RestoreFilesPayload) Validate() error {
	if p.DomainID <= 0 {
		return fmt.Errorf("restore_files: domain_id inválido: %d", p.DomainID)
	}
	if p.ArchivePath == "" {
		return fmt.Errorf("restore_files: archive_path é obrigatório")
	}
	return nil
}
