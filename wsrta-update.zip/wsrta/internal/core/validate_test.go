package core

import "testing"



func TestValidUpstreamHostSSRF(t *testing.T) {
	blocked := []string{"169.254.169.254", "169.254.0.1", "fe80::1", "0.0.0.0", "::", "224.0.0.1"}
	for _, s := range blocked {
		if err := ValidUpstreamHost(s); err == nil {
			t.Errorf("ValidUpstreamHost(%q) deveria ser BLOQUEADO (SSRF link-local)", s)
		}
	}
	allowed := []string{"127.0.0.1", "10.0.0.5", "192.168.1.10", "app.interno.com", "exemplo.com"}
	for _, s := range allowed {
		if err := ValidUpstreamHost(s); err != nil {
			t.Errorf("ValidUpstreamHost(%q) deveria ser permitido: %v", s, err)
		}
	}
}

func TestValidFQDN(t *testing.T) {
	valid := []string{
		"site.com", "est.uea.edu.br", "a.b", "sub.dom-inio.com", "x1.y2.z3",
	}
	for _, s := range valid {
		if err := ValidFQDN(s); err != nil {
			t.Errorf("esperava válido: %q (erro: %v)", s, err)
		}
	}

	
	invalid := []string{
		"", "semponto", "site", "-bad.com", "bad-.com", "a..b",
		"x;}server{listen 9",    
		"evil.com\n}\nserver{}", 
		"../../etc/nginx", "a/b.com", "site .com", "site;.com",
		"under_score.com", 
	}
	for _, s := range invalid {
		if err := ValidFQDN(s); err == nil {
			t.Errorf("esperava INVÁLIDO: %q", s)
		}
	}
}
