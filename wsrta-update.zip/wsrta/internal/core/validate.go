package core

import (
	"fmt"
	"net"
	"regexp"
	"strconv"
	"strings"
)



func ValidUpstreamTarget(s string) error {
	s = strings.TrimSpace(s)
	s = strings.TrimPrefix(strings.TrimPrefix(s, "https://"), "http://")
	if s == "" {
		return fmt.Errorf("destino vazio")
	}
	hostport, path := s, ""
	if i := strings.IndexByte(s, '/'); i >= 0 {
		hostport, path = s[:i], s[i:]
	}
	host := hostport
	if i := strings.IndexByte(hostport, ':'); i >= 0 {
		host = hostport[:i]
		p, e := strconv.Atoi(hostport[i+1:])
		if e != nil || p < 1 || p > 65535 {
			return fmt.Errorf("porta inválida")
		}
	}
	if err := ValidUpstreamHost(host); err != nil {
		return err
	}
	return ValidUpstreamPath(path)
}



func ValidIP(s string) error {
	if net.ParseIP(strings.TrimSpace(s)) == nil {
		return fmt.Errorf("ip inválido: %q", s)
	}
	return nil
}




func ValidUpstreamHost(s string) error {
	s = strings.TrimSpace(s)
	if s == "" {
		return fmt.Errorf("destino vazio")
	}
	if ip := net.ParseIP(s); ip != nil {
		
		
		
		
		if ip.IsLinkLocalUnicast() || ip.IsLinkLocalMulticast() || ip.IsMulticast() || ip.IsUnspecified() {
			return fmt.Errorf("destino não permitido (SSRF): %q", s)
		}
		return nil
	}
	if len(s) > 253 {
		return fmt.Errorf("host inválido (muito longo)")
	}
	for _, l := range strings.Split(s, ".") {
		if !fqdnLabelRe.MatchString(l) {
			return fmt.Errorf("host inválido: %q", s)
		}
	}
	return nil
}


var upstreamPathRe = regexp.MustCompile(`^/[A-Za-z0-9._~/-]*$`)


func ValidUpstreamPath(s string) error {
	if s == "" {
		return nil
	}
	if !upstreamPathRe.MatchString(s) || strings.Contains(s, "..") {
		return fmt.Errorf("caminho inválido: %q", s)
	}
	return nil
}


var fqdnLabelRe = regexp.MustCompile(`^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?$`)




func ValidFQDN(s string) error {
	if s == "" || len(s) > 253 {
		return fmt.Errorf("fqdn inválido (vazio ou > 253 caracteres)")
	}
	labels := strings.Split(s, ".")
	if len(labels) < 2 {
		return fmt.Errorf("fqdn inválido: informe um domínio com ponto (ex.: site.com.br)")
	}
	for _, l := range labels {
		if !fqdnLabelRe.MatchString(l) {
			return fmt.Errorf("fqdn inválido: %q", s)
		}
	}
	return nil
}
