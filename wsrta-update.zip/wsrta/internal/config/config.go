

package config

import (
	"log/slog"
	"strings"

	"github.com/caarlos0/env/v11"
	"github.com/joho/godotenv"
)


type Config struct {
	DatabaseURL     string `env:"WSRTA_DATABASE_URL,required"`
	PDNSDatabaseURL string `env:"WSRTA_PDNS_DATABASE_URL"`
	APIAddr         string `env:"WSRTA_API_ADDR" envDefault:":8080"`
	
	
	Edition         string `env:"WSRTA_EDITION" envDefault:"simple"`
	JWTSecret       string `env:"WSRTA_JWT_SECRET"`
	JWTTTLMinutes   int    `env:"WSRTA_JWT_TTL_MINUTES" envDefault:"60"`
	LoginRatePerMin int    `env:"WSRTA_LOGIN_RATE_PER_MIN" envDefault:"10"`
	TOTPIssuer      string `env:"WSRTA_TOTP_ISSUER" envDefault:"WSRTA"`
	DaemonSocket    string `env:"WSRTA_DAEMON_SOCKET" envDefault:"/tmp/wsrta-daemon.sock"`
	LXDDriver       string `env:"WSRTA_LXD_DRIVER" envDefault:"fake"`
	LXDSocket       string `env:"WSRTA_LXD_SOCKET"`
	
	
	LXDFakeFSRoot  string `env:"WSRTA_LXD_FAKE_FSROOT" envDefault:"/var/lib/wsrta/fakefs"`
	LXDImage       string `env:"WSRTA_LXD_IMAGE" envDefault:"wsrta-base"`
	LXDStoragePool string `env:"WSRTA_LXD_STORAGE_POOL" envDefault:"default"`
	LXDNetwork     string `env:"WSRTA_LXD_NETWORK" envDefault:"lxdbr0"`

	
	NginxSitesDir     string `env:"WSRTA_NGINX_SITES_DIR" envDefault:"/etc/nginx/sites-enabled"`
	NginxPreviewDir   string `env:"WSRTA_NGINX_PREVIEW_DIR" envDefault:"/etc/nginx/wsrta-preview.d"`
	NginxForwardsDir  string `env:"WSRTA_NGINX_FORWARDS_DIR" envDefault:"/etc/nginx/wsrta-forwards.d"`
	NginxReloadCmd    string `env:"WSRTA_NGINX_RELOAD_CMD" envDefault:"nginx -s reload"`
	AcmeSh            string `env:"WSRTA_ACME_SH" envDefault:"acme.sh"`
	AcmeEmail         string `env:"WSRTA_ACME_EMAIL"`
	AcmeWebroot       string `env:"WSRTA_ACME_WEBROOT" envDefault:"/var/www/acme"`
	AcmeCertDir       string `env:"WSRTA_ACME_CERT_DIR" envDefault:"/etc/wsrta/certs"`
	AcmeStaging       bool   `env:"WSRTA_ACME_STAGING" envDefault:"true"`
	DomainDocrootBase string `env:"WSRTA_DOMAIN_DOCROOT_BASE" envDefault:"/var/www"`

	
	PDNSPrimaryNS   string `env:"WSRTA_PDNS_PRIMARY_NS" envDefault:"ns1.wsrta.local"`
	PDNSSecondaryNS string `env:"WSRTA_PDNS_SECONDARY_NS"`
	PDNSHostmaster  string `env:"WSRTA_PDNS_HOSTMASTER" envDefault:"hostmaster.wsrta.local"`
	PDNSRecordTTL   int    `env:"WSRTA_PDNS_RECORD_TTL" envDefault:"3600"`
	CronUser        string `env:"WSRTA_CRON_USER" envDefault:"www-data"`

	
	SFTPHost     string `env:"WSRTA_SFTP_HOST" envDefault:"localhost"`
	SFTPBasePort int    `env:"WSRTA_SFTP_BASE_PORT" envDefault:"30000"`

	
	BackupDir      string `env:"WSRTA_BACKUP_DIR" envDefault:"/var/lib/wsrta/cyberpanel"`
	MigrateStaging string `env:"WSRTA_MIGRATE_STAGING" envDefault:"/var/lib/wsrta/migrate"`

	
	ClientBackupDir string `env:"WSRTA_CLIENT_BACKUP_DIR" envDefault:"/var/lib/wsrta/backups"`

	
	
	
	NiktoBin string `env:"WSRTA_NIKTO_BIN"`

	
	FileAPISocket string `env:"WSRTA_FILEAPI_SOCKET" envDefault:"/tmp/wsrta-fileapi.sock"`
	FileAPIToken  string `env:"WSRTA_FILEAPI_TOKEN"`

	
	PMABasePort int    `env:"WSRTA_PMA_BASE_PORT" envDefault:"33000"`
	PMAConfD    string `env:"WSRTA_PMA_CONFD" envDefault:"/etc/phpmyadmin/wsrta.d"`
	PMAURL      string `env:"WSRTA_PMA_URL" envDefault:"/phpmyadmin/"`
	
	
	PPABasePort int    `env:"WSRTA_PPA_BASE_PORT" envDefault:"34000"`
	PPAConfD    string `env:"WSRTA_PPA_CONFD" envDefault:"/etc/phppgadmin/wsrta.d"`
	PPAURL      string `env:"WSRTA_PPA_URL" envDefault:"/phppgadmin/"`

	
	RepoDir string `env:"WSRTA_REPO_DIR" envDefault:"/opt/wsrta/src"`
	
	UpdateRepo string `env:"WSRTA_UPDATE_REPO" envDefault:"jdobrito-cbs/updates"`

	LogLevel string `env:"WSRTA_LOG_LEVEL" envDefault:"info"`
}


func Load() (Config, error) {
	
	_ = godotenv.Load()

	var cfg Config
	if err := env.Parse(&cfg); err != nil {
		return Config{}, err
	}
	return cfg, nil
}


func (c Config) SlogLevel() slog.Level {
	switch strings.ToLower(c.LogLevel) {
	case "debug":
		return slog.LevelDebug
	case "warn":
		return slog.LevelWarn
	case "error":
		return slog.LevelError
	default:
		return slog.LevelInfo
	}
}
