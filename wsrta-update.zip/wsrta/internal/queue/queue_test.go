package queue_test

import (
	"context"
	"errors"
	"os"
	"testing"

	"github.com/jdobrito/wsrta/internal/core"
	"github.com/jdobrito/wsrta/internal/db"
	"github.com/jdobrito/wsrta/internal/queue"
)



func TestEnqueueClaimDone(t *testing.T) {
	dsn := os.Getenv("WSRTA_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("defina WSRTA_TEST_DATABASE_URL para rodar os testes de integração da fila")
	}

	ctx := context.Background()
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		t.Fatalf("abrir banco: %v", err)
	}
	defer pool.Close()

	if _, err := pool.Exec(ctx, "DELETE FROM actions"); err != nil {
		t.Fatalf("limpar actions: %v", err)
	}

	q := queue.New(pool)

	
	id, err := q.Enqueue(ctx, core.ActionProvisionClient, map[string]any{"client_id": 1}, nil)
	if err != nil {
		t.Fatalf("enqueue: %v", err)
	}

	
	a, err := q.Claim(ctx)
	if err != nil {
		t.Fatalf("claim: %v", err)
	}
	if a.ID != id {
		t.Fatalf("claim trouxe id %d, esperava %d", a.ID, id)
	}
	if a.Status != core.ActionRunning {
		t.Fatalf("status após claim = %q, esperava %q", a.Status, core.ActionRunning)
	}
	if a.StartedAt == nil {
		t.Fatal("started_at deveria estar preenchido após claim")
	}

	
	if _, err := q.Claim(ctx); !errors.Is(err, queue.ErrNoPending) {
		t.Fatalf("esperava ErrNoPending, veio %v", err)
	}

	
	if err := q.MarkDone(ctx, id, "ok"); err != nil {
		t.Fatalf("mark done: %v", err)
	}
	got, err := q.Get(ctx, id)
	if err != nil {
		t.Fatalf("get: %v", err)
	}
	if got.Status != core.ActionDone {
		t.Fatalf("status final = %q, esperava %q", got.Status, core.ActionDone)
	}
	if got.FinishedAt == nil {
		t.Fatal("finished_at deveria estar preenchido após done")
	}

	
	if _, err := q.Get(ctx, 0); !errors.Is(err, queue.ErrNotFound) {
		t.Fatalf("esperava ErrNotFound, veio %v", err)
	}
}
