package queue

import (
	"context"
	"net"
	"os"
	"time"
)






func Nudge(socketPath string) {
	conn, err := net.DialTimeout("unix", socketPath, 200*time.Millisecond)
	if err != nil {
		return
	}
	defer conn.Close()
	_ = conn.SetWriteDeadline(time.Now().Add(200 * time.Millisecond))
	_, _ = conn.Write([]byte{1})
}



func Listen(ctx context.Context, socketPath string, onNudge func()) error {
	_ = os.Remove(socketPath)

	ln, err := net.Listen("unix", socketPath)
	if err != nil {
		return err
	}

	
	go func() {
		<-ctx.Done()
		_ = ln.Close()
	}()

	for {
		conn, err := ln.Accept()
		if err != nil {
			if ctx.Err() != nil {
				return nil 
			}
			return err
		}
		go func(c net.Conn) {
			defer c.Close()
			_ = c.SetReadDeadline(time.Now().Add(time.Second))
			buf := make([]byte, 1)
			_, _ = c.Read(buf)
			onNudge()
		}(conn)
	}
}
