




package queue

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strings"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/jdobrito/wsrta/internal/core"
)


var ErrNoPending = errors.New("queue: nenhuma ação pendente")


var ErrNotFound = errors.New("queue: ação não encontrada")


type Queue struct {
	pool *pgxpool.Pool
}


func New(pool *pgxpool.Pool) *Queue {
	return &Queue{pool: pool}
}



func (q *Queue) Enqueue(ctx context.Context, t core.ActionType, payload any, requestedBy *int64) (int64, error) {
	if !t.Valid() {
		return 0, fmt.Errorf("queue: tipo de ação inválido: %q", t)
	}

	raw, err := json.Marshal(payload)
	if err != nil {
		return 0, fmt.Errorf("queue: serializar payload: %w", err)
	}

	var id int64
	err = q.pool.QueryRow(ctx,
		`INSERT INTO actions (type, payload, requested_by)
		 VALUES ($1, $2, $3)
		 RETURNING id`,
		string(t), raw, requestedBy,
	).Scan(&id)
	if err != nil {
		return 0, fmt.Errorf("queue: inserir ação: %w", err)
	}
	return id, nil
}






func (q *Queue) Claim(ctx context.Context) (*core.Action, error) {
	const query = `
		UPDATE actions
		   SET status = 'running', started_at = now()
		 WHERE id = (
		       SELECT id FROM actions
		        WHERE status = 'pending'
		        ORDER BY created_at
		        FOR UPDATE SKIP LOCKED
		        LIMIT 1
		 )
		 RETURNING id, type, payload, status, result, requested_by, created_at, started_at, finished_at, progress, progress_stage`

	a, err := scanAction(q.pool.QueryRow(ctx, query))
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNoPending
	}
	if err != nil {
		return nil, fmt.Errorf("queue: claim: %w", err)
	}
	return a, nil
}


func (q *Queue) MarkDone(ctx context.Context, id int64, result string) error {
	_, err := q.pool.Exec(ctx,
		`UPDATE actions SET status = 'done', result = $2, finished_at = now() WHERE id = $1`,
		id, strings.ToValidUTF8(result, ""))
	if err != nil {
		return fmt.Errorf("queue: marcar done: %w", err)
	}
	return nil
}







func (q *Queue) MarkFailed(ctx context.Context, id int64, reason string) error {
	_, err := q.pool.Exec(ctx,
		`UPDATE actions SET status = 'failed', result = $2, finished_at = now() WHERE id = $1`,
		id, strings.ToValidUTF8(reason, ""))
	if err != nil {
		return fmt.Errorf("queue: marcar failed: %w", err)
	}
	return nil
}





func (q *Queue) ReclaimRunning(ctx context.Context) (int64, error) {
	tag, err := q.pool.Exec(ctx,
		`UPDATE actions SET status = 'pending', started_at = NULL, progress = 0, progress_stage = '' WHERE status = 'running'`)
	if err != nil {
		return 0, fmt.Errorf("queue: reclaim running: %w", err)
	}
	return tag.RowsAffected(), nil
}




func (q *Queue) UpdateProgress(ctx context.Context, id int64, percent int, stage string) error {
	if percent < 0 {
		percent = 0
	}
	if percent > 100 {
		percent = 100
	}
	_, err := q.pool.Exec(ctx,
		`UPDATE actions SET progress = $2, progress_stage = $3 WHERE id = $1 AND status = 'running'`,
		id, percent, stage)
	if err != nil {
		return fmt.Errorf("queue: atualizar progresso: %w", err)
	}
	return nil
}



func (q *Queue) Get(ctx context.Context, id int64) (*core.Action, error) {
	const query = `
		SELECT id, type, payload, status, result, requested_by, created_at, started_at, finished_at, progress, progress_stage
		  FROM actions WHERE id = $1`

	a, err := scanAction(q.pool.QueryRow(ctx, query, id))
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("queue: get: %w", err)
	}
	return a, nil
}


type row interface {
	Scan(dest ...any) error
}




func scanAction(r row) (*core.Action, error) {
	var a core.Action
	var typeStr, statusStr string
	var payload []byte

	if err := r.Scan(
		&a.ID,
		&typeStr,
		&payload,
		&statusStr,
		&a.Result,
		&a.RequestedBy,
		&a.CreatedAt,
		&a.StartedAt,
		&a.FinishedAt,
		&a.Progress,
		&a.ProgressStage,
	); err != nil {
		return nil, err
	}

	a.Type = core.ActionType(typeStr)
	a.Status = core.ActionStatus(statusStr)
	a.Payload = payload
	return &a, nil
}
