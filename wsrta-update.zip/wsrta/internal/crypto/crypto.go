





package crypto

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"io"
	"os"
	"strings"
)

const encPrefix = "enc:v1:"


func Key() []byte {
	h := strings.TrimSpace(os.Getenv("WSRTA_SECRETS_KEY"))
	if h == "" {
		return nil
	}
	k, err := hex.DecodeString(h)
	if err != nil || len(k) != 32 {
		return nil
	}
	return k
}


func Encrypt(plain string) string {
	if plain == "" {
		return ""
	}
	key := Key()
	if key == nil {
		return plain
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return plain
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return plain
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return plain
	}
	ct := gcm.Seal(nonce, nonce, []byte(plain), nil)
	return encPrefix + base64.StdEncoding.EncodeToString(ct)
}


func Decrypt(stored string) string {
	if !strings.HasPrefix(stored, encPrefix) {
		return stored
	}
	key := Key()
	if key == nil {
		return ""
	}
	raw, err := base64.StdEncoding.DecodeString(strings.TrimPrefix(stored, encPrefix))
	if err != nil {
		return ""
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return ""
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil || len(raw) < gcm.NonceSize() {
		return ""
	}
	nonce, ct := raw[:gcm.NonceSize()], raw[gcm.NonceSize():]
	pt, err := gcm.Open(nil, nonce, ct, nil)
	if err != nil {
		return ""
	}
	return string(pt)
}
