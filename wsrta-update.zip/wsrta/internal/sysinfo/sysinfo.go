


package sysinfo

import (
	"bufio"
	"encoding/binary"
	"encoding/hex"
	"net"
	"os"
	"strconv"
	"strings"
	"syscall"
)


type OSInfo struct {
	Name     string `json:"name"`     
	Version  string `json:"version"`  
	Type     string `json:"type"`     
	Kernel   string `json:"kernel"`   
	Hostname string `json:"hostname"` 
}


type MemUsage struct {
	TotalKB int64   `json:"total_kb"`
	UsedKB  int64   `json:"used_kb"`
	Percent float64 `json:"percent"`
}


type DiskUsage struct {
	TotalBytes uint64  `json:"total_bytes"`
	UsedBytes  uint64  `json:"used_bytes"`
	Percent    float64 `json:"percent"`
}


type CPUInfo struct {
	Model string `json:"model"` 
	Cores int    `json:"cores"` 
}


func CPUDesc() CPUInfo {
	info := CPUInfo{Model: "CPU"}
	b, err := os.ReadFile("/proc/cpuinfo")
	if err != nil {
		return info
	}
	model := ""
	for _, line := range strings.Split(string(b), "\n") {
		k, v, ok := strings.Cut(line, ":")
		if !ok {
			continue
		}
		k, v = strings.TrimSpace(k), strings.TrimSpace(v)
		switch k {
		case "model name", "Model", "Hardware", "cpu model":
			if model == "" {
				model = v
			}
		case "processor":
			info.Cores++
		}
	}
	if model != "" {
		info.Model = model
	}
	return info
}


type NetIface struct {
	Name string `json:"name"`
	MAC  string `json:"mac"`
	IP   string `json:"ip"`
	Mask string `json:"mask"`
}


type NetworkConfig struct {
	Interfaces []NetIface `json:"interfaces"`
	Gateway    string     `json:"gateway"`
	DNS        []string   `json:"dns"`
}


func OS() OSInfo {
	o := OSInfo{Type: "linux"}
	if b, err := os.ReadFile("/etc/os-release"); err == nil {
		for _, line := range strings.Split(string(b), "\n") {
			k, v, ok := strings.Cut(line, "=")
			if !ok {
				continue
			}
			v = strings.Trim(v, `"`)
			switch k {
			case "NAME":
				o.Name = v
			case "VERSION":
				o.Version = v
			}
		}
	}
	var u syscall.Utsname
	if err := syscall.Uname(&u); err == nil {
		o.Kernel = charsToString(u.Release[:])
		o.Hostname = charsToString(u.Nodename[:])
		if o.Type == "" {
			o.Type = charsToString(u.Sysname[:])
		}
	}
	if o.Hostname == "" {
		o.Hostname, _ = os.Hostname()
	}
	return o
}

func charsToString(ca []int8) string {
	b := make([]byte, 0, len(ca))
	for _, c := range ca {
		if c == 0 {
			break
		}
		b = append(b, byte(c))
	}
	return string(b)
}


func Mem() MemUsage {
	var total, avail int64
	if b, err := os.ReadFile("/proc/meminfo"); err == nil {
		for _, line := range strings.Split(string(b), "\n") {
			f := strings.Fields(line)
			if len(f) < 2 {
				continue
			}
			v, _ := strconv.ParseInt(f[1], 10, 64)
			switch f[0] {
			case "MemTotal:":
				total = v
			case "MemAvailable:":
				avail = v
			}
		}
	}
	used := total - avail
	var pct float64
	if total > 0 {
		pct = float64(used) / float64(total) * 100
	}
	return MemUsage{TotalKB: total, UsedKB: used, Percent: round1(pct)}
}


func Disk(path string) DiskUsage {
	if path == "" {
		path = "/"
	}
	var st syscall.Statfs_t
	if err := syscall.Statfs(path, &st); err != nil {
		return DiskUsage{}
	}
	total := st.Blocks * uint64(st.Bsize)
	free := st.Bavail * uint64(st.Bsize)
	used := total - free
	var pct float64
	if total > 0 {
		pct = float64(used) / float64(total) * 100
	}
	return DiskUsage{TotalBytes: total, UsedBytes: used, Percent: round1(pct)}
}


func PrimaryIP() string {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return ""
	}
	for _, a := range addrs {
		if ipnet, ok := a.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
			if v4 := ipnet.IP.To4(); v4 != nil && !ipnet.IP.IsLinkLocalUnicast() {
				return v4.String()
			}
		}
	}
	return ""
}


func Network() NetworkConfig {
	cfg := NetworkConfig{Interfaces: []NetIface{}, DNS: []string{}}
	ifaces, _ := net.Interfaces()
	for _, ifc := range ifaces {
		if ifc.Flags&net.FlagLoopback != 0 || ifc.Flags&net.FlagUp == 0 {
			continue
		}
		addrs, _ := ifc.Addrs()
		for _, a := range addrs {
			ipnet, ok := a.(*net.IPNet)
			if !ok {
				continue
			}
			if v4 := ipnet.IP.To4(); v4 != nil {
				cfg.Interfaces = append(cfg.Interfaces, NetIface{
					Name: ifc.Name,
					MAC:  ifc.HardwareAddr.String(),
					IP:   v4.String(),
					Mask: net.IP(ipnet.Mask).String(),
				})
			}
		}
	}
	cfg.Gateway = defaultGateway()
	cfg.DNS = resolvers()
	return cfg
}


func defaultGateway() string {
	f, err := os.Open("/proc/net/route")
	if err != nil {
		return ""
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	sc.Scan() 
	for sc.Scan() {
		fields := strings.Fields(sc.Text())
		if len(fields) < 3 {
			continue
		}
		
		if fields[1] == "00000000" && fields[2] != "00000000" {
			if b, err := hex.DecodeString(fields[2]); err == nil && len(b) == 4 {
				ip := make(net.IP, 4)
				binary.LittleEndian.PutUint32(ip, binary.BigEndian.Uint32(b))
				return ip.String()
			}
		}
	}
	return ""
}


func resolvers() []string {
	out := []string{}
	b, err := os.ReadFile("/etc/resolv.conf")
	if err != nil {
		return out
	}
	for _, line := range strings.Split(string(b), "\n") {
		f := strings.Fields(line)
		if len(f) >= 2 && f[0] == "nameserver" {
			out = append(out, f[1])
		}
	}
	return out
}


type CPUSample struct {
	Total uint64
	Idle  uint64
}


func CPU() CPUSample {
	f, err := os.Open("/proc/stat")
	if err != nil {
		return CPUSample{}
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		fields := strings.Fields(sc.Text())
		if len(fields) == 0 || fields[0] != "cpu" {
			continue
		}
		var total, idle uint64
		for i := 1; i < len(fields); i++ {
			v, _ := strconv.ParseUint(fields[i], 10, 64)
			total += v
			if i == 4 || i == 5 { 
				idle += v
			}
		}
		return CPUSample{Total: total, Idle: idle}
	}
	return CPUSample{}
}


func CPUPercent(prev, cur CPUSample) float64 {
	dt := float64(cur.Total - prev.Total)
	di := float64(cur.Idle - prev.Idle)
	if dt <= 0 {
		return 0
	}
	return round1((dt - di) / dt * 100)
}


func NetCounters() (rx, tx uint64) {
	f, err := os.Open("/proc/net/dev")
	if err != nil {
		return 0, 0
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := sc.Text()
		name, rest, ok := strings.Cut(line, ":")
		if !ok {
			continue
		}
		if strings.TrimSpace(name) == "lo" {
			continue
		}
		fields := strings.Fields(rest)
		if len(fields) < 9 {
			continue
		}
		r, _ := strconv.ParseUint(fields[0], 10, 64)
		t, _ := strconv.ParseUint(fields[8], 10, 64)
		rx += r
		tx += t
	}
	return rx, tx
}

func round1(f float64) float64 {
	return float64(int64(f*10+0.5)) / 10
}
