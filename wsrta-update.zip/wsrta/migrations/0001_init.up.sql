BEGIN;


CREATE TABLE users (
    id            BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    email         TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL CHECK (role IN ('admin', 'client')),
    status        TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);


CREATE TABLE clients (
    id                 BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    user_id            BIGINT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    name               TEXT NOT NULL,
    lxc_container_name TEXT NOT NULL UNIQUE,
    cpu_limit          NUMERIC(4, 2) NOT NULL DEFAULT 1.0,   
    ram_limit_mb       INTEGER NOT NULL DEFAULT 512,
    disk_quota_mb      INTEGER NOT NULL DEFAULT 5120,
    status             TEXT NOT NULL DEFAULT 'provisioning'
                         CHECK (status IN ('provisioning', 'active', 'suspended', 'deprovisioning', 'deleted')),
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE domains (
    id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    client_id   BIGINT NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    fqdn        TEXT NOT NULL UNIQUE,
    docroot     TEXT NOT NULL,
    php_version TEXT NOT NULL DEFAULT '8.3',
    ssl_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_domains_client_id ON domains(client_id);


CREATE TABLE databases (
    id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    client_id  BIGINT NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    db_name    TEXT NOT NULL,
    db_user    TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (client_id, db_name)
);
CREATE INDEX idx_databases_client_id ON databases(client_id);

CREATE TABLE dns_records (
    id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    domain_id  BIGINT NOT NULL REFERENCES domains(id) ON DELETE CASCADE,
    type       TEXT NOT NULL CHECK (type IN ('A', 'AAAA', 'CNAME', 'MX', 'TXT', 'NS')),
    name       TEXT NOT NULL,
    content    TEXT NOT NULL,
    ttl        INTEGER NOT NULL DEFAULT 3600,
    prio       INTEGER,                                       
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_dns_records_domain_id ON dns_records(domain_id);

CREATE TABLE cron_jobs (
    id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    client_id  BIGINT NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    schedule   TEXT NOT NULL,                                 
    command    TEXT NOT NULL,
    enabled    BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_cron_jobs_client_id ON cron_jobs(client_id);

CREATE TABLE ssl_certs (
    id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    domain_id  BIGINT NOT NULL REFERENCES domains(id) ON DELETE CASCADE,
    issuer     TEXT,
    expires_at TIMESTAMPTZ,
    status     TEXT NOT NULL DEFAULT 'pending'
                 CHECK (status IN ('pending', 'active', 'expired', 'failed', 'revoked')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_ssl_certs_domain_id ON ssl_certs(domain_id);



CREATE TABLE actions (
    id           BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    type         TEXT NOT NULL,
    payload      JSONB NOT NULL DEFAULT '{}'::jsonb,
    status       TEXT NOT NULL DEFAULT 'pending'
                   CHECK (status IN ('pending', 'running', 'done', 'failed')),
    result       TEXT,
    requested_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
    started_at   TIMESTAMPTZ,
    finished_at  TIMESTAMPTZ
);


CREATE INDEX idx_actions_pending ON actions(created_at) WHERE status = 'pending';

COMMIT;
