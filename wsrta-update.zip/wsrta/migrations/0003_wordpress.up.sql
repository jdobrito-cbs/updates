BEGIN;


CREATE TABLE wordpress_installs (
    id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    domain_id  BIGINT NOT NULL REFERENCES domains(id) ON DELETE CASCADE,
    path       TEXT NOT NULL DEFAULT '', 
    admin_user TEXT NOT NULL,
    db_name    TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (domain_id, path)
);
CREATE INDEX idx_wordpress_installs_domain ON wordpress_installs(domain_id);

COMMIT;
