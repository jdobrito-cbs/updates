DROP TABLE IF EXISTS bandwidth_client_daily;
ALTER TABLE clients DROP COLUMN IF EXISTS bandwidth_limit_mb;
