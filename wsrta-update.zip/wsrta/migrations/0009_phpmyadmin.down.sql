BEGIN;
ALTER TABLE clients DROP COLUMN IF EXISTS phpmyadmin_enabled;
COMMIT;
