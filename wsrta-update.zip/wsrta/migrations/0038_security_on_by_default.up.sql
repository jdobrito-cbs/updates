BEGIN;







ALTER TABLE settings ALTER COLUMN sec_modsecurity SET DEFAULT TRUE;
ALTER TABLE settings ALTER COLUMN sec_csf         SET DEFAULT TRUE;
ALTER TABLE settings ALTER COLUMN sec_fail2ban    SET DEFAULT TRUE;


UPDATE settings
   SET sec_modsecurity = TRUE, sec_csf = TRUE, sec_fail2ban = TRUE, sec_ssl_autorenew = TRUE
 WHERE id = 1;

COMMIT;
