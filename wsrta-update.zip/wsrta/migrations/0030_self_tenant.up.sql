





ALTER TABLE clients ADD COLUMN owner_user_id BIGINT REFERENCES users(id) ON DELETE SET NULL;
CREATE INDEX idx_clients_owner_user_id ON clients(owner_user_id) WHERE owner_user_id IS NOT NULL;


ALTER TABLE resellers ADD COLUMN max_clients INTEGER NOT NULL DEFAULT 0;
