


ALTER TABLE domains ADD COLUMN offline_mode TEXT NOT NULL DEFAULT ''
    CHECK (offline_mode IN ('', 'maintenance', 'suspended'));
