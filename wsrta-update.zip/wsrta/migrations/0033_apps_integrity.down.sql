DROP INDEX IF EXISTS uq_app_installs_docker_port;
DROP INDEX IF EXISTS uq_app_installs_slug;
ALTER TABLE app_installs DROP CONSTRAINT IF EXISTS app_installs_domain_id_fkey;
ALTER TABLE app_installs
  ADD CONSTRAINT app_installs_domain_id_fkey
  FOREIGN KEY (domain_id) REFERENCES domains(id) ON DELETE SET NULL;
