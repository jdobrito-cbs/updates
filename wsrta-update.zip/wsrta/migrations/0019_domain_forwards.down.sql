DROP TABLE IF EXISTS domain_forwards;
