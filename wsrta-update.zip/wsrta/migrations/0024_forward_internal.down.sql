ALTER TABLE domain_forwards DROP COLUMN IF EXISTS target_domain_id;
