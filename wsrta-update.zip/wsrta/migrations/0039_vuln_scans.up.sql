BEGIN;




CREATE TABLE vuln_scans (
    id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    
    client_id   BIGINT REFERENCES clients(id) ON DELETE CASCADE,
    status      TEXT NOT NULL DEFAULT 'pending'
                  CHECK (status IN ('pending', 'running', 'done', 'failed')),
    high        INT NOT NULL DEFAULT 0,
    medium      INT NOT NULL DEFAULT 0,
    low         INT NOT NULL DEFAULT 0,
    info        INT NOT NULL DEFAULT 0,
    summary     TEXT NOT NULL DEFAULT '',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at TIMESTAMPTZ
);
CREATE INDEX idx_vuln_scans_client ON vuln_scans(client_id, id DESC);

CREATE TABLE vuln_findings (
    id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    scan_id     BIGINT NOT NULL REFERENCES vuln_scans(id) ON DELETE CASCADE,
    fqdn        TEXT NOT NULL DEFAULT '',
    severity    TEXT NOT NULL CHECK (severity IN ('high', 'medium', 'low', 'info')),
    category    TEXT NOT NULL DEFAULT '',
    title       TEXT NOT NULL,
    detail      TEXT NOT NULL DEFAULT '',
    remediation TEXT NOT NULL DEFAULT ''
);
CREATE INDEX idx_vuln_findings_scan ON vuln_findings(scan_id, id);


ALTER TABLE clients ADD COLUMN vuln_schedule  TEXT NOT NULL DEFAULT ''
    CHECK (vuln_schedule IN ('', 'daily', 'weekly'));
ALTER TABLE clients ADD COLUMN last_vuln_scan TIMESTAMPTZ;

COMMIT;
