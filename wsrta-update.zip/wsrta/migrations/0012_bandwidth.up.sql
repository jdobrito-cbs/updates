BEGIN;

CREATE TABLE bandwidth_daily (
    day      DATE   PRIMARY KEY,
    rx_bytes BIGINT NOT NULL DEFAULT 0,
    tx_bytes BIGINT NOT NULL DEFAULT 0
);
COMMIT;
