BEGIN;




ALTER TABLE users ADD COLUMN tokens_invalidated_at TIMESTAMPTZ;

COMMIT;
