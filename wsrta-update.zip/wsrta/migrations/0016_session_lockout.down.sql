ALTER TABLE settings DROP COLUMN IF EXISTS lockout_minutes;
ALTER TABLE settings DROP COLUMN IF EXISTS max_login_attempts;
ALTER TABLE users DROP COLUMN IF EXISTS session_timeout_minutes;
