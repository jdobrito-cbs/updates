ALTER TABLE clients DROP COLUMN IF EXISTS phppgadmin_enabled;
ALTER TABLE clients DROP COLUMN IF EXISTS postgres_enabled;
ALTER TABLE databases DROP COLUMN IF EXISTS engine;
