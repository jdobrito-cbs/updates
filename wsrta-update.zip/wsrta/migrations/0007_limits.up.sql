BEGIN;


ALTER TABLE settings ADD COLUMN max_domains_per_client   INT NOT NULL DEFAULT 0;
ALTER TABLE settings ADD COLUMN max_databases_per_client INT NOT NULL DEFAULT 0;

ALTER TABLE clients ADD COLUMN max_domains   INT NOT NULL DEFAULT 0;
ALTER TABLE clients ADD COLUMN max_databases INT NOT NULL DEFAULT 0;

COMMIT;
