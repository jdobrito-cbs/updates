BEGIN;
DROP TABLE IF EXISTS security_events;
COMMIT;
