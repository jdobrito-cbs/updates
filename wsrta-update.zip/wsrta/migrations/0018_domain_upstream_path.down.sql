ALTER TABLE domains DROP COLUMN IF EXISTS upstream_path;
