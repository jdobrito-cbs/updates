BEGIN;
ALTER TABLE users DROP COLUMN IF EXISTS tokens_invalidated_at;
COMMIT;
