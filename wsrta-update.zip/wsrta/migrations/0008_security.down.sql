BEGIN;
ALTER TABLE settings DROP COLUMN IF EXISTS sec_ssl_autorenew;
ALTER TABLE settings DROP COLUMN IF EXISTS sec_fail2ban;
ALTER TABLE settings DROP COLUMN IF EXISTS sec_csf;
ALTER TABLE settings DROP COLUMN IF EXISTS sec_modsecurity;
COMMIT;
