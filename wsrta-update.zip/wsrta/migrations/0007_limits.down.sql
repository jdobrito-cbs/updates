BEGIN;
ALTER TABLE clients DROP COLUMN IF EXISTS max_databases;
ALTER TABLE clients DROP COLUMN IF EXISTS max_domains;
ALTER TABLE settings DROP COLUMN IF EXISTS max_databases_per_client;
ALTER TABLE settings DROP COLUMN IF EXISTS max_domains_per_client;
COMMIT;
