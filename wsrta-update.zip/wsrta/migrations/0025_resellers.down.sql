DROP INDEX IF EXISTS idx_clients_reseller;
ALTER TABLE clients DROP COLUMN IF EXISTS reseller_id;
DROP TABLE IF EXISTS resellers;
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_role_check;
ALTER TABLE users ADD CONSTRAINT users_role_check CHECK (role IN ('admin', 'client'));
