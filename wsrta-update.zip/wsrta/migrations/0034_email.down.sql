DROP TABLE IF EXISTS mailboxes;
ALTER TABLE domains  DROP COLUMN IF EXISTS email_enabled;
ALTER TABLE packages DROP COLUMN IF EXISTS max_mailboxes;
ALTER TABLE clients  DROP COLUMN IF EXISTS max_mailboxes;
ALTER TABLE settings DROP COLUMN IF EXISTS mailcow_api_key;
ALTER TABLE settings DROP COLUMN IF EXISTS mailcow_url;
