BEGIN;
ALTER TABLE clients DROP COLUMN IF EXISTS fast_nginx_enabled;
COMMIT;
