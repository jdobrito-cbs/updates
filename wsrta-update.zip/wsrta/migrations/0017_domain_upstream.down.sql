ALTER TABLE domains DROP COLUMN IF EXISTS upstream_port;
ALTER TABLE domains DROP COLUMN IF EXISTS upstream_ip;
