BEGIN;
ALTER TABLE clients DROP COLUMN IF EXISTS last_vuln_scan;
ALTER TABLE clients DROP COLUMN IF EXISTS vuln_schedule;
DROP TABLE IF EXISTS vuln_findings;
DROP TABLE IF EXISTS vuln_scans;
COMMIT;
