BEGIN;


CREATE TABLE site_rules (
    domain_id BIGINT PRIMARY KEY REFERENCES domains(id) ON DELETE CASCADE,
    config    JSONB NOT NULL DEFAULT '{}'
);
COMMIT;
