



CREATE TABLE packages (
    id                 BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    reseller_id        BIGINT REFERENCES resellers(id) ON DELETE CASCADE,
    name               TEXT NOT NULL,
    price_cents        BIGINT NOT NULL DEFAULT 0,
    cpu_limit          DOUBLE PRECISION NOT NULL DEFAULT 1,
    ram_limit_mb       INTEGER NOT NULL DEFAULT 1024,
    disk_quota_mb      INTEGER NOT NULL DEFAULT 10240,
    max_domains        INTEGER NOT NULL DEFAULT 0,
    max_databases      INTEGER NOT NULL DEFAULT 0,
    bandwidth_limit_mb BIGINT NOT NULL DEFAULT 0,
    duration_days      INTEGER NOT NULL DEFAULT 30,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_packages_reseller ON packages(reseller_id);


ALTER TABLE clients ADD COLUMN package_id BIGINT REFERENCES packages(id) ON DELETE SET NULL;
ALTER TABLE clients ADD COLUMN expires_at TIMESTAMPTZ;
