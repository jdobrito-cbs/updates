ALTER TABLE clients DROP COLUMN IF EXISTS power_state;
