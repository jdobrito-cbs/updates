


ALTER TABLE settings ADD COLUMN mp_access_token TEXT NOT NULL DEFAULT '';
ALTER TABLE resellers ADD COLUMN mp_access_token TEXT NOT NULL DEFAULT '';

CREATE TABLE orders (
    id               BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    reseller_id      BIGINT REFERENCES resellers(id) ON DELETE SET NULL, 
    package_id       BIGINT REFERENCES packages(id) ON DELETE SET NULL,
    buyer_email      TEXT NOT NULL,
    amount_cents     BIGINT NOT NULL DEFAULT 0,
    status           TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'failed')),
    mp_preference_id TEXT NOT NULL DEFAULT '',
    mp_payment_id    TEXT NOT NULL DEFAULT '',
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_orders_reseller ON orders(reseller_id);
CREATE INDEX idx_orders_pref ON orders(mp_preference_id);
