BEGIN;



CREATE TABLE security_events (
    id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    event_type TEXT NOT NULL,          
    severity   TEXT NOT NULL DEFAULT 'low'
                 CHECK (severity IN ('high', 'medium', 'low', 'info')),
    ip         TEXT NOT NULL DEFAULT '',
    email      TEXT NOT NULL DEFAULT '',
    user_agent TEXT NOT NULL DEFAULT '',
    detail     TEXT NOT NULL DEFAULT '',
    blocked    BOOLEAN NOT NULL DEFAULT FALSE, 
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_security_events_id ON security_events(id DESC);
CREATE INDEX idx_security_events_ip ON security_events(ip, created_at DESC);

COMMIT;
