ALTER TABLE clients DROP COLUMN IF EXISTS phpmyadmin_password;
ALTER TABLE clients DROP COLUMN IF EXISTS phppgadmin_password;
