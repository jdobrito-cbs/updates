DROP TABLE IF EXISTS app_installs;
DROP TABLE IF EXISTS app_allowed;
