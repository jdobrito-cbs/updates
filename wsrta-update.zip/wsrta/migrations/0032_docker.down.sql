ALTER TABLE clients DROP COLUMN IF EXISTS docker_enabled;
