BEGIN;
DROP TABLE IF EXISTS bandwidth_daily;
COMMIT;
