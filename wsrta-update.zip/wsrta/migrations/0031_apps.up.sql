










CREATE TABLE app_allowed (
    id          BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    audience    TEXT NOT NULL CHECK (audience IN ('resellers', 'admin_clients', 'reseller_clients')),
    reseller_id BIGINT REFERENCES resellers(id) ON DELETE CASCADE, 
    app_slug    TEXT NOT NULL
);


CREATE UNIQUE INDEX uq_app_allowed_admin ON app_allowed (audience, app_slug) WHERE reseller_id IS NULL;
CREATE UNIQUE INDEX uq_app_allowed_reseller ON app_allowed (audience, reseller_id, app_slug) WHERE reseller_id IS NOT NULL;




CREATE TABLE app_installs (
    id             BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    client_id      BIGINT NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    app_slug       TEXT NOT NULL,
    kind           TEXT NOT NULL CHECK (kind IN ('php', 'docker')),
    domain_id      BIGINT REFERENCES domains(id) ON DELETE SET NULL, 
    path           TEXT NOT NULL DEFAULT '',
    db_name        TEXT NOT NULL DEFAULT '',
    container_name TEXT NOT NULL DEFAULT '', 
    host_port      INTEGER NOT NULL DEFAULT 0,
    status         TEXT NOT NULL DEFAULT 'installing',
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_app_installs_client ON app_installs(client_id);
