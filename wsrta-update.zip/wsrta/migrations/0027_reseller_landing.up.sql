


ALTER TABLE resellers ADD COLUMN slug TEXT NOT NULL DEFAULT '';
ALTER TABLE resellers ADD COLUMN landing_template TEXT NOT NULL DEFAULT 'aurora';
ALTER TABLE resellers ADD COLUMN landing_headline TEXT NOT NULL DEFAULT '';
ALTER TABLE resellers ADD COLUMN landing_subtitle TEXT NOT NULL DEFAULT '';
ALTER TABLE resellers ADD COLUMN external_site_url TEXT NOT NULL DEFAULT '';
CREATE UNIQUE INDEX idx_resellers_slug ON resellers(slug) WHERE slug <> '';
