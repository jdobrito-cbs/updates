



ALTER TABLE domain_forwards
  ADD COLUMN target_domain_id BIGINT REFERENCES domains(id) ON DELETE CASCADE;
