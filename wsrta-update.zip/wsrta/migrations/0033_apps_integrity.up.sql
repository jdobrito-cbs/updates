




ALTER TABLE app_installs DROP CONSTRAINT IF EXISTS app_installs_domain_id_fkey;
ALTER TABLE app_installs
  ADD CONSTRAINT app_installs_domain_id_fkey
  FOREIGN KEY (domain_id) REFERENCES domains(id) ON DELETE CASCADE;



CREATE UNIQUE INDEX uq_app_installs_slug ON app_installs(client_id, app_slug) WHERE status <> 'failed';



CREATE UNIQUE INDEX uq_app_installs_docker_port ON app_installs(host_port) WHERE kind = 'docker' AND host_port <> 0;
