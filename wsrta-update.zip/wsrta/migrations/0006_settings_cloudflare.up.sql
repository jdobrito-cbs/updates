BEGIN;


CREATE TABLE settings (
    id                      INT PRIMARY KEY DEFAULT 1,
    session_timeout_minutes INT NOT NULL DEFAULT 60,
    panel_domain            TEXT NOT NULL DEFAULT '',
    CONSTRAINT settings_singleton CHECK (id = 1)
);
INSERT INTO settings (id) VALUES (1) ON CONFLICT DO NOTHING;




ALTER TABLE clients ADD COLUMN cloudflare_status TEXT NOT NULL DEFAULT '';

COMMIT;
