


ALTER TABLE settings  ADD COLUMN mp_webhook_secret TEXT NOT NULL DEFAULT '';
ALTER TABLE resellers ADD COLUMN mp_webhook_secret TEXT NOT NULL DEFAULT '';
