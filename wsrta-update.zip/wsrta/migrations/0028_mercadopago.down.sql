DROP TABLE IF EXISTS orders;
ALTER TABLE resellers DROP COLUMN IF EXISTS mp_access_token;
ALTER TABLE settings DROP COLUMN IF EXISTS mp_access_token;
