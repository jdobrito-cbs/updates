ALTER TABLE resellers DROP COLUMN IF EXISTS max_clients;
DROP INDEX IF EXISTS idx_clients_owner_user_id;
ALTER TABLE clients DROP COLUMN IF EXISTS owner_user_id;
