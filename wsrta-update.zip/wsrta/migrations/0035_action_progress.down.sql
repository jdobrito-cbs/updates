ALTER TABLE actions DROP COLUMN IF EXISTS progress_stage;
ALTER TABLE actions DROP COLUMN IF EXISTS progress;
