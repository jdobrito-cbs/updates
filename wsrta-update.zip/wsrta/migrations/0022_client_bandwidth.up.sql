
ALTER TABLE clients ADD COLUMN IF NOT EXISTS bandwidth_limit_mb BIGINT NOT NULL DEFAULT 0;


CREATE TABLE bandwidth_client_daily (
    client_id BIGINT NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    day       DATE   NOT NULL,
    rx_bytes  BIGINT NOT NULL DEFAULT 0,
    tx_bytes  BIGINT NOT NULL DEFAULT 0,
    PRIMARY KEY (client_id, day)
);
