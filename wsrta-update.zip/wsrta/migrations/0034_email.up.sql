




ALTER TABLE settings ADD COLUMN mailcow_url     TEXT NOT NULL DEFAULT '';
ALTER TABLE settings ADD COLUMN mailcow_api_key TEXT NOT NULL DEFAULT '';


ALTER TABLE clients  ADD COLUMN max_mailboxes INTEGER NOT NULL DEFAULT 0;
ALTER TABLE packages ADD COLUMN max_mailboxes INTEGER NOT NULL DEFAULT 0;


ALTER TABLE domains ADD COLUMN email_enabled BOOLEAN NOT NULL DEFAULT FALSE;


CREATE TABLE mailboxes (
    id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    domain_id  BIGINT NOT NULL REFERENCES domains(id) ON DELETE CASCADE,
    local_part TEXT NOT NULL,
    quota_mb   INTEGER NOT NULL DEFAULT 1024,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (domain_id, local_part)
);
CREATE INDEX idx_mailboxes_domain ON mailboxes(domain_id);
