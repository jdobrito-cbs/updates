ALTER TABLE domains DROP COLUMN IF EXISTS offline_mode;
