BEGIN;
DROP TABLE IF EXISTS wordpress_installs;
COMMIT;
