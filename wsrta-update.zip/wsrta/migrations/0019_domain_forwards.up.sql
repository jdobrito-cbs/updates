

CREATE TABLE domain_forwards (
    id         BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    domain_id  BIGINT NOT NULL REFERENCES domains(id) ON DELETE CASCADE,
    path       TEXT NOT NULL,   
    target     TEXT NOT NULL,   
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (domain_id, path)
);
CREATE INDEX idx_domain_forwards_domain ON domain_forwards(domain_id);
