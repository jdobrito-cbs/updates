DROP INDEX IF EXISTS idx_resellers_slug;
ALTER TABLE resellers DROP COLUMN IF EXISTS external_site_url;
ALTER TABLE resellers DROP COLUMN IF EXISTS landing_subtitle;
ALTER TABLE resellers DROP COLUMN IF EXISTS landing_headline;
ALTER TABLE resellers DROP COLUMN IF EXISTS landing_template;
ALTER TABLE resellers DROP COLUMN IF EXISTS slug;
