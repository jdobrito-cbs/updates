ALTER TABLE resellers DROP COLUMN IF EXISTS mp_webhook_secret;
ALTER TABLE settings  DROP COLUMN IF EXISTS mp_webhook_secret;
