


ALTER TABLE clients ADD COLUMN power_state TEXT NOT NULL DEFAULT 'running'
    CHECK (power_state IN ('running', 'stopped'));
