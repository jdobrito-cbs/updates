


ALTER TABLE actions ADD COLUMN progress SMALLINT NOT NULL DEFAULT 0
    CHECK (progress >= 0 AND progress <= 100);
ALTER TABLE actions ADD COLUMN progress_stage TEXT NOT NULL DEFAULT '';
