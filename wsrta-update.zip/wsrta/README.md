# WSRTA — Painel de Controle de VPS

Painel de hospedagem **self-hosted** para uso interno. Dois papéis: **admin** (opera o host)
e **cliente** (gerencia só os próprios recursos). Cada cliente é isolado em um **container
LXC/LXD** no host Ubuntu Server.

Serviços gerenciados no MVP: **Web** (Nginx + PHP-FPM por container), **DNS** (PowerDNS +
PostgreSQL), **SSL** (acme.sh / Let's Encrypt), **Banco** (MariaDB por container) e **Cron**.
Email está fora do MVP.

> Arquitetura completa em [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).
> Modelo de segurança em `docs/SECURITY.md` (a partir da Fase 1).

---

## Princípio que rege tudo

A **API web nunca executa comandos de sistema**. Ela valida e **enfileira uma ação** numa
tabela do Postgres; o **daemon orquestrador** (único processo com root) consome a fila,
revalida e executa. Uma falha na API não vira root no host.

---

## Pré-requisitos (dev)

- **Go** 1.26+ (exigido pelo cliente `canonical/lxd`)
- **golang-migrate** (CLI) — aplica as migrations: `go install -tags 'postgres' github.com/golang-migrate/migrate/v4/cmd/migrate@latest`
- **Node** 20+ (npm) — para o frontend
- **Docker** + **docker-compose** — sobe Postgres (painel) e Postgres (PowerDNS) em dev
- **make** (no Windows, via WSL/MSYS2 — ou rode os comandos `go`/`migrate` direto)
- (Produção/Fases 2+) **LXD** instalado no host. Em dev, o daemon pode rodar com o driver
  LXD **fake** via `WSRTA_LXD_DRIVER=fake`.

> A infra de dev em containers cobre só os bancos. O daemon e o LXD precisam do host real —
> nas Fases 1 os executores são stubs e não exigem LXD.

---

## Setup de desenvolvimento

```bash
# 1. dependências Go (gera go.sum + indireas) — necessário na primeira vez
go mod tidy

# 2. variáveis de ambiente
cp .env.example .env          # ajuste segredos/portas se necessário

# 3. sobe os bancos (Postgres do painel + Postgres do PowerDNS)
docker compose -f docker-compose.dev.yml up -d

# 4. aplica as migrations
make migrate-up               # ou: migrate -path migrations -database "$WSRTA_DATABASE_URL" up

# 5. roda a API (sem privilégios) e o daemon (orquestrador) em terminais separados
make run-api
make run-daemon               # em dev: WSRTA_LXD_DRIVER=fake

# 6. frontend (painel admin)
cd web && npm install && npm run dev
```

### Smoke test da API

O **primeiro admin** é semeado com o helper `create-admin` (não há cadastro público):

```bash
go run ./api/cmd/create-admin admin@exemplo.com 'sua-senha'   # ou: make create-admin EMAIL=... PASSWORD=...
# bootstrap de um cliente (cria login + container + enfileira provision):
go run ./api/cmd/create-client cli@exemplo.com 'senha-cliente' 'Cliente 1'
```

Depois:

```bash
# login → token JWT
TOKEN=$(curl -s -XPOST localhost:8080/api/auth/login \
  -H 'content-type: application/json' \
  -d '{"email":"admin@exemplo.com","password":"sua-senha"}' | jq -r .token)

# usa o Bearer
curl -s localhost:8080/api/admin/clients -H "Authorization: Bearer $TOKEN"

# admin cria um cliente (cria o login, o container e enfileira o provisionamento)
curl -s -XPOST localhost:8080/api/admin/clients -H "Authorization: Bearer $TOKEN" \
  -H 'content-type: application/json' \
  -d '{"email":"cli@exemplo.com","password":"senha-cliente","name":"Cliente 1"}'
```

---

## Comandos (Makefile)

| Alvo | O que faz |
|---|---|
| `make migrate-up` / `make migrate-down` | aplica/reverte migrations (golang-migrate) |
| `make run-api` | sobe a API web |
| `make run-daemon` | sobe o daemon orquestrador |
| `make build` | compila os dois binários (`go build ./...`) |
| `make test` | testes unitários (`go test ./...`) |
| `make test-integration` | inclui integração; **serial** (`-p 1`), requer `WSRTA_TEST_DATABASE_URL` |
| `make lint` | `go vet ./...` + `gofmt` |

### Rodar um único teste

```bash
go test ./daemon/internal/executors -run TestProvisionClient -v
```

---

## Estrutura do repositório

```
internal/        # código Go compartilhado entre api e daemon (core, config, db, queue)
api/             # API web (sem root)        — cmd/api
daemon/          # orquestrador (root)        — cmd/daemon
web/             # frontend React + TS (Fase 6)
migrations/      # SQL versionado (golang-migrate)
docs/            # ARCHITECTURE.md, SECURITY.md
```

Detalhes e justificativa do layout (módulo Go único) em
[`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md#8-layout-do-monorepo).

---

## Provisionamento (Fase 2)

`provision_client` lança o container do cliente a partir de uma **imagem golden** LXD
(`wsrta-base`) e aplica limites de CPU/RAM/disco; `deprovision_client` para e destrói.
Os executores são idempotentes e atualizam `clients.status`.

- **Dev**: use o driver fake (`WSRTA_LXD_DRIVER=fake`) — não precisa de LXD.
- **Host Ubuntu**: instale o LXD, construa a imagem golden e use o driver real:

```bash
# no host, uma vez: cria a imagem wsrta-base (nginx+php-fpm+mariadb+cron)
make build-base-image            # = bash scripts/build-base-image.sh

# rode o daemon com o LXD real
WSRTA_LXD_DRIVER=real make run-daemon
```

Ajuste `WSRTA_LXD_STORAGE_POOL`/`WSRTA_LXD_NETWORK` ao seu host. Cota de disco exige
storage pool com quota (zfs/btrfs/lvm).

## Web + SSL (Fase 3)

`add_domain` cria docroot + vhost interno no container e o vhost reverse-proxy (HTTP) no
Nginx do host (proxy → IP atual do container:80, com `location` para o challenge ACME).
`issue_ssl` emite o certificado (acme.sh, **HTTP-01/webroot**) e reescreve o vhost com TLS
(443). `remove_domain` remove os vhosts (preserva o docroot).

- **Dev** (driver fake): Nginx e acme.sh também são fakes in-memory — nada é instalado.
- **Host**: precisa de **Nginx** (com `WSRTA_NGINX_SITES_DIR` incluído no `nginx.conf`) e
  **acme.sh**. Configure `WSRTA_ACME_EMAIL`, `WSRTA_ACME_WEBROOT` e `WSRTA_ACME_STAGING`
  (mantenha `true` em testes para não bater nos limites do Let's Encrypt).

> O reverse-proxy usa o **IP atual** do container. Se ele reiniciar e mudar de IP, re-execute
> `add_domain` para regerar o vhost. DNS-01 (preferido) via PowerDNS chega na Fase 4.

## DB, DNS, Cron (Fase 4)

`create_database` cria o banco + usuário MariaDB no container (via `mysql`, root por
unix_socket) e **gera a senha**, retornada uma única vez no resultado da ação;
`drop_database` remove ambos. `set_dns_record`/`delete_dns_record` escrevem direto no backend
Postgres do **PowerDNS** (criam a zona + SOA/NS na primeira vez). `set_cron`/`remove_cron`
gravam/removem um arquivo em `/etc/cron.d` dentro do container.

- **Dev** (driver fake): o backend PowerDNS é fake in-memory — nada externo é necessário.
- **Host**: PowerDNS com backend PostgreSQL. Aplique o schema uma vez e configure os NS:

```bash
psql "$WSRTA_PDNS_DATABASE_URL" -f deploy/powerdns/schema.sql
# WSRTA_PDNS_PRIMARY_NS / WSRTA_PDNS_HOSTMASTER / WSRTA_CRON_USER
```

> A senha do banco aparece em `actions.result` (entregue uma vez); redação/cifragem desse
> campo é um item de hardening — ver [docs/SECURITY.md](docs/SECURITY.md).

## API + Auth/RBAC (Fase 5)

Endpoints reais sob `/api` com **JWT (Bearer)** e **argon2id**; rate-limit no login. RBAC:
`admin` gerencia clientes/fila/host; `client` gerencia só os próprios recursos, com **posse
checada pelo `client_id` do token** (queries escopadas — a regra de ouro). Cada criação/edição
grava no painel **e** enfileira a ação para o daemon. O endpoint de debug foi removido.

- Admin: `GET/POST/DELETE /api/admin/clients`, `GET /api/admin/actions`, `GET /api/admin/system`.
- Cliente: `/api/domains` (+ `/:id/ssl`), `/api/databases`, `/api/dns/:domain_id/records`,
  `/api/cron`, `/api/stats`.

> O primeiro admin é semeado com `go run ./api/cmd/create-admin <email> <senha>`. Editar um
> registro DNS que mude name/type/content pode deixar o registro antigo no PowerDNS até ser removido.

## Frontend (Fase 6a — admin)

React + TS + Tailwind + Vite, tema **Console** (escuro). Login único → redireciona por role.
Painel admin: **Clientes** (criar → provisiona; remover → desprovisiona), **Fila** (estado das
ações, atualiza sozinha) e **Sistema** (host). A fila de ações é o elemento de identidade
(trilho de status no topo). Auth JWT Bearer (token no `localStorage`). Ver [web/](web/README.md).

> O painel do cliente (Fase 6b) e **suspender/retomar** já estão prontos.

## Migração do CyberPanel (CLI + painel)

Recuperar um site do CyberPanel = importar o backup nativo (`.tar.gz` por site).

```bash
# pela CLI (host):
go run ./api/cmd/wsrta-migrate -dry-run -backup backup-site.tar.gz   # confere
go run ./api/cmd/wsrta-migrate -backup backup-site.tar.gz            # recria o site
```

Pelo **painel admin → Importar**: coloque os `.tar.gz` em `WSRTA_BACKUP_DIR` (no host);
a página lista, faz preview e importa (cria cliente/domínio/banco e devolve o login;
restauração de banco/arquivos vai para a Fila). Staging em `WSRTA_MIGRATE_STAGING`.

## SFTP por cliente

Para clientes que **não** usam WordPress enviarem os arquivos do site. No detalhe do
cliente (admin) → aba **SFTP** → habilitar (usuário + senha = a que você deu ao cliente).
O cliente vê as instruções em **SFTP** no próprio painel. Cada cliente recebe a porta
`WSRTA_SFTP_BASE_PORT + id` em `WSRTA_SFTP_HOST` (proxy do LXD → porta 22 do container;
exige `openssh-server`, já incluído na imagem golden).

## Configurações e Cloudflare Tunnel

- **Admin → Configurações**: tempo de **logoff automático** por inatividade e **domínio do
  painel** (usado como host público, ex.: nas instruções de SFTP).
- **Cloudflare Tunnel por cliente**: na aba/página **Cloudflare**, cola-se o **token do
  conector** (Cloudflare Zero Trust → Tunnels) e o cloudflared do container é configurado e
  iniciado; há **iniciar/parar/reiniciar**. O cliente gerencia o próprio túnel; o **admin
  também** configura pelo detalhe do cliente (ajuda na conexão). O token não é guardado no
  painel — fica só no container.

## Instalação em produção (Ubuntu Server)

Um instalador único prepara o host inteiro (PostgreSQL, LXD + imagem golden, nginx,
acme.sh), **compila** api/daemon/frontend deste repositório, instala os serviços
systemd, roda as migrations e cria o 1º admin. O painel é servido por **HTTPS local**
(certificado self-signed) em `https://<IP-do-servidor>:8443`.

```bash
# como root, na raiz do repositório, no servidor Ubuntu:
sudo ADMIN_EMAIL=admin@exemplo.com ADMIN_PASSWORD='senhaForte' bash scripts/install.sh
# variáveis opcionais: PANEL_PORT (8443), WSRTA_DB_PASS, GO_VERSION, NODE_MAJOR
```

### Pacotes prontos (zip) e atualização

`scripts/make-release.sh` gera dois zips em `dist/` (cada um descompacta em `wsrta/`,
trazendo o código-fonte completo — a **compilação acontece no servidor**):

- **`wsrta-install.zip`** — instalação nova: descompacte, `cd wsrta`, rode `scripts/install.sh`.
- **`wsrta-update.zip`** — atualização **sem apagar banco/configurações**: descompacte na raiz do
  código, `cd wsrta`, rode `scripts/update.sh`. Ele **recompila** api/daemon/frontend, aplica
  **apenas as migrations novas** (rastreadas em `schema_migrations`) e reinicia os serviços;
  preserva `/etc/wsrta/wsrta.env` e o Postgres. Use `--golden` para também reconstruir a imagem LXD.

> Os dois zips são regenerados a cada mudança de código (`bash scripts/make-release.sh`).

Ao final ele imprime a URL do painel e o login do admin. Serviços:
`systemctl status wsrta-api wsrta-daemon` · logs: `journalctl -u wsrta-daemon -f`.
O daemon roda como **root** (toca LXD/nginx/sistema); a API roda como o usuário
**`wsrta`** (sem privilégios), em `127.0.0.1:8080` atrás do nginx — o modelo de
segurança do projeto. Config e segredos em `/etc/wsrta/wsrta.env`.

> Como o LXD só existe no host, o instalador só é validável de fato num Ubuntu real
> (passa por `bash -n` + shellcheck no CI/dev).

## Backup por cliente (admin)

No detalhe do cliente → aba **Backup**: **Fazer backup** (o daemon monta um `.tar.gz`
com os bancos e os arquivos dos sites), **baixar**, **restaurar** (do painel ou de um
arquivo enviado) — a restauração é **sobre o mesmo cliente** (sobrescreve os dados
atuais) — e **agendar** (diário/semanal). Os arquivos ficam em `WSRTA_CLIENT_BACKUP_DIR`
no host. O restore reaproveita as ações `restore_database`/`restore_files`.

## Status do projeto

Desenvolvimento em fases, com revisão ao fim de cada uma:

- [x] **Fase 1 — Fundação**: monorepo, migrations, modelos, fila `actions` com executores stub
- [x] **Fase 2 — Provisionamento**: `provision_client` / `deprovision_client` (LXD real ou fake)
- [x] **Fase 3 — Web + SSL**: `add_domain` / `remove_domain` / `issue_ssl` (HTTP-01)
- [x] **Fase 4 — DB, DNS, Cron**: `create_database`/`drop_database`, `set_dns_record`/`delete_dns_record` (PowerDNS), `set_cron`/`remove_cron`
- [x] **Fase 4b — WordPress**: install/remove por cliente (raiz ou subpasta) via wp-cli, DB dedicado, painel próprio
- [x] **Fase 5 — API completa + Auth/RBAC**
- [x] **Fase 6a — Frontend admin**: login + painel admin (clientes, fila, sistema)
- [x] **Round extra**: 2FA obrigatório (TOTP+recovery), admin gerencia recursos de cada cliente, CRUD de clientes (busca/edição), UI com ícones, **suspender/retomar cliente**
- [x] **Fase 6b — Frontend cliente**: domínios, DNS, bancos, SSL, cron, stats (mesmos painéis, `root=/api`)
- [x] **Fase 7 — Migrador CyberPanel**: pacote `api/internal/migrate` + CLI `wsrta-migrate` + **restore pelo painel admin** (página "Importar": lista/preview/importa backups de `WSRTA_BACKUP_DIR`). Parser confirmado em backup real. Falta testar a restauração no host com LXD.
- [x] **SFTP por cliente**: admin habilita SFTP (envio de arquivos sem WordPress); cliente vê as instruções de acesso (host/porta/usuário; senha = a que lhe foi informada).
- [x] **Backup por cliente** (admin): fazer backup, baixar, restaurar (do painel ou de arquivo enviado) **sobre o cliente existente**, e agendar (diário/semanal). Restore reusa `restore_database`/`restore_files`.
- [x] **Modais próprios**: todas as confirmações usam um modal no tema Console (`useConfirm`), não mais o `window.confirm` do navegador.
- [x] **Configurações do sistema** (admin): logoff automático (inatividade) + domínio do painel.
- [x] **Cloudflare Tunnel por cliente**: token + iniciar/parar/reiniciar (cliente e admin).
- [x] **Instalador (VPS/servidor)**: `scripts/install.sh` (Ubuntu) — compila no servidor, painel por HTTPS local (IP:porta), systemd.

> **Painel de gerenciamento web concluído.** O que falta é a validação real no host Ubuntu
> com LXD (provisionamento, WordPress, restauração, SFTP, backup, cloudflared).

### Expansão (em andamento)
- [x] **Limites por cliente**: máximo de domínios e bancos. Padrão global em **Configurações**
  (0 = ilimitado) + override por cliente no cadastro/edição. Bloqueia a criação ao atingir.
- [x] **Segurança (admin)**: página **Segurança** com toggles ModSecurity (WAF), CSF+LFD
  (firewall+brute-force), fail2ban e renovação automática de SSL — aplicados no host pelo daemon.
- [x] **File Manager**: admin = servidor inteiro (menu **Arquivos**); cliente = sandbox no
  `/var/www` dele. Upload/download, criar/renomear/mover/copiar/excluir arquivos e pastas.
  Serviço de arquivos síncrono no daemon (a API só autoriza/faz proxy).
- [x] **phpMyAdmin por cliente**: habilita um phpMyAdmin (no host) que abre já no contexto do
  cliente (vê só os bancos dele). Cliente e admin. (Funciona no host real.)
- [x] **Módulo `.htaccess`** (equivalente em nginx): por domínio, editor de **PHP directives**
  (→ `.user.ini`), **headers de segurança** e **CORS** (→ vhost do container, validado com `nginx -t`).
- [x] **Fast nginx por cliente** (admin): liga aceleração (gzip + cache de descritores) nos
  sites do cliente, deixando-os mais rápidos. Toggle no detalhe do cliente.
- [x] **WordPress Manager Pro** (cliente/admin): por instalação, gerencia plugins
  (ativar/desativar/atualizar/excluir/instalar), temas e atualização do core — via wp-cli
  síncrono no container (a API monta os comandos de uma whitelist; sem wp-cli arbitrário).
- [x] **Dashboard** (admin): IP do servidor, total de domínios/bancos/WordPress e gráficos de
  barra de domínios e bancos **por cliente**.
- [x] **Monitoramento** (admin): uso de CPU/memória/disco em tempo real (linha 0–100% + donuts),
  SO (nome/tipo/kernel/versão) e placa de rede (IP/máscara/gateway/DNS), banda em tempo real e
  por dia, e botões para **atualizar o SO** (apt) e **o painel** (update.sh). Cliente vê só os
  donuts de CPU/memória/disco.
- [x] **Reiniciar serviços da VPS** (admin, em Configurações): nginx, API, daemon, PostgreSQL e
  PowerDNS — via whitelist no daemon.
- [x] **Política de domínios/DNS**: o **cliente** não cria/exclui domínios nem administra DNS
  (exclusivo do **admin**); ele só **gerencia** os domínios criados para ele (SSL + regras) e
  instala WordPress só nos domínios dele. O admin cria domínios, administra DNS e instala WP em
  qualquer domínio.
- [x] **Tema claro/escuro** (padrão escuro, persistido) e **layout responsivo**: barra lateral
  com grupos recolhíveis, **recolhimento automático em celular/tablet** (drawer ≤1100px) e
  página **Sobre** (admin e cliente).
- [x] **Energia da VPS** (start/stop/restart do container): o **cliente** liga/desliga/reinicia a
  própria VPS (na Visão geral); o **revendedor**, a VPS dos clientes dele (botões na lista de
  clientes); o **admin**, a de qualquer cliente (aba Visão geral do detalhe do cliente). Ação
  `power_client` — só controla a energia, não altera o status administrativo (suspenso/ativo).
- [x] **Exclusão em cascata**: ao o admin **excluir um revendedor**, **todos os clientes da
  revenda** são desprovisionados antes (container + dados removidos), inclusive a **VPS pessoal**
  da revenda. Excluir um cliente (admin ou revenda) já desprovisiona tudo dele.
- [x] **Apps (catálogo, VPS Completo)**: instala apps por VPS. **phpBB** entra como app PHP num
  domínio (baixa + cria o banco; conclua o assistente em `/install`). **Liberação em camadas**:
  o **admin** escolhe quais apps as **revendas** e seus **clientes diretos** veem; a **revenda**
  escolhe quais (dentre os liberados pelo admin) os **clientes dela** veem.
- [x] **Home estilo cPanel** (cliente): a **Visão geral** ganhou uma **grade de atalhos** por
  seção (Hospedagem, E-mail, Bancos, Arquivos, Avançado) além dos donuts de recursos e da energia.
- [x] **mailcow no instalador (opcional)**: `INSTALL_MAILCOW=yes MAILCOW_HOSTNAME=mail.seu.dominio
  sudo -E bash scripts/install.sh` instala e sobe o mailcow no host (web em 8080/8443 p/ não
  colidir com o painel); depois o admin cola URL + API key em Configurações. Desligado por padrão.
- [x] **Revenda = admin pleno dos clientes dela**: a revenda agora tem uma **página de detalhe**
  do cliente com os **mesmos painéis do admin** (domínios, DNS, bancos, WordPress, linguagens,
  SFTP, backup, Cloudflare, arquivos, cron, apps, Docker, e-mail, energia) — escopada por posse
  (`ResellerOwnsClient`). Backend: `mountClientResources` espelha as rotas `/admin/clients/{id}`
  em `/reseller/clients/{id}`.
- [x] **E-mail próprio (VPS Completo)**: servidor de e-mail **mailcow** compartilhado no host. O
  admin configura a URL + API key (em Configurações). Cada **domínio** liga/desliga o e-mail
  (cria o domínio no mailcow + MX/SPF/DKIM/DMARC no DNS) e ganha **caixas** com **cota** definida
  pelo admin por cliente, por pacote e por revenda (uso próprio). Webmail integrado (SOGo).
- [x] **Docker por cliente (VPS Completo)**: o dono da VPS **habilita o Docker** (opt-in; liga o
  `security.nesting` no container e inicia o dockerd) e ganha um **painel Docker** para
  iniciar/parar/reiniciar/remover containers. **n8n** e **Evolution API** instalam pela aba Apps
  como containers Docker (expostos por uma porta do host). Isolamento por padrão: o Docker fica
  desligado até o dono habilitar.
- [x] **Autogestão (Minha VPS)**: o **admin** e o **revendedor** têm uma área igual à do cliente
  para gerenciar um container **próprio** (domínios, DNS, bancos, WordPress, SFTP, Cloudflare,
  arquivos, cron, backup, runtimes, energia) — controle total. A VPS pessoal é criada e
  provisionada **automaticamente no cadastro** (a da revenda com os limites que o admin definiu).
  O **admin define os limites da revenda** (CPU/RAM/disco/domínios/bancos/banda + **máximo de
  clientes**) no cadastro/edição; ajustar limites redimensiona o container a quente (`apply_limits`).
  Isolamento total: a VPS pessoal é resolvida pelo dono no token, fica escondida das listas de
  clientes e ninguém alcança a de outro.
