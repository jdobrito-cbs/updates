
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      screens: {
        
        desk: '1100px',
      },
      colors: {
        
        base: 'rgb(var(--c-base) / <alpha-value>)',
        panel: 'rgb(var(--c-panel) / <alpha-value>)',
        elevated: 'rgb(var(--c-elevated) / <alpha-value>)',
        line: 'rgb(var(--c-line) / <alpha-value>)',
        ink: 'rgb(var(--c-ink) / <alpha-value>)',
        muted: 'rgb(var(--c-muted) / <alpha-value>)',
        faint: 'rgb(var(--c-faint) / <alpha-value>)',
        accent: 'rgb(var(--c-accent) / <alpha-value>)',
        accentStrong: 'rgb(var(--c-accent-strong) / <alpha-value>)',
        onAccent: 'rgb(var(--c-on-accent) / <alpha-value>)',
        
        pending: 'rgb(var(--c-pending) / <alpha-value>)',
        running: 'rgb(var(--c-running) / <alpha-value>)',
        done: 'rgb(var(--c-done) / <alpha-value>)',
        failed: 'rgb(var(--c-failed) / <alpha-value>)',
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'system-ui', 'sans-serif'],
        sans: ['"IBM Plex Sans"', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'ui-monospace', 'monospace'],
      },
      borderColor: {
        DEFAULT: 'rgb(var(--c-line) / <alpha-value>)',
      },
      keyframes: {
        pulsering: {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.35' },
        },
      },
      animation: {
        pulsering: 'pulsering 1.4s ease-in-out infinite',
      },
    },
  },
  plugins: [],
}
