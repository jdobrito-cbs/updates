# web — Frontend (React + TS + Tailwind + Vite)

Painel do WSRTA. Tema **Console** (escuro, status-forward); a fila de ações é o elemento de
identidade. Auth por **JWT Bearer** (token no `localStorage`, enviado no header).

- **Fase 6a (feito)**: login único + **painel admin** (clientes, fila de ações, sistema).
- **Fase 6b (a fazer)**: painel do cliente (domínios, editor de DNS, bancos, SSL, cron, stats).

## Rodar

```bash
npm install
npm run dev        # http://localhost:5173 ; /api é redirecionado para localhost:8080
```

Em produção o frontend é servido pelo mesmo Nginx que expõe `/api` (same-origin). Para apontar
para outra base, defina `VITE_API_BASE_URL`.

## Scripts

| Script | O que faz |
|---|---|
| `npm run dev` | servidor de desenvolvimento (proxy `/api` → API Go) |
| `npm run build` | `tsc --noEmit` + `vite build` (gera `dist/`) |
| `npm run typecheck` | só checagem de tipos |
| `npm run preview` | serve o build de produção |

## Estrutura (`src/`)

```
api/        client HTTP tipado, tipos, hooks (React Query + polling)
auth/       AuthContext (token/role/client_id) + RequireRole
components/  AppShell, StatusRail (assinatura), ActionStatus, ui/*
pages/      Login, admin/*, client/* (placeholder 6b)
lib/        cn, format
```
