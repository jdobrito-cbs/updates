export type Role = 'admin' | 'reseller' | 'client'

export type ActionStatusValue = 'pending' | 'running' | 'done' | 'failed'


export type LoginStage =
  | { stage: 'enroll'; token: string; otpauth_url: string; secret: string }
  | { stage: 'mfa'; token: string }


export interface SessionResponse {
  stage: 'done'
  token: string
  role: Role
  client_id: number | null
  recovery_codes?: string[]
  session_timeout_minutes?: number
}

export interface Me {
  user_id: number
  role: Role
  client_id: number | null
  session_timeout_minutes?: number
}

export interface Client {
  id: number
  user_id: number
  name: string
  lxc_container_name: string
  cpu_limit: number
  ram_limit_mb: number
  disk_quota_mb: number
  status: string
  max_domains: number
  max_databases: number
  max_mailboxes: number
  phpmyadmin_enabled: boolean
  fast_nginx_enabled: boolean
  created_at: string
  online: boolean
  last_seen?: string
  session_timeout_minutes: number
  bandwidth_limit_mb: number
  vuln_schedule?: string
}

export interface Action {
  id: number
  type: string
  status: ActionStatusValue
  result: string | null
  requested_by: number | null
  created_at: string
  started_at: string | null
  finished_at: string | null
  
  progress: number
  progress_stage?: string
}

export interface SystemStats {
  loadavg?: { '1m': string; '5m': string; '15m': string }
  memory_kb?: { total?: number; available?: number }
}



export interface Domain {
  id: number
  client_id: number
  fqdn: string
  docroot: string
  php_version: string
  ssl_enabled: boolean
  created_at: string
  upstream_ip: string
  upstream_port: number
  upstream_path: string
  offline_mode?: string 
}

export interface Database {
  id: number
  client_id: number
  db_name: string
  db_user: string
  engine: string
  created_at: string
}

export interface DNSRecord {
  id: number
  domain_id: number
  type: string
  name: string
  content: string
  ttl: number
  prio: number | null
  created_at: string
}

export interface CronJob {
  id: number
  client_id: number
  schedule: string
  command: string
  enabled: boolean
  created_at: string
}
