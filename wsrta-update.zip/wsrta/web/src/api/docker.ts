import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'

import { api } from './client'

export interface DockerContainer {
  name: string
  state: string
  image: string
  ports: string
}

export interface DockerInfo {
  enabled: boolean
  containers: DockerContainer[] | null
}



export function useDocker(root: string) {
  return useQuery({
    queryKey: [root, 'docker'],
    queryFn: () => api.get<DockerInfo>(`${root}/docker`),
    refetchInterval: 8000,
  })
}

export function useEnableDocker(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: () => api.post<{ action_id: number }>(`${root}/docker/enable`, {}),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'docker'] }),
  })
}

export function useDisableDocker(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: () => api.post<{ action_id: number }>(`${root}/docker/disable`, {}),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'docker'] }),
  })
}

export function useDockerControl(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (b: { op: 'start' | 'stop' | 'restart' | 'remove'; name: string }) =>
      api.post<{ ok: boolean }>(`${root}/docker/control`, b),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'docker'] }),
  })
}
