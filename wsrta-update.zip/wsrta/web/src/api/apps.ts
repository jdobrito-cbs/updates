import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'

import { api } from './client'

export interface CatalogApp {
  slug: string
  name: string
  kind: string 
  description: string
  docker_image?: string
  docker_port?: number
}

export interface AppInstall {
  id: number
  client_id: number
  app_slug: string
  kind: string
  domain_id?: number
  fqdn?: string
  path: string
  db_name: string
  container_name: string
  host_port: number
  status: string
  created_at: string
}

export interface AppsInfo {
  catalog: CatalogApp[] | null
  installed: AppInstall[] | null
}



export function useApps(root: string) {
  return useQuery({
    queryKey: [root, 'apps'],
    queryFn: () => api.get<AppsInfo>(`${root}/apps`),
  })
}

export function useInstallApp(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (b: { app_slug: string; domain_id?: number; path?: string }) =>
      api.post<{ install: AppInstall; action_id: number }>(`${root}/apps`, b),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'apps'] }),
  })
}

export function useRemoveApp(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.del<{ action_id: number }>(`${root}/apps/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'apps'] }),
  })
}


export function useUpdateApp(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.post<{ action_id: number }>(`${root}/apps/${id}/update`),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'apps'] }),
  })
}


export interface AdminAppPerms {
  catalog: CatalogApp[]
  resellers: string[]
  admin_clients: string[]
}

export function useAdminAppPerms() {
  return useQuery({
    queryKey: ['admin', 'app-perms'],
    queryFn: () => api.get<AdminAppPerms>('/api/admin/apps'),
  })
}

export function useSetAdminAppPerms() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (b: { resellers: string[]; admin_clients: string[] }) =>
      api.put<{ ok: boolean }>('/api/admin/apps', b),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin', 'app-perms'] }),
  })
}


export interface ResellerAppPerms {
  catalog: CatalogApp[] 
  clients: string[]
}

export function useResellerAppPerms() {
  return useQuery({
    queryKey: ['reseller', 'app-perms'],
    queryFn: () => api.get<ResellerAppPerms>('/api/reseller/apps'),
  })
}

export function useSetResellerAppPerms() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (b: { clients: string[] }) => api.put<{ ok: boolean }>('/api/reseller/apps', b),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['reseller', 'app-perms'] }),
  })
}
