import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'

import { api } from './client'

export interface EmailDomain {
  id: number
  fqdn: string
  email_enabled: boolean
}
export interface Mailbox {
  id: number
  domain_id: number
  fqdn: string
  local_part: string
  address: string
  quota_mb: number
  created_at: string
}
export interface EmailInfo {
  configured: boolean
  webmail_url: string
  domains: EmailDomain[] | null
  mailboxes: Mailbox[] | null
  limit: number 
  used: number
}



export function useEmail(root: string) {
  return useQuery({ queryKey: [root, 'email'], queryFn: () => api.get<EmailInfo>(`${root}/email`) })
}

export function useEnableEmail(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (domainId: number) => api.post<{ enabled: boolean }>(`${root}/domains/${domainId}/email/enable`, {}),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'email'] }),
  })
}
export function useDisableEmail(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (domainId: number) => api.post<{ enabled: boolean }>(`${root}/domains/${domainId}/email/disable`, {}),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'email'] }),
  })
}
export function useCreateMailbox(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (b: { domain_id: number; local_part: string; password: string; quota_mb: number }) =>
      api.post<Mailbox>(`${root}/mailboxes`, b),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'email'] }),
  })
}
export function useDeleteMailbox(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.del<{ deleted: number }>(`${root}/mailboxes/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'email'] }),
  })
}
export function useSetMailboxPassword(root: string) {
  return useMutation({
    mutationFn: (b: { id: number; password: string }) =>
      api.post<{ ok: boolean }>(`${root}/mailboxes/${b.id}/password`, { password: b.password }),
  })
}


export interface MailcowConfig {
  configured: boolean
  url: string
}
export function useMailcowConfig() {
  return useQuery({ queryKey: ['admin', 'mailcow'], queryFn: () => api.get<MailcowConfig>('/api/admin/mailcow') })
}
export function useSetMailcowConfig() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (b: { url: string; api_key: string }) => api.put<{ configured: boolean }>('/api/admin/mailcow', b),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin', 'mailcow'] }),
  })
}
