import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'

import { api } from './client'
import type { Client } from './types'


export interface SelfStatus {
  provisioned: boolean
  client?: Client
  can_edit_limits?: boolean
}



export const SELF_ROOT = '/api/self'

export function useSelfStatus() {
  return useQuery({
    queryKey: ['self', 'status'],
    queryFn: () => api.get<SelfStatus>('/api/self/status'),
    refetchInterval: 5000,
  })
}

export function useActivateSelf() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: () => api.post<{ client_id: number; action_id: number; created: boolean }>('/api/self/activate', {}),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['self', 'status'] }),
  })
}

export interface SelfLimits {
  cpu_limit: number
  ram_limit_mb: number
  disk_quota_mb: number
  max_domains: number
  max_databases: number
  bandwidth_limit_mb: number
}


export function useSetSelfLimits() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (b: SelfLimits) => api.put<{ action_id: number }>('/api/self/limits', b),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['self', 'status'] }),
  })
}
