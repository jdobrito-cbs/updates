


import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'

import { api, apiUpload } from './client'
import type { CronJob, Database, DNSRecord, Domain } from './types'

type ActionResult = { action_id: number }


export function useDomains(root: string) {
  return useQuery({
    queryKey: [root, 'domains'],
    queryFn: async () => (await api.get<Domain[] | null>(`${root}/domains`)) ?? [],
  })
}

export function useCreateDomain(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (body: { fqdn: string; docroot?: string; php_version?: string; upstream?: string }) =>
      api.post<{ domain: Domain } & ActionResult>(`${root}/domains`, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'domains'] }),
  })
}

export function useDeleteDomain(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, deleteFiles }: { id: number; deleteFiles?: boolean }) =>
      api.del<ActionResult>(`${root}/domains/${id}${deleteFiles ? '?files=1' : ''}`),
    
    
    onMutate: async ({ id }: { id: number; deleteFiles?: boolean }) => {
      await qc.cancelQueries({ queryKey: [root, 'domains'] })
      const prev = qc.getQueryData<Domain[]>([root, 'domains'])
      qc.setQueryData<Domain[]>([root, 'domains'], (old) => (old ?? []).filter((d) => d.id !== id))
      return { prev }
    },
    onError: (_e, _v, ctx) => {
      if (ctx?.prev) qc.setQueryData([root, 'domains'], ctx.prev)
    },
  })
}

export function useIssueSSL(root: string) {
  return useMutation({
    mutationFn: (id: number) => api.post<ActionResult>(`${root}/domains/${id}/ssl`),
  })
}

export function useSetDomainPHP(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, version }: { id: number; version: string }) =>
      api.post<ActionResult>(`${root}/domains/${id}/php`, { version }),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'domains'] }),
  })
}


export function useSetDomainOffline(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, mode }: { id: number; mode: string }) =>
      api.post<ActionResult>(`${root}/domains/${id}/offline`, { mode }),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'domains'] }),
  })
}


export function useDatabases(root: string) {
  return useQuery({
    queryKey: [root, 'databases'],
    queryFn: async () => (await api.get<Database[] | null>(`${root}/databases`)) ?? [],
  })
}

export function useCreateDatabase(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (body: { db_name: string; db_user: string; engine?: string }) =>
      api.post<{ database: Database; password: string } & ActionResult>(`${root}/databases`, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'databases'] }),
  })
}


export function useResetDatabasePassword(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, password }: { id: number; password: string }) =>
      api.post<ActionResult>(`${root}/databases/${id}/password`, { password }),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'actions'] }),
  })
}


export function usePostgres(root: string) {
  return useQuery({
    queryKey: [root, 'postgres'],
    queryFn: () =>
      api.get<{
        postgres_enabled: boolean
        phppgadmin_enabled: boolean
        phppgadmin_url: string
        ppa_user: string
        ppa_password: string
      }>(`${root}/postgres`),
  })
}

export function useSetPostgres(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (enabled: boolean) => api.post<{ enabled: boolean }>(`${root}/postgres/${enabled ? 'enable' : 'disable'}`),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: [root, 'postgres'] })
      qc.invalidateQueries({ queryKey: [root, 'actions'] })
    },
  })
}

export function useSetPhpPgAdmin(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (enabled: boolean) =>
      api.post<{ enabled: boolean }>(`${root}/phppgadmin/${enabled ? 'enable' : 'disable'}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'postgres'] }),
  })
}

export function useDeleteDatabase(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.del<ActionResult>(`${root}/databases/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'databases'] }),
  })
}


export function useCron(root: string) {
  return useQuery({
    queryKey: [root, 'cron'],
    queryFn: async () => (await api.get<CronJob[] | null>(`${root}/cron`)) ?? [],
  })
}

export function useCreateCron(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (body: { schedule: string; command: string; enabled: boolean }) =>
      api.post<{ cron_job: CronJob } & ActionResult>(`${root}/cron`, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'cron'] }),
  })
}

export function useDeleteCron(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.del<ActionResult>(`${root}/cron/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'cron'] }),
  })
}


export interface DNSInput {
  type: string
  name: string
  content: string
  ttl: number
  prio: number | null
}

export function useDNSRecords(root: string, domainId: number) {
  return useQuery({
    queryKey: [root, 'dns', domainId],
    queryFn: async () =>
      (await api.get<DNSRecord[] | null>(`${root}/dns/${domainId}/records`)) ?? [],
    enabled: domainId > 0,
  })
}

export function useCreateDNSRecord(root: string, domainId: number) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (body: DNSInput) =>
      api.post<{ record: DNSRecord } & ActionResult>(`${root}/dns/${domainId}/records`, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'dns', domainId] }),
  })
}

export function useDeleteDNSRecord(root: string, domainId: number) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.del<ActionResult>(`${root}/dns/${domainId}/records/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'dns', domainId] }),
  })
}


export interface ClientStats {
  status: string
  limits: { cpu: number; ram_mb: number; disk_mb: number }
  counts: { domains: number; databases: number }
}

export function useStats(root: string) {
  return useQuery({
    queryKey: [root, 'stats'],
    queryFn: () => api.get<ClientStats>(`${root}/stats`),
  })
}


export interface RuntimesInfo {
  available: { key: string; label: string }[]
  enabled: string[]
}

export function useRuntimes(root: string) {
  return useQuery({
    queryKey: [root, 'runtimes'],
    queryFn: () => api.get<RuntimesInfo>(`${root}/runtimes`),
  })
}

export function useSetRuntimes(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (runtimes: string[]) => api.post<{ enabled: string[]; action_id: number }>(`${root}/runtimes`, { runtimes }),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'runtimes'] }),
  })
}


export interface DomainForward {
  id: number
  domain_id: number
  path: string
  target: string
  target_domain_id: number 
  target_fqdn: string
  created_at: string
}

export function useForwards(root: string, domainId: number) {
  return useQuery({
    queryKey: [root, 'forwards', domainId],
    queryFn: async () => (await api.get<DomainForward[] | null>(`${root}/domains/${domainId}/forwards`)) ?? [],
    enabled: domainId > 0,
  })
}

export function useCreateForward(root: string, domainId: number) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (body: { path: string; target: string; internal?: boolean }) =>
      api.post<{ forward: DomainForward } & ActionResult>(`${root}/domains/${domainId}/forwards`, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'forwards', domainId] }),
  })
}

export function useDeleteForward(root: string, domainId: number) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.del<ActionResult>(`${root}/domains/${domainId}/forwards/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'forwards', domainId] }),
  })
}


export interface WordPressInstall {
  id: number
  domain_id: number
  fqdn: string
  path: string
  admin_user: string
  db_name: string
  created_at: string
}

export interface InstallWordPressInput {
  domain_id: number
  path: string
  admin_user: string
  admin_email: string
  admin_password: string
  title: string
}

export function useWordPress(root: string) {
  return useQuery({
    queryKey: [root, 'wordpress'],
    queryFn: async () => (await api.get<WordPressInstall[] | null>(`${root}/wordpress`)) ?? [],
  })
}

export function useInstallWordPress(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (body: InstallWordPressInput) =>
      api.post<{ install: WordPressInstall; action_id: number }>(`${root}/wordpress`, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'wordpress'] }),
  })
}

export function useRemoveWordPress(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.del<{ action_id: number }>(`${root}/wordpress/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'wordpress'] }),
  })
}


export interface WPItem {
  name: string
  status: string
  version: string
  update: string
  update_version?: string 
}
export interface WPAdmin {
  ID: number
  user_login: string
  user_email: string
}
export interface WPManagerInfo {
  core_version: string
  core_update_version?: string 
  site_url: string
  plugins: WPItem[]
  themes: WPItem[]
  admins: WPAdmin[]
}
export interface WPManageBody {
  target: 'plugin' | 'theme' | 'core'
  action: 'activate' | 'deactivate' | 'delete' | 'update' | 'install'
  slug?: string
}

export function useWPManager(root: string, installId: number) {
  return useQuery({
    queryKey: [root, 'wpmanager', installId],
    queryFn: () => api.get<WPManagerInfo>(`${root}/wordpress/${installId}/manager`),
    enabled: installId > 0,
  })
}

export function useWPManage(root: string, installId: number) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (body: WPManageBody) =>
      api.post<{ output: string }>(`${root}/wordpress/${installId}/manage`, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'wpmanager', installId] }),
  })
}


export function useHardenWordPress(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (installId: number) => api.post<{ action_id: number }>(`${root}/wordpress/${installId}/harden`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['actions'] }),
  })
}



export function useWPUpload(root: string, installId: number) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ target, file }: { target: 'plugin' | 'theme'; file: File }) => {
      const form = new FormData()
      form.append('target', target)
      form.append('file', file)
      return apiUpload<{ output: string }>(`${root}/wordpress/${installId}/upload`, form)
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'wpmanager', installId] }),
  })
}



export function useWPSetURL(root: string, installId: number) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (newURL: string) =>
      api.post<{ output: string }>(`${root}/wordpress/${installId}/site-url`, { new_url: newURL }),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'wpmanager', installId] }),
  })
}


export function useWPSetPassword(root: string, installId: number) {
  return useMutation({
    mutationFn: (body: { user_login: string; new_password: string }) =>
      api.post<{ output: string }>(`${root}/wordpress/${installId}/admin-password`, body),
  })
}


export function useAssociateWordPress(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (body: { domain_id: number; path: string }) =>
      api.post<WordPressInstall>(`${root}/wordpress/associate`, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'wordpress'] }),
  })
}


export interface SFTPInfo {
  enabled: boolean
  host: string
  port: number
  user: string
}

export function useSFTPInfo(root: string) {
  return useQuery({
    queryKey: [root, 'sftp'],
    queryFn: () => api.get<SFTPInfo>(`${root}/sftp`),
  })
}

export function useEnableSFTP(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (body: { user: string; password: string }) =>
      api.post<{ action_id: number; host: string; port: number; user: string }>(`${root}/sftp/enable`, body),
    
    
    onSuccess: (data) => {
      qc.setQueryData<SFTPInfo>([root, 'sftp'], { enabled: true, host: data.host, port: data.port, user: data.user })
      setTimeout(() => qc.invalidateQueries({ queryKey: [root, 'sftp'] }), 5000)
    },
  })
}

export function useDisableSFTP(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: () => api.post<{ action_id: number }>(`${root}/sftp/disable`),
    
    
    onSuccess: () => {
      qc.setQueryData<SFTPInfo>([root, 'sftp'], (prev) => (prev ? { ...prev, enabled: false } : prev))
      setTimeout(() => qc.invalidateQueries({ queryKey: [root, 'sftp'] }), 5000)
    },
  })
}


export interface Backup {
  id: number
  client_id: number
  filename: string
  size_bytes: number
  status: string
  note: string
  created_at: string
  finished_at?: string | null
}
export interface BackupList {
  schedule: string
  backups: Backup[]
}

export function useClientBackups(root: string) {
  return useQuery({
    queryKey: [root, 'backups'],
    queryFn: () => api.get<BackupList>(`${root}/backups`),
    refetchInterval: 4000,
  })
}

export function useCreateBackup(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: () => api.post<{ backup_id: number; action_id: number }>(`${root}/backups`),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'backups'] }),
  })
}

export function useRestoreBackup(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.post<{ actions: number }>(`${root}/backups/${id}/restore`),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'backups'] }),
  })
}

export function useSetBackupSchedule(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (schedule: string) => api.put<{ status: string }>(`${root}/backup-schedule`, { schedule }),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'backups'] }),
  })
}


export interface SiteRulesConfig {
  php: { key: string; value: string }[]
  headers: { name: string; value: string }[]
  cors: { enabled: boolean; origin: string }
}

export function useSiteRules(root: string, domainId: number) {
  return useQuery({
    queryKey: [root, 'rules', domainId],
    queryFn: () => api.get<Partial<SiteRulesConfig>>(`${root}/domains/${domainId}/rules`),
    enabled: domainId > 0,
  })
}

export function useUpdateSiteRules(root: string, domainId: number) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (c: SiteRulesConfig) =>
      api.put<{ action_id: number }>(`${root}/domains/${domainId}/rules`, c),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'rules', domainId] }),
  })
}


export interface CloudflareInfo {
  status: string 
  configured: boolean
}

export function useCloudflare(root: string) {
  return useQuery({
    queryKey: [root, 'cloudflare'],
    queryFn: () => api.get<CloudflareInfo>(`${root}/cloudflare`),
    refetchInterval: 5000,
  })
}

export function useSetCloudflare(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (token: string) => api.post<{ action_id: number }>(`${root}/cloudflare/set`, { token }),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'cloudflare'] }),
  })
}

export function useControlCloudflare(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (op: 'start' | 'stop' | 'restart') =>
      api.post<{ action_id: number }>(`${root}/cloudflare/control`, { op }),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'cloudflare'] }),
  })
}




export function usePowerState(root: string) {
  return useQuery({
    queryKey: [root, 'power'],
    queryFn: () => api.get<{ state: string; running: boolean }>(`${root}/power`),
    refetchInterval: 5000, 
  })
}

export function usePowerClient(root: string) {
  
  
  
  return useMutation({
    mutationFn: (op: 'start' | 'stop' | 'restart') =>
      api.post<{ action_id: number }>(`${root}/power`, { op }),
  })
}


export interface PhpMyAdminInfo {
  enabled: boolean
  open_url: string
  user: string
  password: string
}

export function usePhpMyAdmin(root: string) {
  return useQuery({
    queryKey: [root, 'phpmyadmin'],
    queryFn: () => api.get<PhpMyAdminInfo>(`${root}/phpmyadmin`),
    refetchInterval: 5000,
  })
}

export function useEnablePhpMyAdmin(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: () => api.post<{ action_id: number }>(`${root}/phpmyadmin/enable`),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'phpmyadmin'] }),
  })
}

export function useDisablePhpMyAdmin(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: () => api.post<{ action_id: number }>(`${root}/phpmyadmin/disable`),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'phpmyadmin'] }),
  })
}


export interface Package {
  id: number
  reseller_id?: number
  name: string
  price_cents: number
  cpu_limit: number
  ram_limit_mb: number
  disk_quota_mb: number
  max_domains: number
  max_databases: number
  max_mailboxes: number
  bandwidth_limit_mb: number
  duration_days: number
  created_at: string
}
export type PackageInput = Omit<Package, 'id' | 'reseller_id' | 'created_at'>

export function usePackages(root: string) {
  return useQuery({
    queryKey: [root, 'packages'],
    queryFn: async () => (await api.get<Package[] | null>(`${root}/packages`)) ?? [],
  })
}
export function useCreatePackage(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (b: PackageInput) => api.post<{ package_id: number }>(`${root}/packages`, b),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'packages'] }),
  })
}
export function useUpdatePackage(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, ...b }: PackageInput & { id: number }) => api.put<{ ok: boolean }>(`${root}/packages/${id}`, b),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'packages'] }),
  })
}
export function useDeletePackage(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.del<{ deleted: number }>(`${root}/packages/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'packages'] }),
  })
}


export interface Order {
  id: number
  package_name: string
  buyer_email: string
  amount_cents: number
  status: string 
  mp_payment_id: string
  created_at: string
}
export function useMPConfig(root: string) {
  return useQuery({ queryKey: [root, 'mp'], queryFn: () => api.get<{ configured: boolean }>(`${root}/mercadopago`) })
}
export function useSetMPToken(root: string) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (token: string) => api.put<{ configured: boolean }>(`${root}/mercadopago`, { token }),
    onSuccess: () => qc.invalidateQueries({ queryKey: [root, 'mp'] }),
  })
}
export function useOrders(root: string) {
  return useQuery({
    queryKey: [root, 'orders'],
    queryFn: async () => (await api.get<Order[] | null>(`${root}/orders`)) ?? [],
  })
}
