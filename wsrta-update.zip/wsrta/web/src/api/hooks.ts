import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'

import { api } from './client'
import type { Action, Client, SystemStats } from './types'

export interface ClientInput {
  email?: string
  password?: string
  name: string
  cpu_limit?: number
  ram_limit_mb?: number
  disk_quota_mb?: number
  max_domains?: number
  max_databases?: number
  max_mailboxes?: number
  session_timeout_minutes?: number
  bandwidth_limit_mb?: number
}


export function useClients(search: string) {
  return useQuery({
    queryKey: ['clients', search],
    queryFn: async () =>
      (await api.get<Client[] | null>(`/api/admin/clients?q=${encodeURIComponent(search)}`)) ?? [],
  })
}

export function useClient(id: number) {
  return useQuery({
    queryKey: ['client', id],
    queryFn: () => api.get<Client>(`/api/admin/clients/${id}`),
  })
}

export function useCreateClient() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (input: ClientInput) =>
      api.post<{ client_id: number; action_id: number }>('/api/admin/clients', input),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['clients'] })
      qc.invalidateQueries({ queryKey: ['actions'] })
    },
  })
}

export function useUpdateClient() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, input }: { id: number; input: ClientInput }) =>
      api.put<{ status: string }>(`/api/admin/clients/${id}`, input),
    onSuccess: (_data, vars) => {
      qc.invalidateQueries({ queryKey: ['clients'] })
      qc.invalidateQueries({ queryKey: ['client', vars.id] })
    },
  })
}

export function useDeleteClient() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.del<{ action_id: number }>(`/api/admin/clients/${id}`),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['clients'] })
      qc.invalidateQueries({ queryKey: ['actions'] })
    },
  })
}

export function useResetClient2FA() {
  return useMutation({
    mutationFn: (id: number) => api.post<{ status: string }>(`/api/admin/clients/${id}/reset-2fa`),
  })
}

export function useSuspendClient() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.post<{ action_id: number }>(`/api/admin/clients/${id}/suspend`),
    onSuccess: (_d, id) => {
      qc.invalidateQueries({ queryKey: ['clients'] })
      qc.invalidateQueries({ queryKey: ['client', id] })
      qc.invalidateQueries({ queryKey: ['actions'] })
    },
  })
}

export function useResumeClient() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.post<{ action_id: number }>(`/api/admin/clients/${id}/resume`),
    onSuccess: (_d, id) => {
      qc.invalidateQueries({ queryKey: ['clients'] })
      qc.invalidateQueries({ queryKey: ['client', id] })
      qc.invalidateQueries({ queryKey: ['actions'] })
    },
  })
}

export function useSetFastNginx(id: number) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (enabled: boolean) =>
      api.post<{ action_id: number }>(`/api/admin/clients/${id}/fastnginx/${enabled ? 'enable' : 'disable'}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['client', id] }),
  })
}



export function useActions(type?: string) {
  const qs = type ? `?type=${encodeURIComponent(type)}` : ''
  return useQuery({
    queryKey: ['actions', type ?? 'all'],
    queryFn: async () => (await api.get<Action[] | null>(`/api/admin/actions${qs}`)) ?? [],
    refetchInterval: 2500,
  })
}

export function useSystem() {
  return useQuery({
    queryKey: ['system'],
    queryFn: () => api.get<SystemStats>('/api/admin/system'),
    refetchInterval: 5000,
  })
}

export interface DashboardData {
  server_ip: string
  total_domains: number
  total_databases: number
  total_wordpress: number
  clients: { id: number; name: string; domains: number; databases: number }[]
}

export interface VersionInfo {
  version: string
  build_date: string
}
export function useVersion() {
  return useQuery({
    queryKey: ['version'],
    queryFn: () => api.get<VersionInfo>('/api/version'),
    staleTime: Infinity,
  })
}

export function useDashboard() {
  return useQuery({
    queryKey: ['dashboard'],
    queryFn: () => api.get<DashboardData>('/api/admin/dashboard'),
    refetchInterval: 10000,
  })
}


export interface UsageStat {
  percent: number
  total_kb?: number
  used_kb?: number
  total_bytes?: number
  used_bytes?: number
}
export interface CPUInfo {
  model: string
  cores: number
}
export interface MonitoringData {
  os: { name: string; version: string; type: string; kernel: string; hostname: string }
  cpu_info: CPUInfo
  network: {
    interfaces: { name: string; mac: string; ip: string; mask: string }[]
    gateway: string
    dns: string[]
  }
  cpu: number
  mem: UsageStat
  disk: UsageStat
  net: { rx_bps: number; tx_bps: number }
}
export interface BandwidthDay {
  day: string
  rx_bytes: number
  tx_bytes: number
}
export interface ClientMonitoring {
  cpu: number
  cpu_info: CPUInfo
  mem: UsageStat
  disk: UsageStat
}

export function useMonitoring() {
  return useQuery({
    queryKey: ['monitoring'],
    queryFn: () => api.get<MonitoringData>('/api/admin/monitoring'),
    refetchInterval: 2000,
  })
}

export function useBandwidth() {
  return useQuery({
    queryKey: ['bandwidth'],
    queryFn: async () => (await api.get<BandwidthDay[] | null>('/api/admin/monitoring/bandwidth')) ?? [],
    refetchInterval: 60000,
  })
}

export interface ClientBandwidth {
  client_id: number
  name: string
  used_bytes: number
  limit_mb: number
  suspended: boolean
}

export function useClientBandwidth() {
  return useQuery({
    queryKey: ['client-bandwidth'],
    queryFn: async () =>
      (await api.get<ClientBandwidth[] | null>('/api/admin/monitoring/bandwidth/clients')) ?? [],
    refetchInterval: 30000,
  })
}

export function useClientMonitoring() {
  return useQuery({
    queryKey: ['client-monitoring'],
    queryFn: () => api.get<ClientMonitoring>('/api/monitoring'),
    refetchInterval: 2000,
  })
}

export function useSystemUpdate(kind: 'os' | 'panel') {
  return useMutation({
    mutationFn: () => api.post<{ action_id: number }>(`/api/admin/monitoring/update/${kind}`),
  })
}

export function useRestartService() {
  return useMutation({
    mutationFn: (service: string) =>
      api.post<{ action_id: number }>('/api/admin/system/restart', { service }),
  })
}


export interface FirewallState {
  status: { csf: boolean; lfd: boolean; fail2ban: boolean }
  jails: { name: string; banned: string[] }[]
  csf: { deny: string[]; allow: string[]; temp: string[] }
}
export interface FirewallActionBody {
  kind: 'unban' | 'ban' | 'allow' | 'deny' | 'unblock' | 'service'
  ip?: string
  jail?: string
  service?: string
  op?: string
}

export function useFirewall() {
  return useQuery({
    queryKey: ['firewall'],
    queryFn: () => api.get<FirewallState>('/api/admin/firewall'),
    refetchInterval: 15000,
  })
}

export function useFirewallAction() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (body: FirewallActionBody) => api.post<{ ok: boolean }>('/api/admin/firewall/action', body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['firewall'] }),
  })
}


export interface SystemSettings {
  
  session_timeout_minutes?: number
  panel_domain: string
  company_name: string
  max_domains_per_client: number
  max_databases_per_client: number
  max_login_attempts: number
  lockout_minutes: number
}

export function useSettings() {
  return useQuery({
    queryKey: ['settings'],
    queryFn: () => api.get<SystemSettings>('/api/admin/settings'),
  })
}

export function useUpdateSettings() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (s: SystemSettings) => api.put<SystemSettings>('/api/admin/settings', s),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['settings'] })
      qc.invalidateQueries({ queryKey: ['branding'] })
    },
  })
}


export function useChangeOwnPassword() {
  return useMutation({
    mutationFn: (b: { current_password: string; new_password: string }) =>
      api.post<{ ok: boolean }>('/api/account/password', b),
  })
}


export function useSetClientPassword(id: number) {
  return useMutation({
    mutationFn: (new_password: string) =>
      api.post<{ ok: boolean }>(`/api/admin/clients/${id}/password`, { new_password }),
  })
}


export interface EditionInfo {
  edition: string 
  complete: boolean
}


export function useEdition() {
  return useQuery({
    queryKey: ['edition'],
    queryFn: () => api.get<EditionInfo>('/api/edition'),
    staleTime: 5 * 60 * 1000,
  })
}


export interface Reseller {
  id: number
  user_id: number
  email: string
  name: string
  status: string 
  expires_at?: string
  created_at: string
  online: boolean
  clients: number
  slug: string
  landing_template: string
  landing_headline: string
  landing_subtitle: string
  external_site_url: string
  max_clients: number
}



export interface ResellerLimits {
  max_clients?: number
  cpu_limit?: number
  ram_limit_mb?: number
  disk_quota_mb?: number
  max_domains?: number
  max_databases?: number
  max_mailboxes?: number
  bandwidth_limit_mb?: number
}

export function useResellers(search: string) {
  return useQuery({
    queryKey: ['resellers', search],
    queryFn: async () =>
      (await api.get<Reseller[] | null>(`/api/admin/resellers?q=${encodeURIComponent(search)}`)) ?? [],
  })
}

export function useCreateReseller() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (b: { email: string; name: string; password: string; expires_at?: string } & ResellerLimits) =>
      api.post<{ reseller_id: number }>('/api/admin/resellers', b),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['resellers'] }),
  })
}

export function useUpdateReseller() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, ...b }: { id: number; name: string; expires_at?: string } & ResellerLimits) =>
      api.put<{ ok: boolean }>(`/api/admin/resellers/${id}`, b),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['resellers'] }),
  })
}

export function useDeleteReseller() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.del<{ deleted: number }>(`/api/admin/resellers/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['resellers'] }),
  })
}


export function useToggleReseller() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, suspend }: { id: number; suspend: boolean }) =>
      api.post<{ status: string }>(`/api/admin/resellers/${id}/${suspend ? 'suspend' : 'resume'}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['resellers'] }),
  })
}


export interface PublicPackage {
  id: number
  name: string
  price_cents: number
  cpu_limit: number
  ram_limit_mb: number
  disk_quota_mb: number
  max_domains: number
  max_databases: number
  max_mailboxes: number
  bandwidth_limit_mb: number
  duration_days: number
}
export interface PublicSite {
  company_name: string
  packages: PublicPackage[]
}

export interface PublicResellerSite extends PublicSite {
  template: string
  headline: string
  subtitle: string
  external_site_url: string
}

export function usePublicSite() {
  return useQuery({
    queryKey: ['public-site'],
    queryFn: () => api.get<PublicSite>('/api/public/site'),
    retry: false,
  })
}


export function useCheckout() {
  return useMutation({
    mutationFn: (b: { scope: string; package_id: number; email: string }) =>
      api.post<{ init_point: string; order_id: number }>('/api/public/checkout', b),
  })
}

export function usePublicResellerSite(slug: string) {
  return useQuery({
    queryKey: ['public-site', slug],
    queryFn: () => api.get<PublicResellerSite>(`/api/public/site/${slug}`),
    retry: false,
    enabled: !!slug,
  })
}


export function useUpdateResellerSite() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (b: {
      slug: string
      landing_template: string
      landing_headline: string
      landing_subtitle: string
      external_site_url: string
    }) => api.put<{ ok: boolean }>('/api/reseller/site', b),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['reseller-me'] }),
  })
}


export function useResellerProfile() {
  return useQuery({
    queryKey: ['reseller-me'],
    queryFn: () => api.get<Reseller>('/api/reseller/me'),
  })
}


export function useResellerClient(id: number) {
  return useQuery({
    queryKey: ['reseller-client', id],
    queryFn: () => api.get<Client>(`/api/reseller/clients/${id}`),
    enabled: id > 0,
  })
}

export function useResellerClients(search: string) {
  return useQuery({
    queryKey: ['reseller-clients', search],
    queryFn: async () =>
      (await api.get<Client[] | null>(`/api/reseller/clients?q=${encodeURIComponent(search)}`)) ?? [],
  })
}

export function useCreateResellerClient() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (input: {
      email: string
      password: string
      name: string
      cpu_limit: number
      ram_limit_mb: number
      disk_quota_mb: number
      bandwidth_mb?: number
      package_id?: number
    }) => api.post<{ client_id: number; action_id: number }>('/api/reseller/clients', input),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['reseller-clients'] }),
  })
}



export function useResellerClientPower() {
  return useMutation({
    mutationFn: ({ id, op }: { id: number; op: 'start' | 'stop' | 'restart' }) =>
      api.post<{ action_id: number }>(`/api/reseller/clients/${id}/power`, { op }),
  })
}


export function useResellerClientAction() {
  const qc = useQueryClient()
  type Res = { action_id?: number; status?: string }
  return useMutation({
    mutationFn: ({ id, action }: { id: number; action: 'suspend' | 'resume' | 'delete' }): Promise<Res> =>
      action === 'delete'
        ? api.del<Res>(`/api/reseller/clients/${id}`)
        : api.post<Res>(`/api/reseller/clients/${id}/${action}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['reseller-clients'] }),
  })
}


export interface AdminUser {
  id: number
  email: string
  name: string
  status: string 
  created_at: string
  online: boolean
  last_seen?: string
  session_timeout_minutes: number
}

export function useAdmins(search: string) {
  return useQuery({
    queryKey: ['admins', search],
    queryFn: () =>
      api.get<{ admins: AdminUser[]; current: number }>(`/api/admin/admins?q=${encodeURIComponent(search)}`),
  })
}

export function useCreateAdmin() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (b: { email: string; name: string; password: string; session_timeout_minutes: number }) =>
      api.post<{ id: number }>('/api/admin/admins', b),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admins'] }),
  })
}

export function useUpdateAdmin() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({
      id,
      ...b
    }: {
      id: number
      email: string
      name: string
      password?: string
      session_timeout_minutes: number
    }) => api.put<{ ok: boolean }>(`/api/admin/admins/${id}`, b),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admins'] }),
  })
}

export function useDeleteAdmin() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: number) => api.del<{ ok: boolean }>(`/api/admin/admins/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admins'] }),
  })
}

export function useBlockAdmin() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, block }: { id: number; block: boolean }) =>
      api.post<{ ok: boolean }>(`/api/admin/admins/${id}/${block ? 'block' : 'unblock'}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admins'] }),
  })
}


export function useSetupStatus() {
  return useQuery({
    queryKey: ['setup-status'],
    queryFn: () => api.get<{ needs_setup: boolean; server_ip: string }>('/api/setup/status'),
    staleTime: 30000,
  })
}

export function useSetup() {
  return useMutation({
    mutationFn: (b: {
      admin_name: string
      admin_email: string
      admin_password: string
      company_name: string
      panel_domain: string
    }) => api.post<{ ok: boolean }>('/api/setup', b),
  })
}


export function useBranding() {
  return useQuery({
    queryKey: ['branding'],
    queryFn: () => api.get<{ company_name: string }>('/api/branding'),
    staleTime: 60000,
  })
}


export interface SecurityToggles {
  modsecurity: boolean
  csf: boolean
  fail2ban: boolean
  ssl_autorenew: boolean
}

export function useSecurity() {
  return useQuery({
    queryKey: ['security'],
    queryFn: () => api.get<SecurityToggles>('/api/admin/security'),
  })
}

export function useUpdateSecurity() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (s: SecurityToggles) => api.put<{ action_id: number }>('/api/admin/security', s),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['security'] })
      qc.invalidateQueries({ queryKey: ['actions'] })
    },
  })
}


export interface BackupFile {
  name: string
  size_mb: number
}
export interface BackupList {
  dir: string
  backups: BackupFile[]
}
export interface BackupPreview {
  domain: string
  email: string
  php: string
  has_files: boolean
  databases: { name: string; user: string; has_hash: boolean }[]
}
export interface ImportResult {
  client_id: number
  domain: string
  login_email?: string
  login_password?: string
}

export function useBackups() {
  return useQuery({
    queryKey: ['backups'],
    queryFn: () => api.get<BackupList>('/api/admin/import/cyberpanel/backups'),
  })
}


export function useDeleteBackup() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (file: string) => api.post<{ deleted: string }>('/api/admin/import/cyberpanel/delete', { file }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['backups'] }),
  })
}


export interface NginxSite {
  fqdns: string[]
  upstream_ip: string
  upstream_port: number
  proxy_target: string
  root: string
  file: string
  known: boolean
}

export function useNginxImport() {
  return useQuery({
    queryKey: ['nginx-import'],
    queryFn: async () => (await api.get<{ sites: NginxSite[] }>('/api/admin/import/nginx')).sites ?? [],
  })
}


export function useCreateClientDomain() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (b: { client_id: number; fqdn: string; upstream_ip?: string; upstream_port?: number }) =>
      api.post<{ action_id: number }>(`/api/admin/clients/${b.client_id}/domains`, {
        fqdn: b.fqdn,
        upstream_ip: b.upstream_ip,
        upstream_port: b.upstream_port,
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['nginx-import'] })
      qc.invalidateQueries({ queryKey: ['clients'] })
    },
  })
}

export function usePreviewBackup() {
  return useMutation({
    mutationFn: (file: string) =>
      api.post<BackupPreview>('/api/admin/import/cyberpanel/preview', { file }),
  })
}

export function useImportBackup() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ file, client_id, email }: { file: string; client_id: number; email?: string }) =>
      api.post<ImportResult>('/api/admin/import/cyberpanel/import', { file, client_id, email }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['clients'] })
      qc.invalidateQueries({ queryKey: ['actions'] })
    },
  })
}


export interface VulnScan {
  id: number
  client_id: number
  status: string
  high: number
  medium: number
  low: number
  info: number
  summary: string
  created_at: string
  finished_at?: string | null
}
export interface VulnFinding {
  id: number
  scan_id: number
  fqdn: string
  severity: 'high' | 'medium' | 'low' | 'info'
  category: string
  title: string
  detail: string
  remediation: string
}

export function useHostVulnScans() {
  return useQuery({
    queryKey: ['vuln', 'host'],
    queryFn: async () => (await api.get<VulnScan[] | null>('/api/admin/vuln/host')) ?? [],
    refetchInterval: 4000,
  })
}
export function useClientVulnScans(clientId: number) {
  return useQuery({
    queryKey: ['vuln', 'client', clientId],
    queryFn: async () => (await api.get<VulnScan[] | null>(`/api/admin/clients/${clientId}/vuln-scans`)) ?? [],
    enabled: clientId > 0,
    refetchInterval: 4000,
  })
}
export function useVulnFindings(scanId: number) {
  return useQuery({
    queryKey: ['vuln', 'findings', scanId],
    queryFn: async () => (await api.get<VulnFinding[] | null>(`/api/admin/vuln/scans/${scanId}/findings`)) ?? [],
    enabled: scanId > 0,
  })
}
export function useScanHost() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: () => api.post<{ scan_id: number; action_id: number }>('/api/admin/vuln/host'),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['vuln', 'host'] })
      qc.invalidateQueries({ queryKey: ['actions'] })
    },
  })
}
export function useScanClient() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (clientId: number) =>
      api.post<{ scan_id: number; action_id: number }>(`/api/admin/clients/${clientId}/vuln-scans`),
    onSuccess: (_data, clientId) => {
      qc.invalidateQueries({ queryKey: ['vuln', 'client', clientId] })
      qc.invalidateQueries({ queryKey: ['actions'] })
    },
  })
}
export function useSetVulnSchedule() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ clientId, schedule }: { clientId: number; schedule: string }) =>
      api.put<{ schedule: string }>(`/api/admin/clients/${clientId}/vuln-schedule`, { schedule }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['clients'] }),
  })
}


export function useHardenAllWordPress() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: () => api.post<{ queued: number }>('/api/admin/wordpress/harden-all'),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['actions'] }),
  })
}


export interface SecurityEvent {
  id: number
  event_type: string
  severity: 'high' | 'medium' | 'low' | 'info'
  ip: string
  email: string
  user_agent: string
  detail: string
  blocked: boolean
  created_at: string
}
export function useSecurityEvents() {
  return useQuery({
    queryKey: ['security-events'],
    queryFn: async () => (await api.get<SecurityEvent[] | null>('/api/admin/security-events')) ?? [],
    refetchInterval: 5000,
  })
}

export function useBlockIP() {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (ip: string) => api.post<{ ok: boolean }>('/api/admin/firewall/action', { kind: 'deny', ip }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['security-events'] }),
  })
}


export function useUpdateClientPackages(clientId: number) {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: () => api.post<{ action_id: number }>(`/api/admin/clients/${clientId}/update-packages`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['actions'] }),
  })
}
