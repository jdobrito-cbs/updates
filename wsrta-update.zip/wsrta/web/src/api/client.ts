

let authToken: string | null = null

export function setAuthToken(token: string | null): void {
  authToken = token
}

const BASE = import.meta.env.VITE_API_BASE_URL ?? ''



function handleUnauthorized(path: string): void {
  if (path.startsWith('/api/auth/')) return
  authToken = null
  try {
    localStorage.removeItem('wsrta_token')
  } catch {
    
  }
  window.dispatchEvent(new Event('wsrta:unauthorized'))
}

export class ApiError extends Error {
  status: number
  constructor(status: number, message: string) {
    super(message)
    this.status = status
    this.name = 'ApiError'
  }
}

async function request<T>(method: string, path: string, body?: unknown): Promise<T> {
  const headers: Record<string, string> = {}
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  if (authToken) headers['Authorization'] = `Bearer ${authToken}`

  const res = await fetch(`${BASE}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  })

  const text = await res.text()
  const data = text ? JSON.parse(text) : null

  if (!res.ok) {
    if (res.status === 401) handleUnauthorized(path)
    const message =
      (data && typeof data === 'object' && 'error' in data && String(data.error)) ||
      `HTTP ${res.status}`
    throw new ApiError(res.status, message)
  }
  return data as T
}

export const api = {
  get: <T>(path: string) => request<T>('GET', path),
  post: <T>(path: string, body?: unknown) => request<T>('POST', path, body),
  put: <T>(path: string, body?: unknown) => request<T>('PUT', path, body),
  del: <T>(path: string) => request<T>('DELETE', path),
}


export async function apiDownload(path: string, filename: string): Promise<void> {
  const headers: Record<string, string> = {}
  if (authToken) headers['Authorization'] = `Bearer ${authToken}`
  const res = await fetch(`${BASE}${path}`, { headers })
  if (!res.ok) {
    if (res.status === 401) handleUnauthorized(path)
    const text = await res.text().catch(() => '')
    throw new ApiError(res.status, text || `HTTP ${res.status}`)
  }
  const blob = await res.blob()
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}


export async function apiUpload<T>(path: string, form: FormData): Promise<T> {
  const headers: Record<string, string> = {}
  if (authToken) headers['Authorization'] = `Bearer ${authToken}`
  const res = await fetch(`${BASE}${path}`, { method: 'POST', headers, body: form })
  const text = await res.text()
  const data = text ? JSON.parse(text) : null
  if (!res.ok) {
    if (res.status === 401) handleUnauthorized(path)
    const message =
      (data && typeof data === 'object' && 'error' in data && String(data.error)) || `HTTP ${res.status}`
    throw new ApiError(res.status, message)
  }
  return data as T
}




export function uploadWithProgress<T>(
  path: string,
  form: FormData,
  onProgress: (percent: number) => void,
): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const xhr = new XMLHttpRequest()
    xhr.open('POST', `${BASE}${path}`)
    if (authToken) xhr.setRequestHeader('Authorization', `Bearer ${authToken}`)
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100))
    }
    xhr.onload = () => {
      const text = xhr.responseText
      let data: { error?: unknown } | null = null
      try {
        data = text ? JSON.parse(text) : null
      } catch {
        
      }
      if (xhr.status >= 200 && xhr.status < 300) {
        resolve(data as T)
        return
      }
      if (xhr.status === 401) handleUnauthorized(path)
      const message = data && data.error != null ? String(data.error) : `HTTP ${xhr.status}`
      reject(new ApiError(xhr.status, message))
    }
    xhr.onerror = () => reject(new ApiError(0, 'falha de rede no upload'))
    xhr.send(form)
  })
}
