import { createContext, useContext, useEffect, useRef, useState } from 'react'
import type { ReactNode } from 'react'

import { api, setAuthToken } from '../api/client'
import type { LoginStage, Me, Role, SessionResponse } from '../api/types'

interface AuthState {
  token: string | null
  role: Role | null
  clientId: number | null
  ready: boolean
  sessionTimeoutMinutes: number | null
}

interface AuthContextValue extends AuthState {
  
  loginPassword: (email: string, password: string) => Promise<LoginStage>
  
  enroll: (token: string, code: string) => Promise<{ role: Role; recoveryCodes: string[] }>
  
  verify: (token: string, code: string) => Promise<Role>
  logout: () => void
}

const AuthContext = createContext<AuthContextValue | null>(null)
const STORAGE_KEY = 'wsrta_token'

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState>({
    token: null,
    role: null,
    clientId: null,
    ready: false,
    sessionTimeoutMinutes: null,
  })

  useEffect(() => {
    const token = localStorage.getItem(STORAGE_KEY)
    if (!token) {
      setState((s) => ({ ...s, ready: true }))
      return
    }
    setAuthToken(token)
    api
      .get<Me>('/api/auth/me')
      .then((me) =>
        setState({
          token,
          role: me.role,
          clientId: me.client_id,
          ready: true,
          sessionTimeoutMinutes: me.session_timeout_minutes ?? 60,
        }),
      )
      .catch(() => {
        localStorage.removeItem(STORAGE_KEY)
        setAuthToken(null)
        setState({ token: null, role: null, clientId: null, ready: true, sessionTimeoutMinutes: null })
      })
  }, [])

  function setSession(token: string, role: Role, clientId: number | null, timeoutMin?: number) {
    localStorage.setItem(STORAGE_KEY, token)
    setAuthToken(token)
    setState({ token, role, clientId, ready: true, sessionTimeoutMinutes: timeoutMin ?? 60 })
  }

  async function loginPassword(email: string, password: string): Promise<LoginStage> {
    return api.post<LoginStage>('/api/auth/login', { email, password })
  }

  async function enroll(token: string, code: string) {
    const res = await api.post<SessionResponse>('/api/auth/2fa/enroll', { token, code })
    setSession(res.token, res.role, res.client_id, res.session_timeout_minutes)
    return { role: res.role, recoveryCodes: res.recovery_codes ?? [] }
  }

  async function verify(token: string, code: string): Promise<Role> {
    const res = await api.post<SessionResponse>('/api/auth/2fa/verify', { token, code })
    setSession(res.token, res.role, res.client_id, res.session_timeout_minutes)
    return res.role
  }

  function logout(): void {
    localStorage.removeItem(STORAGE_KEY)
    setAuthToken(null)
    setState({ token: null, role: null, clientId: null, ready: true, sessionTimeoutMinutes: null })
  }

  
  
  
  const lastRefresh = useRef(0)
  async function slideRefresh() {
    try {
      const res = await api.post<{ token: string }>('/api/auth/refresh')
      localStorage.setItem(STORAGE_KEY, res.token)
      setAuthToken(res.token)
    } catch {
      
    }
  }

  
  
  
  useEffect(() => {
    const onUnauthorized = () => logout()
    window.addEventListener('wsrta:unauthorized', onUnauthorized)
    return () => window.removeEventListener('wsrta:unauthorized', onUnauthorized)
  }, [])

  
  useEffect(() => {
    if (!state.token) return
    const minutes = state.sessionTimeoutMinutes ?? 60
    
    const refreshEvery = Math.max(30_000, (minutes / 2) * 60_000)
    let timer: ReturnType<typeof setTimeout>
    const reset = () => {
      clearTimeout(timer)
      timer = setTimeout(() => logout(), minutes * 60 * 1000)
      const now = Date.now()
      if (now - lastRefresh.current >= refreshEvery) {
        lastRefresh.current = now
        void slideRefresh()
      }
    }
    const events = ['mousemove', 'keydown', 'click', 'scroll', 'touchstart']
    events.forEach((e) => window.addEventListener(e, reset, { passive: true }))
    reset()
    return () => {
      clearTimeout(timer)
      events.forEach((e) => window.removeEventListener(e, reset))
    }
    
  }, [state.token, state.sessionTimeoutMinutes])

  return (
    <AuthContext.Provider value={{ ...state, loginPassword, enroll, verify, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth deve ser usado dentro de AuthProvider')
  return ctx
}
