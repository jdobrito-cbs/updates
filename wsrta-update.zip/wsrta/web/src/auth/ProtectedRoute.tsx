import { Navigate } from 'react-router-dom'
import type { ReactNode } from 'react'

import { useAuth } from './AuthContext'
import type { Role } from '../api/types'


export function RequireRole({ role, children }: { role: Role; children: ReactNode }) {
  const { token, role: current, ready } = useAuth()

  if (!ready) return null
  if (!token) return <Navigate to="/login" replace />
  if (current !== role) {
    const home = current === 'admin' ? '/admin' : current === 'reseller' ? '/reseller' : '/client'
    return <Navigate to={home} replace />
  }
  return <>{children}</>
}
