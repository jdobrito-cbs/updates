import { Outlet } from 'react-router-dom'
import { AppWindow, Clock, Cloud, Code2, Container, Database, FolderUp, Gauge, Globe, HardDrive, Info, KeyRound, Mail, Newspaper } from 'lucide-react'

import { useEdition } from '../../api/hooks'
import { AppShell } from '../../components/AppShell'
import type { NavGroup } from '../../components/AppShell'



function clientGroups(complete: boolean): NavGroup[] {
  const hospedagem = [
    { to: '/client/domains', label: 'Domínios', icon: <Globe className="h-4 w-4" /> },
    { to: '/client/databases', label: 'Bancos', icon: <Database className="h-4 w-4" /> },
    { to: '/client/wordpress', label: 'WordPress', icon: <Newspaper className="h-4 w-4" /> },
    { to: '/client/runtimes', label: 'Linguagens', icon: <Code2 className="h-4 w-4" /> },
  ]
  if (complete) {
    hospedagem.splice(
      3,
      0,
      { to: '/client/apps', label: 'Apps', icon: <AppWindow className="h-4 w-4" /> },
      { to: '/client/docker', label: 'Docker', icon: <Container className="h-4 w-4" /> },
      { to: '/client/email', label: 'E-mail', icon: <Mail className="h-4 w-4" /> },
    )
  }
  return [
    { items: [{ to: '/client/overview', label: 'Visão geral', icon: <Gauge className="h-4 w-4" /> }] },
    { label: 'Hospedagem', items: hospedagem },
    {
      label: 'Acesso',
      items: [
        { to: '/client/sftp', label: 'SFTP', icon: <FolderUp className="h-4 w-4" /> },
        { to: '/client/cloudflare', label: 'Cloudflare', icon: <Cloud className="h-4 w-4" /> },
        { to: '/client/files', label: 'Arquivos', icon: <HardDrive className="h-4 w-4" /> },
        { to: '/client/cron', label: 'Cron', icon: <Clock className="h-4 w-4" /> },
      ],
    },
    {
      items: [
        { to: '/client/account', label: 'Conta', icon: <KeyRound className="h-4 w-4" /> },
        { to: '/client/about', label: 'Sobre', icon: <Info className="h-4 w-4" /> },
      ],
    },
  ]
}

export function ClientLayout() {
  const edition = useEdition()
  return (
    <AppShell groups={clientGroups(edition.data?.complete ?? false)}>
      <Outlet />
    </AppShell>
  )
}
