import { Code2, Gauge, KeyRound } from 'lucide-react'

import { useEdition } from '../../api/hooks'
import { FeatureGrid } from '../../components/FeatureGrid'
import { AppsPanel } from '../../components/panels/AppsPanel'
import { DockerPanel } from '../../components/panels/DockerPanel'
import { EmailPanel } from '../../components/panels/EmailPanel'
import { ChangePasswordCard } from '../../components/panels/ChangePasswordCard'
import { CronPanel } from '../../components/panels/CronPanel'
import { DatabasesPanel } from '../../components/panels/DatabasesPanel'
import { DomainsPanel } from '../../components/panels/DomainsPanel'
import { FileManager } from '../../components/FileManager'
import { CloudflarePanel } from '../../components/panels/CloudflarePanel'
import { DBAccessPanel } from '../../components/panels/DBAccessPanel'
import { SftpPanel } from '../../components/panels/SftpPanel'
import { StatsPanel } from '../../components/panels/StatsPanel'
import { SystemDonuts } from '../../components/panels/SystemDonuts'
import { VpsPowerPanel } from '../../components/panels/VpsPowerPanel'
import { WordPressPanel } from '../../components/panels/WordPressPanel'
import { RuntimesPanel } from '../../components/panels/RuntimesPanel'
import { PageHeader } from '../../components/ui/PageHeader'


const ROOT = '/api'

export function OverviewPage() {
  const edition = useEdition()
  return (
    <div className="space-y-5">
      <PageHeader icon={<Gauge className="h-6 w-6" />} title="Visão geral" subtitle="Seus recursos" />
      <SystemDonuts />
      {}
      <FeatureGrid complete={edition.data?.complete ?? false} />
      <VpsPowerPanel root={ROOT} />
      <StatsPanel root={ROOT} />
    </div>
  )
}

export function ClientDomainsPage() {
  
  return <DomainsPanel root={ROOT} />
}

export function ClientDatabasesPage() {
  return (
    <div className="space-y-6">
      <DatabasesPanel root={ROOT} />
      {
}
      <DBAccessPanel root={ROOT} />
    </div>
  )
}

export function ClientCronPage() {
  return <CronPanel root={ROOT} />
}

export function ClientWordPressPage() {
  return <WordPressPanel root={ROOT} />
}

export function ClientAppsPage() {
  return <AppsPanel root={ROOT} />
}

export function ClientDockerPage() {
  return <DockerPanel root={ROOT} />
}

export function ClientEmailPage() {
  return <EmailPanel root={ROOT} />
}

export function ClientRuntimesPage() {
  return (
    <div className="space-y-6">
      <PageHeader icon={<Code2 className="h-6 w-6" />} title="Linguagens" subtitle="Liberadas pelo administrador" />
      <RuntimesPanel root={ROOT} canManage={false} />
    </div>
  )
}

export function ClientSftpPage() {
  return <SftpPanel root={ROOT} canManage={false} />
}

export function ClientCloudflarePage() {
  return <CloudflarePanel root={ROOT} />
}

export function ClientFilesPage() {
  return <FileManager base="/api/files" />
}

export function ClientAccountPage() {
  return (
    <div className="space-y-5">
      <PageHeader icon={<KeyRound className="h-6 w-6" />} title="Conta" subtitle="Sua senha de acesso ao painel" />
      <ChangePasswordCard />
    </div>
  )
}
