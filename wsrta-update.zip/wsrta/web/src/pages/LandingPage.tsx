import { useState } from 'react'
import type { ReactNode } from 'react'
import { Link, useParams } from 'react-router-dom'
import { ArrowRight, Check, Cpu, Database, Globe, HardDrive, LogIn, Server, X, Zap } from 'lucide-react'

import { useCheckout, usePublicResellerSite, usePublicSite } from '../api/hooks'
import type { PublicPackage } from '../api/hooks'
import { ApiError } from '../api/client'

const brl = (cents: number) => (cents / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })



interface Theme {
  page: string
  radial: string
  accent: string
  badge: string
  ring: string
  muted: string
}


const THEMES: Record<string, Theme> = {
  admin: { page: 'bg-[#0a0b0f] text-slate-100', radial: 'rgba(99,102,241,0.25)', accent: 'from-indigo-500 to-violet-500', badge: 'text-indigo-300 border-indigo-400/30 bg-indigo-500/10', ring: 'border-indigo-400/40 bg-indigo-500/5', muted: 'text-slate-400' },
  aurora: { page: 'bg-[#06100d] text-emerald-50', radial: 'rgba(16,185,129,0.25)', accent: 'from-emerald-500 to-teal-500', badge: 'text-emerald-300 border-emerald-400/30 bg-emerald-500/10', ring: 'border-emerald-400/40 bg-emerald-500/5', muted: 'text-emerald-200/60' },
  midnight: { page: 'bg-black text-slate-100', radial: 'rgba(59,130,246,0.25)', accent: 'from-blue-500 to-indigo-600', badge: 'text-blue-300 border-blue-400/30 bg-blue-500/10', ring: 'border-blue-400/40 bg-blue-500/5', muted: 'text-slate-400' },
  sunset: { page: 'bg-[#140a0a] text-orange-50', radial: 'rgba(249,115,22,0.28)', accent: 'from-orange-500 to-pink-500', badge: 'text-orange-300 border-orange-400/30 bg-orange-500/10', ring: 'border-orange-400/40 bg-orange-500/5', muted: 'text-orange-200/60' },
  forest: { page: 'bg-[#08120a] text-green-50', radial: 'rgba(34,197,94,0.25)', accent: 'from-green-500 to-lime-600', badge: 'text-green-300 border-green-400/30 bg-green-500/10', ring: 'border-green-400/40 bg-green-500/5', muted: 'text-green-200/60' },
  ocean: { page: 'bg-[#06121a] text-cyan-50', radial: 'rgba(6,182,212,0.28)', accent: 'from-cyan-500 to-blue-500', badge: 'text-cyan-300 border-cyan-400/30 bg-cyan-500/10', ring: 'border-cyan-400/40 bg-cyan-500/5', muted: 'text-cyan-200/60' },
  royal: { page: 'bg-[#100a16] text-purple-50', radial: 'rgba(168,85,247,0.28)', accent: 'from-purple-500 to-fuchsia-500', badge: 'text-purple-300 border-purple-400/30 bg-purple-500/10', ring: 'border-purple-400/40 bg-purple-500/5', muted: 'text-purple-200/60' },
  ember: { page: 'bg-[#160808] text-red-50', radial: 'rgba(239,68,68,0.28)', accent: 'from-red-500 to-orange-500', badge: 'text-red-300 border-red-400/30 bg-red-500/10', ring: 'border-red-400/40 bg-red-500/5', muted: 'text-red-200/60' },
  slate: { page: 'bg-[#0d1117] text-slate-100', radial: 'rgba(148,163,184,0.22)', accent: 'from-slate-500 to-slate-700', badge: 'text-slate-300 border-slate-400/30 bg-slate-500/10', ring: 'border-slate-400/40 bg-slate-500/5', muted: 'text-slate-400' },
  neon: { page: 'bg-black text-lime-50', radial: 'rgba(132,204,22,0.25)', accent: 'from-lime-400 to-emerald-500', badge: 'text-lime-300 border-lime-400/30 bg-lime-500/10', ring: 'border-lime-400/40 bg-lime-500/5', muted: 'text-lime-200/60' },
  sand: { page: 'bg-[#15110a] text-amber-50', radial: 'rgba(245,158,11,0.26)', accent: 'from-amber-500 to-yellow-500', badge: 'text-amber-300 border-amber-400/30 bg-amber-500/10', ring: 'border-amber-400/40 bg-amber-500/5', muted: 'text-amber-200/60' },
  rose: { page: 'bg-[#160a10] text-rose-50', radial: 'rgba(244,63,94,0.26)', accent: 'from-rose-500 to-pink-500', badge: 'text-rose-300 border-rose-400/30 bg-rose-500/10', ring: 'border-rose-400/40 bg-rose-500/5', muted: 'text-rose-200/60' },
  mono: { page: 'bg-zinc-950 text-zinc-100', radial: 'rgba(255,255,255,0.12)', accent: 'from-zinc-200 to-zinc-400', badge: 'text-zinc-300 border-zinc-500/30 bg-zinc-500/10', ring: 'border-zinc-300/40 bg-zinc-500/5', muted: 'text-zinc-400' },
}

export const LANDING_TEMPLATES = ['aurora', 'midnight', 'sunset', 'forest', 'ocean', 'royal', 'ember', 'slate', 'neon', 'sand', 'rose', 'mono']

interface LandingData {
  company_name: string
  packages: PublicPackage[]
  headline?: string
  subtitle?: string
}



export function LandingView({ data, template, scope }: { data: LandingData; template: string; scope: string }) {
  const t = THEMES[template] ?? THEMES.admin
  const checkout = useCheckout()
  const [buying, setBuying] = useState<PublicPackage | null>(null)
  const [email, setEmail] = useState('')
  const [err, setErr] = useState('')

  async function pay() {
    if (!buying) return
    setErr('')
    try {
      const res = await checkout.mutateAsync({ scope, package_id: buying.id, email: email.trim() })
      window.location.href = res.init_point 
    } catch (e) {
      setErr(e instanceof ApiError ? e.message : 'falha ao iniciar o pagamento')
    }
  }

  const company = data.company_name || 'WSRTA'
  const packages = data.packages ?? []
  const headline = data.headline || 'Seu site no ar, rápido e isolado'
  const subtitle =
    data.subtitle ||
    'Containers isolados por cliente, painel completo, banco de dados, SSL automático e suporte. Escolha um plano e comece em minutos.'

  return (
    <div className={`min-h-screen ${t.page}`}>
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <div className="flex items-center gap-2 text-lg font-semibold">
          <Server className="h-6 w-6 opacity-80" /> {company}
        </div>
        <Link to="/login" className="inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/5 px-4 py-2 text-sm font-medium transition hover:bg-white/10">
          <LogIn className="h-4 w-4" /> Entrar
        </Link>
      </header>

      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0" style={{ background: `radial-gradient(60% 50% at 50% 0%, ${t.radial}, transparent)` }} />
        <div className="mx-auto max-w-4xl px-6 py-20 text-center">
          <span className={`inline-flex items-center gap-1 rounded-full border px-3 py-1 text-xs font-medium ${t.badge}`}>
            <Zap className="h-3.5 w-3.5" /> Hospedagem em VPS de alto desempenho
          </span>
          <h1 className="mt-5 text-4xl font-bold tracking-tight sm:text-5xl">{headline}</h1>
          <p className={`mx-auto mt-4 max-w-2xl text-base ${t.muted}`}>{subtitle}</p>
          <div className="mt-8 flex items-center justify-center gap-3">
            <a href="#planos" className={`inline-flex items-center gap-2 rounded-lg bg-gradient-to-r ${t.accent} px-5 py-3 text-sm font-semibold text-white shadow-lg transition hover:opacity-90`}>
              Ver planos <ArrowRight className="h-4 w-4" />
            </a>
            <Link to="/login" className="rounded-lg border border-white/15 px-5 py-3 text-sm font-medium hover:bg-white/5">
              Já sou cliente
            </Link>
          </div>
        </div>
      </section>

      <section id="planos" className="mx-auto max-w-6xl px-6 pb-24">
        <h2 className="mb-2 text-center text-2xl font-bold">Planos</h2>
        <p className={`mb-10 text-center text-sm ${t.muted}`}>Escolha o que cabe no seu projeto.</p>
        {packages.length === 0 ? (
          <p className={`text-center ${t.muted}`}>Em breve novos planos. Fale com a gente pelo login.</p>
        ) : (
          <div className="grid gap-6 md:grid-cols-3">
            {packages.map((p, i) => (
              <PlanCard key={p.id} p={p} t={t} featured={i === 1} onSubscribe={setBuying} />
            ))}
          </div>
        )}
      </section>

      {}
      {buying && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4" onClick={() => setBuying(null)}>
          <div className="w-full max-w-sm rounded-2xl border border-white/15 bg-zinc-900 p-6 text-slate-100" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-lg font-semibold">Assinar {buying.name}</h3>
              <button onClick={() => setBuying(null)} className="text-slate-400 hover:text-white">
                <X className="h-5 w-5" />
              </button>
            </div>
            <p className="mb-4 text-sm text-slate-400">{brl(buying.price_cents)}{buying.duration_days > 0 && ` / ${buying.duration_days} dias`}</p>
            <label className="mb-1 block text-xs text-slate-400">seu e-mail (será o login)</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="voce@email.com"
              className="w-full rounded-lg border border-white/15 bg-white/5 px-3 py-2 text-sm text-white outline-none focus:border-white/40"
            />
            {err && <p className="mt-2 text-xs text-red-400">{err}</p>}
            <button
              onClick={pay}
              disabled={checkout.isPending || !email.trim()}
              className={`mt-4 w-full rounded-lg bg-gradient-to-r ${t.accent} px-4 py-2.5 text-sm font-semibold text-white transition hover:opacity-90 disabled:opacity-50`}
            >
              {checkout.isPending ? 'redirecionando…' : 'Ir para o pagamento'}
            </button>
            <p className="mt-3 text-center text-[11px] text-slate-500">pagamento processado pelo MercadoPago</p>
          </div>
        </div>
      )}

      <footer className="border-t border-white/10 py-8 text-center text-xs opacity-60">© {company} — painel WSRTA</footer>
    </div>
  )
}

function PlanCard({ p, t, featured, onSubscribe }: { p: PublicPackage; t: Theme; featured?: boolean; onSubscribe: (p: PublicPackage) => void }) {
  return (
    <div className={`relative rounded-2xl border p-6 ${featured ? `${t.ring} shadow-xl` : 'border-white/10 bg-white/[0.03]'}`}>
      {featured && (
        <span className={`absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r ${t.accent} px-3 py-0.5 text-[11px] font-semibold text-white`}>
          mais popular
        </span>
      )}
      <h3 className="text-lg font-semibold">{p.name}</h3>
      <p className="mt-2">
        <span className="text-3xl font-bold">{brl(p.price_cents)}</span>
        {p.duration_days > 0 && <span className={`text-sm ${t.muted}`}> /{p.duration_days}d</span>}
      </p>
      <ul className="mt-5 space-y-2 text-sm opacity-90">
        <Spec icon={<Cpu className="h-4 w-4 opacity-70" />}>{p.cpu_limit} vCPU</Spec>
        <Spec icon={<Zap className="h-4 w-4 opacity-70" />}>{p.ram_limit_mb} MB RAM</Spec>
        <Spec icon={<HardDrive className="h-4 w-4 opacity-70" />}>{Math.round(p.disk_quota_mb / 1024)} GB disco</Spec>
        <Spec icon={<Globe className="h-4 w-4 opacity-70" />}>{p.max_domains || '∞'} domínios</Spec>
        <Spec icon={<Database className="h-4 w-4 opacity-70" />}>{p.max_databases || '∞'} bancos</Spec>
      </ul>
      <button
        onClick={() => onSubscribe(p)}
        className={`mt-6 block w-full rounded-lg px-4 py-2.5 text-center text-sm font-semibold transition ${
          featured ? `bg-gradient-to-r ${t.accent} text-white hover:opacity-90` : 'border border-white/15 hover:bg-white/5'
        }`}
      >
        Assinar
      </button>
    </div>
  )
}

function Spec({ icon, children }: { icon: ReactNode; children: ReactNode }) {
  return (
    <li className="flex items-center gap-2">
      {icon}
      <Check className="h-3.5 w-3.5 text-emerald-400" /> {children}
    </li>
  )
}


export function LandingPage() {
  const { data } = usePublicSite()
  return <LandingView data={{ company_name: data?.company_name ?? 'WSRTA', packages: data?.packages ?? [] }} template="admin" scope="admin" />
}



export function ResellerLandingPage() {
  const { slug = '' } = useParams()
  const { data, isLoading, isError } = usePublicResellerSite(slug)

  
  
  if (data?.external_site_url && /^https?:\/\//i.test(data.external_site_url)) {
    window.location.href = data.external_site_url
    return null
  }
  if (isLoading) return <div className="grid min-h-screen place-items-center bg-zinc-950 text-zinc-400">carregando…</div>
  if (isError || !data) return <div className="grid min-h-screen place-items-center bg-zinc-950 text-zinc-400">revenda não encontrada</div>
  return (
    <LandingView
      data={{ company_name: data.company_name, packages: data.packages, headline: data.headline, subtitle: data.subtitle }}
      template={data.template}
      scope={slug}
    />
  )
}
