import { useEffect, useRef, useState } from 'react'
import type { FormEvent } from 'react'
import {
  AppWindow,
  Archive,
  Clock,
  Cloud,
  Code2,
  Container,
  Database,
  FolderUp,
  Gauge,
  Globe,
  HardDrive,
  Mail,
  Newspaper,
  Server,
  SlidersHorizontal,
  Waypoints,
} from 'lucide-react'

import { ApiError } from '../../api/client'
import { useEdition } from '../../api/hooks'
import { SELF_ROOT, useActivateSelf, useSelfStatus, useSetSelfLimits } from '../../api/self'
import { AppsPanel } from '../../components/panels/AppsPanel'
import { DockerPanel } from '../../components/panels/DockerPanel'
import { EmailPanel } from '../../components/panels/EmailPanel'
import { BackupPanel } from '../../components/panels/BackupPanel'
import { CloudflarePanel } from '../../components/panels/CloudflarePanel'
import { CronPanel } from '../../components/panels/CronPanel'
import { DatabasesPanel } from '../../components/panels/DatabasesPanel'
import { DBAccessPanel } from '../../components/panels/DBAccessPanel'
import { DnsPanel } from '../../components/panels/DnsPanel'
import { DomainsPanel } from '../../components/panels/DomainsPanel'
import { FileManager } from '../../components/FileManager'
import { LiberacoesPanel } from '../../components/panels/LiberacoesPanel'
import { RuntimesPanel } from '../../components/panels/RuntimesPanel'
import { SftpPanel } from '../../components/panels/SftpPanel'
import { StatsPanel } from '../../components/panels/StatsPanel'
import { VpsPowerPanel } from '../../components/panels/VpsPowerPanel'
import { WordPressPanel } from '../../components/panels/WordPressPanel'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { Field } from '../../components/ui/Field'
import { Input } from '../../components/ui/Input'
import { PageHeader } from '../../components/ui/PageHeader'
import { Spinner } from '../../components/ui/Spinner'
import { Tabs } from '../../components/ui/Tabs'
import type { TabItem } from '../../components/ui/Tabs'
import { useToast } from '../../components/ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

const tabs: TabItem[] = [
  { key: 'visao', label: 'Visão geral', icon: <Gauge className="h-4 w-4" /> },
  { key: 'dominios', label: 'Domínios', icon: <Globe className="h-4 w-4" /> },
  { key: 'dns', label: 'DNS', icon: <Waypoints className="h-4 w-4" /> },
  { key: 'bancos', label: 'Bancos', icon: <Database className="h-4 w-4" /> },
  { key: 'wordpress', label: 'WordPress', icon: <Newspaper className="h-4 w-4" /> },
  { key: 'linguagens', label: 'Linguagens', icon: <Code2 className="h-4 w-4" /> },
  { key: 'sftp', label: 'SFTP', icon: <FolderUp className="h-4 w-4" /> },
  { key: 'backup', label: 'Backup', icon: <Archive className="h-4 w-4" /> },
  { key: 'cloudflare', label: 'Cloudflare', icon: <Cloud className="h-4 w-4" /> },
  { key: 'arquivos', label: 'Arquivos', icon: <HardDrive className="h-4 w-4" /> },
  { key: 'cron', label: 'Cron', icon: <Clock className="h-4 w-4" /> },
]

const appsTab: TabItem = { key: 'apps', label: 'Apps', icon: <AppWindow className="h-4 w-4" /> }
const dockerTab: TabItem = { key: 'docker', label: 'Docker', icon: <Container className="h-4 w-4" /> }
const emailTab: TabItem = { key: 'email', label: 'E-mail', icon: <Mail className="h-4 w-4" /> }





export function SelfVpsArea() {
  const { data, isLoading } = useSelfStatus()
  const edition = useEdition()
  const activate = useActivateSelf()
  const [tab, setTab] = useState('visao')
  const triggered = useRef(false)

  
  
  useEffect(() => {
    if (data && !data.provisioned && !triggered.current && !activate.isPending) {
      triggered.current = true
      activate.mutate()
    }
  }, [data, activate])

  if (isLoading || !data) return <Spinner />

  if (!data.provisioned) {
    return (
      <div className="space-y-5">
        <PageHeader icon={<Server className="h-6 w-6" />} title="Minha VPS" subtitle="Sua hospedagem própria" />
        <Card className="space-y-3 p-6 text-center">
          <Server className="mx-auto h-10 w-10 text-accent" />
          <p className="text-ink">Ativando sua VPS pessoal…</p>
          <p className="text-sm text-muted">
            O container está sendo criado e provisionado. Isso leva alguns instantes — acompanhe pela Fila.
          </p>
          {activate.isError && (
            <Button onClick={() => activate.mutate()} disabled={activate.isPending}>
              {activate.isPending ? <Spinner /> : 'Tentar ativar novamente'}
            </Button>
          )}
        </Card>
      </div>
    )
  }

  const provisioning = data.client?.status === 'provisioning'

  return (
    <div className="space-y-5">
      <PageHeader
        icon={<Server className="h-6 w-6" />}
        title="Minha VPS"
        subtitle={`Container ${data.client?.lxc_container_name ?? ''} — controle total`}
      />
      {provisioning && (
        <Card className="border-pending/40 bg-pending/10 p-4 text-sm text-pending">
          Sua VPS está sendo provisionada. Alguns recursos podem ficar indisponíveis até concluir (acompanhe pela Fila).
        </Card>
      )}

      <Tabs tabs={edition.data?.complete ? [...tabs, appsTab, dockerTab, emailTab] : tabs} active={tab} onChange={setTab} />

      <div>
        {tab === 'visao' && (
          <div className="space-y-5">
            <StatsPanel root={SELF_ROOT} />
            <VpsPowerPanel root={SELF_ROOT} />
            {data.can_edit_limits && <SelfLimitsCard status={data} />}
          </div>
        )}
        {tab === 'dominios' && <DomainsPanel root={SELF_ROOT} canManage />}
        {tab === 'dns' && <DnsPanel root={SELF_ROOT} />}
        {tab === 'bancos' && (
          <div className="space-y-6">
            <DatabasesPanel root={SELF_ROOT} />
            <DBAccessPanel root={SELF_ROOT} />
            <LiberacoesPanel root={SELF_ROOT} />
          </div>
        )}
        {tab === 'wordpress' && <WordPressPanel root={SELF_ROOT} />}
        {tab === 'linguagens' && <RuntimesPanel root={SELF_ROOT} canManage />}
        {tab === 'sftp' && <SftpPanel root={SELF_ROOT} canManage />}
        {tab === 'backup' && <BackupPanel root={SELF_ROOT} />}
        {tab === 'cloudflare' && <CloudflarePanel root={SELF_ROOT} />}
        {tab === 'arquivos' && <FileManager base={`${SELF_ROOT}/files`} />}
        {tab === 'cron' && <CronPanel root={SELF_ROOT} />}
        {tab === 'apps' && <AppsPanel root={SELF_ROOT} />}
        {tab === 'docker' && <DockerPanel root={SELF_ROOT} />}
        {tab === 'email' && <EmailPanel root={SELF_ROOT} />}
      </div>
    </div>
  )
}


function SelfLimitsCard({ status }: { status: { client?: { cpu_limit: number; ram_limit_mb: number; disk_quota_mb: number; max_domains: number; max_databases: number; bandwidth_limit_mb: number } } }) {
  const set = useSetSelfLimits()
  const toast = useToast()
  const c = status.client
  const [cpu, setCpu] = useState(String(c?.cpu_limit ?? 2))
  const [ram, setRam] = useState(String(c?.ram_limit_mb ?? 2048))
  const [disk, setDisk] = useState(String(c?.disk_quota_mb ?? 20480))
  const [maxDom, setMaxDom] = useState(String(c?.max_domains ?? 0))
  const [maxDb, setMaxDb] = useState(String(c?.max_databases ?? 0))
  const [band, setBand] = useState(String(c?.bandwidth_limit_mb ?? 0))

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    try {
      await set.mutateAsync({
        cpu_limit: Number(cpu) || 1,
        ram_limit_mb: Number(ram) || 512,
        disk_quota_mb: Number(disk) || 5120,
        max_domains: Number(maxDom) || 0,
        max_databases: Number(maxDb) || 0,
        bandwidth_limit_mb: Number(band) || 0,
      })
      toast.push('success', 'limites atualizados — aplicando ao container (acompanhe a Fila)')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <Card className="p-5">
      <h2 className="mb-3 flex items-center gap-2 font-display text-lg text-ink">
        <SlidersHorizontal className="h-4 w-4 text-accent" /> Limites da sua VPS
      </h2>
      <form onSubmit={onSubmit} className="space-y-3">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          <Field label="vCPU">
            <Input type="number" min="1" step="0.5" value={cpu} onChange={(e) => setCpu(e.target.value)} />
          </Field>
          <Field label="RAM (MB)">
            <Input type="number" min="256" step="256" value={ram} onChange={(e) => setRam(e.target.value)} />
          </Field>
          <Field label="Disco (MB)">
            <Input type="number" min="1024" step="1024" value={disk} onChange={(e) => setDisk(e.target.value)} />
          </Field>
          <Field label="Máx. domínios (0=ilim.)">
            <Input type="number" min="0" value={maxDom} onChange={(e) => setMaxDom(e.target.value)} />
          </Field>
          <Field label="Máx. bancos (0=ilim.)">
            <Input type="number" min="0" value={maxDb} onChange={(e) => setMaxDb(e.target.value)} />
          </Field>
          <Field label="Banda MB/mês (0=ilim.)">
            <Input type="number" min="0" value={band} onChange={(e) => setBand(e.target.value)} />
          </Field>
        </div>
        <Button type="submit" disabled={set.isPending}>
          {set.isPending ? <Spinner /> : 'Salvar limites'}
        </Button>
      </form>
    </Card>
  )
}
