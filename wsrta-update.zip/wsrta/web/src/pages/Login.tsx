import { useState } from 'react'
import type { FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { QRCodeSVG } from 'qrcode.react'
import { Copy, KeyRound, ShieldCheck } from 'lucide-react'

import { ApiError } from '../api/client'
import type { Role } from '../api/types'
import { useAuth } from '../auth/AuthContext'
import { Logo } from '../components/Logo'
import { Button } from '../components/ui/Button'
import { Field } from '../components/ui/Field'
import { Input } from '../components/ui/Input'
import { Spinner } from '../components/ui/Spinner'

type Step = 'password' | 'enroll' | 'mfa' | 'recovery'

export function LoginPage() {
  const { loginPassword, enroll, verify } = useAuth()
  const navigate = useNavigate()

  const [step, setStep] = useState<Step>('password')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [code, setCode] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  const [tempToken, setTempToken] = useState('')
  const [otpauthUrl, setOtpauthUrl] = useState('')
  const [secret, setSecret] = useState('')
  const [recoveryCodes, setRecoveryCodes] = useState<string[]>([])
  const [role, setRole] = useState<Role>('client')

  const go = (r: Role) =>
    navigate(r === 'admin' ? '/admin' : r === 'reseller' ? '/reseller' : '/client', { replace: true })
  const fail = (err: unknown) => setError(err instanceof ApiError ? err.message : 'falha na autenticação')

  async function onPassword(e: FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      const res = await loginPassword(email, password)
      setTempToken(res.token)
      setCode('')
      if (res.stage === 'enroll') {
        setOtpauthUrl(res.otpauth_url)
        setSecret(res.secret)
        setStep('enroll')
      } else {
        setStep('mfa')
      }
    } catch (err) {
      fail(err)
    } finally {
      setLoading(false)
    }
  }

  async function onEnroll(e: FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      const res = await enroll(tempToken, code)
      setRole(res.role)
      setRecoveryCodes(res.recoveryCodes)
      setStep('recovery')
    } catch (err) {
      fail(err)
    } finally {
      setLoading(false)
    }
  }

  async function onVerify(e: FormEvent) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    try {
      go(await verify(tempToken, code))
    } catch (err) {
      fail(err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div
      className="flex h-full items-center justify-center p-4"
      style={{
        background:
          'radial-gradient(820px 480px at 12% -10%, rgb(var(--c-accent) / 0.16), transparent 60%), radial-gradient(720px 480px at 110% 120%, rgb(var(--c-accent) / 0.10), transparent 55%)',
      }}
    >
      <div className="w-full max-w-sm">
        <div className="mb-8 flex items-center gap-3">
          <Logo size={42} />
          <span className="font-display text-2xl tracking-tight text-ink">wsrta</span>
          <span className="ml-auto font-mono text-xs text-faint">painel de controle</span>
        </div>

        <div className="rounded-2xl border border-line bg-panel p-6 shadow-2xl shadow-black/30">
          {step === 'password' && (
            <form onSubmit={onPassword} className="space-y-4">
              <Field label="email">
                <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="username" required />
              </Field>
              <Field label="senha">
                <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" required />
              </Field>
              {error && <p className="text-sm text-failed">{error}</p>}
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? <Spinner /> : 'Entrar'}
              </Button>
            </form>
          )}

          {step === 'enroll' && (
            <form onSubmit={onEnroll} className="space-y-4">
              <div className="flex items-center gap-2 text-ink">
                <ShieldCheck className="h-5 w-5 text-accent" />
                <h2 className="font-display text-lg">Configure o 2FA</h2>
              </div>
              <p className="text-sm text-muted">
                Escaneie o QR no Google Authenticator (ou app TOTP) e informe o código gerado.
              </p>
              <div className="flex justify-center">
                <div className="rounded-md bg-white p-3">
                  <QRCodeSVG value={otpauthUrl} size={160} />
                </div>
              </div>
              <p className="break-all text-center font-mono text-xs text-faint">{secret}</p>
              <Field label="código de 6 dígitos">
                <Input value={code} onChange={(e) => setCode(e.target.value)} inputMode="numeric" autoFocus required />
              </Field>
              {error && <p className="text-sm text-failed">{error}</p>}
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? <Spinner /> : 'Ativar e entrar'}
              </Button>
            </form>
          )}

          {step === 'mfa' && (
            <form onSubmit={onVerify} className="space-y-4">
              <div className="flex items-center gap-2 text-ink">
                <KeyRound className="h-5 w-5 text-accent" />
                <h2 className="font-display text-lg">Verificação 2FA</h2>
              </div>
              <Field label="código do autenticador">
                <Input value={code} onChange={(e) => setCode(e.target.value)} inputMode="text" autoFocus required />
              </Field>
              <p className="text-xs text-faint">Sem o app? Use um dos seus códigos de recuperação aqui.</p>
              {error && <p className="text-sm text-failed">{error}</p>}
              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? <Spinner /> : 'Entrar'}
              </Button>
            </form>
          )}

          {step === 'recovery' && (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-ink">
                <KeyRound className="h-5 w-5 text-running" />
                <h2 className="font-display text-lg">Códigos de recuperação</h2>
              </div>
              <p className="text-sm text-muted">
                Guarde estes códigos em local seguro. Cada um serve uma vez, no lugar do app.
                <strong className="text-ink"> Não serão exibidos de novo.</strong>
              </p>
              <div className="grid grid-cols-2 gap-2 rounded-md border border-line bg-base p-3 font-mono text-sm text-ink">
                {recoveryCodes.map((c) => (
                  <span key={c}>{c}</span>
                ))}
              </div>
              <Button
                variant="ghost"
                className="w-full"
                onClick={() => navigator.clipboard?.writeText(recoveryCodes.join('\n'))}
              >
                <Copy className="h-4 w-4" /> Copiar códigos
              </Button>
              <Button className="w-full" onClick={() => go(role)}>
                Entrar
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
