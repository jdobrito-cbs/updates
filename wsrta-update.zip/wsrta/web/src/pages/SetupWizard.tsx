import { useState } from 'react'
import type { FormEvent } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { Building2, CheckCircle2, Globe, Server, UserCog } from 'lucide-react'

import { ApiError } from '../api/client'
import { useSetup } from '../api/hooks'
import { Logo } from '../components/Logo'
import { Button } from '../components/ui/Button'
import { Field } from '../components/ui/Field'
import { Input } from '../components/ui/Input'
import { Spinner } from '../components/ui/Spinner'



export function SetupWizard({ serverIp }: { serverIp: string }) {
  const setup = useSetup()
  const qc = useQueryClient()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [company, setCompany] = useState('')
  const [domain, setDomain] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [done, setDone] = useState(false)

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)
    if (password.length < 8) {
      setError('a senha do admin deve ter ao menos 8 caracteres')
      return
    }
    if (password !== confirm) {
      setError('as senhas não conferem')
      return
    }
    try {
      await setup.mutateAsync({
        admin_name: name,
        admin_email: email,
        admin_password: password,
        company_name: company,
        panel_domain: domain,
      })
      setDone(true)
      
      setTimeout(() => {
        qc.invalidateQueries({ queryKey: ['setup-status'] })
      }, 2000)
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'falha ao concluir a instalação')
    }
  }

  return (
    <div
      className="flex min-h-full items-center justify-center p-4"
      style={{
        background:
          'radial-gradient(820px 480px at 12% -10%, rgb(var(--c-accent) / 0.16), transparent 60%), radial-gradient(720px 480px at 110% 120%, rgb(var(--c-accent) / 0.10), transparent 55%)',
      }}
    >
      <div className="w-full max-w-lg py-8">
        <div className="mb-8 flex items-center gap-3">
          <Logo size={42} />
          <span className="font-display text-2xl tracking-tight text-ink">wsrta</span>
          <span className="ml-auto font-mono text-xs text-faint">instalação</span>
        </div>

        <div className="rounded-2xl border border-line bg-panel p-6 shadow-2xl shadow-black/30">
          {done ? (
            <div className="space-y-3 py-6 text-center">
              <CheckCircle2 className="mx-auto h-12 w-12 text-done" />
              <h2 className="font-display text-xl text-ink">Instalação concluída!</h2>
              <p className="text-sm text-muted">Redirecionando para o login…</p>
              <Spinner />
            </div>
          ) : (
            <form onSubmit={onSubmit} className="space-y-5">
              <div>
                <h1 className="font-display text-xl text-ink">Bem-vindo ao WSRTA</h1>
                <p className="mt-1 text-sm text-muted">
                  Conclua a instalação criando o administrador e definindo a empresa e o domínio.
                </p>
                {serverIp && (
                  <p className="mt-2 inline-flex items-center gap-1.5 rounded-md bg-elevated px-2 py-1 font-mono text-xs text-muted">
                    <Server className="h-3.5 w-3.5" /> {serverIp}
                  </p>
                )}
              </div>

              <div className="space-y-3">
                <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-faint">
                  <UserCog className="h-4 w-4" /> Administrador
                </p>
                <Field label="nome">
                  <Input value={name} onChange={(e) => setName(e.target.value)} required maxLength={80} />
                </Field>
                <Field label="email">
                  <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="username" />
                </Field>
                <div className="grid gap-3 sm:grid-cols-2">
                  <Field label="senha (mín. 8)">
                    <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} autoComplete="new-password" />
                  </Field>
                  <Field label="confirmar senha">
                    <Input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} required autoComplete="new-password" />
                  </Field>
                </div>
              </div>

              <div className="space-y-3 border-t border-line pt-4">
                <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-faint">
                  <Building2 className="h-4 w-4" /> Painel
                </p>
                <Field label="nome da empresa">
                  <Input value={company} onChange={(e) => setCompany(e.target.value)} placeholder="Ex.: Minha Empresa" maxLength={60} />
                </Field>
                <Field label="domínio do painel (opcional)">
                  <div className="flex items-center gap-2">
                    <Globe className="h-4 w-4 flex-none text-faint" />
                    <Input value={domain} onChange={(e) => setDomain(e.target.value)} placeholder="painel.seudominio.com" />
                  </div>
                  <p className="mt-1 text-xs text-faint">Deixe em branco para usar o IP do servidor.</p>
                </Field>
              </div>

              {error && <p className="text-sm text-failed">{error}</p>}
              <Button type="submit" className="w-full" disabled={setup.isPending}>
                {setup.isPending ? <Spinner /> : 'Concluir instalação'}
              </Button>
            </form>
          )}
        </div>
        <p className="mt-4 text-center text-xs text-faint">
          Acesso somente por HTTPS · certificado autoassinado do servidor
        </p>
      </div>
    </div>
  )
}
