import { useEffect, useState } from 'react'
import { Navigate } from 'react-router-dom'
import { Boxes } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useAdminAppPerms, useSetAdminAppPerms } from '../../api/apps'
import type { CatalogApp } from '../../api/apps'
import { useEdition } from '../../api/hooks'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { PageHeader } from '../../components/ui/PageHeader'
import { Spinner } from '../../components/ui/Spinner'
import { useToast } from '../../components/ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')


function AppToggleList({ catalog, value, onChange }: { catalog: CatalogApp[]; value: string[]; onChange: (v: string[]) => void }) {
  function toggle(slug: string) {
    onChange(value.includes(slug) ? value.filter((s) => s !== slug) : [...value, slug])
  }
  return (
    <div className="space-y-2">
      {catalog.map((a) => (
        <label key={a.slug} className="flex cursor-pointer items-start gap-3 rounded-lg border border-line p-3 hover:bg-elevated/60">
          <input type="checkbox" checked={value.includes(a.slug)} onChange={() => toggle(a.slug)} className="mt-1" />
          <span>
            <span className="block text-sm text-ink">
              {a.name} <span className="text-[10px] uppercase text-faint">{a.kind}</span>
            </span>
            <span className="block text-xs text-muted">{a.description}</span>
          </span>
        </label>
      ))}
    </div>
  )
}



export function AppsPermissionsPage() {
  const edition = useEdition()
  const { data, isLoading } = useAdminAppPerms()
  const save = useSetAdminAppPerms()
  const toast = useToast()

  const [resellers, setResellers] = useState<string[]>([])
  const [adminClients, setAdminClients] = useState<string[]>([])

  useEffect(() => {
    if (data) {
      setResellers(data.resellers ?? [])
      setAdminClients(data.admin_clients ?? [])
    }
  }, [data])

  if (edition.data && !edition.data.complete) return <Navigate to="/admin/dashboard" replace />
  if (isLoading || !data) return <Spinner />

  async function onSave() {
    try {
      await save.mutateAsync({ resellers, admin_clients: adminClients })
      toast.push('success', 'liberações salvas')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader
        icon={<Boxes className="h-6 w-6" />}
        title="Apps"
        subtitle="Libere quais apps aparecem para as revendas e para os seus clientes diretos"
        actions={
          <Button onClick={onSave} disabled={save.isPending}>
            {save.isPending ? <Spinner /> : 'Salvar'}
          </Button>
        }
      />
      <div className="grid gap-5 lg:grid-cols-2">
        <Card className="space-y-3 p-5">
          <h2 className="font-display text-lg text-ink">Para as revendas</h2>
          <p className="text-sm text-muted">
            O que a revenda pode usar na própria VPS e repassar aos clientes dela (a revenda escolhe um subconjunto).
          </p>
          <AppToggleList catalog={data.catalog} value={resellers} onChange={setResellers} />
        </Card>
        <Card className="space-y-3 p-5">
          <h2 className="font-display text-lg text-ink">Para os meus clientes</h2>
          <p className="text-sm text-muted">Apps que os seus clientes diretos (sem revenda) podem ver e instalar.</p>
          <AppToggleList catalog={data.catalog} value={adminClients} onChange={setAdminClients} />
        </Card>
      </div>
    </div>
  )
}
