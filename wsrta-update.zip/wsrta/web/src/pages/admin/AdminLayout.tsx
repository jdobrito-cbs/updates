import { Outlet } from 'react-router-dom'
import {
  Activity,
  AppWindow,
  Boxes,
  CreditCard,
  DownloadCloud,
  HardDrive,
  HardDriveDownload,
  Info,
  LayoutDashboard,
  ListChecks,
  Server,
  Settings,
  ShieldAlert,
  ShieldCheck,
  ShieldX,
  Store,
  UserCog,
  Users,
} from 'lucide-react'

import { useEdition } from '../../api/hooks'
import { AppShell } from '../../components/AppShell'
import type { NavGroup } from '../../components/AppShell'
import { StatusRail } from '../../components/StatusRail'


function adminGroups(complete: boolean): NavGroup[] {
  const operacao = [
    { to: '/admin/clients', label: 'Clientes', icon: <Users className="h-4 w-4" /> },
    { to: '/admin/import', label: 'Importar', icon: <DownloadCloud className="h-4 w-4" /> },
    { to: '/admin/files', label: 'Arquivos', icon: <HardDrive className="h-4 w-4" /> },
    { to: '/admin/queue', label: 'Fila', icon: <ListChecks className="h-4 w-4" /> },
  ]
  if (complete) {
    
    operacao.splice(
      1,
      0,
      { to: '/admin/resellers', label: 'Revendedores', icon: <Store className="h-4 w-4" /> },
      { to: '/admin/packages', label: 'Pacotes', icon: <Boxes className="h-4 w-4" /> },
      { to: '/admin/apps', label: 'Apps', icon: <AppWindow className="h-4 w-4" /> },
      { to: '/admin/payments', label: 'Pagamentos', icon: <CreditCard className="h-4 w-4" /> },
    )
  }
  return [
    {
      items: [
        { to: '/admin/dashboard', label: 'Dashboard', icon: <LayoutDashboard className="h-4 w-4" /> },
        { to: '/admin/minha-vps', label: 'Minha VPS', icon: <Server className="h-4 w-4" /> },
      ],
    },
    { label: 'Operação', items: operacao },
    {
      label: 'Sistema',
      items: [
        { to: '/admin/monitoring', label: 'Monitoramento', icon: <Activity className="h-4 w-4" /> },
        { to: '/admin/os-update', label: 'Atualizar SO', icon: <HardDriveDownload className="h-4 w-4" /> },
        { to: '/admin/admins', label: 'Admins', icon: <UserCog className="h-4 w-4" /> },
        { to: '/admin/settings', label: 'Configurações', icon: <Settings className="h-4 w-4" /> },
        { to: '/admin/security', label: 'Segurança', icon: <ShieldCheck className="h-4 w-4" /> },
        { to: '/admin/vulnerabilities', label: 'Vulnerabilidades', icon: <ShieldAlert className="h-4 w-4" /> },
        { to: '/admin/security-events', label: 'Eventos de segurança', icon: <ShieldX className="h-4 w-4" /> },
        { to: '/admin/about', label: 'Sobre', icon: <Info className="h-4 w-4" /> },
      ],
    },
  ]
}

export function AdminLayout() {
  const edition = useEdition()
  return (
    <AppShell groups={adminGroups(edition.data?.complete ?? false)} rail={<StatusRail />}>
      <Outlet />
    </AppShell>
  )
}
