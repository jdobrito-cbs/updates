import { useState } from 'react'
import type { FormEvent } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import {
  AppWindow,
  Archive,
  ArrowLeft,
  Clock,
  Cloud,
  Container,
  Database,
  Mail,
  FolderUp,
  Gauge,
  Globe,
  HardDrive,
  KeyRound,
  Lock,
  Code2,
  Newspaper,
  Package,
  Pause,
  Play,
  Trash2,
  Waypoints,
  Zap,
} from 'lucide-react'

import { ApiError } from '../../api/client'
import {
  useClient,
  useDeleteClient,
  useEdition,
  useResetClient2FA,
  useResumeClient,
  useSetClientPassword,
  useSetFastNginx,
  useUpdateClientPackages,
  useSuspendClient,
} from '../../api/hooks'
import type { Client } from '../../api/types'
import { FileManager } from '../../components/FileManager'
import { BackupPanel } from '../../components/panels/BackupPanel'
import { CloudflarePanel } from '../../components/panels/CloudflarePanel'
import { AppsPanel } from '../../components/panels/AppsPanel'
import { DockerPanel } from '../../components/panels/DockerPanel'
import { EmailPanel } from '../../components/panels/EmailPanel'
import { VpsPowerPanel } from '../../components/panels/VpsPowerPanel'
import { CronPanel } from '../../components/panels/CronPanel'
import { DBAccessPanel } from '../../components/panels/DBAccessPanel'
import { LiberacoesPanel } from '../../components/panels/LiberacoesPanel'
import { DatabasesPanel } from '../../components/panels/DatabasesPanel'
import { DnsPanel } from '../../components/panels/DnsPanel'
import { DomainsPanel } from '../../components/panels/DomainsPanel'
import { SftpPanel } from '../../components/panels/SftpPanel'
import { StatsPanel } from '../../components/panels/StatsPanel'
import { WordPressPanel } from '../../components/panels/WordPressPanel'
import { RuntimesPanel } from '../../components/panels/RuntimesPanel'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { useConfirm } from '../../components/ui/ConfirmDialog'
import { Field } from '../../components/ui/Field'
import { Input } from '../../components/ui/Input'
import { Modal } from '../../components/ui/Modal'
import { Spinner } from '../../components/ui/Spinner'
import { StatusBadge } from '../../components/ui/StatusBadge'
import { PresenceBadge } from '../../components/ui/PresenceBadge'
import { Tabs } from '../../components/ui/Tabs'
import type { TabItem } from '../../components/ui/Tabs'
import { useToast } from '../../components/ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

const tabs: TabItem[] = [
  { key: 'visao', label: 'Visão geral', icon: <Gauge className="h-4 w-4" /> },
  { key: 'dominios', label: 'Domínios', icon: <Globe className="h-4 w-4" /> },
  { key: 'dns', label: 'DNS', icon: <Waypoints className="h-4 w-4" /> },
  { key: 'bancos', label: 'Bancos', icon: <Database className="h-4 w-4" /> },
  { key: 'wordpress', label: 'WordPress', icon: <Newspaper className="h-4 w-4" /> },
  { key: 'linguagens', label: 'Linguagens', icon: <Code2 className="h-4 w-4" /> },
  { key: 'sftp', label: 'SFTP', icon: <FolderUp className="h-4 w-4" /> },
  { key: 'backup', label: 'Backup', icon: <Archive className="h-4 w-4" /> },
  { key: 'cloudflare', label: 'Cloudflare', icon: <Cloud className="h-4 w-4" /> },
  { key: 'arquivos', label: 'Arquivos', icon: <HardDrive className="h-4 w-4" /> },
  { key: 'cron', label: 'Cron', icon: <Clock className="h-4 w-4" /> },
]


const appsTab: TabItem = { key: 'apps', label: 'Apps', icon: <AppWindow className="h-4 w-4" /> }
const dockerTab: TabItem = { key: 'docker', label: 'Docker', icon: <Container className="h-4 w-4" /> }
const emailTab: TabItem = { key: 'email', label: 'E-mail', icon: <Mail className="h-4 w-4" /> }

export function ClientDetailPage() {
  const { id } = useParams()
  const clientId = Number(id)
  const { data: client, isLoading } = useClient(clientId)
  const edition = useEdition()
  const reset = useResetClient2FA()
  const del = useDeleteClient()
  const suspend = useSuspendClient()
  const resume = useResumeClient()
  const setPwd = useSetClientPassword(clientId)
  const toast = useToast()
  const confirm = useConfirm()
  const navigate = useNavigate()
  const [tab, setTab] = useState('visao')
  const [pwdOpen, setPwdOpen] = useState(false)
  const [newPwd, setNewPwd] = useState('')
  const [confirmPwd, setConfirmPwd] = useState('')

  const root = `/api/admin/clients/${clientId}`

  if (isLoading || !client) return <Spinner />

  async function onSetPassword(e: FormEvent) {
    e.preventDefault()
    if (newPwd.length < 8) {
      toast.push('error', 'a senha deve ter ao menos 8 caracteres')
      return
    }
    if (newPwd !== confirmPwd) {
      toast.push('error', 'a confirmação não confere')
      return
    }
    try {
      await setPwd.mutateAsync(newPwd)
      toast.push('success', 'senha do cliente alterada')
      setPwdOpen(false)
      setNewPwd('')
      setConfirmPwd('')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onReset() {
    if (!(await confirm({ title: 'Resetar 2FA', message: 'Resetar o 2FA deste cliente? Ele reconfigura no próximo login.', confirmLabel: 'Resetar' }))) return
    try {
      await reset.mutateAsync(clientId)
      toast.push('success', '2FA resetado')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onDelete() {
    if (
      !(await confirm({
        title: 'Remover cliente',
        message: `Remover ${client!.name} e destruir o container? Irreversível.`,
        confirmLabel: 'Remover',
        danger: true,
      }))
    )
      return
    try {
      await del.mutateAsync(clientId)
      toast.push('success', 'desprovisionamento enfileirado')
      navigate('/admin/clients')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onToggle() {
    try {
      if (client!.status === 'suspended') {
        await resume.mutateAsync(clientId)
        toast.push('success', 'retomada enfileirada')
      } else {
        if (!(await confirm({ title: 'Suspender cliente', message: 'O container será parado.', confirmLabel: 'Suspender' }))) return
        await suspend.mutateAsync(clientId)
        toast.push('success', 'suspensão enfileirada')
      }
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-5">
      <button
        onClick={() => navigate('/admin/clients')}
        className="flex items-center gap-1 text-sm text-muted hover:text-ink"
      >
        <ArrowLeft className="h-4 w-4" /> Clientes
      </button>

      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="flex flex-wrap items-center gap-3 font-display text-2xl text-ink">
            {client.name}
            <StatusBadge status={client.status} />
            <PresenceBadge online={client.online} lastSeen={client.last_seen} />
          </h1>
          <p className="font-mono text-sm text-muted">
            {client.lxc_container_name} · {client.cpu_limit} vCPU · {client.ram_limit_mb}MB ·{' '}
            {client.disk_quota_mb}MB
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" onClick={onToggle}>
            {client.status === 'suspended' ? (
              <>
                <Play className="h-4 w-4" /> Retomar
              </>
            ) : (
              <>
                <Pause className="h-4 w-4" /> Suspender
              </>
            )}
          </Button>
          <Button variant="ghost" onClick={() => setPwdOpen(true)}>
            <Lock className="h-4 w-4" /> Trocar senha
          </Button>
          <Button variant="ghost" onClick={onReset}>
            <KeyRound className="h-4 w-4" /> Reset 2FA
          </Button>
          <Button variant="danger" onClick={onDelete}>
            <Trash2 className="h-4 w-4" /> Remover
          </Button>
        </div>
      </header>

      <Modal open={pwdOpen} onClose={() => setPwdOpen(false)} title={`Trocar senha de ${client.name}`}>
        <form onSubmit={onSetPassword} className="space-y-3">
          <p className="text-sm text-muted">
            Define uma nova senha para o cliente (útil se ele perdeu a senha). Informe a nova senha
            ao cliente — ela não é exibida depois.
          </p>
          <Field label="nova senha (mín. 8)">
            <Input type="password" value={newPwd} onChange={(e) => setNewPwd(e.target.value)} required minLength={8} autoComplete="new-password" />
          </Field>
          <Field label="confirmar nova senha">
            <Input type="password" value={confirmPwd} onChange={(e) => setConfirmPwd(e.target.value)} required autoComplete="new-password" />
          </Field>
          <div className="flex justify-end gap-2 pt-1">
            <Button type="button" variant="ghost" onClick={() => setPwdOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={setPwd.isPending}>
              {setPwd.isPending ? <Spinner /> : 'Salvar senha'}
            </Button>
          </div>
        </form>
      </Modal>

      <Tabs tabs={edition.data?.complete ? [...tabs, appsTab, dockerTab, emailTab] : tabs} active={tab} onChange={setTab} />

      <div>
        {tab === 'visao' && (
          <div className="space-y-5">
            <StatsPanel root={root} />
            <VpsPowerPanel root={root} label="a VPS deste cliente" />
            <FastNginxCard client={client} />
            <UpdatePackagesCard client={client} />
          </div>
        )}
        {tab === 'dominios' && <DomainsPanel root={root} canManage />}
        {tab === 'dns' && <DnsPanel root={root} />}
        {tab === 'bancos' && (
          <div className="space-y-6">
            <DatabasesPanel root={root} />
            <DBAccessPanel root={root} />
            <LiberacoesPanel root={root} />
          </div>
        )}
        {tab === 'wordpress' && <WordPressPanel root={root} />}
        {tab === 'linguagens' && <RuntimesPanel root={root} canManage />}
        {tab === 'sftp' && <SftpPanel root={root} canManage />}
        {tab === 'backup' && <BackupPanel root={root} />}
        {tab === 'cloudflare' && <CloudflarePanel root={root} asAdmin />}
        {tab === 'arquivos' && <FileManager base={`/api/admin/clients/${clientId}/files`} />}
        {tab === 'cron' && <CronPanel root={root} />}
        {tab === 'apps' && <AppsPanel root={root} />}
        {tab === 'docker' && <DockerPanel root={root} />}
        {tab === 'email' && <EmailPanel root={root} />}
      </div>
    </div>
  )
}


function UpdatePackagesCard({ client }: { client: Client }) {
  const update = useUpdateClientPackages(client.id)
  const toast = useToast()
  async function go() {
    try {
      await update.mutateAsync()
      toast.push('success', 'atualização de pacotes enfileirada (veja o log na Fila)')
    } catch (e) {
      toast.push('error', msg(e))
    }
  }
  return (
    <Card className="flex flex-wrap items-center justify-between gap-3 p-5">
      <div className="flex items-center gap-3">
        <Package className="h-5 w-5 text-accent" />
        <div>
          <p className="text-sm font-medium text-ink">Atualizar ferramentas</p>
          <p className="text-xs text-faint">
            atualiza os pacotes do container (nginx, mariadb, php, postgres…) via apt. O log fica na Fila.
          </p>
        </div>
      </div>
      <Button onClick={go} disabled={update.isPending}>
        Atualizar
      </Button>
    </Card>
  )
}

function FastNginxCard({ client }: { client: Client }) {
  const fast = useSetFastNginx(client.id)
  const toast = useToast()
  async function toggle() {
    try {
      await fast.mutateAsync(!client.fast_nginx_enabled)
      toast.push('success', client.fast_nginx_enabled ? 'desativando aceleração' : 'ativando aceleração')
    } catch (e) {
      toast.push('error', msg(e))
    }
  }
  return (
    <Card className="flex flex-wrap items-center justify-between gap-3 p-5">
      <div className="flex items-center gap-3">
        <Zap className="h-5 w-5 text-accent" />
        <div>
          <p className="text-sm font-medium text-ink">
            Fast nginx (aceleração){' '}
            {client.fast_nginx_enabled && <span className="text-xs text-done">· ativo</span>}
          </p>
          <p className="text-xs text-faint">
            gzip + cache de descritores nos sites do cliente — abrem mais rápido.
          </p>
        </div>
      </div>
      <Button
        variant={client.fast_nginx_enabled ? 'danger' : 'primary'}
        onClick={toggle}
        disabled={fast.isPending}
      >
        {client.fast_nginx_enabled ? 'Desativar' : 'Ativar'}
      </Button>
    </Card>
  )
}
