import { useState } from 'react'
import type { FormEvent } from 'react'
import { Ban, CircleCheck, Pencil, Plus, Search, Trash2, UserCog } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useAdmins, useBlockAdmin, useCreateAdmin, useDeleteAdmin, useUpdateAdmin } from '../../api/hooks'
import type { AdminUser } from '../../api/hooks'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { useConfirm } from '../../components/ui/ConfirmDialog'
import { EmptyState } from '../../components/ui/EmptyState'
import { Field } from '../../components/ui/Field'
import { Input } from '../../components/ui/Input'
import { Modal } from '../../components/ui/Modal'
import { PageHeader } from '../../components/ui/PageHeader'
import { PresenceBadge } from '../../components/ui/PresenceBadge'
import { Spinner } from '../../components/ui/Spinner'
import { useToast } from '../../components/ui/Toast'
import { formatTime } from '../../lib/format'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

export function AdminsPage() {
  const [search, setSearch] = useState('')
  const { data, isLoading, error } = useAdmins(search)
  const create = useCreateAdmin()
  const update = useUpdateAdmin()
  const del = useDeleteAdmin()
  const block = useBlockAdmin()
  const toast = useToast()
  const confirm = useConfirm()

  const [mode, setMode] = useState<'create' | 'edit' | null>(null)
  const [editId, setEditId] = useState(0)
  const [email, setEmail] = useState('')
  const [name, setName] = useState('')
  const [password, setPassword] = useState('')
  const [session, setSession] = useState('0')

  const admins = data?.admins ?? []
  const current = data?.current ?? 0

  function openCreate() {
    setMode('create')
    setEditId(0)
    setEmail('')
    setName('')
    setPassword('')
    setSession('0')
  }

  function openEdit(a: AdminUser) {
    setMode('edit')
    setEditId(a.id)
    setEmail(a.email)
    setName(a.name)
    setPassword('')
    setSession(String(a.session_timeout_minutes ?? 0))
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    const session_timeout_minutes = Number(session) || 0
    try {
      if (mode === 'create') {
        await create.mutateAsync({ email, name, password, session_timeout_minutes })
        toast.push('success', 'admin criado')
      } else {
        await update.mutateAsync({ id: editId, email, name, password: password || undefined, session_timeout_minutes })
        toast.push('success', 'admin atualizado')
      }
      setMode(null)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onDelete(a: AdminUser) {
    if (
      !(await confirm({
        title: 'Excluir admin',
        message: `Excluir o admin ${a.name || a.email}? Esta ação é irreversível.`,
        confirmLabel: 'Excluir',
        danger: true,
      }))
    )
      return
    try {
      await del.mutateAsync(a.id)
      toast.push('success', 'admin excluído')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onToggleBlock(a: AdminUser) {
    const blocking = a.status !== 'blocked'
    if (
      blocking &&
      !(await confirm({
        title: 'Bloquear login',
        message: `Bloquear o login de ${a.name || a.email}? Ele não conseguirá entrar até ser desbloqueado.`,
        confirmLabel: 'Bloquear',
        danger: true,
      }))
    )
      return
    try {
      await block.mutateAsync({ id: a.id, block: blocking })
      toast.push('success', blocking ? 'login bloqueado' : 'login reativado')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader
        icon={<UserCog className="h-6 w-6" />}
        title="Administradores"
        subtitle={`${admins.length} admin(s) — crie, edite, bloqueie ou remova outros admins`}
        actions={
          <Button onClick={openCreate}>
            <Plus className="h-4 w-4" /> Novo admin
          </Button>
        }
      />

      <div className="relative max-w-sm">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
        <Input
          className="pl-9"
          placeholder="Buscar por nome ou email…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {isLoading && <Spinner />}
      {error && <p className="text-sm text-failed">{(error as Error).message}</p>}

      {!isLoading && admins.length === 0 && (
        <EmptyState
          title={search ? 'Nenhum admin encontrado' : 'Nenhum admin'}
          hint={search ? 'Ajuste a busca.' : 'Crie o primeiro administrador.'}
          action={!search && <Button onClick={openCreate}>+ Novo admin</Button>}
        />
      )}

      {admins.length > 0 && (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-faint">
                <th className="px-4 py-3 font-medium">Nome</th>
                <th className="px-4 py-3 font-medium">Email</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Criado</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {admins.map((a) => (
                <tr key={a.id} className="border-b border-line/60 last:border-0 hover:bg-elevated/60">
                  <td className="px-4 py-3 text-ink">
                    {a.name || <span className="text-faint">—</span>}
                    {a.id === current && (
                      <span className="ml-2 rounded bg-elevated px-1.5 py-0.5 text-[10px] uppercase tracking-wide text-muted">você</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-muted">{a.email}</td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap items-center gap-2">
                      {a.status === 'blocked' ? (
                        <span className="inline-flex items-center gap-1 rounded-full bg-failed/15 px-2 py-0.5 text-xs font-medium text-failed">
                          <Ban className="h-3 w-3" /> bloqueado
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 rounded-full bg-done/15 px-2 py-0.5 text-xs font-medium text-done">
                          <CircleCheck className="h-3 w-3" /> ativo
                        </span>
                      )}
                      <PresenceBadge online={a.online} lastSeen={a.last_seen} />
                    </div>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-muted">{formatTime(a.created_at)}</td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" onClick={() => openEdit(a)} title="Editar">
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        onClick={() => onToggleBlock(a)}
                        disabled={a.id === current}
                        title={a.id === current ? 'Não é possível bloquear a si mesmo' : a.status === 'blocked' ? 'Reativar login' : 'Bloquear login'}
                      >
                        {a.status === 'blocked' ? <CircleCheck className="h-4 w-4" /> : <Ban className="h-4 w-4" />}
                      </Button>
                      <Button
                        variant="danger"
                        onClick={() => onDelete(a)}
                        disabled={a.id === current || admins.length <= 1}
                        title={
                          a.id === current
                            ? 'Não é possível excluir a si mesmo'
                            : admins.length <= 1
                              ? 'Deve existir ao menos um admin'
                              : 'Excluir'
                        }
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <p className="text-xs text-faint">
        É possível excluir ou bloquear o admin padrão desde que exista outro admin cadastrado. Você não pode excluir
        nem bloquear o seu próprio usuário — entre com outro admin para isso.
      </p>

      <Modal open={mode !== null} onClose={() => setMode(null)} title={mode === 'edit' ? 'Editar admin' : 'Novo admin'}>
        <form onSubmit={onSubmit} className="space-y-3">
          <Field label="nome">
            <Input value={name} onChange={(e) => setName(e.target.value)} required maxLength={80} />
          </Field>
          <Field label="email">
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </Field>
          <Field label={mode === 'edit' ? 'nova senha (deixe em branco para manter)' : 'senha (mín. 8)'}>
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required={mode === 'create'}
              minLength={mode === 'create' ? 8 : undefined}
              autoComplete="new-password"
            />
          </Field>
          <Field label="limite de sessão em minutos (0 = padrão: 60 min)">
            <Input type="number" min="0" max="1440" value={session} onChange={(e) => setSession(e.target.value)} />
          </Field>
          <div className="flex justify-end gap-2 pt-1">
            <Button type="button" variant="ghost" onClick={() => setMode(null)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={create.isPending || update.isPending}>
              {create.isPending || update.isPending ? <Spinner /> : mode === 'edit' ? 'Salvar' : 'Criar admin'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
