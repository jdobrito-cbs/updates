import { useEffect, useRef, useState } from 'react'
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'
import { Activity, Network, Server } from 'lucide-react'

import { useBandwidth, useClientBandwidth, useMonitoring, useSystem } from '../../api/hooks'
import { C, DonutGauge, RealtimeLine } from '../../components/charts/Charts'
import { Card } from '../../components/ui/Card'
import { PageHeader } from '../../components/ui/PageHeader'
import { Spinner } from '../../components/ui/Spinner'

const MAXPTS = 30

function fmtBytes(n: number): string {
  if (n <= 0) return '0 B'
  const u = ['B', 'KB', 'MB', 'GB', 'TB']
  const i = Math.min(u.length - 1, Math.floor(Math.log(n) / Math.log(1024)))
  return `${(n / 1024 ** i).toFixed(i ? 1 : 0)} ${u[i]}`
}
const fmtBps = (n: number) => `${fmtBytes(n)}/s`
const clock = () => new Date().toLocaleTimeString('pt-BR', { hour12: false })

export function MonitoringPage() {
  const mq = useMonitoring()
  const { data: sys } = useSystem()
  const { data: bandwidth } = useBandwidth()
  const { data: clientBw } = useClientBandwidth()

  const [sysSeries, setSysSeries] = useState<Record<string, number | string>[]>([])
  const [netSeries, setNetSeries] = useState<Record<string, number | string>[]>([])
  const lastAt = useRef(0)

  const d = mq.data
  useEffect(() => {
    if (!d || mq.dataUpdatedAt === lastAt.current) return
    lastAt.current = mq.dataUpdatedAt
    const t = clock()
    setSysSeries((s) => [...s, { t, cpu: d.cpu, mem: d.mem.percent, disco: d.disk.percent }].slice(-MAXPTS))
    setNetSeries((s) =>
      [...s, { t, entrada: Math.round(d.net.rx_bps / 1024), saída: Math.round(d.net.tx_bps / 1024) }].slice(-MAXPTS),
    )
  }, [mq.dataUpdatedAt, d])

  if (!d) {
    return (
      <div className="space-y-6">
        <PageHeader icon={<Activity className="h-6 w-6" />} title="Monitoramento" subtitle="Uso do sistema em tempo real" />
        <Spinner />
      </div>
    )
  }

  const bw = (bandwidth ?? []).map((b) => ({
    name: b.day.slice(5),
    entrada: +(b.rx_bytes / 1024 / 1024).toFixed(1),
    saída: +(b.tx_bytes / 1024 / 1024).toFixed(1),
  }))

  return (
    <div className="space-y-6">
      <PageHeader
        icon={<Activity className="h-6 w-6" />}
        title="Monitoramento"
        subtitle={`${d.os.hostname} · ${d.os.name} ${d.os.version}`}
      />

      {}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <DonutGauge
          label="CPU"
          value={d.cpu}
          color={C.accent}
          detail={
            <>
              <span className="block truncate" title={d.cpu_info.model}>
                {d.cpu_info.model}
              </span>
              <span className="text-faint">{d.cpu_info.cores} núcleos</span>
            </>
          }
        />
        <DonutGauge
          label="Memória"
          value={d.mem.percent}
          color={C.running}
          detail={`${fmtBytes((d.mem.used_kb ?? 0) * 1024)} / ${fmtBytes((d.mem.total_kb ?? 0) * 1024)}`}
        />
        <DonutGauge
          label="Disco"
          value={d.disk.percent}
          color={C.done}
          detail={`${fmtBytes(d.disk.used_bytes ?? 0)} / ${fmtBytes(d.disk.total_bytes ?? 0)}`}
        />
      </div>

      {}
      {sys?.loadavg && (
        <Card className="p-5">
          <h3 className="mb-3 text-xs uppercase tracking-wide text-faint">Carga (load average)</h3>
          <div className="flex gap-8">
            {(['1m', '5m', '15m'] as const).map((k) => (
              <div key={k}>
                <div className="font-display text-2xl text-ink">{sys.loadavg?.[k] ?? '—'}</div>
                <div className="text-xs text-faint">{k}</div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {}
      <RealtimeLine
        title="Uso do sistema (tempo real)"
        data={sysSeries}
        domainMax={100}
        unit="%"
        series={[
          { key: 'cpu', color: C.accent, label: 'CPU' },
          { key: 'mem', color: C.running, label: 'Memória' },
          { key: 'disco', color: C.done, label: 'Disco' },
        ]}
      />

      {}
      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="p-5">
          <h3 className="mb-3 flex items-center gap-2 text-sm font-medium text-ink">
            <Server className="h-4 w-4 text-accent" /> Sistema
          </h3>
          <dl className="grid grid-cols-2 gap-y-2 text-sm">
            <Info label="Nome" value={d.os.hostname} />
            <Info label="Sistema" value={d.os.name} />
            <Info label="Versão" value={d.os.version} />
            <Info label="Tipo" value={d.os.type} />
            <Info label="Kernel" value={d.os.kernel} mono />
          </dl>
        </Card>
        <Card className="p-5">
          <h3 className="mb-3 flex items-center gap-2 text-sm font-medium text-ink">
            <Network className="h-4 w-4 text-accent" /> Placa de rede
          </h3>
          <dl className="grid grid-cols-2 gap-y-2 text-sm">
            {d.network.interfaces.map((i) => (
              <Info key={i.name} label={i.name} value={`${i.ip} / ${i.mask}`} mono />
            ))}
            <Info label="Gateway" value={d.network.gateway || '—'} mono />
            <Info label="DNS" value={d.network.dns.join(', ') || '—'} mono />
          </dl>
        </Card>
      </div>

      {}
      <RealtimeLine
        title="Banda da rede (tempo real, KB/s)"
        data={netSeries}
        unit=" KB/s"
        series={[
          { key: 'entrada', color: C.accent, label: `entrada ${fmtBps(d.net.rx_bps)}` },
          { key: 'saída', color: C.failed, label: `saída ${fmtBps(d.net.tx_bps)}` },
        ]}
      />

      {}
      <Card className="p-4">
        <h3 className="mb-3 text-sm font-medium text-ink">Banda por dia (MB)</h3>
        {bw.length === 0 ? (
          <p className="py-10 text-center text-sm text-muted">ainda sem amostras</p>
        ) : (
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={bw} margin={{ top: 4, right: 8, left: -8, bottom: 0 }}>
              <CartesianGrid stroke={C.line} vertical={false} />
              <XAxis dataKey="name" tick={{ fill: C.faint, fontSize: 11 }} />
              <YAxis tick={{ fill: C.faint, fontSize: 11 }} />
              <Tooltip contentStyle={{ background: '#1B1E24', border: '1px solid #2A2F38', borderRadius: 8 }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="entrada" fill={C.accent} radius={[3, 3, 0, 0]} maxBarSize={28} />
              <Bar dataKey="saída" fill={C.failed} radius={[3, 3, 0, 0]} maxBarSize={28} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </Card>

      {}
      <Card className="p-4">
        <h3 className="mb-3 text-sm font-medium text-ink">Banda por cliente — uso do mês (MB)</h3>
        {!clientBw || clientBw.length === 0 ? (
          <p className="py-10 text-center text-sm text-muted">ainda sem clientes/amostras</p>
        ) : (
          <>
            <ResponsiveContainer width="100%" height={Math.max(140, clientBw.length * 34)}>
              <BarChart
                layout="vertical"
                data={clientBw.map((c) => ({ name: c.name, usado: +(c.used_bytes / 1048576).toFixed(1), sus: c.suspended }))}
                margin={{ top: 4, right: 16, left: 8, bottom: 0 }}
              >
                <CartesianGrid stroke={C.line} horizontal={false} />
                <XAxis type="number" tick={{ fill: C.faint, fontSize: 11 }} />
                <YAxis type="category" dataKey="name" width={120} tick={{ fill: C.faint, fontSize: 11 }} />
                <Tooltip contentStyle={{ background: '#1B1E24', border: '1px solid #2A2F38', borderRadius: 8 }} />
                <Bar dataKey="usado" radius={[0, 3, 3, 0]} maxBarSize={22}>
                  {clientBw.map((c) => (
                    <Cell key={c.client_id} fill={c.suspended ? C.failed : C.accent} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <table className="mt-3 w-full text-sm">
              <thead>
                <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-faint">
                  <th className="py-2 font-medium">Cliente</th>
                  <th className="py-2 font-medium">Uso (mês)</th>
                  <th className="py-2 font-medium">Limite</th>
                  <th className="py-2 font-medium">%</th>
                </tr>
              </thead>
              <tbody>
                {clientBw.map((c) => {
                  const limitBytes = c.limit_mb * 1048576
                  const pct = c.limit_mb > 0 ? Math.round((c.used_bytes / limitBytes) * 100) : 0
                  return (
                    <tr key={c.client_id} className="border-b border-line/60 last:border-0">
                      <td className="py-2 text-ink">
                        {c.name}
                        {c.suspended && <span className="ml-2 rounded bg-failed/15 px-1.5 py-0.5 text-[10px] text-failed">suspenso</span>}
                      </td>
                      <td className="py-2 font-mono text-xs text-muted">{fmtBytes(c.used_bytes)}</td>
                      <td className="py-2 font-mono text-xs text-muted">{c.limit_mb > 0 ? `${c.limit_mb} MB` : 'ilimitado'}</td>
                      <td className="py-2 font-mono text-xs">
                        {c.limit_mb > 0 ? <span className={pct >= 100 ? 'text-failed' : pct >= 80 ? 'text-pending' : 'text-muted'}>{pct}%</span> : <span className="text-faint">—</span>}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </>
        )}
      </Card>

    </div>
  )
}

function Info({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <>
      <dt className="text-faint">{label}</dt>
      <dd className={`text-right text-ink ${mono ? 'font-mono text-xs' : ''}`}>{value}</dd>
    </>
  )
}
