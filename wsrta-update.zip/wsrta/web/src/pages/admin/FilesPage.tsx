import { HardDrive } from 'lucide-react'

import { FileManager } from '../../components/FileManager'
import { PageHeader } from '../../components/ui/PageHeader'

export function FilesPage() {
  return (
    <div className="space-y-5">
      <PageHeader
        icon={<HardDrive className="h-6 w-6" />}
        title="Arquivos do servidor"
        subtitle="Gerenciador de arquivos do host (acesso total ao servidor)."
      />
      <FileManager base="/api/admin/files" />
    </div>
  )
}
