import { HardDriveDownload, RefreshCw } from 'lucide-react'

import { useActions, useSystemUpdate } from '../../api/hooks'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { useConfirm } from '../../components/ui/ConfirmDialog'
import { PageHeader } from '../../components/ui/PageHeader'
import { StatusBadge } from '../../components/ui/StatusBadge'
import { useToast } from '../../components/ui/Toast'
import { formatTime } from '../../lib/format'

const msg = (e: unknown) => (e instanceof Error ? e.message : 'falha na operação')



export function OSUpdatePage() {
  
  
  const { data: updates } = useActions('system_update')
  const update = useSystemUpdate('os')
  const toast = useToast()
  const confirm = useConfirm()

  const list = updates ?? []
  const running = list.some((a) => a.status === 'running' || a.status === 'pending')
  const last = list[0] 

  async function onUpdate() {
    const ok = await confirm({
      title: 'Atualizar o sistema operacional',
      message:
        'Roda apt-get update && apt-get -y upgrade no servidor. Pode levar alguns minutos e alguns serviços podem reiniciar. Continuar?',
      confirmLabel: 'Atualizar',
      danger: true,
    })
    if (!ok) return
    try {
      await update.mutateAsync()
      toast.push('success', 'atualização do SO enfileirada')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader
        icon={<HardDriveDownload className="h-6 w-6" />}
        title="Atualizar sistema"
        subtitle="Atualiza os pacotes do sistema operacional do servidor (apt)"
      />

      <Card className="flex flex-wrap items-center justify-between gap-3 p-5">
        <p className="max-w-xl text-sm text-muted">
          Executa <span className="font-mono text-xs text-ink">apt-get update &amp;&amp; apt-get -y upgrade</span> no
          host. A ação é enfileirada e executada pelo servidor; o log aparece abaixo assim que concluir.
        </p>
        <Button onClick={onUpdate} disabled={running || update.isPending}>
          <RefreshCw className={`h-4 w-4 ${running ? 'animate-spin' : ''}`} />{' '}
          {running ? 'Atualizando…' : 'Atualizar SO'}
        </Button>
      </Card>

      <div>
        <h2 className="mb-2 text-sm font-semibold text-ink">Log da última atualização</h2>
        {last ? (
          <Card className="p-4">
            <div className="mb-3 flex flex-wrap items-center gap-2 text-xs text-muted">
              <StatusBadge status={last.status} />
              <span className="font-mono text-faint">#{last.id}</span>
              <span>
                {formatTime(last.created_at)}
                {last.finished_at ? ` → ${formatTime(last.finished_at)}` : ''}
              </span>
            </div>
            <pre className="max-h-[28rem] overflow-auto whitespace-pre-wrap rounded-lg bg-base/60 p-3 font-mono text-[11px] leading-relaxed text-muted">
              {last.result ?? (running ? 'executando… (o log aparece ao concluir)' : '—')}
            </pre>
          </Card>
        ) : (
          <Card className="p-6 text-center text-sm text-muted">Nenhuma atualização executada ainda.</Card>
        )}
      </div>
    </div>
  )
}
