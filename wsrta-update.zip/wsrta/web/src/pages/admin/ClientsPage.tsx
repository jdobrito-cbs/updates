import { useState } from 'react'
import type { FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { KeyRound, Pause, Pencil, Play, Plus, Search, Trash2, Users } from 'lucide-react'

import { ApiError } from '../../api/client'
import {
  useClients,
  useCreateClient,
  useDeleteClient,
  useResetClient2FA,
  useResumeClient,
  useSuspendClient,
  useUpdateClient,
} from '../../api/hooks'
import type { Client } from '../../api/types'
import { ActionStatus } from '../../components/ActionStatus'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { useConfirm } from '../../components/ui/ConfirmDialog'
import { EmptyState } from '../../components/ui/EmptyState'
import { Field } from '../../components/ui/Field'
import { Input } from '../../components/ui/Input'
import { Modal } from '../../components/ui/Modal'
import { PageHeader } from '../../components/ui/PageHeader'
import { PresenceBadge } from '../../components/ui/PresenceBadge'
import { Spinner } from '../../components/ui/Spinner'
import { StatusBadge } from '../../components/ui/StatusBadge'
import { useToast } from '../../components/ui/Toast'
import { formatTime } from '../../lib/format'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

export function ClientsPage() {
  const [search, setSearch] = useState('')
  const { data: clients, isLoading, error } = useClients(search)
  const create = useCreateClient()
  const update = useUpdateClient()
  const del = useDeleteClient()
  const reset = useResetClient2FA()
  const suspend = useSuspendClient()
  const resume = useResumeClient()
  const toast = useToast()
  const confirm = useConfirm()
  const navigate = useNavigate()

  const [lastAction, setLastAction] = useState<number | null>(null)
  const [mode, setMode] = useState<'create' | 'edit' | null>(null)
  const [editId, setEditId] = useState(0)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [cpu, setCpu] = useState('1')
  const [ram, setRam] = useState('512')
  const [disk, setDisk] = useState('5120')
  const [maxDom, setMaxDom] = useState('0')
  const [maxDb, setMaxDb] = useState('0')
  const [maxMail, setMaxMail] = useState('0')
  const [session, setSession] = useState('0')
  const [bandwidth, setBandwidth] = useState('0')

  function openCreate() {
    setMode('create')
    setEditId(0)
    setEmail('')
    setPassword('')
    setName('')
    setCpu('1')
    setRam('512')
    setDisk('5120')
    setMaxDom('0')
    setMaxDb('0')
    setMaxMail('0')
    setSession('0')
    setBandwidth('0')
  }

  function openEdit(c: Client) {
    setMode('edit')
    setEditId(c.id)
    setName(c.name)
    setCpu(String(c.cpu_limit))
    setRam(String(c.ram_limit_mb))
    setDisk(String(c.disk_quota_mb))
    setMaxDom(String(c.max_domains))
    setMaxDb(String(c.max_databases))
    setMaxMail(String(c.max_mailboxes ?? 0))
    setSession(String(c.session_timeout_minutes ?? 0))
    setBandwidth(String(c.bandwidth_limit_mb ?? 0))
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    const limits = {
      cpu_limit: Number(cpu),
      ram_limit_mb: Number(ram),
      disk_quota_mb: Number(disk),
      max_domains: Number(maxDom),
      max_databases: Number(maxDb),
      max_mailboxes: Number(maxMail),
      session_timeout_minutes: Number(session) || 0,
      bandwidth_limit_mb: Number(bandwidth) || 0,
    }
    try {
      if (mode === 'create') {
        const res = await create.mutateAsync({ email, password, name, ...limits })
        setLastAction(res.action_id)
        toast.push('success', 'cliente criado; provisionando…')
      } else {
        await update.mutateAsync({ id: editId, input: { name, ...limits } })
        toast.push('success', 'cliente atualizado')
      }
      setMode(null)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onDelete(c: Client) {
    if (
      !(await confirm({
        title: 'Remover cliente',
        message: `Remover ${c.name} e destruir ${c.lxc_container_name}? Irreversível.`,
        confirmLabel: 'Remover',
        danger: true,
      }))
    )
      return
    try {
      const res = await del.mutateAsync(c.id)
      setLastAction(res.action_id)
      toast.push('success', 'desprovisionamento enfileirado')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onReset(c: Client) {
    if (!(await confirm({ title: 'Resetar 2FA', message: `Resetar o 2FA de ${c.name}? Ele reconfigura no próximo login.`, confirmLabel: 'Resetar' }))) return
    try {
      await reset.mutateAsync(c.id)
      toast.push('success', '2FA resetado')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onToggleStatus(c: Client) {
    try {
      if (c.status === 'suspended') {
        await resume.mutateAsync(c.id)
        toast.push('success', 'retomada enfileirada')
      } else {
        if (!(await confirm({ title: 'Suspender cliente', message: `Suspender ${c.name}? O container será parado.`, confirmLabel: 'Suspender' }))) return
        await suspend.mutateAsync(c.id)
        toast.push('success', 'suspensão enfileirada')
      }
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader
        icon={<Users className="h-6 w-6" />}
        title="Clientes"
        subtitle={`${(clients ?? []).length} conta(s)`}
        actions={
          <Button onClick={openCreate}>
            <Plus className="h-4 w-4" /> Novo cliente
          </Button>
        }
      />

      <div className="relative max-w-sm">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
        <Input
          className="pl-9"
          placeholder="Buscar por nome ou container…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {lastAction !== null && (
        <Card className="flex items-center gap-3 px-4 py-3 text-sm">
          <span className="text-muted">Última ação:</span>
          <ActionStatus actionId={lastAction} />
        </Card>
      )}

      {isLoading && <Spinner />}
      {error && <p className="text-sm text-failed">{(error as Error).message}</p>}

      {clients && clients.length === 0 && (
        <EmptyState
          title={search ? 'Nenhum cliente encontrado' : 'Nenhum cliente ainda'}
          hint={search ? 'Ajuste a busca.' : 'Crie o primeiro cliente para provisionar um container.'}
          action={!search && <Button onClick={openCreate}>+ Novo cliente</Button>}
        />
      )}

      {clients && clients.length > 0 && (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-faint">
                <th className="px-4 py-3 font-medium">Container</th>
                <th className="px-4 py-3 font-medium">Nome</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Recursos</th>
                <th className="px-4 py-3 font-medium">Criado</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {clients.map((c) => (
                <tr
                  key={c.id}
                  onClick={() => navigate(`/admin/clients/${c.id}`)}
                  className="cursor-pointer border-b border-line/60 last:border-0 hover:bg-elevated/60"
                >
                  <td className="px-4 py-3 font-mono text-ink">{c.lxc_container_name}</td>
                  <td className="px-4 py-3 text-ink">{c.name}</td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap items-center gap-2">
                      <StatusBadge status={c.status} />
                      <PresenceBadge online={c.online} lastSeen={c.last_seen} />
                    </div>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-muted">
                    {c.cpu_limit} vCPU · {c.ram_limit_mb}MB · {c.disk_quota_mb}MB
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-muted">{formatTime(c.created_at)}</td>
                  <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" onClick={() => openEdit(c)} title="Editar">
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        onClick={() => onToggleStatus(c)}
                        title={c.status === 'suspended' ? 'Retomar' : 'Suspender'}
                      >
                        {c.status === 'suspended' ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
                      </Button>
                      <Button variant="ghost" onClick={() => onReset(c)} title="Resetar 2FA">
                        <KeyRound className="h-4 w-4" />
                      </Button>
                      <Button variant="danger" onClick={() => onDelete(c)} title="Remover">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <Modal open={mode !== null} onClose={() => setMode(null)} title={mode === 'edit' ? 'Editar cliente' : 'Novo cliente'}>
        <form onSubmit={onSubmit} className="space-y-3">
          {mode === 'create' && (
            <>
              <Field label="email">
                <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </Field>
              <Field label="senha (mín. 8)">
                <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} />
              </Field>
            </>
          )}
          <Field label="nome">
            <Input value={name} onChange={(e) => setName(e.target.value)} required />
          </Field>
          <div className="grid grid-cols-3 gap-3">
            <Field label="vCPU">
              <Input type="number" step="0.5" min="0.5" value={cpu} onChange={(e) => setCpu(e.target.value)} />
            </Field>
            <Field label="RAM (MB)">
              <Input type="number" value={ram} onChange={(e) => setRam(e.target.value)} />
            </Field>
            <Field label="Disco (MB)">
              <Input type="number" value={disk} onChange={(e) => setDisk(e.target.value)} />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Máx. domínios (0 = ilimitado)">
              <Input type="number" min="0" value={maxDom} onChange={(e) => setMaxDom(e.target.value)} />
            </Field>
            <Field label="Máx. bancos (0 = ilimitado)">
              <Input type="number" min="0" value={maxDb} onChange={(e) => setMaxDb(e.target.value)} />
            </Field>
            <Field label="Máx. caixas de e-mail (0 = ilimitado)">
              <Input type="number" min="0" value={maxMail} onChange={(e) => setMaxMail(e.target.value)} />
            </Field>
          </div>
          <p className="-mt-1 text-xs text-faint">
            Limite individual deste cliente (não há limite global). 0 = sem limite.
          </p>
          <Field label="limite de sessão em minutos (0 = padrão: 60 min)">
            <Input type="number" min="0" max="1440" value={session} onChange={(e) => setSession(e.target.value)} />
          </Field>
          <Field label="limite de banda mensal em MB (0 = ilimitado)">
            <Input type="number" min="0" value={bandwidth} onChange={(e) => setBandwidth(e.target.value)} />
          </Field>
          <p className="-mt-1 text-xs text-faint">
            Ao atingir o limite no mês, o cliente é <strong>suspenso automaticamente</strong>.
          </p>
          <div className="flex justify-end gap-2 pt-1">
            <Button type="button" variant="ghost" onClick={() => setMode(null)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={create.isPending || update.isPending}>
              {create.isPending || update.isPending ? <Spinner /> : mode === 'edit' ? 'Salvar' : 'Criar e provisionar'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
