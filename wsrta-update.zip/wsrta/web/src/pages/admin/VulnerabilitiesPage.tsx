import { useState } from 'react'
import { RefreshCw, Server, ShieldAlert, ShieldCheck } from 'lucide-react'

import type { VulnFinding, VulnScan } from '../../api/hooks'
import {
  useClientVulnScans,
  useClients,
  useHardenAllWordPress,
  useHostVulnScans,
  useScanClient,
  useScanHost,
  useSetVulnSchedule,
  useVulnFindings,
} from '../../api/hooks'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { useConfirm } from '../../components/ui/ConfirmDialog'
import { Modal } from '../../components/ui/Modal'
import { PageHeader } from '../../components/ui/PageHeader'
import { Spinner } from '../../components/ui/Spinner'
import { StatusBadge } from '../../components/ui/StatusBadge'
import { useToast } from '../../components/ui/Toast'

const msg = (e: unknown) => (e instanceof Error ? e.message : 'falha na operação')

const SEV: Record<string, { label: string; cls: string }> = {
  high: { label: 'crítico', cls: 'bg-failed/15 text-failed' },
  medium: { label: 'médio', cls: 'bg-running/15 text-running' },
  low: { label: 'baixo', cls: 'bg-pending/15 text-pending' },
  info: { label: 'info', cls: 'bg-line text-muted' },
}



function Counts({ s }: { s: VulnScan }) {
  if (s.status !== 'done' && s.status !== 'failed') return <StatusBadge status={s.status} />
  if (s.status === 'failed') return <StatusBadge status="failed" />
  const total = s.high + s.medium + s.low
  if (total === 0)
    return (
      <span className="inline-flex items-center gap-1 text-xs text-done">
        <ShieldCheck className="h-3.5 w-3.5" /> limpo
      </span>
    )
  const chips: [number, string][] = [
    [s.high, SEV.high.cls],
    [s.medium, SEV.medium.cls],
    [s.low, SEV.low.cls],
  ]
  return (
    <span className="flex gap-1">
      {chips.map(([n, cls], i) =>
        n > 0 ? (
          <span key={i} className={`rounded px-1.5 py-0.5 text-xs font-medium ${cls}`}>
            {n}
          </span>
        ) : null,
      )}
    </span>
  )
}

export function VulnerabilitiesPage() {
  const clients = useClients('')
  const [findingsScan, setFindingsScan] = useState<number | null>(null)

  return (
    <div className="space-y-5">
      <PageHeader
        icon={<ShieldAlert className="h-6 w-6" />}
        title="Vulnerabilidades"
        subtitle="Analisa os sites/WordPress dos clientes e o próprio sistema; cada achado vem com como corrigir"
      />

      <HostScan onView={setFindingsScan} />

      <HardenAllCard />

      <div>
        <h2 className="mb-2 text-sm font-semibold text-ink">Clientes</h2>
        <Card className="divide-y divide-line">
          {(clients.data ?? []).length === 0 && <p className="p-4 text-sm text-faint">nenhum cliente</p>}
          {(clients.data ?? []).map((c) => (
            <ClientScanRow key={c.id} clientId={c.id} name={c.name} schedule={c.vuln_schedule ?? ''} onView={setFindingsScan} />
          ))}
        </Card>
      </div>

      {findingsScan != null && <FindingsModal scanId={findingsScan} onClose={() => setFindingsScan(null)} />}
    </div>
  )
}


function HardenAllCard() {
  const harden = useHardenAllWordPress()
  const toast = useToast()
  const confirm = useConfirm()
  async function go() {
    const ok = await confirm({
      title: 'Proteger todos os WordPress',
      message:
        'Instala o mu-plugin de hardening (bloqueia a enumeração de usuários — CVE-2017-5487) em TODAS as instalações WordPress do servidor. Continuar?',
      confirmLabel: 'Proteger todos',
    })
    if (!ok) return
    try {
      const r = await harden.mutateAsync()
      toast.push('success', `proteção enfileirada em ${r.queued} instalação(ões)`)
    } catch (e) {
      toast.push('error', msg(e))
    }
  }
  return (
    <Card className="flex flex-wrap items-center justify-between gap-3 p-5">
      <div className="flex items-center gap-3">
        <ShieldCheck className="h-5 w-5 text-accent" />
        <div>
          <p className="text-sm font-medium text-ink">Proteger WordPress (todos)</p>
          <p className="text-xs text-muted">Bloqueia a enumeração de usuários (CVE-2017-5487) em todas as instalações do servidor</p>
        </div>
      </div>
      <Button onClick={go} disabled={harden.isPending}>
        <ShieldCheck className="h-4 w-4" /> Proteger todos
      </Button>
    </Card>
  )
}

function HostScan({ onView }: { onView: (id: number) => void }) {
  const { data } = useHostVulnScans()
  const scan = useScanHost()
  const toast = useToast()
  const list = data ?? []
  const last = list[0]
  const running = list.some((s) => s.status === 'pending' || s.status === 'running')

  async function go() {
    try {
      await scan.mutateAsync()
      toast.push('success', 'scan do sistema enfileirado')
    } catch (e) {
      toast.push('error', msg(e))
    }
  }

  return (
    <Card className="flex flex-wrap items-center justify-between gap-3 p-5">
      <div className="flex items-center gap-3">
        <Server className="h-5 w-5 text-accent" />
        <div>
          <p className="text-sm font-medium text-ink">Sistema / painel</p>
          <p className="text-xs text-muted">SO desatualizado, SSH, proteções ligadas, permissões de segredos</p>
        </div>
      </div>
      <div className="flex items-center gap-3">
        {last ? <Counts s={last} /> : <span className="text-xs text-faint">nunca escaneado</span>}
        {last?.status === 'done' && (
          <Button variant="ghost" onClick={() => onView(last.id)}>
            Ver achados
          </Button>
        )}
        <Button onClick={go} disabled={running || scan.isPending}>
          <RefreshCw className={`h-4 w-4 ${running ? 'animate-spin' : ''}`} /> {running ? 'Escaneando…' : 'Escanear sistema'}
        </Button>
      </div>
    </Card>
  )
}

function ClientScanRow({
  clientId,
  name,
  schedule,
  onView,
}: {
  clientId: number
  name: string
  schedule: string
  onView: (id: number) => void
}) {
  const { data } = useClientVulnScans(clientId)
  const scan = useScanClient()
  const setSchedule = useSetVulnSchedule()
  const toast = useToast()
  const list = data ?? []
  const last = list[0]
  const running = list.some((s) => s.status === 'pending' || s.status === 'running')

  async function go() {
    try {
      await scan.mutateAsync(clientId)
      toast.push('success', `scan de ${name} enfileirado`)
    } catch (e) {
      toast.push('error', msg(e))
    }
  }
  async function onSchedule(v: string) {
    try {
      await setSchedule.mutateAsync({ clientId, schedule: v })
      toast.push('success', 'agendamento salvo')
    } catch (e) {
      toast.push('error', msg(e))
    }
  }

  return (
    <div className="flex flex-wrap items-center gap-3 p-3">
      <span className="min-w-0 flex-1 truncate text-sm text-ink">{name}</span>
      {last ? <Counts s={last} /> : <span className="text-xs text-faint">nunca</span>}
      <select
        value={schedule}
        onChange={(e) => onSchedule(e.target.value)}
        title="Agendamento automático do scan"
        className="rounded-lg border border-line bg-base px-2 py-1 text-xs text-muted"
      >
        <option value="">sem agenda</option>
        <option value="daily">diário</option>
        <option value="weekly">semanal</option>
      </select>
      {last?.status === 'done' && (
        <Button variant="ghost" onClick={() => onView(last.id)}>
          Ver
        </Button>
      )}
      <Button onClick={go} disabled={running || scan.isPending}>
        <RefreshCw className={`h-4 w-4 ${running ? 'animate-spin' : ''}`} /> {running ? '…' : 'Escanear'}
      </Button>
    </div>
  )
}

function FindingsModal({ scanId, onClose }: { scanId: number; onClose: () => void }) {
  const { data, isLoading } = useVulnFindings(scanId)
  return (
    <Modal open onClose={onClose} title="Achados do scan" className="max-w-3xl">
      {isLoading ? (
        <Spinner />
      ) : (
        <div className="max-h-[72vh] space-y-3 overflow-y-auto pr-1">
          {(data ?? []).length === 0 && <p className="text-sm text-muted">Nenhum achado.</p>}
          {(data ?? []).map((f) => (
            <FindingCard key={f.id} f={f} />
          ))}
        </div>
      )}
    </Modal>
  )
}

function FindingCard({ f }: { f: VulnFinding }) {
  const sev = SEV[f.severity] ?? SEV.info
  return (
    <div className="rounded-lg border border-line p-3">
      <div className="mb-1 flex flex-wrap items-center gap-2">
        <span className={`rounded px-1.5 py-0.5 text-xs font-semibold ${sev.cls}`}>{sev.label}</span>
        {f.fqdn && <span className="font-mono text-xs text-muted">{f.fqdn}</span>}
        <span className="text-sm font-medium text-ink">{f.title}</span>
      </div>
      {f.detail && (
        <pre className="mb-2 max-h-40 overflow-auto whitespace-pre-wrap rounded bg-base/60 p-2 font-mono text-[11px] text-muted">
          {f.detail}
        </pre>
      )}
      {f.remediation && (
        <p className="text-xs text-muted">
          <span className="font-semibold text-done">Como corrigir: </span>
          {f.remediation}
        </p>
      )}
    </div>
  )
}
