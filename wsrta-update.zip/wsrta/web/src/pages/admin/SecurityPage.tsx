import { useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { Ban, Flame, RefreshCw, Shield, ShieldCheck } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useSecurity, useUpdateSecurity } from '../../api/hooks'
import type { SecurityToggles } from '../../api/hooks'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { FirewallPanel } from '../../components/panels/FirewallPanel'
import { PageHeader } from '../../components/ui/PageHeader'
import { Spinner } from '../../components/ui/Spinner'
import { useToast } from '../../components/ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

function Toggle({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      onClick={onClick}
      className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${on ? 'bg-accent' : 'bg-line'}`}
    >
      <span
        className={`absolute top-0.5 h-5 w-5 rounded-full bg-ink transition-all ${on ? 'left-[1.375rem]' : 'left-0.5'}`}
      />
    </button>
  )
}

function Row({
  icon,
  title,
  desc,
  on,
  onToggle,
}: {
  icon: ReactNode
  title: string
  desc: string
  on: boolean
  onToggle: () => void
}) {
  return (
    <div className="flex items-center gap-4 px-5 py-4">
      <span className="text-accent">{icon}</span>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-medium text-ink">{title}</p>
        <p className="text-xs text-faint">{desc}</p>
      </div>
      <Toggle on={on} onClick={onToggle} />
    </div>
  )
}

export function SecurityPage() {
  const { data, isLoading } = useSecurity()
  const update = useUpdateSecurity()
  const toast = useToast()
  const [s, setS] = useState<SecurityToggles | null>(null)

  useEffect(() => {
    if (data) setS(data)
  }, [data])

  if (isLoading || !s) return <Spinner />

  const flip = (k: keyof SecurityToggles) => setS({ ...s, [k]: !s[k] })

  async function onSave() {
    if (!s) return
    try {
      await update.mutateAsync(s)
      toast.push('success', 'aplicação enfileirada — acompanhe a Fila')
    } catch (e) {
      toast.push('error', msg(e))
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader
        icon={<ShieldCheck className="h-6 w-6" />}
        title="Segurança"
        subtitle="Proteções do servidor (host). Ao salvar, a aplicação roda no host real e vai para a Fila."
      />

      <Card className="divide-y divide-line p-0">
        <Row
          icon={<Shield className="h-5 w-5" />}
          title="ModSecurity (WAF)"
          desc="Firewall de aplicação web no nginx do host (regras OWASP CRS)."
          on={s.modsecurity}
          onToggle={() => flip('modsecurity')}
        />
        <Row
          icon={<Flame className="h-5 w-5" />}
          title="CSF + LFD"
          desc="ConfigServer Firewall + LFD: firewall e proteção contra brute-force (substitui o ufw)."
          on={s.csf}
          onToggle={() => flip('csf')}
        />
        <Row
          icon={<Ban className="h-5 w-5" />}
          title="fail2ban"
          desc="Bane IPs com tentativas repetidas de login (SSH, painel, sites)."
          on={s.fail2ban}
          onToggle={() => flip('fail2ban')}
        />
        <Row
          icon={<RefreshCw className="h-5 w-5" />}
          title="Renovação automática de SSL"
          desc="Mantém o cron do acme.sh renovando os certificados antes de expirar."
          on={s.ssl_autorenew}
          onToggle={() => flip('ssl_autorenew')}
        />
      </Card>

      <div className="flex items-center gap-3">
        <Button onClick={onSave} disabled={update.isPending}>
          {update.isPending ? <Spinner /> : 'Salvar e aplicar'}
        </Button>
        <span className="text-xs text-faint">
          O login do painel já tem rate-limit embutido (proteção de brute-force na aplicação).
        </span>
      </div>

      <div className="pt-2">
        <h2 className="mb-1 font-display text-lg text-ink">Gerência do firewall</h2>
        <p className="mb-4 text-sm text-muted">
          fail2ban (desbloquear IPs) e CSF+LFD (regras de allow/deny e controle dos serviços).
        </p>
        <FirewallPanel />
      </div>
    </div>
  )
}
