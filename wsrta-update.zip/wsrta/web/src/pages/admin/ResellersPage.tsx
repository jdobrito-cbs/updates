import { useState } from 'react'
import type { FormEvent } from 'react'
import { Navigate } from 'react-router-dom'
import { Ban, CircleCheck, Pencil, Plus, Search, Store, Trash2, Users } from 'lucide-react'

import { ApiError } from '../../api/client'
import {
  useCreateReseller,
  useDeleteReseller,
  useEdition,
  useResellers,
  useToggleReseller,
  useUpdateReseller,
} from '../../api/hooks'
import type { Reseller } from '../../api/hooks'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { useConfirm } from '../../components/ui/ConfirmDialog'
import { EmptyState } from '../../components/ui/EmptyState'
import { Field } from '../../components/ui/Field'
import { Input } from '../../components/ui/Input'
import { Modal } from '../../components/ui/Modal'
import { PageHeader } from '../../components/ui/PageHeader'
import { PresenceBadge } from '../../components/ui/PresenceBadge'
import { Spinner } from '../../components/ui/Spinner'
import { useToast } from '../../components/ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')


function expiryLabel(s?: string): string {
  if (!s) return '—'
  const d = new Date(s)
  return Number.isNaN(d.getTime()) ? '—' : d.toLocaleDateString()
}

export function ResellersPage() {
  const edition = useEdition()
  const [search, setSearch] = useState('')
  const { data, isLoading, error } = useResellers(search)
  const create = useCreateReseller()
  const update = useUpdateReseller()
  const del = useDeleteReseller()
  const toggle = useToggleReseller()
  const toast = useToast()
  const confirm = useConfirm()

  const [mode, setMode] = useState<'create' | 'edit' | null>(null)
  const [editId, setEditId] = useState(0)
  const [email, setEmail] = useState('')
  const [name, setName] = useState('')
  const [password, setPassword] = useState('')
  const [expires, setExpires] = useState('') 
  
  const [maxClients, setMaxClients] = useState('0')
  const [cpu, setCpu] = useState('2')
  const [ram, setRam] = useState('2048')
  const [disk, setDisk] = useState('20480')
  const [maxDom, setMaxDom] = useState('0')
  const [maxDb, setMaxDb] = useState('0')
  const [maxMail, setMaxMail] = useState('0')
  const [band, setBand] = useState('0')

  
  if (edition.data && !edition.data.complete) return <Navigate to="/admin/dashboard" replace />

  const resellers = data ?? []

  function resetLimits() {
    setMaxClients('0')
    setCpu('2')
    setRam('2048')
    setDisk('20480')
    setMaxDom('0')
    setMaxDb('0')
    setMaxMail('0')
    setBand('0')
  }

  function openCreate() {
    setMode('create')
    setEditId(0)
    setEmail('')
    setName('')
    setPassword('')
    setExpires('')
    resetLimits()
  }

  function openEdit(r: Reseller) {
    setMode('edit')
    setEditId(r.id)
    setEmail(r.email)
    setName(r.name)
    setPassword('')
    setExpires(r.expires_at ? r.expires_at.slice(0, 10) : '')
    setMaxClients(String(r.max_clients ?? 0))
    
    resetLimitsFrom()
  }

  
  
  function resetLimitsFrom() {
    setCpu('2')
    setRam('2048')
    setDisk('20480')
    setMaxDom('0')
    setMaxDb('0')
    setMaxMail('0')
    setBand('0')
  }

  function limitsPayload() {
    return {
      max_clients: Number(maxClients) || 0,
      cpu_limit: Number(cpu) || 1,
      ram_limit_mb: Number(ram) || 512,
      disk_quota_mb: Number(disk) || 5120,
      max_domains: Number(maxDom) || 0,
      max_databases: Number(maxDb) || 0,
      max_mailboxes: Number(maxMail) || 0,
      bandwidth_limit_mb: Number(band) || 0,
    }
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    try {
      if (mode === 'create') {
        await create.mutateAsync({ email, name, password, expires_at: expires, ...limitsPayload() })
        toast.push('success', 'revendedor criado')
      } else {
        await update.mutateAsync({ id: editId, name, expires_at: expires, ...limitsPayload() })
        toast.push('success', 'revendedor atualizado')
      }
      setMode(null)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onDelete(r: Reseller) {
    if (
      !(await confirm({
        title: 'Excluir revendedor',
        message: `Excluir o revendedor ${r.name || r.email}? Os clientes dele passam a ser do admin (não são apagados).`,
        confirmLabel: 'Excluir',
        danger: true,
      }))
    )
      return
    try {
      await del.mutateAsync(r.id)
      toast.push('success', 'revendedor excluído')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onToggle(r: Reseller) {
    const suspend = r.status !== 'suspended'
    if (
      suspend &&
      !(await confirm({
        title: 'Suspender revendedor',
        message: `Suspender ${r.name || r.email}? Ele não conseguirá operar até ser reativado.`,
        confirmLabel: 'Suspender',
        danger: true,
      }))
    )
      return
    try {
      await toggle.mutateAsync({ id: r.id, suspend })
      toast.push('success', suspend ? 'revendedor suspenso' : 'revendedor reativado')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader
        icon={<Store className="h-6 w-6" />}
        title="Revendedores"
        subtitle={`${resellers.length} revendedor(es) — cada um gerencia os próprios clientes, isolado dos demais`}
        actions={
          <Button onClick={openCreate}>
            <Plus className="h-4 w-4" /> Novo revendedor
          </Button>
        }
      />

      <div className="relative max-w-sm">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
        <Input
          className="pl-9"
          placeholder="Buscar por nome ou email…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {isLoading && <Spinner />}
      {error && <p className="text-sm text-failed">{(error as Error).message}</p>}

      {!isLoading && resellers.length === 0 && (
        <EmptyState
          title={search ? 'Nenhum revendedor encontrado' : 'Nenhum revendedor'}
          hint={search ? 'Ajuste a busca.' : 'Crie o primeiro revendedor para começar a revenda.'}
          action={!search && <Button onClick={openCreate}>+ Novo revendedor</Button>}
        />
      )}

      {resellers.length > 0 && (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-faint">
                <th className="px-4 py-3 font-medium">Nome</th>
                <th className="px-4 py-3 font-medium">Email</th>
                <th className="px-4 py-3 font-medium">Clientes</th>
                <th className="px-4 py-3 font-medium">Validade</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {resellers.map((r) => (
                <tr key={r.id} className="border-b border-line/60 last:border-0 hover:bg-elevated/60">
                  <td className="px-4 py-3 text-ink">{r.name || <span className="text-faint">—</span>}</td>
                  <td className="px-4 py-3 text-muted">{r.email}</td>
                  <td className="px-4 py-3">
                    <span className="inline-flex items-center gap-1 text-muted">
                      <Users className="h-3.5 w-3.5 text-faint" /> {r.clients}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-muted">{expiryLabel(r.expires_at)}</td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap items-center gap-2">
                      {r.status === 'suspended' ? (
                        <span className="inline-flex items-center gap-1 rounded-full bg-failed/15 px-2 py-0.5 text-xs font-medium text-failed">
                          <Ban className="h-3 w-3" /> suspenso
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 rounded-full bg-done/15 px-2 py-0.5 text-xs font-medium text-done">
                          <CircleCheck className="h-3 w-3" /> ativo
                        </span>
                      )}
                      <PresenceBadge online={r.online} />
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" onClick={() => openEdit(r)} title="Editar">
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        onClick={() => onToggle(r)}
                        title={r.status === 'suspended' ? 'Reativar' : 'Suspender'}
                      >
                        {r.status === 'suspended' ? <CircleCheck className="h-4 w-4" /> : <Ban className="h-4 w-4" />}
                      </Button>
                      <Button variant="danger" onClick={() => onDelete(r)} title="Excluir">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <p className="text-xs text-faint">
        O revendedor é admin <strong>apenas dos próprios clientes</strong> — não vê os clientes de outras revendas, nem
        os demais revendedores, nem o admin geral. A validade controla o vencimento do plano de revenda.
      </p>

      <Modal open={mode !== null} onClose={() => setMode(null)} title={mode === 'edit' ? 'Editar revendedor' : 'Novo revendedor'}>
        <form onSubmit={onSubmit} className="space-y-3">
          <Field label="nome">
            <Input value={name} onChange={(e) => setName(e.target.value)} required maxLength={80} />
          </Field>
          <Field label="email">
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required disabled={mode === 'edit'} />
          </Field>
          {mode === 'create' && (
            <Field label="senha (mín. 8)">
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={8}
                autoComplete="new-password"
              />
            </Field>
          )}
          <Field label="validade do plano (opcional)">
            <Input type="date" value={expires} onChange={(e) => setExpires(e.target.value)} />
          </Field>

          <div className="rounded-lg border border-line p-3">
            <p className="mb-2 text-xs font-medium uppercase tracking-wide text-faint">
              Cotas da revenda
            </p>
            <Field label="máximo de clientes (0 = ilimitado)">
              <Input type="number" min="0" value={maxClients} onChange={(e) => setMaxClients(e.target.value)} />
            </Field>
            <p className="mb-2 mt-3 text-xs font-medium uppercase tracking-wide text-faint">
              VPS pessoal da revenda
            </p>
            <div className="grid grid-cols-3 gap-2">
              <Field label="vCPU">
                <Input type="number" min="1" step="0.5" value={cpu} onChange={(e) => setCpu(e.target.value)} />
              </Field>
              <Field label="RAM (MB)">
                <Input type="number" min="256" step="256" value={ram} onChange={(e) => setRam(e.target.value)} />
              </Field>
              <Field label="Disco (MB)">
                <Input type="number" min="1024" step="1024" value={disk} onChange={(e) => setDisk(e.target.value)} />
              </Field>
              <Field label="Máx. domínios">
                <Input type="number" min="0" value={maxDom} onChange={(e) => setMaxDom(e.target.value)} />
              </Field>
              <Field label="Máx. bancos">
                <Input type="number" min="0" value={maxDb} onChange={(e) => setMaxDb(e.target.value)} />
              </Field>
              <Field label="Máx. caixas e-mail">
                <Input type="number" min="0" value={maxMail} onChange={(e) => setMaxMail(e.target.value)} />
              </Field>
              <Field label="Banda MB/mês">
                <Input type="number" min="0" value={band} onChange={(e) => setBand(e.target.value)} />
              </Field>
            </div>
            {mode === 'edit' && (
              <p className="mt-2 text-xs text-faint">
                Os limites da VPS pessoal são reaplicados ao salvar (resize do container).
              </p>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <Button type="button" variant="ghost" onClick={() => setMode(null)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={create.isPending || update.isPending}>
              {create.isPending || update.isPending ? <Spinner /> : mode === 'edit' ? 'Salvar' : 'Criar revendedor'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
