import { useActions } from '../../api/hooks'
import { Card } from '../../components/ui/Card'
import { EmptyState } from '../../components/ui/EmptyState'
import { ProgressBar } from '../../components/ui/ProgressBar'
import { Spinner } from '../../components/ui/Spinner'
import { StatusBadge } from '../../components/ui/StatusBadge'
import { formatTime } from '../../lib/format'

export function ActionsPage() {
  const { data: actions, isLoading, error } = useActions()

  return (
    <div className="space-y-5">
      <header>
        <h1 className="font-display text-2xl text-ink">Fila de ações</h1>
        <p className="text-sm text-muted">Atualiza sozinha · o daemon consome em ordem</p>
      </header>

      {isLoading && <Spinner />}
      {error && <p className="text-sm text-failed">{(error as Error).message}</p>}
      {actions && actions.length === 0 && (
        <EmptyState title="Fila vazia" hint="Nenhuma ação registrada ainda." />
      )}

      {actions && actions.length > 0 && (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-faint">
                <th className="px-4 py-3 font-medium">#</th>
                <th className="px-4 py-3 font-medium">Tipo</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Criada</th>
                <th className="px-4 py-3 font-medium">Finalizada</th>
                <th className="px-4 py-3 font-medium">Resultado</th>
              </tr>
            </thead>
            <tbody>
              {actions.map((a) => (
                <tr key={a.id} className="border-b border-line/60 last:border-0">
                  <td className="px-4 py-3 font-mono text-faint">{a.id}</td>
                  <td className="px-4 py-3 font-mono text-ink">{a.type}</td>
                  <td className="px-4 py-3">
                    <StatusBadge status={a.status} />
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-muted">{formatTime(a.created_at)}</td>
                  <td className="px-4 py-3 font-mono text-xs text-muted">{formatTime(a.finished_at)}</td>
                  <td className="max-w-xs px-4 py-3 text-xs text-muted" title={a.result ?? ''}>
                    {a.status === 'running' && a.progress > 0 ? (
                      <ProgressBar pct={a.progress} stage={a.progress_stage} />
                    ) : (
                      <span className="block truncate">{a.result ?? '—'}</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </div>
  )
}
