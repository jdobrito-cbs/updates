import { useEffect, useState } from 'react'
import type { FormEvent } from 'react'
import { Building2, Globe, Mail, RotateCw, Server, Settings as SettingsIcon } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useMailcowConfig, useSetMailcowConfig } from '../../api/email'
import { useEdition, useRestartService, useSettings, useUpdateSettings } from '../../api/hooks'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { useConfirm } from '../../components/ui/ConfirmDialog'
import { Field } from '../../components/ui/Field'
import { Input } from '../../components/ui/Input'
import { PageHeader } from '../../components/ui/PageHeader'
import { Spinner } from '../../components/ui/Spinner'
import { useToast } from '../../components/ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

const SERVICES: { unit: string; label: string }[] = [
  { unit: 'nginx', label: 'nginx (host)' },
  { unit: 'wsrta-api', label: 'API (wsrta-api)' },
  { unit: 'wsrta-daemon', label: 'Daemon (wsrta-daemon)' },
  { unit: 'postgresql', label: 'PostgreSQL' },
  { unit: 'pdns', label: 'PowerDNS' },
]

export function SettingsPage() {
  const { data, isLoading } = useSettings()
  const update = useUpdateSettings()
  const toast = useToast()
  const [domain, setDomain] = useState('')
  const [company, setCompany] = useState('')
  const [maxAttempts, setMaxAttempts] = useState('0')
  const [lockoutMin, setLockoutMin] = useState('15')

  useEffect(() => {
    if (data) {
      setDomain(data.panel_domain)
      setCompany(data.company_name ?? '')
      setMaxAttempts(String(data.max_login_attempts ?? 0))
      setLockoutMin(String(data.lockout_minutes || 15))
    }
  }, [data])

  if (isLoading || !data) return <Spinner />

  async function onSave(e: FormEvent) {
    e.preventDefault()
    if (!data) return
    const attempts = Number(maxAttempts)
    const lockMin = Number(lockoutMin)
    if (!Number.isFinite(attempts) || attempts < 0 || attempts > 100) {
      toast.push('error', 'tentativas de login deve estar entre 0 (desativado) e 100')
      return
    }
    if (!Number.isFinite(lockMin) || lockMin < 1 || lockMin > 1440) {
      toast.push('error', 'minutos de bloqueio deve estar entre 1 e 1440')
      return
    }
    try {
      
      
      await update.mutateAsync({
        panel_domain: domain.trim(),
        company_name: company.trim(),
        max_domains_per_client: data.max_domains_per_client,
        max_databases_per_client: data.max_databases_per_client,
        max_login_attempts: attempts,
        lockout_minutes: lockMin,
      })
      toast.push('success', 'configurações salvas')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader
        icon={<SettingsIcon className="h-6 w-6" />}
        title="Configurações do sistema"
        subtitle="Identidade do painel, sessão, segurança de login e serviços."
      />

      <Card className="max-w-3xl p-6">
        <form onSubmit={onSave} className="space-y-6">
          {}
          <section>
            <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-faint">Identidade do painel</h3>
            <div className="grid gap-x-5 gap-y-4 sm:grid-cols-2">
              <Field label="Nome da empresa">
                <div className="flex items-center gap-2">
                  <Building2 className="h-4 w-4 flex-none text-faint" />
                  <Input
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    placeholder="Ex.: Minha Empresa"
                    maxLength={60}
                  />
                </div>
                <p className="mt-1 text-xs text-faint">Ao lado de “wsrta” na barra lateral e no título da aba.</p>
              </Field>

              <Field label="Domínio do painel">
                <div className="flex items-center gap-2">
                  <Globe className="h-4 w-4 flex-none text-faint" />
                  <Input
                    value={domain}
                    onChange={(e) => setDomain(e.target.value)}
                    placeholder="painel.seudominio.com"
                  />
                </div>
                <p className="mt-1 text-xs text-faint">Host público (ex.: SFTP). Vazio = endereço do servidor.</p>
              </Field>
            </div>
          </section>

          {}
          <section className="border-t border-line pt-5">
            <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-faint">Sessão e segurança</h3>
            <div className="grid gap-x-5 gap-y-4 sm:grid-cols-2">
              <Field label="Máx. tentativas de login">
                <Input
                  type="number"
                  min={0}
                  max={100}
                  value={maxAttempts}
                  onChange={(e) => setMaxAttempts(e.target.value)}
                />
                <p className="mt-1 text-xs text-faint">0 = desativado.</p>
              </Field>

              <Field label="Tempo de bloqueio (min)">
                <Input
                  type="number"
                  min={1}
                  max={1440}
                  value={lockoutMin}
                  onChange={(e) => setLockoutMin(e.target.value)}
                />
                <p className="mt-1 text-xs text-faint">Bloqueio após N falhas.</p>
              </Field>
            </div>
          </section>

          <Button type="submit" disabled={update.isPending}>
            {update.isPending ? <Spinner /> : 'Salvar'}
          </Button>
        </form>
      </Card>

      <MailcowCard />
      <RestartServicesCard />
    </div>
  )
}



function MailcowCard() {
  const edition = useEdition()
  const { data } = useMailcowConfig()
  const save = useSetMailcowConfig()
  const toast = useToast()
  const [url, setUrl] = useState('')
  const [apiKey, setApiKey] = useState('')

  useEffect(() => {
    if (data) setUrl(data.url ?? '')
  }, [data])

  if (edition.data && !edition.data.complete) return null

  async function onSave(e: FormEvent) {
    e.preventDefault()
    try {
      await save.mutateAsync({ url: url.trim(), api_key: apiKey.trim() })
      toast.push('success', 'config de e-mail salva')
      setApiKey('')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <Card className="max-w-3xl p-6">
      <h3 className="mb-1 flex items-center gap-2 text-sm font-medium text-ink">
        <Mail className="h-4 w-4 text-accent" /> Servidor de e-mail (mailcow)
      </h3>
      <p className="mb-3 text-xs text-faint">
        Aponte para o mailcow do host e cole uma API key (read-write). Status:{' '}
        <strong className={data?.configured ? 'text-done' : 'text-faint'}>
          {data?.configured ? 'configurado' : 'não configurado'}
        </strong>
        . Os domínios passam a oferecer e-mail; cada cliente cria caixas dentro da cota.
      </p>
      <form onSubmit={onSave} className="grid gap-4 sm:grid-cols-2">
        <Field label="URL do mailcow">
          <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://mail.seudominio.com" />
        </Field>
        <Field label="API key (read-write)">
          <Input type="password" value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder={data?.configured ? '•••••• (reenvie para trocar)' : ''} autoComplete="off" />
        </Field>
        <div className="sm:col-span-2">
          <Button type="submit" disabled={save.isPending}>
            {save.isPending ? <Spinner /> : 'Salvar e-mail'}
          </Button>
        </div>
      </form>
    </Card>
  )
}

function RestartServicesCard() {
  const restart = useRestartService()
  const confirm = useConfirm()
  const toast = useToast()

  async function onRestart(unit: string, label: string) {
    if (
      !(await confirm({
        title: 'Reiniciar serviço',
        message: `Reiniciar ${label}? O serviço fica indisponível por alguns segundos.`,
        confirmLabel: 'Reiniciar',
        danger: true,
      }))
    )
      return
    try {
      await restart.mutateAsync(unit)
      toast.push('success', `reinício de ${label} enfileirado — acompanhe a Fila`)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <Card className="max-w-3xl p-6">
      <h3 className="mb-1 flex items-center gap-2 text-sm font-medium text-ink">
        <Server className="h-4 w-4 text-accent" /> Reiniciar serviços da VPS
      </h3>
      <p className="mb-3 text-xs text-faint">
        Roda no daemon (root) via systemd. Reiniciar a API/daemon pode encerrar sua sessão por
        instantes.
      </p>
      <div className="flex flex-wrap gap-2">
        {SERVICES.map((s) => (
          <Button
            key={s.unit}
            variant="ghost"
            onClick={() => onRestart(s.unit, s.label)}
            disabled={restart.isPending}
          >
            <RotateCw className="h-4 w-4" /> {s.label}
          </Button>
        ))}
      </div>
    </Card>
  )
}
