import { Navigate } from 'react-router-dom'
import { Boxes } from 'lucide-react'

import { useEdition } from '../../api/hooks'
import { PackagesPanel } from '../../components/panels/PackagesPanel'
import { PageHeader } from '../../components/ui/PageHeader'


export function PackagesPage() {
  const edition = useEdition()
  if (edition.data && !edition.data.complete) return <Navigate to="/admin/dashboard" replace />
  return (
    <div className="space-y-5">
      <PageHeader
        icon={<Boxes className="h-6 w-6" />}
        title="Pacotes"
        subtitle="Planos de cliente — cotas (CPU/RAM/disco, domínios, bancos), preço e validade"
      />
      <PackagesPanel root="/api/admin" />
    </div>
  )
}
