import { useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { Link } from 'react-router-dom'
import {
  Database,
  DownloadCloud,
  FileArchive,
  Globe,
  KeyRound,
  Link2,
  Mail,
  RefreshCw,
  Server,
  Trash2,
  Upload,
} from 'lucide-react'

import { ApiError } from '../../api/client'
import { useUpload } from '../../components/UploadProvider'
import {
  useBackups,
  useClients,
  useCreateClientDomain,
  useDeleteBackup,
  useImportBackup,
  useNginxImport,
  usePreviewBackup,
} from '../../api/hooks'
import type { ImportResult, NginxSite } from '../../api/hooks'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { useConfirm } from '../../components/ui/ConfirmDialog'
import { EmptyState } from '../../components/ui/EmptyState'
import { Field } from '../../components/ui/Field'
import { Modal } from '../../components/ui/Modal'
import { PageHeader } from '../../components/ui/PageHeader'
import { Spinner } from '../../components/ui/Spinner'
import { useToast } from '../../components/ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

export function ImportPage() {
  const { data, isLoading, refetch, isFetching } = useBackups()
  const preview = usePreviewBackup()
  const importMut = useImportBackup()
  const deleteBackup = useDeleteBackup()
  const toast = useToast()
  const confirm = useConfirm()
  const [selected, setSelected] = useState<string | null>(null)
  const [result, setResult] = useState<ImportResult | null>(null)
  const [targetClientId, setTargetClientId] = useState(0) 
  const [newEmail, setNewEmail] = useState('') 
  const { upload, startUpload } = useUpload() 
  const fileRef = useRef<HTMLInputElement>(null)
  const { data: clients } = useClients('')

  async function onSelect(name: string) {
    setSelected(name)
    setResult(null)
    try {
      const pv = await preview.mutateAsync(name)
      setNewEmail(pv.email ?? '') 
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onUploadFile(file: File) {
    if (!file.name.endsWith('.tar.gz')) {
      toast.push('error', 'envie um arquivo .tar.gz')
      return
    }
    
    
    
    await startUpload({
      path: '/api/admin/import/cyberpanel/upload',
      file,
      invalidate: ['backups'],
      onDone: () => refetch(),
    })
  }

  async function onDeleteBackup(name: string) {
    if (
      !(await confirm({
        title: 'Apagar arquivo de backup',
        message: `Apagar "${name}" do servidor? A recuperação já feita não é afetada — só o arquivo .tar.gz é removido.`,
        confirmLabel: 'Apagar',
        danger: true,
      }))
    )
      return
    try {
      await deleteBackup.mutateAsync(name)
      if (selected === name) {
        setSelected(null)
        setResult(null)
      }
      toast.push('success', 'arquivo apagado')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onImport() {
    if (!selected) return
    const target =
      targetClientId > 0
        ? `o cliente "${clients?.find((c) => c.id === targetClientId)?.name ?? targetClientId}"`
        : 'um novo cliente'
    if (
      !(await confirm({
        title: 'Importar backup',
        message: `Importar este backup para ${target}?`,
        confirmLabel: 'Importar',
      }))
    )
      return
    try {
      const r = await importMut.mutateAsync({
        file: selected,
        client_id: targetClientId,
        email: targetClientId === 0 ? newEmail.trim() : undefined,
      })
      setResult(r)
      toast.push('success', targetClientId > 0 ? 'Importado para o cliente — restauração na Fila' : 'Cliente criado — restauração na Fila')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  const backups = data?.backups ?? []

  return (
    <div className="space-y-5">
      <PageHeader
        icon={<DownloadCloud className="h-6 w-6" />}
        title="Importar do CyberPanel"
        subtitle="Restaure um site (cliente, domínio, banco e arquivos) a partir de um backup nativo do CyberPanel."
      />

      <div className="grid gap-5 md:grid-cols-[20rem_1fr]">
        {}
        <Card className="p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-display text-sm text-ink">Backups</h2>
            <button
              onClick={() => refetch()}
              className="text-muted hover:text-ink"
              title="Atualizar"
            >
              <RefreshCw className={`h-4 w-4 ${isFetching ? 'animate-spin' : ''}`} />
            </button>
          </div>

          {}
          <div className="mb-3">
            <input
              ref={fileRef}
              type="file"
              accept=".tar.gz,.gz,application/gzip"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0]
                if (f) onUploadFile(f)
                e.target.value = '' 
              }}
            />
            <Button
              variant="ghost"
              className="w-full justify-center"
              disabled={upload?.status === 'uploading'}
              onClick={() => fileRef.current?.click()}
            >
              <Upload className="h-4 w-4" />{' '}
              {upload?.status === 'uploading'
                ? `Enviando… ${upload.pct}%`
                : 'Enviar backup (.tar.gz)'}
            </Button>
            <p className="mt-1 text-[11px] text-faint">Vai direto para o diretório do servidor, pronto para recuperar.</p>
          </div>

          {isLoading ? (
            <Spinner />
          ) : backups.length === 0 ? (
            <EmptyState
              title="Nenhum backup"
              hint={`Coloque os arquivos .tar.gz em ${data?.dir ?? ''} no host.`}
            />
          ) : (
            <ul className="space-y-1">
              {backups.map((b) => (
                <li key={b.name} className="flex items-center gap-1">
                  <button
                    onClick={() => onSelect(b.name)}
                    className={`flex min-w-0 flex-1 items-center gap-2 rounded-md px-2 py-2 text-left text-sm transition ${
                      selected === b.name
                        ? 'bg-elevated text-ink ring-1 ring-accent'
                        : 'text-muted hover:bg-elevated hover:text-ink'
                    }`}
                  >
                    <FileArchive className="h-4 w-4 shrink-0 text-accent" />
                    <span className="min-w-0 flex-1 truncate font-mono text-xs">{b.name}</span>
                    <span className="shrink-0 text-faint">{b.size_mb} MB</span>
                  </button>
                  <button
                    title="Apagar o arquivo do servidor"
                    onClick={() => onDeleteBackup(b.name)}
                    className="shrink-0 rounded-md p-2 text-muted transition hover:bg-failed/15 hover:text-failed"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Card>

        {}
        <div className="space-y-4">
          {!selected ? (
            <EmptyState
              title="Selecione um backup"
              hint="Escolha um arquivo à esquerda para ver o que será importado."
            />
          ) : (
            <>
              <Card className="p-5">
                <h2 className="mb-3 font-display text-lg text-ink">O que será importado</h2>
                {preview.isPending || !preview.data ? (
                  <Spinner />
                ) : (
                  <dl className="grid grid-cols-[8rem_1fr] gap-y-2 text-sm">
                    <Row icon={<Globe className="h-4 w-4" />} label="Domínio" value={preview.data.domain} mono />
                    <Row label="PHP" value={preview.data.php || '—'} />
                    <Row icon={<Mail className="h-4 w-4" />} label="E-mail" value={preview.data.email} mono />
                    <Row
                      icon={<Database className="h-4 w-4" />}
                      label="Bancos"
                      value={
                        preview.data.databases.length === 0
                          ? 'nenhum'
                          : preview.data.databases
                              .map((d) => `${d.name}${d.has_hash ? '' : ' (sem senha)'}`)
                              .join(', ')
                      }
                      mono
                    />
                    <Row label="Arquivos" value={preview.data.has_files ? 'public_html incluído' : 'sem arquivos'} />
                  </dl>
                )}

                <div className="mt-4 border-t border-line pt-4">
                  <label className="mb-1.5 block text-xs font-medium text-faint">Associar a</label>
                  <select
                    className="w-full max-w-sm rounded-md border border-line bg-base px-3 py-1.5 text-sm text-ink"
                    value={targetClientId}
                    onChange={(e) => setTargetClientId(Number(e.target.value))}
                  >
                    <option value={0}>Criar um novo cliente</option>
                    {(clients ?? []).map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.lxc_container_name})
                      </option>
                    ))}
                  </select>
                  <p className="mt-1 text-xs text-faint">
                    Escolha um cliente existente para configurar o domínio, banco e arquivos do backup nele — ou crie um
                    novo cliente.
                  </p>

                  {targetClientId === 0 && (
                    <div className="mt-3 max-w-sm">
                      <label className="mb-1.5 block text-xs font-medium text-faint">E-mail de login do novo cliente</label>
                      <input
                        type="email"
                        className="w-full rounded-md border border-line bg-base px-3 py-1.5 text-sm text-ink"
                        value={newEmail}
                        onChange={(e) => setNewEmail(e.target.value)}
                        placeholder="cliente@exemplo.com"
                      />
                      <p className="mt-1 text-xs text-faint">
                        Vem do backup — troque se for igual ao seu e-mail de admin (o e-mail é único no sistema).
                      </p>
                    </div>
                  )}
                </div>

                <div className="mt-4 flex items-center gap-3">
                  <Button onClick={onImport} disabled={importMut.isPending || preview.isPending}>
                    {importMut.isPending ? <Spinner /> : <DownloadCloud className="h-4 w-4" />}
                    {targetClientId > 0 ? 'Importar para o cliente' : 'Importar e criar cliente'}
                  </Button>
                  <span className="text-xs text-faint">
                    Backups grandes levam alguns minutos — acompanhe na{' '}
                    <Link to="/admin/queue" className="text-accent hover:underline">
                      Fila
                    </Link>
                    .
                  </span>
                </div>
              </Card>

              {result && (
                <Card className="border-done/40 p-5">
                  <h2 className="mb-1 flex items-center gap-2 font-display text-lg text-ink">
                    <KeyRound className="h-4 w-4 text-done" />{' '}
                    {result.login_password ? 'Cliente criado' : 'Importado para o cliente'}
                  </h2>
                  <p className="mb-3 text-sm text-muted">
                    {result.login_password
                      ? 'Guarde o login abaixo (a senha é mostrada só uma vez). A restauração do banco e dos arquivos está na Fila.'
                      : 'O domínio e o banco foram configurados no cliente. A restauração do banco e dos arquivos está na Fila.'}
                  </p>
                  <dl className="grid grid-cols-[8rem_1fr] gap-y-2 text-sm">
                    <Row label="Domínio" value={result.domain} mono />
                    {result.login_password && (
                      <>
                        <Row label="Login" value={result.login_email ?? ''} mono />
                        <Row label="Senha" value={result.login_password} mono highlight />
                      </>
                    )}
                  </dl>
                </Card>
              )}
            </>
          )}
        </div>
      </div>

      <NginxImportCard />
    </div>
  )
}



function NginxImportCard() {
  const { data: sites, isLoading, refetch, isFetching } = useNginxImport()
  const { data: clients } = useClients('')
  const associate = useCreateClientDomain()
  const toast = useToast()
  const [target, setTarget] = useState<NginxSite | null>(null)
  const [clientId, setClientId] = useState(0)

  function openAssociate(s: NginxSite) {
    setTarget(s)
    setClientId(clients?.[0]?.id ?? 0)
  }

  async function onAssociate() {
    if (!target || clientId <= 0) return
    try {
      await associate.mutateAsync({
        client_id: clientId,
        fqdn: target.fqdns[0],
        upstream_ip: target.upstream_ip || undefined,
        upstream_port: target.upstream_ip ? target.upstream_port || 80 : undefined,
      })
      toast.push('success', `domínio ${target.fqdns[0]} associado`)
      setTarget(null)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  const list = sites ?? []

  return (
    <Card className="p-5">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h2 className="flex items-center gap-2 font-display text-lg text-ink">
            <Server className="h-4 w-4 text-accent" /> Importar do Nginx local
          </h2>
          <p className="text-xs text-faint">
            Domínios detectados na configuração do Nginx já instalado no host (vhosts locais e
            redirecionamentos para outros servidores). Associe cada um a um cliente.
          </p>
        </div>
        <button onClick={() => refetch()} className="text-muted hover:text-ink" title="Reescanear">
          <RefreshCw className={`h-4 w-4 ${isFetching ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {isLoading ? (
        <Spinner />
      ) : list.length === 0 ? (
        <EmptyState title="Nenhum domínio detectado" hint="Só funciona no host com o Nginx instalado (/etc/nginx)." />
      ) : (
        <div className="overflow-hidden rounded-lg border border-line">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-faint">
                <th className="px-3 py-2 font-medium">Domínio(s)</th>
                <th className="px-3 py-2 font-medium">Destino</th>
                <th className="px-3 py-2" />
              </tr>
            </thead>
            <tbody>
              {list.map((s, i) => (
                <tr key={i} className="border-b border-line/60 last:border-0">
                  <td className="px-3 py-2 font-mono text-xs text-ink">{s.fqdns.join(', ')}</td>
                  <td className="px-3 py-2 text-xs text-muted">
                    {s.upstream_ip
                      ? `proxy → ${s.upstream_ip}:${s.upstream_port || 80}`
                      : s.proxy_target
                        ? `proxy → ${s.proxy_target}`
                        : s.root
                          ? `local (${s.root})`
                          : '—'}
                  </td>
                  <td className="px-3 py-2 text-right">
                    {s.known ? (
                      <span className="text-xs text-faint">já no painel</span>
                    ) : (
                      <Button variant="ghost" onClick={() => openAssociate(s)}>
                        <Link2 className="h-4 w-4" /> Associar
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Modal open={target !== null} onClose={() => setTarget(null)} title="Associar domínio a um cliente">
        {target && (
          <div className="space-y-3">
            <p className="text-sm text-ink">
              <span className="font-mono">{target.fqdns[0]}</span>
              {target.upstream_ip && (
                <span className="ml-2 text-xs text-accent">→ {target.upstream_ip}:{target.upstream_port || 80}</span>
              )}
            </p>
            <Field label="cliente">
              <select
                className="w-full rounded-md border border-line bg-base px-3 py-1.5 text-sm text-ink"
                value={clientId}
                onChange={(e) => setClientId(Number(e.target.value))}
              >
                {(clients ?? []).map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.lxc_container_name})
                  </option>
                ))}
              </select>
            </Field>
            <div className="flex justify-end gap-2 pt-1">
              <Button type="button" variant="ghost" onClick={() => setTarget(null)}>
                Cancelar
              </Button>
              <Button onClick={onAssociate} disabled={associate.isPending || clientId <= 0}>
                {associate.isPending ? <Spinner /> : 'Associar'}
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </Card>
  )
}

function Row({
  icon,
  label,
  value,
  mono,
  highlight,
}: {
  icon?: ReactNode
  label: string
  value: string
  mono?: boolean
  highlight?: boolean
}) {
  return (
    <>
      <dt className="flex items-center gap-1.5 text-faint">
        {icon}
        {label}
      </dt>
      <dd
        className={`${mono ? 'font-mono' : ''} ${
          highlight ? 'rounded bg-elevated px-2 py-0.5 text-done' : 'text-ink'
        } break-all`}
      >
        {value}
      </dd>
    </>
  )
}
