import type { ReactNode } from 'react'
import { Database, Globe, LayoutDashboard, Loader2, Newspaper, Server, Users } from 'lucide-react'

import { useActions, useClients, useDashboard } from '../../api/hooks'
import { BarCard, C } from '../../components/charts/Charts'
import { Card } from '../../components/ui/Card'
import { PageHeader } from '../../components/ui/PageHeader'
import { StatusBadge } from '../../components/ui/StatusBadge'
import { formatTime } from '../../lib/format'

export function DashboardPage() {
  const { data: clients } = useClients('')
  const { data: actions } = useActions()
  const { data: dash } = useDashboard()

  const acts = actions ?? []
  const pending = acts.filter((a) => a.status === 'pending' || a.status === 'running').length
  const perClient = (dash?.clients ?? []).map((c) => ({
    name: c.name,
    domínios: c.domains,
    bancos: c.databases,
  }))

  return (
    <div className="space-y-6">
      <PageHeader
        icon={<LayoutDashboard className="h-6 w-6" />}
        title="Visão geral"
        subtitle={dash?.server_ip ? `Servidor ${dash.server_ip}` : 'Estado do host e da fila'}
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-3 xl:grid-cols-6">
        <Metric icon={<Server className="h-4 w-4" />} label="IP do servidor" value={dash?.server_ip ?? '—'} mono />
        <Metric icon={<Users className="h-4 w-4" />} label="Clientes" value={(clients ?? []).length} />
        <Metric icon={<Globe className="h-4 w-4" />} label="Domínios" value={dash?.total_domains ?? '—'} />
        <Metric icon={<Database className="h-4 w-4" />} label="Bancos" value={dash?.total_databases ?? '—'} />
        <Metric icon={<Newspaper className="h-4 w-4" />} label="WordPress" value={dash?.total_wordpress ?? '—'} />
        <Metric icon={<Loader2 className="h-4 w-4" />} label="Na fila" value={pending} accent="text-running" />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <BarCard title="Domínios por cliente" data={perClient} dataKey="domínios" color={C.accent} />
        <BarCard title="Bancos por cliente" data={perClient} dataKey="bancos" color={C.running} />
      </div>

      <div>
        <h2 className="mb-3 font-display text-lg text-ink">Atividade recente</h2>
        <Card className="overflow-hidden">
          {acts.length === 0 ? (
            <p className="px-4 py-6 text-center text-sm text-muted">Nenhuma ação ainda.</p>
          ) : (
            <table className="w-full text-sm">
              <tbody>
                {acts.slice(0, 6).map((a) => (
                  <tr key={a.id} className="border-b border-line/60 last:border-0">
                    <td className="px-4 py-3 font-mono text-faint">#{a.id}</td>
                    <td className="px-4 py-3 font-mono text-ink">{a.type}</td>
                    <td className="px-4 py-3">
                      <StatusBadge status={a.status} />
                    </td>
                    <td className="px-4 py-3 text-right font-mono text-xs text-muted">{formatTime(a.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      </div>
    </div>
  )
}

function Metric({
  icon,
  label,
  value,
  accent,
  mono,
}: {
  icon: ReactNode
  label: string
  value: ReactNode
  accent?: string
  mono?: boolean
}) {
  return (
    <Card className="p-4">
      <div className="mb-2 flex items-center gap-1.5 text-xs uppercase tracking-wide text-faint">
        <span className="text-accent">{icon}</span> {label}
      </div>
      <div className={`${mono ? 'font-mono text-base' : 'font-display text-2xl'} ${accent ?? 'text-ink'}`}>
        {value}
      </div>
    </Card>
  )
}
