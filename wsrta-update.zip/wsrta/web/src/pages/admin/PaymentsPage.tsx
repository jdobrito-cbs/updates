import { Navigate } from 'react-router-dom'
import { CreditCard } from 'lucide-react'

import { useEdition } from '../../api/hooks'
import { MercadoPagoPanel } from '../../components/panels/MercadoPagoPanel'
import { PageHeader } from '../../components/ui/PageHeader'


export function PaymentsPage() {
  const edition = useEdition()
  if (edition.data && !edition.data.complete) return <Navigate to="/admin/dashboard" replace />
  return (
    <div className="space-y-5">
      <PageHeader icon={<CreditCard className="h-6 w-6" />} title="Pagamentos" subtitle="MercadoPago e vendas dos seus pacotes" />
      <MercadoPagoPanel root="/api/admin" />
    </div>
  )
}
