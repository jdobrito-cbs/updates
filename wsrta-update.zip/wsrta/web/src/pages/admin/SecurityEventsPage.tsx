import { Ban, ShieldX } from 'lucide-react'

import type { SecurityEvent } from '../../api/hooks'
import { useBlockIP, useSecurityEvents } from '../../api/hooks'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { PageHeader } from '../../components/ui/PageHeader'
import { Spinner } from '../../components/ui/Spinner'
import { useToast } from '../../components/ui/Toast'
import { formatTime } from '../../lib/format'

const msg = (e: unknown) => (e instanceof Error ? e.message : 'falha na operação')

const SEV: Record<string, string> = {
  high: 'bg-failed/15 text-failed',
  medium: 'bg-running/15 text-running',
  low: 'bg-pending/15 text-pending',
  info: 'bg-line text-muted',
}
const TYPE_LABEL: Record<string, string> = {
  login_failed: 'login falhou',
  '2fa_failed': '2FA falhou',
  account_locked: 'conta bloqueada',
  rate_limited: 'rate-limit',
  auto_blocked: 'auto-bloqueado',
  manual_block: 'bloqueio manual',
  ssh_failed: 'SSH falhou',
  waf_block: 'WAF bloqueou',
}

export function SecurityEventsPage() {
  const { data, isLoading } = useSecurityEvents()
  const block = useBlockIP()
  const toast = useToast()
  const events = data ?? []

  async function onBlock(ip: string) {
    try {
      await block.mutateAsync(ip)
      toast.push('success', `IP ${ip} bloqueado no firewall`)
    } catch (e) {
      toast.push('error', msg(e))
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader
        icon={<ShieldX className="h-6 w-6" />}
        title="Eventos de segurança"
        subtitle="Tentativas de login/brute-force com IP e dados de quem tentou; IPs públicos com muitas falhas são bloqueados no firewall automaticamente"
      />

      {isLoading ? (
        <Spinner />
      ) : (
        <Card className="overflow-x-auto p-0">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs text-faint">
                <th className="px-4 py-2 font-medium">Quando</th>
                <th className="px-4 py-2 font-medium">Tipo</th>
                <th className="px-4 py-2 font-medium">IP</th>
                <th className="px-4 py-2 font-medium">E-mail tentado</th>
                <th className="px-4 py-2 font-medium">Detalhe</th>
                <th className="px-4 py-2"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {events.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-4 py-6 text-center text-faint">
                    Nenhuma tentativa registrada.
                  </td>
                </tr>
              )}
              {events.map((e) => (
                <EventRow key={e.id} e={e} onBlock={onBlock} disabled={block.isPending} />
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </div>
  )
}

function EventRow({ e, onBlock, disabled }: { e: SecurityEvent; onBlock: (ip: string) => void; disabled: boolean }) {
  return (
    <tr className="align-top">
      <td className="whitespace-nowrap px-4 py-2 text-xs text-muted">{formatTime(e.created_at)}</td>
      <td className="px-4 py-2">
        <span className={`rounded px-1.5 py-0.5 text-xs font-medium ${SEV[e.severity] ?? SEV.info}`}>
          {TYPE_LABEL[e.event_type] ?? e.event_type}
        </span>
      </td>
      <td className="whitespace-nowrap px-4 py-2 font-mono text-xs text-ink">
        {e.ip || '—'}
        {e.blocked && <span className="ml-1 text-failed" title="IP bloqueado no firewall">⛔</span>}
      </td>
      <td className="px-4 py-2 text-xs text-muted">{e.email || '—'}</td>
      <td className="max-w-md px-4 py-2 text-xs text-muted">
        <span title={e.user_agent}>{e.detail}</span>
      </td>
      <td className="whitespace-nowrap px-4 py-2 text-right">
        {e.ip && (
          <Button
            variant="ghost"
            onClick={() => onBlock(e.ip)}
            disabled={disabled}
            title="Bloquear este IP no firewall (CSF deny)"
          >
            <Ban className="h-4 w-4" /> Bloquear
          </Button>
        )}
      </td>
    </tr>
  )
}
