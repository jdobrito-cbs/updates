import { useState } from 'react'
import { Boxes, DownloadCloud, Info, Linkedin, Mail, RefreshCw, ShieldCheck } from 'lucide-react'

import { useSystemUpdate, useVersion } from '../api/hooks'
import { useAuth } from '../auth/AuthContext'
import { Button } from '../components/ui/Button'
import { Card } from '../components/ui/Card'
import { useConfirm } from '../components/ui/ConfirmDialog'
import { PageHeader } from '../components/ui/PageHeader'
import { useToast } from '../components/ui/Toast'


function brDate(iso?: string): string {
  if (!iso) return 'desenvolvimento'
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso)
  return m ? `${m[3]}/${m[2]}/${m[1]}` : iso
}

export function AboutPage() {
  const { data: ver } = useVersion()
  const { role } = useAuth()

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <PageHeader icon={<Info className="h-6 w-6" />} title="Sobre" subtitle="Informações do sistema e do criador" />

      {}
      <Card className="p-6">
        <div className="flex items-start gap-4">
          <span className="grid h-12 w-12 flex-none place-items-center rounded-2xl bg-accent/15 text-accent">
            <Boxes className="h-6 w-6" />
          </span>
          <div className="min-w-0">
            <h2 className="font-display text-xl text-ink">WSRTA — Painel de Controle de Hospedagem</h2>
            <p className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-sm">
              <span className="rounded-md border border-line bg-elevated px-2 py-0.5 font-mono text-xs text-accent">
                v{ver?.version ?? '—'}
              </span>
              <span className="text-muted">
                atualizado em{' '}
                <b className="text-ink">{brDate(ver?.build_date)}</b>
              </span>
            </p>
            <p className="mt-3 text-sm leading-relaxed text-muted">
              Painel de hospedagem <b className="text-ink">self-hosted</b>, de uso interno, que roda em Ubuntu Server.
              Cada cliente é isolado em seu próprio <b className="text-ink">container LXC/LXD</b>, e o painel gerencia
              Web (Nginx + PHP-FPM), DNS (PowerDNS), SSL (Let's Encrypt), Bancos (MariaDB), WordPress, SFTP,
              Cloudflare Tunnel, backups, monitoramento do servidor e muito mais — tudo a partir de uma interface única.
            </p>
            <div className="mt-4 flex items-start gap-2 rounded-lg border border-line bg-elevated/60 p-3 text-xs text-muted">
              <ShieldCheck className="h-4 w-4 flex-none text-accent" />
              <span>
                Princípio de segurança: a API web <b className="text-ink">nunca executa comandos de sistema</b>. Ela
                valida e enfileira ações; um daemon orquestrador (único processo com root) revalida e executa.
              </span>
            </div>
          </div>
        </div>
      </Card>

      {/* Atualização do sistema — só admin */}
      {role === 'admin' && <UpdateCard />}

      {/* Os criadores */}
      <Card className="space-y-6 p-6">
        <h2 className="text-sm font-semibold uppercase tracking-wide text-faint">Criadores</h2>
        <Creator
          photo="/creator-jorge-brito.jpg"
          initials="JB"
          name="Jorge Brito"
          title="Desenvolvedor Full Stack · Especialista em Desenvolvimento de Jogos Eletrônicos e Gestão de Projetos"
          email="jdbrito@uea.edu.br"
          linkedin="https://www.linkedin.com/in/jorge-obrito/"
        />
        <div className="border-t border-line" />
        <Creator
          photo="/creator-jorge-manoel.jpg"
          initials="JMB"
          name="Jorge Manoel Brito"
          title="Desenvolvedor Full Stack · Aluno Pesquisador em Cibersegurança Mobile"
          email="j22.rbrito@gmail.com"
          linkedin="https://br.linkedin.com/in/jorge-manoel-reis-brito-01bba1371"
        />
      </Card>

      <p className="text-center text-xs text-faint">
        WSRTA v{ver?.version ?? '—'} · © {new Date().getFullYear()} Jorge Brito · Jorge Manoel Brito
      </p>
    </div>
  )
}

// Creator: cartão de um criador com foto REDONDA com borda (anel em gradiente). A foto é
// carregada de web/public (ex.: /creator-jorge-manoel.jpg); se o arquivo não existir,
// mostra as iniciais.
function Creator({
  photo,
  initials,
  name,
  title,
  email,
  linkedin,
}: {
  photo: string
  initials: string
  name: string
  title: string
  email: string
  linkedin: string
}) {
  const [err, setErr] = useState(false)
  return (
    <div className="flex flex-col gap-5 sm:flex-row sm:items-center">
      <span className="flex-none rounded-full bg-gradient-to-br from-accent via-accentStrong to-accent p-[3px] shadow-lg shadow-accent/20">
        {err ? (
          <span className="grid h-24 w-24 place-items-center rounded-full bg-elevated font-display text-2xl text-accent ring-2 ring-base">
            {initials}
          </span>
        ) : (
          <img
            src={photo}
            alt={name}
            onError={() => setErr(true)}
            className="h-24 w-24 rounded-full object-cover ring-2 ring-base"
          />
        )}
      </span>
      <div className="min-w-0 flex-1">
        <p className="font-display text-lg text-ink">{name}</p>
        <p className="mt-1 text-sm text-muted">{title}</p>
        <div className="mt-4 flex flex-wrap gap-2">
          <a
            href={`mailto:${email}`}
            className="inline-flex items-center gap-2 rounded-lg border border-line bg-elevated px-3 py-2 text-sm text-ink transition-colors hover:border-accent hover:text-accent"
          >
            <Mail className="h-4 w-4" /> {email}
          </a>
          <a
            href={linkedin}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-lg border border-line bg-elevated px-3 py-2 text-sm text-ink transition-colors hover:border-accent hover:text-accent"
          >
            <Linkedin className="h-4 w-4" /> LinkedIn
          </a>
        </div>
      </div>
    </div>
  )
}

function UpdateCard() {
  const updateOS = useSystemUpdate('os')
  const updatePanel = useSystemUpdate('panel')
  const confirm = useConfirm()
  const toast = useToast()

  async function run(kind: 'os' | 'panel') {
    const label = kind === 'os' ? 'os pacotes do SO (apt upgrade)' : 'o painel WSRTA (busca o pacote mais recente no GitHub)'
    if (!(await confirm({ title: 'Atualizar sistema', message: `Atualizar ${label}? Acompanhe na Fila.`, confirmLabel: 'Atualizar' })))
      return
    try {
      await (kind === 'os' ? updateOS : updatePanel).mutateAsync()
      toast.push('success', 'atualização enfileirada — acompanhe a Fila')
    } catch {
      toast.push('error', 'falha ao enfileirar')
    }
  }

  return (
    <Card className="flex flex-wrap items-center justify-between gap-3 p-5">
      <div>
        <h3 className="text-sm font-medium text-ink">Atualizar o sistema</h3>
        <p className="text-xs text-faint">
          As atualizações rodam no daemon (root) e aparecem na Fila. O painel busca o pacote
          <span className="font-mono"> wsrta-&lt;data&gt;-update.zip</span> mais recente no GitHub.
        </p>
      </div>
      <div className="flex gap-2">
        <Button variant="ghost" onClick={() => run('os')} disabled={updateOS.isPending}>
          <DownloadCloud className="h-4 w-4" /> Atualizar SO
        </Button>
        <Button onClick={() => run('panel')} disabled={updatePanel.isPending}>
          <RefreshCw className="h-4 w-4" /> Atualizar painel
        </Button>
      </div>
    </Card>
  )
}
