import { useEffect, useState } from 'react'
import type { FormEvent } from 'react'
import { ExternalLink, Globe, Palette } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useResellerProfile, useUpdateResellerSite } from '../../api/hooks'
import { LANDING_TEMPLATES } from '../LandingPage'
import { MercadoPagoPanel } from '../../components/panels/MercadoPagoPanel'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { Field } from '../../components/ui/Field'
import { Input } from '../../components/ui/Input'
import { PageHeader } from '../../components/ui/PageHeader'
import { Spinner } from '../../components/ui/Spinner'
import { useToast } from '../../components/ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')


const SWATCH: Record<string, string> = {
  aurora: 'from-emerald-500 to-teal-500',
  midnight: 'from-blue-500 to-indigo-600',
  sunset: 'from-orange-500 to-pink-500',
  forest: 'from-green-500 to-lime-600',
  ocean: 'from-cyan-500 to-blue-500',
  royal: 'from-purple-500 to-fuchsia-500',
  ember: 'from-red-500 to-orange-500',
  slate: 'from-slate-500 to-slate-700',
  neon: 'from-lime-400 to-emerald-500',
  sand: 'from-amber-500 to-yellow-500',
  rose: 'from-rose-500 to-pink-500',
  mono: 'from-zinc-200 to-zinc-400',
}

export function ResellerSitePage() {
  const me = useResellerProfile()
  const save = useUpdateResellerSite()
  const toast = useToast()

  const [slug, setSlug] = useState('')
  const [template, setTemplate] = useState('aurora')
  const [headline, setHeadline] = useState('')
  const [subtitle, setSubtitle] = useState('')
  const [external, setExternal] = useState('')

  useEffect(() => {
    if (me.data) {
      setSlug(me.data.slug || '')
      setTemplate(me.data.landing_template || 'aurora')
      setHeadline(me.data.landing_headline || '')
      setSubtitle(me.data.landing_subtitle || '')
      setExternal(me.data.external_site_url || '')
    }
  }, [me.data])

  if (me.isLoading || !me.data) return <Spinner />

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    try {
      await save.mutateAsync({
        slug: slug.trim().toLowerCase(),
        landing_template: template,
        landing_headline: headline.trim(),
        landing_subtitle: subtitle.trim(),
        external_site_url: external.trim(),
      })
      toast.push('success', 'site salvo')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  const publicUrl = slug ? `${window.location.origin}/r/${slug}` : ''

  return (
    <div className="space-y-5">
      <PageHeader icon={<Globe className="h-6 w-6" />} title="Meu site (landpage)" subtitle="Página pública de vendas da sua revenda" />

      <form onSubmit={onSubmit} className="space-y-5">
        <Card className="space-y-3 p-5">
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="endereço (slug)">
              <Input value={slug} onChange={(e) => setSlug(e.target.value)} placeholder="minharevenda" />
            </Field>
            <div className="flex items-end">
              {publicUrl ? (
                <a href={publicUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-sm text-accent hover:underline">
                  <ExternalLink className="h-4 w-4" /> {publicUrl}
                </a>
              ) : (
                <span className="text-xs text-faint">defina uma slug para publicar em /r/&lt;slug&gt;</span>
              )}
            </div>
          </div>
          <Field label="título (headline)">
            <Input value={headline} onChange={(e) => setHeadline(e.target.value)} placeholder="Hospedagem rápida e segura" maxLength={120} />
          </Field>
          <Field label="subtítulo">
            <Input value={subtitle} onChange={(e) => setSubtitle(e.target.value)} placeholder="Planos a partir de..." maxLength={240} />
          </Field>
          <Field label="OU usar site próprio / WordPress (URL externa — substitui o modelo)">
            <Input value={external} onChange={(e) => setExternal(e.target.value)} placeholder="https://meusite.com" />
          </Field>
        </Card>

        <Card className="space-y-3 p-5">
          <h3 className="flex items-center gap-2 text-sm font-medium text-ink">
            <Palette className="h-4 w-4 text-accent" /> Modelo da landpage
          </h3>
          <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-6">
            {LANDING_TEMPLATES.map((tpl) => (
              <button
                key={tpl}
                type="button"
                onClick={() => setTemplate(tpl)}
                className={`overflow-hidden rounded-lg border text-left transition ${template === tpl ? 'border-accent ring-1 ring-accent' : 'border-line hover:border-muted'}`}
              >
                <div className={`h-12 w-full bg-gradient-to-r ${SWATCH[tpl] ?? 'from-slate-500 to-slate-700'}`} />
                <span className="block px-2 py-1 text-xs capitalize text-muted">{tpl}</span>
              </button>
            ))}
          </div>
        </Card>

        <div className="flex justify-end">
          <Button type="submit" disabled={save.isPending}>
            {save.isPending ? <Spinner /> : 'Salvar site'}
          </Button>
        </div>
      </form>

      <MercadoPagoPanel root="/api/reseller" />
    </div>
  )
}
