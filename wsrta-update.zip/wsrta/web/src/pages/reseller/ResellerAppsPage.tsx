import { useEffect, useState } from 'react'
import { Boxes } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useResellerAppPerms, useSetResellerAppPerms } from '../../api/apps'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { EmptyState } from '../../components/ui/EmptyState'
import { PageHeader } from '../../components/ui/PageHeader'
import { Spinner } from '../../components/ui/Spinner'
import { useToast } from '../../components/ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')



export function ResellerAppsPage() {
  const { data, isLoading } = useResellerAppPerms()
  const save = useSetResellerAppPerms()
  const toast = useToast()
  const [clients, setClients] = useState<string[]>([])

  useEffect(() => {
    if (data) setClients(data.clients ?? [])
  }, [data])

  if (isLoading || !data) return <Spinner />

  const catalog = data.catalog ?? []

  function toggle(slug: string) {
    setClients((c) => (c.includes(slug) ? c.filter((s) => s !== slug) : [...c, slug]))
  }

  async function onSave() {
    try {
      await save.mutateAsync({ clients })
      toast.push('success', 'liberações salvas')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader
        icon={<Boxes className="h-6 w-6" />}
        title="Apps"
        subtitle="Libere quais apps aparecem para os seus clientes"
        actions={
          <Button onClick={onSave} disabled={save.isPending || catalog.length === 0}>
            {save.isPending ? <Spinner /> : 'Salvar'}
          </Button>
        }
      />
      {catalog.length === 0 ? (
        <EmptyState title="Nenhum app disponível" hint="O administrador ainda não liberou apps para as revendas." />
      ) : (
        <Card className="space-y-2 p-5">
          {catalog.map((a) => (
            <label key={a.slug} className="flex cursor-pointer items-start gap-3 rounded-lg border border-line p-3 hover:bg-elevated/60">
              <input type="checkbox" checked={clients.includes(a.slug)} onChange={() => toggle(a.slug)} className="mt-1" />
              <span>
                <span className="block text-sm text-ink">
                  {a.name} <span className="text-[10px] uppercase text-faint">{a.kind}</span>
                </span>
                <span className="block text-xs text-muted">{a.description}</span>
              </span>
            </label>
          ))}
        </Card>
      )}
    </div>
  )
}
