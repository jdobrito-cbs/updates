import { useState } from 'react'
import type { FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { Ban, CircleCheck, Pause, Play, Plus, Power, PowerOff, RotateCcw, Search, Settings2, Trash2, Users } from 'lucide-react'

import { ApiError } from '../../api/client'
import {
  useCreateResellerClient,
  useResellerClientAction,
  useResellerClientPower,
  useResellerClients,
} from '../../api/hooks'
import { usePackages } from '../../api/resources'
import type { Client } from '../../api/types'
import { Button } from '../../components/ui/Button'
import { Card } from '../../components/ui/Card'
import { useConfirm } from '../../components/ui/ConfirmDialog'
import { EmptyState } from '../../components/ui/EmptyState'
import { Field } from '../../components/ui/Field'
import { Input } from '../../components/ui/Input'
import { Modal } from '../../components/ui/Modal'
import { PageHeader } from '../../components/ui/PageHeader'
import { PresenceBadge } from '../../components/ui/PresenceBadge'
import { Spinner } from '../../components/ui/Spinner'
import { useToast } from '../../components/ui/Toast'
import { formatTime } from '../../lib/format'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

export function ResellerClientsPage() {
  const [search, setSearch] = useState('')
  const { data, isLoading } = useResellerClients(search)
  const create = useCreateResellerClient()
  const action = useResellerClientAction()
  const power = useResellerClientPower()
  const navigate = useNavigate()
  const toast = useToast()
  const confirm = useConfirm()

  const packages = usePackages('/api/reseller')

  const [open, setOpen] = useState(false)
  const [email, setEmail] = useState('')
  const [name, setName] = useState('')
  const [password, setPassword] = useState('')
  const [cpu, setCpu] = useState('1')
  const [ram, setRam] = useState('1024')
  const [disk, setDisk] = useState('10240')
  const [pkgId, setPkgId] = useState('0') 

  const clients = data ?? []
  const pkgs = packages.data ?? []

  function openCreate() {
    setOpen(true)
    setEmail('')
    setName('')
    setPassword('')
    setCpu('1')
    setRam('1024')
    setDisk('10240')
    setPkgId('0')
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    const pid = Number(pkgId) || 0
    try {
      await create.mutateAsync({
        email,
        name,
        password,
        
        cpu_limit: Number(cpu) || 1,
        ram_limit_mb: Number(ram) || 1024,
        disk_quota_mb: Number(disk) || 10240,
        package_id: pid > 0 ? pid : undefined,
      })
      toast.push('success', 'cliente criado — provisionando (acompanhe o status)')
      setOpen(false)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onAction(c: Client, act: 'suspend' | 'resume' | 'delete') {
    const labels = { suspend: 'Suspender', resume: 'Reativar', delete: 'Excluir' }
    if (act !== 'resume') {
      if (
        !(await confirm({
          title: `${labels[act]} cliente`,
          message:
            act === 'delete'
              ? `Excluir o cliente ${c.name}? O container e os dados serão removidos. Irreversível.`
              : `Suspender o cliente ${c.name}? Os sites dele ficam fora do ar até reativar.`,
          confirmLabel: labels[act],
          danger: true,
        }))
      )
        return
    }
    try {
      await action.mutateAsync({ id: c.id, action: act })
      toast.push('success', act === 'delete' ? 'cliente removido' : act === 'suspend' ? 'cliente suspenso' : 'cliente reativado')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onPower(c: Client, op: 'start' | 'stop' | 'restart') {
    const verbo = op === 'start' ? 'iniciar' : op === 'stop' ? 'parar' : 'reiniciar'
    if (op !== 'start') {
      if (
        !(await confirm({
          title: `${verbo[0].toUpperCase()}${verbo.slice(1)} VPS`,
          message:
            op === 'stop'
              ? `Parar a VPS de ${c.name} derruba os sites dele até ser iniciada de novo. Continuar?`
              : `Reiniciar a VPS de ${c.name} interrompe os sites por alguns segundos. Continuar?`,
          confirmLabel: verbo,
          danger: op === 'stop',
        }))
      )
        return
    }
    try {
      await power.mutateAsync({ id: c.id, op })
      toast.push('success', `${verbo} da VPS de ${c.name} enfileirado`)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-5">
      <PageHeader
        icon={<Users className="h-6 w-6" />}
        title="Clientes"
        subtitle={`${clients.length} cliente(s) da sua revenda`}
        actions={
          <Button onClick={openCreate}>
            <Plus className="h-4 w-4" /> Novo cliente
          </Button>
        }
      />

      <div className="relative max-w-sm">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
        <Input className="pl-9" placeholder="Buscar…" value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>

      {isLoading && <Spinner />}

      {!isLoading && clients.length === 0 && (
        <EmptyState
          title={search ? 'Nenhum cliente encontrado' : 'Nenhum cliente'}
          hint={search ? 'Ajuste a busca.' : 'Crie o primeiro cliente da sua revenda.'}
          action={!search && <Button onClick={openCreate}>+ Novo cliente</Button>}
        />
      )}

      {clients.length > 0 && (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-faint">
                <th className="px-4 py-3 font-medium">Nome</th>
                <th className="px-4 py-3 font-medium">Recursos</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Criado</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {clients.map((c) => (
                <tr key={c.id} className="border-b border-line/60 last:border-0 hover:bg-elevated/60">
                  <td className="px-4 py-3 text-ink">{c.name}</td>
                  <td className="px-4 py-3 text-xs text-muted">
                    {c.cpu_limit} vCPU · {c.ram_limit_mb} MB · {Math.round(c.disk_quota_mb / 1024)} GB
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap items-center gap-2">
                      {c.status === 'suspended' ? (
                        <span className="inline-flex items-center gap-1 rounded-full bg-failed/15 px-2 py-0.5 text-xs font-medium text-failed">
                          <Ban className="h-3 w-3" /> suspenso
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 rounded-full bg-done/15 px-2 py-0.5 text-xs font-medium text-done">
                          <CircleCheck className="h-3 w-3" /> {c.status}
                        </span>
                      )}
                      <PresenceBadge online={c.online} lastSeen={c.last_seen} />
                    </div>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-muted">{formatTime(c.created_at)}</td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" onClick={() => navigate(`/reseller/clients/${c.id}`)} title="Gerenciar">
                        <Settings2 className="h-4 w-4" />
                      </Button>
                      {}
                      <Button variant="ghost" onClick={() => onPower(c, 'start')} disabled={power.isPending} title="Iniciar VPS">
                        <Power className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" onClick={() => onPower(c, 'restart')} disabled={power.isPending} title="Reiniciar VPS">
                        <RotateCcw className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" onClick={() => onPower(c, 'stop')} disabled={power.isPending} title="Parar VPS">
                        <PowerOff className="h-4 w-4" />
                      </Button>
                      {c.status === 'suspended' ? (
                        <Button variant="ghost" onClick={() => onAction(c, 'resume')} title="Reativar">
                          <Play className="h-4 w-4" />
                        </Button>
                      ) : (
                        <Button variant="ghost" onClick={() => onAction(c, 'suspend')} title="Suspender">
                          <Pause className="h-4 w-4" />
                        </Button>
                      )}
                      <Button variant="danger" onClick={() => onAction(c, 'delete')} title="Excluir">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Novo cliente">
        <form onSubmit={onSubmit} className="space-y-3">
          <Field label="nome">
            <Input value={name} onChange={(e) => setName(e.target.value)} required maxLength={80} />
          </Field>
          <Field label="email (login do cliente)">
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </Field>
          <Field label="senha (mín. 8)">
            <Input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={8}
              autoComplete="new-password"
            />
          </Field>
          {pkgs.length > 0 && (
            <Field label="pacote (aplica cotas + validade)">
              <select
                value={pkgId}
                onChange={(e) => setPkgId(e.target.value)}
                className="w-full rounded-lg border border-line bg-base px-3 py-2 text-sm text-ink"
              >
                <option value="0">— sem pacote (cotas manuais) —</option>
                {pkgs.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} · {p.cpu_limit}vCPU/{p.ram_limit_mb}MB/{Math.round(p.disk_quota_mb / 1024)}GB
                    {p.duration_days ? ` · ${p.duration_days}d` : ''}
                  </option>
                ))}
              </select>
            </Field>
          )}
          {Number(pkgId) === 0 && (
            <div className="grid grid-cols-3 gap-3">
              <Field label="vCPU">
                <Input type="number" min="1" step="0.5" value={cpu} onChange={(e) => setCpu(e.target.value)} />
              </Field>
              <Field label="RAM (MB)">
                <Input type="number" min="256" step="256" value={ram} onChange={(e) => setRam(e.target.value)} />
              </Field>
              <Field label="Disco (MB)">
                <Input type="number" min="1024" step="1024" value={disk} onChange={(e) => setDisk(e.target.value)} />
              </Field>
            </div>
          )}
          <div className="flex justify-end gap-2 pt-1">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={create.isPending}>
              {create.isPending ? <Spinner /> : 'Criar cliente'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
