import { Outlet } from 'react-router-dom'
import { AppWindow, Boxes, Globe, Info, LayoutDashboard, Server, Users } from 'lucide-react'

import { AppShell } from '../../components/AppShell'
import type { NavGroup } from '../../components/AppShell'


const groups: NavGroup[] = [
  {
    items: [
      { to: '/reseller/dashboard', label: 'Dashboard', icon: <LayoutDashboard className="h-4 w-4" /> },
      { to: '/reseller/minha-vps', label: 'Minha VPS', icon: <Server className="h-4 w-4" /> },
    ],
  },
  {
    label: 'Revenda',
    items: [
      { to: '/reseller/clients', label: 'Clientes', icon: <Users className="h-4 w-4" /> },
      { to: '/reseller/packages', label: 'Pacotes', icon: <Boxes className="h-4 w-4" /> },
      { to: '/reseller/apps', label: 'Apps', icon: <AppWindow className="h-4 w-4" /> },
      { to: '/reseller/site', label: 'Meu site', icon: <Globe className="h-4 w-4" /> },
    ],
  },
  { items: [{ to: '/reseller/about', label: 'Sobre', icon: <Info className="h-4 w-4" /> }] },
]

export function ResellerLayout() {
  return (
    <AppShell groups={groups}>
      <Outlet />
    </AppShell>
  )
}
