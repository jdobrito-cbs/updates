import { Boxes } from 'lucide-react'

import { PackagesPanel } from '../../components/panels/PackagesPanel'
import { PageHeader } from '../../components/ui/PageHeader'


export function ResellerPackagesPage() {
  return (
    <div className="space-y-5">
      <PageHeader
        icon={<Boxes className="h-6 w-6" />}
        title="Pacotes"
        subtitle="Seus planos de cliente — cotas, preço e validade (usados ao criar clientes)"
      />
      <PackagesPanel root="/api/reseller" />
    </div>
  )
}
