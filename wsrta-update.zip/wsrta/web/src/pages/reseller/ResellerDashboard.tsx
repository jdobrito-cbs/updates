import { Link } from 'react-router-dom'
import { CalendarClock, LayoutDashboard, Users } from 'lucide-react'

import { useResellerClients, useResellerProfile } from '../../api/hooks'
import { Card } from '../../components/ui/Card'
import { PageHeader } from '../../components/ui/PageHeader'
import { Spinner } from '../../components/ui/Spinner'

function expiry(s?: string): string {
  if (!s) return 'sem validade'
  const d = new Date(s)
  return Number.isNaN(d.getTime()) ? 'sem validade' : d.toLocaleDateString()
}

export function ResellerDashboard() {
  const me = useResellerProfile()
  const clients = useResellerClients('')

  if (me.isLoading || !me.data) return <Spinner />
  const total = clients.data?.length ?? 0

  return (
    <div className="space-y-5">
      <PageHeader
        icon={<LayoutDashboard className="h-6 w-6" />}
        title={`Olá, ${me.data.name}`}
        subtitle="Painel da revenda — você gerencia apenas os seus clientes"
      />

      <div className="grid gap-4 sm:grid-cols-3">
        <Card className="p-5">
          <div className="flex items-center gap-3">
            <Users className="h-5 w-5 text-accent" />
            <div>
              <p className="text-2xl font-semibold text-ink">{total}</p>
              <p className="text-xs text-faint">clientes</p>
            </div>
          </div>
          <Link to="/reseller/clients" className="mt-3 inline-block text-xs text-accent hover:underline">
            gerenciar clientes →
          </Link>
        </Card>

        <Card className="p-5">
          <div className="flex items-center gap-3">
            <CalendarClock className="h-5 w-5 text-accent" />
            <div>
              <p className="text-lg font-semibold text-ink">{expiry(me.data.expires_at)}</p>
              <p className="text-xs text-faint">validade do plano</p>
            </div>
          </div>
        </Card>

        <Card className="p-5">
          <p className="text-xs text-faint">status</p>
          <p
            className={`mt-1 text-lg font-semibold ${
              me.data.status === 'suspended' ? 'text-failed' : 'text-done'
            }`}
          >
            {me.data.status === 'suspended' ? 'suspenso' : 'ativo'}
          </p>
          <p className="mt-2 text-xs text-faint">{me.data.email}</p>
        </Card>
      </div>

      <p className="text-xs text-faint">
        Seus clientes são isolados: nenhum outro revendedor ou cliente vê os seus, e você não vê os de outras revendas.
      </p>
    </div>
  )
}
