import { useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import {
  AppWindow,
  Archive,
  ArrowLeft,
  Ban,
  Clock,
  Cloud,
  Code2,
  Container,
  Database,
  FolderUp,
  Gauge,
  Globe,
  HardDrive,
  Mail,
  Newspaper,
  Play,
  Trash2,
  Waypoints,
} from 'lucide-react'

import { ApiError } from '../../api/client'
import { useEdition, useResellerClient, useResellerClientAction } from '../../api/hooks'
import { AppsPanel } from '../../components/panels/AppsPanel'
import { BackupPanel } from '../../components/panels/BackupPanel'
import { CloudflarePanel } from '../../components/panels/CloudflarePanel'
import { CronPanel } from '../../components/panels/CronPanel'
import { DatabasesPanel } from '../../components/panels/DatabasesPanel'
import { DBAccessPanel } from '../../components/panels/DBAccessPanel'
import { DnsPanel } from '../../components/panels/DnsPanel'
import { DockerPanel } from '../../components/panels/DockerPanel'
import { DomainsPanel } from '../../components/panels/DomainsPanel'
import { EmailPanel } from '../../components/panels/EmailPanel'
import { FileManager } from '../../components/FileManager'
import { LiberacoesPanel } from '../../components/panels/LiberacoesPanel'
import { RuntimesPanel } from '../../components/panels/RuntimesPanel'
import { SftpPanel } from '../../components/panels/SftpPanel'
import { StatsPanel } from '../../components/panels/StatsPanel'
import { VpsPowerPanel } from '../../components/panels/VpsPowerPanel'
import { WordPressPanel } from '../../components/panels/WordPressPanel'
import { Button } from '../../components/ui/Button'
import { PageHeader } from '../../components/ui/PageHeader'
import { PresenceBadge } from '../../components/ui/PresenceBadge'
import { Spinner } from '../../components/ui/Spinner'
import { StatusBadge } from '../../components/ui/StatusBadge'
import { Tabs } from '../../components/ui/Tabs'
import type { TabItem } from '../../components/ui/Tabs'
import { useConfirm } from '../../components/ui/ConfirmDialog'
import { useToast } from '../../components/ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

const baseTabs: TabItem[] = [
  { key: 'visao', label: 'Visão geral', icon: <Gauge className="h-4 w-4" /> },
  { key: 'dominios', label: 'Domínios', icon: <Globe className="h-4 w-4" /> },
  { key: 'dns', label: 'DNS', icon: <Waypoints className="h-4 w-4" /> },
  { key: 'bancos', label: 'Bancos', icon: <Database className="h-4 w-4" /> },
  { key: 'wordpress', label: 'WordPress', icon: <Newspaper className="h-4 w-4" /> },
  { key: 'linguagens', label: 'Linguagens', icon: <Code2 className="h-4 w-4" /> },
  { key: 'sftp', label: 'SFTP', icon: <FolderUp className="h-4 w-4" /> },
  { key: 'backup', label: 'Backup', icon: <Archive className="h-4 w-4" /> },
  { key: 'cloudflare', label: 'Cloudflare', icon: <Cloud className="h-4 w-4" /> },
  { key: 'arquivos', label: 'Arquivos', icon: <HardDrive className="h-4 w-4" /> },
  { key: 'cron', label: 'Cron', icon: <Clock className="h-4 w-4" /> },
]
const completeTabs: TabItem[] = [
  { key: 'apps', label: 'Apps', icon: <AppWindow className="h-4 w-4" /> },
  { key: 'docker', label: 'Docker', icon: <Container className="h-4 w-4" /> },
  { key: 'email', label: 'E-mail', icon: <Mail className="h-4 w-4" /> },
]



export function ResellerClientDetailPage() {
  const { id } = useParams()
  const clientId = Number(id)
  const { data: client, isLoading } = useResellerClient(clientId)
  const action = useResellerClientAction()
  const edition = useEdition()
  const toast = useToast()
  const confirm = useConfirm()
  const navigate = useNavigate()
  const [tab, setTab] = useState('visao')

  const root = `/api/reseller/clients/${clientId}`

  if (isLoading || !client) return <Spinner />

  const suspended = client.status === 'suspended'

  async function onAction(act: 'suspend' | 'resume' | 'delete') {
    const labels = { suspend: 'Suspender', resume: 'Reativar', delete: 'Excluir' }
    if (act !== 'resume') {
      const ok = await confirm({
        title: `${labels[act]} cliente`,
        message:
          act === 'delete'
            ? `Excluir ${client!.name}? O container e os dados serão removidos. Irreversível.`
            : `Suspender ${client!.name}? Os sites dele ficam fora do ar até reativar.`,
        confirmLabel: labels[act],
        danger: true,
      })
      if (!ok) return
    }
    try {
      await action.mutateAsync({ id: clientId, action: act })
      toast.push('success', act === 'delete' ? 'cliente removido' : act === 'suspend' ? 'cliente suspenso' : 'cliente reativado')
      if (act === 'delete') navigate('/reseller/clients')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  const tabs = edition.data?.complete ? [...baseTabs, ...completeTabs] : baseTabs

  return (
    <div className="space-y-5">
      <PageHeader
        icon={<Gauge className="h-6 w-6" />}
        title={client.name}
        subtitle={client.lxc_container_name}
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge status={client.status} />
            <PresenceBadge online={client.online} lastSeen={client.last_seen} />
            {suspended ? (
              <Button variant="ghost" onClick={() => onAction('resume')}>
                <Play className="h-4 w-4" /> Reativar
              </Button>
            ) : (
              <Button variant="ghost" onClick={() => onAction('suspend')}>
                <Ban className="h-4 w-4" /> Suspender
              </Button>
            )}
            <Button variant="danger" onClick={() => onAction('delete')}>
              <Trash2 className="h-4 w-4" /> Excluir
            </Button>
            <Button variant="ghost" onClick={() => navigate('/reseller/clients')}>
              <ArrowLeft className="h-4 w-4" /> Voltar
            </Button>
          </div>
        }
      />

      <Tabs tabs={tabs} active={tab} onChange={setTab} />

      <div>
        {tab === 'visao' && (
          <div className="space-y-5">
            <StatsPanel root={root} />
            <VpsPowerPanel root={root} label="a VPS deste cliente" />
          </div>
        )}
        {tab === 'dominios' && <DomainsPanel root={root} canManage />}
        {tab === 'dns' && <DnsPanel root={root} />}
        {tab === 'bancos' && (
          <div className="space-y-6">
            <DatabasesPanel root={root} />
            <DBAccessPanel root={root} />
            <LiberacoesPanel root={root} />
          </div>
        )}
        {tab === 'wordpress' && <WordPressPanel root={root} />}
        {tab === 'linguagens' && <RuntimesPanel root={root} canManage />}
        {tab === 'sftp' && <SftpPanel root={root} canManage />}
        {tab === 'backup' && <BackupPanel root={root} />}
        {tab === 'cloudflare' && <CloudflarePanel root={root} asAdmin />}
        {tab === 'arquivos' && <FileManager base={`${root}/files`} />}
        {tab === 'cron' && <CronPanel root={root} />}
        {tab === 'apps' && <AppsPanel root={root} />}
        {tab === 'docker' && <DockerPanel root={root} />}
        {tab === 'email' && <EmailPanel root={root} />}
      </div>
    </div>
  )
}
