import { Navigate, Route, Routes } from 'react-router-dom'

import { useSetupStatus } from './api/hooks'
import { useAuth } from './auth/AuthContext'
import { RequireRole } from './auth/ProtectedRoute'
import { Spinner } from './components/ui/Spinner'
import { LoginPage } from './pages/Login'
import { LandingPage, ResellerLandingPage } from './pages/LandingPage'
import { SetupWizard } from './pages/SetupWizard'
import { AboutPage } from './pages/AboutPage'
import { AdminLayout } from './pages/admin/AdminLayout'
import { DashboardPage } from './pages/admin/Dashboard'
import { ClientsPage } from './pages/admin/ClientsPage'
import { ClientDetailPage } from './pages/admin/ClientDetailPage'
import { ImportPage } from './pages/admin/ImportPage'
import { FilesPage } from './pages/admin/FilesPage'
import { ActionsPage } from './pages/admin/ActionsPage'
import { MonitoringPage } from './pages/admin/MonitoringPage'
import { OSUpdatePage } from './pages/admin/OSUpdatePage'
import { SettingsPage } from './pages/admin/SettingsPage'
import { SecurityEventsPage } from './pages/admin/SecurityEventsPage'
import { SecurityPage } from './pages/admin/SecurityPage'
import { VulnerabilitiesPage } from './pages/admin/VulnerabilitiesPage'
import { AdminsPage } from './pages/admin/AdminsPage'
import { ResellersPage } from './pages/admin/ResellersPage'
import { PackagesPage } from './pages/admin/PackagesPage'
import { PaymentsPage } from './pages/admin/PaymentsPage'
import { AppsPermissionsPage } from './pages/admin/AppsPermissionsPage'
import { ResellerLayout } from './pages/reseller/ResellerLayout'
import { ResellerDashboard } from './pages/reseller/ResellerDashboard'
import { ResellerClientsPage } from './pages/reseller/ResellerClientsPage'
import { ResellerClientDetailPage } from './pages/reseller/ResellerClientDetailPage'
import { ResellerPackagesPage } from './pages/reseller/ResellerPackagesPage'
import { ResellerSitePage } from './pages/reseller/ResellerSitePage'
import { ResellerAppsPage } from './pages/reseller/ResellerAppsPage'
import { SelfVpsArea } from './pages/self/SelfVpsArea'
import { ClientLayout } from './pages/client/ClientLayout'
import {
  ClientAccountPage,
  ClientCronPage,
  ClientDatabasesPage,
  ClientCloudflarePage,
  ClientDomainsPage,
  ClientFilesPage,
  ClientSftpPage,
  ClientWordPressPage,
  ClientRuntimesPage,
  ClientAppsPage,
  ClientDockerPage,
  ClientEmailPage,
  OverviewPage,
} from './pages/client/ClientPages'

export function App() {
  const { ready, token, role } = useAuth()
  const setup = useSetupStatus()

  if (!ready || setup.isLoading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Spinner />
      </div>
    )
  }

  
  if (setup.data?.needs_setup) {
    return <SetupWizard serverIp={setup.data.server_ip} />
  }

  const home = token ? (role === 'admin' ? '/admin' : role === 'reseller' ? '/reseller' : '/client') : '/login'

  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/site" element={<LandingPage />} />{}
      <Route path="/r/:slug" element={<ResellerLandingPage />} />{}

      <Route
        path="/admin"
        element={
          <RequireRole role="admin">
            <AdminLayout />
          </RequireRole>
        }
      >
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<DashboardPage />} />
        <Route path="minha-vps" element={<SelfVpsArea />} />{}
        <Route path="clients" element={<ClientsPage />} />
        <Route path="clients/:id" element={<ClientDetailPage />} />
        <Route path="resellers" element={<ResellersPage />} />{}
        <Route path="packages" element={<PackagesPage />} />{}
        <Route path="payments" element={<PaymentsPage />} />{}
        <Route path="apps" element={<AppsPermissionsPage />} />{}
        <Route path="import" element={<ImportPage />} />
        <Route path="files" element={<FilesPage />} />
        <Route path="queue" element={<ActionsPage />} />
        <Route path="monitoring" element={<MonitoringPage />} />
        <Route path="os-update" element={<OSUpdatePage />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route path="security" element={<SecurityPage />} />
        <Route path="vulnerabilities" element={<VulnerabilitiesPage />} />
        <Route path="security-events" element={<SecurityEventsPage />} />
        <Route path="admins" element={<AdminsPage />} />
        <Route path="about" element={<AboutPage />} />
      </Route>

      <Route
        path="/reseller"
        element={
          <RequireRole role="reseller">
            <ResellerLayout />
          </RequireRole>
        }
      >
        <Route index element={<Navigate to="dashboard" replace />} />
        <Route path="dashboard" element={<ResellerDashboard />} />
        <Route path="minha-vps" element={<SelfVpsArea />} />{}
        <Route path="clients" element={<ResellerClientsPage />} />
        <Route path="clients/:id" element={<ResellerClientDetailPage />} />{}
        <Route path="packages" element={<ResellerPackagesPage />} />
        <Route path="apps" element={<ResellerAppsPage />} />
        <Route path="site" element={<ResellerSitePage />} />
        <Route path="about" element={<AboutPage />} />
      </Route>

      <Route
        path="/client"
        element={
          <RequireRole role="client">
            <ClientLayout />
          </RequireRole>
        }
      >
        <Route index element={<Navigate to="overview" replace />} />
        <Route path="overview" element={<OverviewPage />} />
        <Route path="domains" element={<ClientDomainsPage />} />
        <Route path="databases" element={<ClientDatabasesPage />} />
        <Route path="wordpress" element={<ClientWordPressPage />} />
        <Route path="apps" element={<ClientAppsPage />} />
        <Route path="docker" element={<ClientDockerPage />} />
        <Route path="email" element={<ClientEmailPage />} />
        <Route path="runtimes" element={<ClientRuntimesPage />} />
        <Route path="sftp" element={<ClientSftpPage />} />
        <Route path="cloudflare" element={<ClientCloudflarePage />} />
        <Route path="files" element={<ClientFilesPage />} />
        <Route path="cron" element={<ClientCronPage />} />
        <Route path="account" element={<ClientAccountPage />} />
        <Route path="about" element={<AboutPage />} />
      </Route>

      <Route path="*" element={<Navigate to={home} replace />} />
    </Routes>
  )
}
