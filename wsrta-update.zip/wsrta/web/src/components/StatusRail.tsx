import { useActions } from '../api/hooks'
import type { Action, ActionStatusValue } from '../api/types'
import { cn } from '../lib/cn'



const ORDER: ActionStatusValue[] = ['running', 'pending', 'done', 'failed']

const TEXT: Record<ActionStatusValue, string> = {
  running: 'text-running',
  pending: 'text-pending',
  done: 'text-done',
  failed: 'text-failed',
}
const DOT: Record<ActionStatusValue, string> = {
  running: 'bg-running',
  pending: 'bg-pending',
  done: 'bg-done',
  failed: 'bg-failed',
}

export function StatusRail() {
  const { data } = useActions()
  const actions = data ?? []
  const counts = countByStatus(actions)
  const running = actions.find((a) => a.status === 'running')

  return (
    <div className="flex items-center gap-5 border-b border-line bg-panel/60 px-5 py-2 font-mono text-xs">
      <span className="text-faint">fila</span>
      {ORDER.map((s) => (
        <span key={s} className={cn('flex items-center gap-1.5', TEXT[s])}>
          <span
            className={cn(
              'h-2 w-2 rounded-full',
              DOT[s],
              s === 'running' && counts.running > 0 && 'animate-pulsering',
            )}
          />
          {counts[s]} {s}
        </span>
      ))}
      <span className="ml-auto min-w-0 truncate text-muted">
        {running ? (
          <>
            processando <span className="text-running">{running.type}</span> #{running.id}
            {running.progress > 0 && <span className="text-running"> · {running.progress}%</span>}
            {running.progress_stage && <span className="text-faint"> · {running.progress_stage}</span>}
          </>
        ) : (
          <span className="text-faint">ociosa</span>
        )}
      </span>
    </div>
  )
}

function countByStatus(actions: Action[]): Record<ActionStatusValue, number> {
  const c: Record<ActionStatusValue, number> = { running: 0, pending: 0, done: 0, failed: 0 }
  for (const a of actions) c[a.status]++
  return c
}
