import { useActions } from '../api/hooks'
import { ProgressBar } from './ui/ProgressBar'
import { StatusBadge } from './ui/StatusBadge'



export function ActionStatus({ actionId }: { actionId: number }) {
  const { data } = useActions()
  const action = (data ?? []).find((a) => a.id === actionId)

  if (!action) {
    return <span className="font-mono text-xs text-faint">ação #{actionId}…</span>
  }
  return (
    <span className="inline-flex items-center gap-2">
      <span className="font-mono text-xs text-faint">#{action.id}</span>
      <StatusBadge status={action.status} />
      {action.status === 'running' && action.progress > 0 && (
        <ProgressBar pct={action.progress} stage={action.progress_stage} className="w-44" />
      )}
      {action.status === 'failed' && action.result && (
        <span className="text-xs text-failed">{action.result}</span>
      )}
    </span>
  )
}
