import { formatTime } from '../../lib/format'



export function PresenceBadge({ online, lastSeen }: { online: boolean; lastSeen?: string }) {
  const title = online ? 'Online agora' : lastSeen ? `Visto por último: ${formatTime(lastSeen)}` : 'Nunca acessou'
  return (
    <span
      title={title}
      className={`inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-medium ${
        online ? 'bg-done/15 text-done' : 'bg-elevated text-faint'
      }`}
    >
      <span className={`h-2 w-2 rounded-full ${online ? 'bg-done' : 'bg-faint/60'}`} />
      {online ? 'online' : 'offline'}
    </span>
  )
}
