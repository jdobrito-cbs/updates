import { useEffect } from 'react'
import type { ReactNode } from 'react'
import { createPortal } from 'react-dom'

import { cn } from '../../lib/cn'




export function Modal({
  open,
  onClose,
  title,
  children,
  className,
}: {
  open: boolean
  onClose: () => void
  title?: string
  children: ReactNode
  className?: string
}) {
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [open, onClose])

  if (!open) return null

  return createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onMouseDown={onClose}>
      <div className="absolute inset-0 bg-base/70 backdrop-blur-sm" aria-hidden="true" />
      <div
        role="dialog"
        aria-modal="true"
        onMouseDown={(e) => e.stopPropagation()}
        className={cn(
          
          
          'relative flex max-h-[90dvh] w-full max-w-md flex-col rounded-xl border border-line bg-panel shadow-2xl',
          className,
        )}
      >
        {title && (
          <div className="flex flex-none items-center justify-between border-b border-line px-5 py-4">
            <h2 className="font-display text-lg text-ink">{title}</h2>
            <button onClick={onClose} className="text-muted hover:text-ink" aria-label="fechar">
              ✕
            </button>
          </div>
        )}
        {}
        <div className="min-h-0 overflow-y-auto p-5">{children}</div>
      </div>
    </div>,
    document.body,
  )
}
