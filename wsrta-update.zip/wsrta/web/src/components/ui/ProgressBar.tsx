import { cn } from '../../lib/cn'



export function ProgressBar({
  pct,
  stage,
  className,
}: {
  pct: number
  stage?: string
  className?: string
}) {
  const v = Math.max(0, Math.min(100, Math.round(pct)))
  return (
    <div className={cn('min-w-[8rem]', className)}>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-line/60">
        <div
          className="h-full rounded-full bg-running transition-all duration-500"
          style={{ width: `${v}%` }}
        />
      </div>
      {stage && (
        <div className="mt-1 flex justify-between gap-2 font-mono text-[10px] text-faint">
          <span className="truncate">{stage}</span>
          <span className="flex-none tabular-nums">{v}%</span>
        </div>
      )}
    </div>
  )
}
