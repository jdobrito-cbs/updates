import type { ButtonHTMLAttributes } from 'react'

import { cn } from '../../lib/cn'

type Variant = 'primary' | 'ghost' | 'danger'

const variants: Record<Variant, string> = {
  
  primary:
    'border-transparent bg-gradient-to-br from-accent to-accentStrong text-onAccent shadow-sm hover:brightness-110',
  ghost: 'border-line bg-transparent text-muted hover:bg-elevated hover:text-ink hover:border-faint',
  danger: 'border-failed/30 bg-failed/10 text-failed hover:bg-failed/20',
}

export function Button({
  variant = 'primary',
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  return (
    <button
      className={cn(
        'inline-flex items-center justify-center gap-2 rounded-lg border px-3.5 py-2 text-sm font-semibold transition-all active:translate-y-px disabled:pointer-events-none disabled:opacity-50',
        variants[variant],
        className,
      )}
      {...props}
    />
  )
}
