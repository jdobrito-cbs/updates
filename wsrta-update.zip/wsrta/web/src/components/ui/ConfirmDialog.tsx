import { createContext, useCallback, useContext, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { AlertTriangle, HelpCircle } from 'lucide-react'

import { Button } from './Button'
import { Modal } from './Modal'

export interface ConfirmOptions {
  title: string
  message?: ReactNode
  confirmLabel?: string
  cancelLabel?: string
  danger?: boolean
}

type ConfirmFn = (opts: ConfirmOptions) => Promise<boolean>

const ConfirmContext = createContext<ConfirmFn | null>(null)

type State = ConfirmOptions & { open: boolean }



export function ConfirmProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<State>({ open: false, title: '' })
  const resolver = useRef<((v: boolean) => void) | null>(null)

  const confirm = useCallback<ConfirmFn>((opts) => {
    return new Promise<boolean>((resolve) => {
      resolver.current = resolve
      setState({ ...opts, open: true })
    })
  }, [])

  const settle = useCallback((result: boolean) => {
    setState((s) => ({ ...s, open: false }))
    resolver.current?.(result)
    resolver.current = null
  }, [])

  return (
    <ConfirmContext.Provider value={confirm}>
      {children}
      <Modal open={state.open} onClose={() => settle(false)} className="max-w-sm">
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <span
              className={
                state.danger
                  ? 'mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-failed/15 text-failed'
                  : 'mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent/15 text-accent'
              }
            >
              {state.danger ? <AlertTriangle className="h-5 w-5" /> : <HelpCircle className="h-5 w-5" />}
            </span>
            <div className="space-y-1 pt-0.5">
              <h2 className="font-display text-lg leading-tight text-ink">{state.title}</h2>
              {state.message && <p className="text-sm text-muted">{state.message}</p>}
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => settle(false)}>
              {state.cancelLabel ?? 'Cancelar'}
            </Button>
            <Button variant={state.danger ? 'danger' : 'primary'} onClick={() => settle(true)} autoFocus>
              {state.confirmLabel ?? 'Confirmar'}
            </Button>
          </div>
        </div>
      </Modal>
    </ConfirmContext.Provider>
  )
}

export function useConfirm(): ConfirmFn {
  const ctx = useContext(ConfirmContext)
  if (!ctx) throw new Error('useConfirm deve ser usado dentro de ConfirmProvider')
  return ctx
}
