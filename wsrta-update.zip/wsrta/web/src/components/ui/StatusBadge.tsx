import { cn } from '../../lib/cn'

function colorFor(status: string): { dot: string; text: string } {
  switch (status) {
    case 'running':
    case 'provisioning':
    case 'deprovisioning':
      return { dot: 'bg-running', text: 'text-running' }
    case 'done':
    case 'active':
      return { dot: 'bg-done', text: 'text-done' }
    case 'failed':
      return { dot: 'bg-failed', text: 'text-failed' }
    case 'suspended':
    case 'deleted':
      return { dot: 'bg-muted', text: 'text-muted' }
    case 'pending':
    default:
      return { dot: 'bg-pending', text: 'text-pending' }
  }
}

const PULSE = new Set(['running', 'provisioning', 'deprovisioning'])

export function StatusBadge({ status }: { status: string }) {
  const c = colorFor(status)
  return (
    <span className="inline-flex items-center gap-1.5 font-mono text-xs">
      <span className={cn('h-2 w-2 rounded-full', c.dot, PULSE.has(status) && 'animate-pulsering')} />
      <span className={c.text}>{status}</span>
    </span>
  )
}
