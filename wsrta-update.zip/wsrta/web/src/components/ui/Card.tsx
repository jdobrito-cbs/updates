import type { ReactNode } from 'react'

import { cn } from '../../lib/cn'

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <div
      className={cn(
        'rounded-xl border border-line bg-panel shadow-sm shadow-black/10 transition-colors',
        className,
      )}
    >
      {children}
    </div>
  )
}
