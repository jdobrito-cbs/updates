import { createContext, useCallback, useContext, useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import type { QueryKey } from '@tanstack/react-query'
import { UploadCloud, X } from 'lucide-react'

import { ApiError, uploadWithProgress } from '../api/client'
import { cn } from '../lib/cn'
import { useToast } from './ui/Toast'

type UploadState = { label: string; pct: number; status: 'uploading' | 'done' | 'error' } | null

interface StartOpts {
  path: string
  file: File
  field?: string 
  label?: string 
  invalidate?: QueryKey 
  onDone?: (name: string) => void
}

const UploadCtx = createContext<{ upload: UploadState; startUpload: (o: StartOpts) => Promise<void> } | null>(
  null,
)




export function UploadProvider({ children }: { children: ReactNode }) {
  const [upload, setUpload] = useState<UploadState>(null)
  const qc = useQueryClient()
  const toast = useToast()

  const startUpload = useCallback(
    async (o: StartOpts) => {
      const label = o.label ?? o.file.name
      const form = new FormData()
      form.append(o.field ?? 'file', o.file)
      setUpload({ label, pct: 0, status: 'uploading' })
      try {
        const res = await uploadWithProgress<{ name: string }>(o.path, form, (pct) =>
          setUpload((u) => (u && u.status === 'uploading' ? { ...u, pct } : u)),
        )
        setUpload({ label, pct: 100, status: 'done' })
        if (o.invalidate) qc.invalidateQueries({ queryKey: o.invalidate })
        toast.push('success', `"${label}" enviado`)
        o.onDone?.(res?.name ?? label)
      } catch (err) {
        setUpload({ label, pct: 0, status: 'error' })
        toast.push('error', err instanceof ApiError ? err.message : 'falha no upload')
      }
    },
    [qc, toast],
  )

  return (
    <UploadCtx.Provider value={{ upload, startUpload }}>
      {children}
      <GlobalUploadIndicator upload={upload} onClose={() => setUpload(null)} />
    </UploadCtx.Provider>
  )
}

function GlobalUploadIndicator({ upload, onClose }: { upload: UploadState; onClose: () => void }) {
  
  useEffect(() => {
    if (upload?.status !== 'done') return
    const t = setTimeout(onClose, 6000)
    return () => clearTimeout(t)
  }, [upload?.status, onClose])

  if (!upload) return null
  const { status, pct, label } = upload
  const done = status === 'done'
  const error = status === 'error'
  return (
    <div className="fixed bottom-4 right-4 z-[60] w-80 max-w-[calc(100vw-2rem)] rounded-xl border border-line bg-panel p-4 shadow-2xl">
      <div className="mb-2 flex items-center gap-2">
        <UploadCloud
          className={cn('h-4 w-4 flex-none', error ? 'text-failed' : done ? 'text-done' : 'text-running')}
        />
        <span className="min-w-0 flex-1 truncate text-sm font-medium text-ink" title={label}>
          {label}
        </span>
        {(done || error) && (
          <button onClick={onClose} className="flex-none text-muted hover:text-ink" aria-label="fechar">
            <X className="h-4 w-4" />
          </button>
        )}
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-line/60">
        <div
          className={cn(
            'h-full rounded-full transition-all duration-300',
            error ? 'bg-failed' : done ? 'bg-done' : 'bg-running',
          )}
          style={{ width: `${done ? 100 : pct}%` }}
        />
      </div>
      <div className="mt-1 flex justify-between font-mono text-[10px] text-faint">
        <span>{error ? 'falhou' : done ? 'concluído' : 'enviando… (não feche o navegador)'}</span>
        <span className="tabular-nums">{done ? 100 : pct}%</span>
      </div>
    </div>
  )
}

export function useUpload() {
  const ctx = useContext(UploadCtx)
  if (!ctx) throw new Error('useUpload deve ser usado dentro de UploadProvider')
  return ctx
}
