import type { ReactNode } from 'react'
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts'

import { Card } from '../ui/Card'


export const C = {
  accent: '#63B3ED',
  accent2: '#818CF8',
  running: '#E0A33E',
  done: '#4FB477',
  failed: '#E5604D',
  pending: '#7C8AA0',
  line: '#2A2F38',
  faint: '#69707C',
  ink: '#E6E8EC',
  track: '#262B33',
}

const tooltipStyle = {
  background: '#1B1E24',
  border: '1px solid #2A2F38',
  borderRadius: 8,
  color: '#E6E8EC',
  fontSize: 12,
}


export function BarCard({
  title,
  data,
  dataKey,
  color,
}: {
  title: string
  data: { name: string; [k: string]: number | string }[]
  dataKey: string
  color: string
}) {
  return (
    <Card className="p-4">
      <h3 className="mb-3 text-sm font-medium text-ink">{title}</h3>
      {data.length === 0 ? (
        <p className="py-10 text-center text-sm text-muted">sem dados</p>
      ) : (
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={data} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
            <CartesianGrid stroke={C.line} vertical={false} />
            <XAxis dataKey="name" tick={{ fill: C.faint, fontSize: 11 }} interval={0} angle={-15} textAnchor="end" height={48} />
            <YAxis allowDecimals={false} tick={{ fill: C.faint, fontSize: 11 }} />
            <Tooltip cursor={{ fill: '#ffffff10' }} contentStyle={tooltipStyle} />
            <Bar dataKey={dataKey} fill={color} radius={[3, 3, 0, 0]} maxBarSize={48} />
          </BarChart>
        </ResponsiveContainer>
      )}
    </Card>
  )
}


export function DonutGauge({
  label,
  value,
  color,
  detail,
}: {
  label: string
  value: number
  color: string
  detail?: ReactNode
}) {
  const v = Math.max(0, Math.min(100, value))
  const data = [
    { name: 'used', value: v },
    { name: 'free', value: 100 - v },
  ]
  return (
    <Card className="flex flex-col items-center p-4">
      <h3 className="mb-1 text-xs uppercase tracking-wide text-faint">{label}</h3>
      <div className="relative">
        <ResponsiveContainer width={140} height={140}>
          <PieChart>
            <Pie
              data={data}
              dataKey="value"
              innerRadius={48}
              outerRadius={64}
              startAngle={90}
              endAngle={-270}
              stroke="none"
              isAnimationActive={false}
            >
              <Cell fill={color} />
              <Cell fill={C.track} />
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <span className="font-display text-xl text-ink">{v.toFixed(0)}%</span>
        </div>
      </div>
      {detail && <div className="mt-1 w-full px-1 text-center text-xs text-muted">{detail}</div>}
    </Card>
  )
}


export function RealtimeLine({
  title,
  data,
  series,
  unit,
  domainMax,
  height = 200,
}: {
  title: string
  data: Record<string, number | string>[]
  series: { key: string; color: string; label: string }[]
  unit?: string
  domainMax?: number
  height?: number
}) {
  return (
    <Card className="p-4">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-sm font-medium text-ink">{title}</h3>
        <div className="flex gap-3 text-xs text-muted">
          {series.map((s) => (
            <span key={s.key} className="flex items-center gap-1">
              <span className="inline-block h-2 w-2 rounded-full" style={{ background: s.color }} /> {s.label}
            </span>
          ))}
        </div>
      </div>
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={data} margin={{ top: 4, right: 8, left: -16, bottom: 0 }}>
          <CartesianGrid stroke={C.line} vertical={false} />
          <XAxis dataKey="t" tick={{ fill: C.faint, fontSize: 10 }} minTickGap={28} />
          <YAxis
            domain={[0, domainMax ?? 'auto']}
            tick={{ fill: C.faint, fontSize: 10 }}
            unit={unit}
            width={44}
          />
          <Tooltip contentStyle={tooltipStyle} />
          {series.map((s) => (
            <Line
              key={s.key}
              type="monotone"
              dataKey={s.key}
              stroke={s.color}
              strokeWidth={2}
              dot={false}
              isAnimationActive={false}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </Card>
  )
}
