import type { ReactNode } from 'react'
import { Link } from 'react-router-dom'
import {
  AppWindow,
  Clock,
  Cloud,
  Code2,
  Container,
  Database,
  FolderUp,
  Globe,
  HardDrive,
  Mail,
  Newspaper,
} from 'lucide-react'

type Tile = { to: string; label: string; icon: ReactNode; complete?: boolean }
type Section = { title: string; tiles: Tile[] }



const SECTIONS: Section[] = [
  {
    title: 'Hospedagem',
    tiles: [
      { to: '/client/domains', label: 'Domínios', icon: <Globe className="h-5 w-5" /> },
      { to: '/client/wordpress', label: 'WordPress', icon: <Newspaper className="h-5 w-5" /> },
      { to: '/client/apps', label: 'Apps', icon: <AppWindow className="h-5 w-5" />, complete: true },
      { to: '/client/docker', label: 'Docker', icon: <Container className="h-5 w-5" />, complete: true },
    ],
  },
  {
    title: 'E-mail',
    tiles: [{ to: '/client/email', label: 'Caixas de e-mail', icon: <Mail className="h-5 w-5" />, complete: true }],
  },
  {
    title: 'Bancos de dados',
    tiles: [{ to: '/client/databases', label: 'Bancos', icon: <Database className="h-5 w-5" /> }],
  },
  {
    title: 'Arquivos',
    tiles: [
      { to: '/client/files', label: 'Gerenciador', icon: <HardDrive className="h-5 w-5" /> },
      { to: '/client/sftp', label: 'SFTP', icon: <FolderUp className="h-5 w-5" /> },
    ],
  },
  {
    title: 'Avançado',
    tiles: [
      { to: '/client/cron', label: 'Cron', icon: <Clock className="h-5 w-5" /> },
      { to: '/client/runtimes', label: 'Linguagens', icon: <Code2 className="h-5 w-5" /> },
      { to: '/client/cloudflare', label: 'Cloudflare', icon: <Cloud className="h-5 w-5" /> },
    ],
  },
]

export function FeatureGrid({ complete }: { complete: boolean }) {
  const sections = SECTIONS.map((s) => ({ ...s, tiles: s.tiles.filter((t) => !t.complete || complete) })).filter(
    (s) => s.tiles.length > 0,
  )
  return (
    <div className="space-y-5">
      {sections.map((s) => (
        <div key={s.title}>
          <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-faint">{s.title}</h3>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {s.tiles.map((t) => (
              <Link
                key={t.to}
                to={t.to}
                className="group flex items-center gap-3 rounded-xl border border-line bg-panel p-4 transition hover:border-accent/50 hover:bg-elevated"
              >
                <span className="flex h-10 w-10 flex-none items-center justify-center rounded-lg bg-accent/10 text-accent transition group-hover:bg-accent/20">
                  {t.icon}
                </span>
                <span className="text-sm font-medium text-ink">{t.label}</span>
              </Link>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}
