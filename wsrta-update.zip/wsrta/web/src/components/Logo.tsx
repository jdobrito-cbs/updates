


export function Logo({ size = 36, className = '' }: { size?: number; className?: string }) {
  return (
    <span className={`wsrta-logo ${className}`} style={{ display: 'inline-flex', lineHeight: 0 }}>
      <svg width={size} height={size} viewBox="0 0 48 48" fill="none" role="img" aria-label="WSRTA">
        <defs>
          <linearGradient id="wsrtaBadge" x1="7" y1="5" x2="41" y2="43" gradientUnits="userSpaceOnUse">
            <stop stopColor="#7CC4F7" />
            <stop offset="0.55" stopColor="#63B3ED" />
            <stop offset="1" stopColor="#818CF8" />
          </linearGradient>
          <radialGradient
            id="wsrtaShine"
            cx="0"
            cy="0"
            r="1"
            gradientUnits="userSpaceOnUse"
            gradientTransform="translate(13 9) rotate(55) scale(42)"
          >
            <stop stopColor="#ffffff" stopOpacity="0.42" />
            <stop offset="1" stopColor="#ffffff" stopOpacity="0" />
          </radialGradient>
        </defs>

        {}
        <rect x="2" y="2" width="44" height="44" rx="14" fill="url(#wsrtaBadge)" />
        <rect x="2" y="2" width="44" height="44" rx="14" fill="url(#wsrtaShine)" />
        <rect x="2.5" y="2.5" width="43" height="43" rx="13.5" stroke="#ffffff" strokeOpacity="0.22" />

        {}
        <path
          d="M13 16 L18.5 32 L24 23 L29.5 32 L35 16"
          transform="translate(0 1)"
          stroke="#2A2F6A"
          strokeOpacity="0.35"
          strokeWidth="4.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {}
        <path
          d="M13 16 L18.5 32 L24 23 L29.5 32 L35 16"
          stroke="#ffffff"
          strokeWidth="4.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {}
        <circle className="wsrta-node" cx="24" cy="22.4" r="3.7" fill="#ffffff" />
        <circle className="wsrta-core" cx="24" cy="22.4" r="1.7" fill="#818CF8" />
      </svg>
    </span>
  )
}
