import { useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { NavLink } from 'react-router-dom'
import { ChevronLeft, ChevronRight, LogOut, Menu, Moon, Sun, X } from 'lucide-react'

import { useBranding } from '../api/hooks'
import { useAuth } from '../auth/AuthContext'
import { Logo } from './Logo'
import { cn } from '../lib/cn'
import { getTheme, toggleTheme } from '../lib/theme'
import type { Theme } from '../lib/theme'

export interface NavEntry {
  to: string
  label: string
  icon?: ReactNode
}
export interface NavGroup {
  label?: string
  items: NavEntry[]
}


const DESK = 1100

export function AppShell({
  groups,
  rail,
  children,
}: {
  groups: NavGroup[]
  rail?: ReactNode
  children: ReactNode
}) {
  const { logout } = useAuth()
  const company = useBranding().data?.company_name ?? ''
  const [drawer, setDrawer] = useState(false)

  
  useEffect(() => {
    document.title = company ? `WSRTA · ${company}` : 'WSRTA · Painel'
  }, [company])
  const [collapsed, setCollapsed] = useState(() => {
    try {
      return localStorage.getItem('wsrta-sb') === '1'
    } catch {
      return false
    }
  })
  const [theme, setThemeState] = useState<Theme>(() => getTheme())
  const [openGroups, setOpenGroups] = useState<Record<number, boolean>>(() =>
    Object.fromEntries(groups.map((_, i) => [i, true])),
  )

  
  useEffect(() => {
    const onResize = () => {
      if (window.innerWidth >= DESK) setDrawer(false)
    }
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  function toggleCollapse() {
    setCollapsed((c) => {
      const n = !c
      try {
        localStorage.setItem('wsrta-sb', n ? '1' : '0')
      } catch {
        
      }
      return n
    })
  }

  return (
    <div className="flex h-full">
      {}
      <div
        onClick={() => setDrawer(false)}
        aria-hidden="true"
        className={cn(
          'fixed inset-0 z-40 bg-black/55 backdrop-blur-sm transition-opacity duration-200 desk:hidden',
          drawer ? 'opacity-100' : 'pointer-events-none opacity-0',
        )}
      />

      {}
      <aside
        aria-label="Menu principal"
        className={cn(
          'fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-line bg-panel transition-[transform,width] duration-300 ease-out',
          'desk:sticky desk:top-0 desk:h-screen desk:translate-x-0',
          drawer ? 'translate-x-0 shadow-2xl' : '-translate-x-full',
          collapsed ? 'desk:w-[76px]' : 'desk:w-64',
        )}
      >
        <div className={cn('flex items-center gap-2.5 px-5 py-4', collapsed && 'desk:justify-center desk:px-0')}>
          <Logo size={38} className="flex-none" />
          <div className={cn('flex min-w-0 items-baseline gap-1.5', collapsed && 'desk:hidden')}>
            <span className="font-display text-lg tracking-tight text-ink">wsrta</span>
            {company && <span className="min-w-0 truncate text-xs font-medium text-muted">{company}</span>}
          </div>
          <button
            onClick={() => setDrawer(false)}
            className="ml-auto rounded-md p-1 text-muted hover:text-ink desk:hidden"
            aria-label="Fechar menu"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 pb-3">
          {groups.map((g, gi) => (
            <div key={gi} className="mb-1">
              {g.label && (
                <button
                  onClick={() => setOpenGroups((s) => ({ ...s, [gi]: !s[gi] }))}
                  aria-expanded={openGroups[gi]}
                  className={cn(
                    'flex w-full items-center justify-between rounded px-3 pb-1 pt-3 text-[0.68rem] font-bold uppercase tracking-wider text-faint',
                    collapsed && 'desk:justify-center',
                  )}
                >
                  <span className={cn(collapsed && 'desk:hidden')}>{g.label}</span>
                  <ChevronRight
                    className={cn('h-3 w-3 transition-transform', openGroups[gi] && 'rotate-90', collapsed && 'desk:hidden')}
                  />
                </button>
              )}
              <div
                className={cn(
                  'grid gap-0.5 overflow-hidden transition-all duration-300',
                  openGroups[gi] ? 'max-h-[640px] opacity-100' : 'max-h-0 opacity-0',
                )}
              >
                {g.items.map((n) => (
                  <NavLink
                    key={n.to}
                    to={n.to}
                    title={n.label}
                    onClick={() => setDrawer(false)}
                    className={({ isActive }) =>
                      cn(
                        'flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-colors',
                        collapsed && 'desk:justify-center desk:px-0',
                        isActive
                          ? 'border border-accent/30 bg-accent/15 text-accent'
                          : 'border border-transparent text-muted hover:bg-elevated hover:text-ink',
                      )
                    }
                  >
                    <span className="flex-none">{n.icon}</span>
                    <span className={cn(collapsed && 'desk:hidden')}>{n.label}</span>
                  </NavLink>
                ))}
              </div>
            </div>
          ))}
        </nav>

        <div className="mt-auto flex flex-col gap-1 p-3">
          <button
            onClick={toggleCollapse}
            aria-label={collapsed ? 'Expandir menu' : 'Recolher menu'}
            className={cn(
              'hidden items-center gap-2.5 rounded-md border border-line bg-elevated px-3 py-2 text-sm text-muted hover:text-ink desk:flex',
              collapsed && 'desk:justify-center',
            )}
          >
            {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
            <span className={cn(collapsed && 'desk:hidden')}>Recolher</span>
          </button>
          <button
            onClick={logout}
            className={cn(
              'flex items-center gap-2.5 rounded-md px-3 py-2 text-sm text-muted hover:bg-elevated hover:text-ink',
              collapsed && 'desk:justify-center',
            )}
            aria-label="Sair"
          >
            <LogOut className="h-4 w-4" />
            <span className={cn(collapsed && 'desk:hidden')}>Sair</span>
          </button>
        </div>
      </aside>

      {}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-16 flex-none items-center gap-3 border-b border-line bg-base/80 px-4 backdrop-blur md:px-6">
          <button
            onClick={() => setDrawer(true)}
            className="grid h-10 w-10 flex-none place-items-center rounded-lg border border-line text-muted hover:text-ink desk:hidden"
            aria-label="Abrir menu"
            aria-expanded={drawer}
          >
            <Menu className="h-5 w-5" />
          </button>
          <span className="font-display text-ink desk:hidden">wsrta</span>
          <div className="ml-auto flex items-center gap-2">
            <span
              className="flex items-center gap-1.5 rounded-full bg-done/15 px-2.5 py-1 text-xs font-medium text-done"
              title="Você está online"
            >
              <span className="h-2 w-2 animate-pulse rounded-full bg-done" />
              online
            </span>
            <button
              onClick={() => setThemeState(toggleTheme())}
              className="grid h-10 w-10 flex-none place-items-center rounded-lg border border-line text-muted hover:text-ink"
              aria-label="Alternar tema claro/escuro"
              aria-pressed={theme === 'light'}
            >
              {theme === 'dark' ? <Sun className="h-[18px] w-[18px]" /> : <Moon className="h-[18px] w-[18px]" />}
            </button>
          </div>
        </header>
        {rail}
        <main className="flex-1 overflow-auto p-4 md:p-6">{children}</main>
      </div>
    </div>
  )
}
