import { useState } from 'react'
import type { FormEvent } from 'react'
import { Boxes, Pencil, Plus, Trash2 } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useCreatePackage, useDeletePackage, usePackages, useUpdatePackage } from '../../api/resources'
import type { Package, PackageInput } from '../../api/resources'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { useConfirm } from '../ui/ConfirmDialog'
import { EmptyState } from '../ui/EmptyState'
import { Field } from '../ui/Field'
import { Input } from '../ui/Input'
import { Modal } from '../ui/Modal'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')
const brl = (cents: number) => (cents / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })

const empty = {
  name: '',
  price: '0',
  cpu: '1',
  ram: '1024',
  disk: '10240',
  domains: '0',
  databases: '0',
  mailboxes: '0',
  bandwidth: '0',
  duration: '30',
}



export function PackagesPanel({ root }: { root: string }) {
  const { data, isLoading } = usePackages(root)
  const create = useCreatePackage(root)
  const update = useUpdatePackage(root)
  const del = useDeletePackage(root)
  const toast = useToast()
  const confirm = useConfirm()

  const [editId, setEditId] = useState<number | null>(null)
  const [open, setOpen] = useState(false)
  const [f, setF] = useState({ ...empty })

  const list = data ?? []
  const set = (k: keyof typeof empty) => (e: { target: { value: string } }) => setF((s) => ({ ...s, [k]: e.target.value }))

  function openCreate() {
    setEditId(null)
    setF({ ...empty })
    setOpen(true)
  }
  function openEdit(p: Package) {
    setEditId(p.id)
    setF({
      name: p.name,
      price: String(p.price_cents / 100),
      cpu: String(p.cpu_limit),
      ram: String(p.ram_limit_mb),
      disk: String(p.disk_quota_mb),
      domains: String(p.max_domains),
      databases: String(p.max_databases),
      mailboxes: String(p.max_mailboxes ?? 0),
      bandwidth: String(p.bandwidth_limit_mb),
      duration: String(p.duration_days),
    })
    setOpen(true)
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    const body: PackageInput = {
      name: f.name.trim(),
      price_cents: Math.round((Number(f.price) || 0) * 100),
      cpu_limit: Number(f.cpu) || 1,
      ram_limit_mb: Number(f.ram) || 1024,
      disk_quota_mb: Number(f.disk) || 10240,
      max_domains: Number(f.domains) || 0,
      max_databases: Number(f.databases) || 0,
      max_mailboxes: Number(f.mailboxes) || 0,
      bandwidth_limit_mb: Number(f.bandwidth) || 0,
      duration_days: Number(f.duration) || 0,
    }
    try {
      if (editId) await update.mutateAsync({ id: editId, ...body })
      else await create.mutateAsync(body)
      toast.push('success', editId ? 'pacote atualizado' : 'pacote criado')
      setOpen(false)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onDelete(p: Package) {
    if (!(await confirm({ title: 'Excluir pacote', message: `Excluir "${p.name}"? Clientes atuais não são afetados.`, confirmLabel: 'Excluir', danger: true })))
      return
    try {
      await del.mutateAsync(p.id)
      toast.push('success', 'pacote excluído')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="flex items-center gap-2 text-sm font-medium text-ink">
          <Boxes className="h-4 w-4 text-accent" /> Pacotes ({list.length})
        </h3>
        <Button onClick={openCreate}>
          <Plus className="h-4 w-4" /> Novo pacote
        </Button>
      </div>

      {isLoading && <Spinner />}
      {!isLoading && list.length === 0 && (
        <EmptyState title="Nenhum pacote" hint="Crie planos com cotas, preço e validade para agilizar o cadastro de clientes." action={<Button onClick={openCreate}>+ Novo pacote</Button>} />
      )}

      {list.length > 0 && (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((p) => (
            <Card key={p.id} className="space-y-2 p-4">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="truncate font-medium text-ink">{p.name}</p>
                  <p className="text-lg font-semibold text-accent">{brl(p.price_cents)}</p>
                </div>
                <div className="flex flex-none gap-1">
                  <button onClick={() => openEdit(p)} title="Editar" className="rounded p-1 text-muted hover:bg-line hover:text-ink">
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button onClick={() => onDelete(p)} title="Excluir" className="rounded p-1 text-muted hover:bg-failed/15 hover:text-failed">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
              <ul className="space-y-0.5 text-xs text-muted">
                <li>{p.cpu_limit} vCPU · {p.ram_limit_mb} MB RAM · {Math.round(p.disk_quota_mb / 1024)} GB disco</li>
                <li>{p.max_domains || '∞'} domínios · {p.max_databases || '∞'} bancos</li>
                <li>banda: {p.bandwidth_limit_mb ? `${p.bandwidth_limit_mb} MB/mês` : 'ilimitada'}</li>
                <li>validade: {p.duration_days ? `${p.duration_days} dias` : 'sem validade'}</li>
              </ul>
            </Card>
          ))}
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title={editId ? 'Editar pacote' : 'Novo pacote'} className="max-w-lg">
        <form onSubmit={onSubmit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <Field label="nome">
              <Input value={f.name} onChange={set('name')} required maxLength={60} />
            </Field>
            <Field label="preço (R$)">
              <Input type="number" min="0" step="0.01" value={f.price} onChange={set('price')} />
            </Field>
            <Field label="vCPU">
              <Input type="number" min="0.5" step="0.5" value={f.cpu} onChange={set('cpu')} />
            </Field>
            <Field label="RAM (MB)">
              <Input type="number" min="256" step="256" value={f.ram} onChange={set('ram')} />
            </Field>
            <Field label="Disco (MB)">
              <Input type="number" min="1024" step="1024" value={f.disk} onChange={set('disk')} />
            </Field>
            <Field label="Banda (MB/mês, 0=∞)">
              <Input type="number" min="0" step="1024" value={f.bandwidth} onChange={set('bandwidth')} />
            </Field>
            <Field label="domínios (0=∞)">
              <Input type="number" min="0" value={f.domains} onChange={set('domains')} />
            </Field>
            <Field label="bancos (0=∞)">
              <Input type="number" min="0" value={f.databases} onChange={set('databases')} />
            </Field>
            <Field label="caixas e-mail (0=∞)">
              <Input type="number" min="0" value={f.mailboxes} onChange={set('mailboxes')} />
            </Field>
            <Field label="validade (dias, 0=∞)">
              <Input type="number" min="0" value={f.duration} onChange={set('duration')} />
            </Field>
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={create.isPending || update.isPending}>
              {create.isPending || update.isPending ? <Spinner /> : editId ? 'Salvar' : 'Criar'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
