import { useEffect, useState } from 'react'
import type { FormEvent } from 'react'
import { Plus, Trash2, Waypoints } from 'lucide-react'

import { ApiError } from '../../api/client'
import {
  useCreateDNSRecord,
  useDeleteDNSRecord,
  useDNSRecords,
  useDomains,
} from '../../api/resources'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { useConfirm } from '../ui/ConfirmDialog'
import { EmptyState } from '../ui/EmptyState'
import { Field } from '../ui/Field'
import { Input } from '../ui/Input'
import { Modal } from '../ui/Modal'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'

const TYPES = ['A', 'AAAA', 'CNAME', 'MX', 'TXT', 'NS']
const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')
const selectCls = 'rounded-md border border-line bg-base px-3 py-1.5 text-sm text-ink'

export function DnsPanel({ root }: { root: string }) {
  const { data: domains } = useDomains(root)
  const [domainId, setDomainId] = useState(0)
  const toast = useToast()
  const confirm = useConfirm()

  useEffect(() => {
    if (domainId === 0 && domains && domains.length > 0) setDomainId(domains[0].id)
  }, [domains, domainId])

  const { data: records, isLoading } = useDNSRecords(root, domainId)
  const create = useCreateDNSRecord(root, domainId)
  const del = useDeleteDNSRecord(root, domainId)

  const [open, setOpen] = useState(false)
  const [type, setType] = useState('A')
  const [name, setName] = useState('')
  const [content, setContent] = useState('')
  const [ttl, setTtl] = useState('3600')
  const [prio, setPrio] = useState('10')

  if (domains && domains.length === 0) {
    return <EmptyState title="Sem domínios" hint="Crie um domínio para gerenciar a zona DNS." />
  }

  async function onCreate(e: FormEvent) {
    e.preventDefault()
    try {
      await create.mutateAsync({
        type,
        name,
        content,
        ttl: Number(ttl),
        prio: type === 'MX' ? Number(prio) : null,
      })
      toast.push('success', 'registro aplicado')
      setOpen(false)
      setName('')
      setContent('')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onDelete(id: number) {
    if (!(await confirm({ title: 'Remover registro', message: 'Remover este registro DNS?', confirmLabel: 'Remover', danger: true }))) return
    try {
      await del.mutateAsync(id)
      toast.push('success', 'remoção enfileirada')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="flex items-center gap-2 font-display text-lg text-ink">
          <Waypoints className="h-4 w-4 text-accent" /> Zona DNS
        </h2>
        <div className="flex items-center gap-2">
          <select className={selectCls} value={domainId} onChange={(e) => setDomainId(Number(e.target.value))}>
            {(domains ?? []).map((d) => (
              <option key={d.id} value={d.id}>
                {d.fqdn}
              </option>
            ))}
          </select>
          <Button onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4" /> Novo registro
          </Button>
        </div>
      </div>

      {isLoading && <Spinner />}
      {records && records.length === 0 && <EmptyState title="Zona vazia" hint="Adicione registros (A, MX, TXT…)." />}

      {records && records.length > 0 && (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-faint">
                <th className="px-4 py-3 font-medium">Tipo</th>
                <th className="px-4 py-3 font-medium">Nome</th>
                <th className="px-4 py-3 font-medium">Conteúdo</th>
                <th className="px-4 py-3 font-medium">TTL</th>
                <th className="px-4 py-3 font-medium">Prio</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {records.map((r) => (
                <tr key={r.id} className="border-b border-line/60 last:border-0">
                  <td className="px-4 py-3 font-mono text-accent">{r.type}</td>
                  <td className="px-4 py-3 font-mono text-ink">{r.name}</td>
                  <td className="max-w-xs truncate px-4 py-3 font-mono text-xs text-muted" title={r.content}>
                    {r.content}
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-muted">{r.ttl}</td>
                  <td className="px-4 py-3 font-mono text-xs text-muted">{r.prio ?? '—'}</td>
                  <td className="px-4 py-3 text-right">
                    <Button variant="danger" onClick={() => onDelete(r.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Novo registro DNS">
        <form onSubmit={onCreate} className="space-y-3">
          <Field label="tipo">
            <select className={`${selectCls} w-full`} value={type} onChange={(e) => setType(e.target.value)}>
              {TYPES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </Field>
          <Field label="nome (FQDN)">
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="www.exemplo.com" required />
          </Field>
          <Field label="conteúdo">
            <Input value={content} onChange={(e) => setContent(e.target.value)} placeholder="1.2.3.4" required />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="ttl">
              <Input type="number" value={ttl} onChange={(e) => setTtl(e.target.value)} />
            </Field>
            {type === 'MX' && (
              <Field label="prioridade">
                <Input type="number" value={prio} onChange={(e) => setPrio(e.target.value)} />
              </Field>
            )}
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={create.isPending}>
              {create.isPending ? <Spinner /> : 'Adicionar'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
