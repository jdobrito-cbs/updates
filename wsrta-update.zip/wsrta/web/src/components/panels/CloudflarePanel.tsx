import { useState } from 'react'
import type { FormEvent } from 'react'
import { Cloud, Play, RotateCcw, Square } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useCloudflare, useControlCloudflare, useSetCloudflare } from '../../api/resources'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { Field } from '../ui/Field'
import { Input } from '../ui/Input'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

function StatusPill({ status, configured }: { status: string; configured: boolean }) {
  if (!configured) return <span className="rounded-full bg-elevated px-2 py-0.5 text-xs text-faint">não configurado</span>
  const running = status === 'running'
  return (
    <span
      className={`rounded-full px-2 py-0.5 text-xs ${
        running ? 'bg-done/15 text-done' : 'bg-failed/15 text-failed'
      }`}
    >
      {running ? 'rodando' : 'parado'}
    </span>
  )
}

export function CloudflarePanel({ root, asAdmin }: { root: string; asAdmin?: boolean }) {
  const { data, isLoading } = useCloudflare(root)
  const set = useSetCloudflare(root)
  const control = useControlCloudflare(root)
  const toast = useToast()
  const [token, setToken] = useState('')

  if (isLoading || !data) return <Spinner />

  async function onSet(e: FormEvent) {
    e.preventDefault()
    try {
      await set.mutateAsync(token)
      toast.push('success', 'túnel sendo configurado e iniciado')
      setToken('')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onControl(op: 'start' | 'stop' | 'restart') {
    try {
      await control.mutateAsync(op)
      toast.push('success', `cloudflared: ${op} enfileirado`)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="flex items-center gap-2 font-display text-lg text-ink">
        <Cloud className="h-4 w-4 text-accent" /> Cloudflare Tunnel
      </h2>

      {asAdmin && (
        <p className="text-sm text-muted">
          Você está configurando o túnel <strong className="text-ink">deste cliente</strong> — útil
          para ajudar na conexão.
        </p>
      )}

      <Card className="flex flex-wrap items-center justify-between gap-3 p-5">
        <div className="flex items-center gap-2 text-sm text-muted">
          Status <StatusPill status={data.status} configured={data.configured} />
        </div>
        {data.configured && (
          <div className="flex gap-2">
            <Button variant="ghost" onClick={() => onControl('start')} disabled={control.isPending}>
              <Play className="h-4 w-4" /> Iniciar
            </Button>
            <Button variant="ghost" onClick={() => onControl('restart')} disabled={control.isPending}>
              <RotateCcw className="h-4 w-4" /> Reiniciar
            </Button>
            <Button variant="danger" onClick={() => onControl('stop')} disabled={control.isPending}>
              <Square className="h-4 w-4" /> Parar
            </Button>
          </div>
        )}
      </Card>

      <Card className="p-5">
        <form onSubmit={onSet} className="space-y-3">
          <p className="text-sm text-muted">
            Cole o <strong className="text-ink">token do conector</strong> do túnel (Cloudflare
            Zero Trust → Networks → Tunnels → seu túnel → token). Salvar reconfigura e inicia o
            cloudflared no container.
          </p>
          <Field label="token do túnel">
            <Input
              type="password"
              value={token}
              onChange={(e) => setToken(e.target.value)}
              placeholder="eyJ…"
              required
            />
          </Field>
          <Button type="submit" disabled={set.isPending}>
            {set.isPending ? <Spinner /> : <Cloud className="h-4 w-4" />} Salvar e iniciar
          </Button>
        </form>
      </Card>
    </div>
  )
}
