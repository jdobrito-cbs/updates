import { useEffect, useState } from 'react'
import { Plus, Trash2 } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useSiteRules, useUpdateSiteRules } from '../../api/resources'
import type { Domain } from '../../api/types'
import { Button } from '../ui/Button'
import { Input } from '../ui/Input'
import { Modal } from '../ui/Modal'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

export function SiteRulesEditor({
  root,
  domain,
  onClose,
}: {
  root: string
  domain: Domain
  onClose: () => void
}) {
  const { data, isLoading } = useSiteRules(root, domain.id)
  const update = useUpdateSiteRules(root, domain.id)
  const toast = useToast()
  const [php, setPhp] = useState<{ key: string; value: string }[]>([])
  const [headers, setHeaders] = useState<{ name: string; value: string }[]>([])
  const [cors, setCors] = useState({ enabled: false, origin: '' })

  useEffect(() => {
    if (data) {
      setPhp(data.php ?? [])
      setHeaders(data.headers ?? [])
      setCors(data.cors ?? { enabled: false, origin: '' })
    }
  }, [data])

  async function onSave() {
    try {
      await update.mutateAsync({
        php: php.filter((d) => d.key.trim()),
        headers: headers.filter((h) => h.name.trim()),
        cors,
      })
      toast.push('success', 'regras aplicadas — acompanhe a Fila')
      onClose()
    } catch (e) {
      toast.push('error', msg(e))
    }
  }

  return (
    <Modal open onClose={onClose} title={`Regras de ${domain.fqdn}`} className="max-w-lg">
      {isLoading ? (
        <Spinner />
      ) : (
        <div className="max-h-[70vh] space-y-5 overflow-y-auto pr-1">
          {}
          <section className="space-y-2">
            <h3 className="text-sm font-medium text-ink">Diretivas PHP (php_value / php_flag)</h3>
            <p className="text-xs text-faint">Ex.: upload_max_filesize = 64M · memory_limit = 256M</p>
            {php.map((d, i) => (
              <div key={i} className="flex gap-2">
                <Input
                  value={d.key}
                  placeholder="diretiva"
                  onChange={(e) => setPhp(php.map((x, j) => (j === i ? { ...x, key: e.target.value } : x)))}
                />
                <Input
                  value={d.value}
                  placeholder="valor"
                  onChange={(e) => setPhp(php.map((x, j) => (j === i ? { ...x, value: e.target.value } : x)))}
                />
                <button onClick={() => setPhp(php.filter((_, j) => j !== i))} className="text-muted hover:text-failed">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
            <Button variant="ghost" onClick={() => setPhp([...php, { key: '', value: '' }])}>
              <Plus className="h-4 w-4" /> Diretiva
            </Button>
          </section>

          {}
          <section className="space-y-2">
            <h3 className="text-sm font-medium text-ink">Headers (segurança/customizados)</h3>
            <p className="text-xs text-faint">Ex.: X-Frame-Options = SAMEORIGIN</p>
            {headers.map((h, i) => (
              <div key={i} className="flex gap-2">
                <Input
                  value={h.name}
                  placeholder="Header"
                  onChange={(e) => setHeaders(headers.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))}
                />
                <Input
                  value={h.value}
                  placeholder="valor"
                  onChange={(e) => setHeaders(headers.map((x, j) => (j === i ? { ...x, value: e.target.value } : x)))}
                />
                <button onClick={() => setHeaders(headers.filter((_, j) => j !== i))} className="text-muted hover:text-failed">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
            <Button variant="ghost" onClick={() => setHeaders([...headers, { name: '', value: '' }])}>
              <Plus className="h-4 w-4" /> Header
            </Button>
          </section>

          {}
          <section className="space-y-2">
            <h3 className="text-sm font-medium text-ink">CORS</h3>
            <label className="flex items-center gap-2 text-sm text-muted">
              <input
                type="checkbox"
                checked={cors.enabled}
                onChange={(e) => setCors({ ...cors, enabled: e.target.checked })}
              />
              Habilitar CORS
            </label>
            {cors.enabled && (
              <Input
                value={cors.origin}
                placeholder="Access-Control-Allow-Origin (ex.: * ou https://app.com)"
                onChange={(e) => setCors({ ...cors, origin: e.target.value })}
              />
            )}
          </section>

          <div className="flex justify-end gap-2 border-t border-line pt-3">
            <Button variant="ghost" onClick={onClose}>
              Cancelar
            </Button>
            <Button onClick={onSave} disabled={update.isPending}>
              {update.isPending ? <Spinner /> : 'Salvar e aplicar'}
            </Button>
          </div>
        </div>
      )}
    </Modal>
  )
}
