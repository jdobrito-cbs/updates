import { useRef, useState } from 'react'
import type { ChangeEvent } from 'react'
import { Archive, Clock, Download, HardDriveDownload, RotateCcw, Upload } from 'lucide-react'

import { ApiError, apiDownload, apiUpload } from '../../api/client'
import {
  useClientBackups,
  useCreateBackup,
  useRestoreBackup,
  useSetBackupSchedule,
} from '../../api/resources'
import type { Backup } from '../../api/resources'
import { formatTime } from '../../lib/format'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { useConfirm } from '../ui/ConfirmDialog'
import { EmptyState } from '../ui/EmptyState'
import { Spinner } from '../ui/Spinner'
import { StatusBadge } from '../ui/StatusBadge'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')
const selectCls = 'rounded-md border border-line bg-base px-3 py-1.5 text-sm text-ink'

const sizeLabel = (b: number) =>
  b >= 1024 * 1024 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`

export function BackupPanel({ root }: { root: string }) {
  const { data, isLoading } = useClientBackups(root)
  const create = useCreateBackup(root)
  const restore = useRestoreBackup(root)
  const setSchedule = useSetBackupSchedule(root)
  const toast = useToast()
  const confirm = useConfirm()
  const fileRef = useRef<HTMLInputElement>(null)
  const [uploading, setUploading] = useState(false)
  const [downloading, setDownloading] = useState(0)

  if (isLoading || !data) return <Spinner />

  const backups = data.backups ?? []

  async function onCreate() {
    try {
      await create.mutateAsync()
      toast.push('success', 'backup iniciado — acompanhe abaixo')
    } catch (e) {
      toast.push('error', msg(e))
    }
  }

  async function onDownload(b: Backup) {
    setDownloading(b.id)
    try {
      await apiDownload(`${root}/backups/${b.id}/download`, b.filename)
    } catch (e) {
      toast.push('error', msg(e))
    } finally {
      setDownloading(0)
    }
  }

  async function onRestore(b: Backup) {
    if (
      !(await confirm({
        title: 'Restaurar backup',
        message: `Restaurar ${b.filename} SOBRE este cliente? Os sites e bancos atuais serão sobrescritos.`,
        confirmLabel: 'Restaurar',
        danger: true,
      }))
    )
      return
    try {
      const r = await restore.mutateAsync(b.id)
      toast.push('success', `restauração enfileirada (${r.actions} ações)`)
    } catch (e) {
      toast.push('error', msg(e))
    }
  }

  async function onChangeSchedule(e: ChangeEvent<HTMLSelectElement>) {
    try {
      await setSchedule.mutateAsync(e.target.value)
      toast.push('success', 'agendamento salvo')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onUpload(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    const ok = await confirm({
      title: 'Restaurar de arquivo',
      message: `Restaurar a partir de ${file.name} SOBRE este cliente? Sobrescreve os dados atuais.`,
      confirmLabel: 'Restaurar',
      danger: true,
    })
    if (!ok) {
      if (fileRef.current) fileRef.current.value = ''
      return
    }
    setUploading(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      const r = await apiUpload<{ actions: number }>(`${root}/backups/restore-upload`, fd)
      toast.push('success', `restauração enfileirada (${r.actions} ações)`)
    } catch (err) {
      toast.push('error', msg(err))
    } finally {
      setUploading(false)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="flex items-center gap-2 font-display text-lg text-ink">
          <Archive className="h-4 w-4 text-accent" /> Backups
        </h2>
        <div className="flex flex-wrap items-center gap-2">
          <span className="flex items-center gap-1 text-xs text-faint">
            <Clock className="h-3.5 w-3.5" /> Agendamento
          </span>
          <select value={data.schedule} onChange={onChangeSchedule} className={selectCls}>
            <option value="">Nenhum</option>
            <option value="daily">Diário</option>
            <option value="weekly">Semanal</option>
          </select>
          <Button onClick={onCreate} disabled={create.isPending}>
            <HardDriveDownload className="h-4 w-4" /> Fazer backup
          </Button>
        </div>
      </div>

      <Card className="flex flex-wrap items-center justify-between gap-3 p-4">
        <p className="text-sm text-muted">
          Restaurar a partir de um arquivo <span className="text-faint">.tar.gz</span> baixado do painel.
        </p>
        <input ref={fileRef} type="file" accept=".gz,.tgz" onChange={onUpload} className="hidden" />
        <Button variant="ghost" onClick={() => fileRef.current?.click()} disabled={uploading}>
          {uploading ? <Spinner /> : <Upload className="h-4 w-4" />} Restaurar de arquivo
        </Button>
      </Card>

      {backups.length === 0 ? (
        <EmptyState title="Nenhum backup" hint="Clique em “Fazer backup” para gerar o primeiro." />
      ) : (
        <Card className="divide-y divide-line p-0">
          {backups.map((b) => (
            <div key={b.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
              <StatusBadge status={b.status} />
              <div className="min-w-0 flex-1">
                <p className="truncate font-mono text-sm text-ink">
                  {b.filename || (b.status === 'failed' ? '(falhou)' : 'gerando…')}
                </p>
                <p className="text-xs text-faint">
                  {formatTime(b.created_at)}
                  {b.status === 'done' && ` · ${sizeLabel(b.size_bytes)}`}
                  {b.note && ` · ${b.note}`}
                </p>
              </div>
              {b.status === 'done' && (
                <div className="flex gap-2">
                  <Button variant="ghost" onClick={() => onDownload(b)} disabled={downloading === b.id}>
                    {downloading === b.id ? <Spinner /> : <Download className="h-4 w-4" />} Baixar
                  </Button>
                  <Button variant="ghost" onClick={() => onRestore(b)}>
                    <RotateCcw className="h-4 w-4" /> Restaurar
                  </Button>
                </div>
              )}
            </div>
          ))}
        </Card>
      )}
    </div>
  )
}
