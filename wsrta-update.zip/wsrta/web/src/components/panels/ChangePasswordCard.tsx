import { useState } from 'react'
import type { FormEvent } from 'react'
import { KeyRound } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useChangeOwnPassword } from '../../api/hooks'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { Field } from '../ui/Field'
import { Input } from '../ui/Input'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')


export function ChangePasswordCard() {
  const change = useChangeOwnPassword()
  const toast = useToast()
  const [cur, setCur] = useState('')
  const [next, setNext] = useState('')
  const [confirm, setConfirm] = useState('')

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (next.length < 8) {
      toast.push('error', 'a nova senha deve ter ao menos 8 caracteres')
      return
    }
    if (next !== confirm) {
      toast.push('error', 'a confirmação não confere')
      return
    }
    try {
      await change.mutateAsync({ current_password: cur, new_password: next })
      toast.push('success', 'senha alterada com sucesso')
      setCur('')
      setNext('')
      setConfirm('')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <Card className="max-w-md p-5">
      <h3 className="mb-3 flex items-center gap-2 text-sm font-medium text-ink">
        <KeyRound className="h-4 w-4 text-accent" /> Trocar minha senha
      </h3>
      <form onSubmit={onSubmit} className="space-y-3">
        <Field label="senha atual">
          <Input type="password" value={cur} onChange={(e) => setCur(e.target.value)} required autoComplete="current-password" />
        </Field>
        <Field label="nova senha (mín. 8)">
          <Input type="password" value={next} onChange={(e) => setNext(e.target.value)} required minLength={8} autoComplete="new-password" />
        </Field>
        <Field label="confirmar nova senha">
          <Input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} required autoComplete="new-password" />
        </Field>
        <Button type="submit" disabled={change.isPending}>
          {change.isPending ? <Spinner /> : 'Salvar nova senha'}
        </Button>
      </form>
    </Card>
  )
}
