import { useState } from 'react'
import type { FormEvent } from 'react'
import { Copy, Database, KeyRound, Plus, Trash2 } from 'lucide-react'

import { ApiError } from '../../api/client'
import {
  useCreateDatabase,
  useDatabases,
  useDeleteDatabase,
  usePostgres,
  useResetDatabasePassword,
} from '../../api/resources'
import type { Database as DB } from '../../api/types'
import { formatTime } from '../../lib/format'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { useConfirm } from '../ui/ConfirmDialog'
import { EmptyState } from '../ui/EmptyState'
import { Field } from '../ui/Field'
import { Input } from '../ui/Input'
import { Modal } from '../ui/Modal'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')


type Creds = { name: string; user: string; password: string; engine: string }

export function DatabasesPanel({ root }: { root: string }) {
  const { data: dbs, isLoading } = useDatabases(root)
  const create = useCreateDatabase(root)
  const del = useDeleteDatabase(root)
  const resetPw = useResetDatabasePassword(root)
  const toast = useToast()
  const confirm = useConfirm()

  const pg = usePostgres(root)
  const pgEnabled = pg.data?.postgres_enabled ?? false

  const [open, setOpen] = useState(false)
  const [dbName, setDbName] = useState('')
  const [dbUser, setDbUser] = useState('')
  const [engine, setEngine] = useState('mariadb')

  const [creds, setCreds] = useState<Creds | null>(null) 
  const [pwTarget, setPwTarget] = useState<DB | null>(null) 
  const [newPw, setNewPw] = useState('')

  function copy(text: string) {
    navigator.clipboard?.writeText(text).then(
      () => toast.push('success', 'copiado'),
      () => {},
    )
  }

  async function onCreate(e: FormEvent) {
    e.preventDefault()
    try {
      const res = await create.mutateAsync({ db_name: dbName, db_user: dbUser, engine })
      setOpen(false)
      setCreds({ name: dbName, user: dbUser, password: res.password, engine })
      setDbName('')
      setDbUser('')
      setEngine('mariadb')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onResetPw(e: FormEvent) {
    e.preventDefault()
    if (!pwTarget) return
    try {
      await resetPw.mutateAsync({ id: pwTarget.id, password: newPw })
      toast.push('success', `senha do banco ${pwTarget.db_name} sendo alterada (Fila)`)
      setPwTarget(null)
      setNewPw('')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onDelete(id: number, name: string) {
    if (!(await confirm({ title: 'Remover banco', message: `Remover o banco ${name}? Irreversível.`, confirmLabel: 'Remover', danger: true }))) return
    try {
      await del.mutateAsync(id)
      toast.push('success', 'remoção enfileirada')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 font-display text-lg text-ink">
          <Database className="h-4 w-4 text-accent" /> Bancos de dados
        </h2>
        <Button onClick={() => setOpen(true)}>
          <Plus className="h-4 w-4" /> Novo banco
        </Button>
      </div>

      {isLoading && <Spinner />}
      {dbs && dbs.length === 0 && <EmptyState title="Nenhum banco" hint="Crie um banco MariaDB ou PostgreSQL no container." />}

      {dbs && dbs.length > 0 && (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-faint">
                <th className="px-4 py-3 font-medium">Banco</th>
                <th className="px-4 py-3 font-medium">Usuário</th>
                <th className="px-4 py-3 font-medium">Criado</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {dbs.map((d) => (
                <tr key={d.id} className="border-b border-line/60 last:border-0">
                  <td className="px-4 py-3 font-mono text-ink">
                    {d.db_name}
                    <span
                      className={`ml-2 rounded px-1.5 py-0.5 text-[10px] uppercase ${
                        d.engine === 'postgres' ? 'bg-accent/15 text-accent' : 'bg-elevated text-faint'
                      }`}
                    >
                      {d.engine === 'postgres' ? 'postgres' : 'mariadb'}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-muted">{d.db_user}@localhost</td>
                  <td className="px-4 py-3 font-mono text-xs text-muted">{formatTime(d.created_at)}</td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" className="px-2.5 py-1.5 text-xs" title="Alterar senha" onClick={() => setPwTarget(d)}>
                        <KeyRound className="h-4 w-4" /> Senha
                      </Button>
                      <Button variant="danger" className="px-2.5 py-1.5" title="Remover" onClick={() => onDelete(d.id, d.db_name)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      {}
      <Modal open={open} onClose={() => setOpen(false)} title="Novo banco">
        <form onSubmit={onCreate} className="space-y-3">
          {pgEnabled && (
            <Field label="tipo de banco">
              <select
                className="w-full rounded-md border border-line bg-base px-3 py-1.5 text-sm text-ink"
                value={engine}
                onChange={(e) => setEngine(e.target.value)}
              >
                <option value="mariadb">MariaDB</option>
                <option value="postgres">PostgreSQL</option>
              </select>
            </Field>
          )}
          <Field label="nome do banco">
            <Input value={dbName} onChange={(e) => setDbName(e.target.value)} placeholder="app" required />
          </Field>
          <Field label="usuário">
            <Input value={dbUser} onChange={(e) => setDbUser(e.target.value)} placeholder="appuser" required />
          </Field>
          <p className="text-xs text-faint">Apenas [A-Za-z0-9_]. A senha é gerada e exibida ao criar.</p>
          <div className="flex justify-end gap-2 pt-1">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={create.isPending}>
              {create.isPending ? <Spinner /> : 'Criar'}
            </Button>
          </div>
        </form>
      </Modal>

      {}
      <Modal open={!!creds} onClose={() => setCreds(null)} title="Banco criado — anote a senha">
        {creds && (
          <div className="space-y-3">
            <p className="text-sm text-muted">
              Esta senha <strong className="text-ink">não será exibida de novo</strong>. Use-a para configurar seus
              apps/sistemas. Se perder, gere uma nova com o botão <em>Senha</em> na lista.
            </p>
            <div className="space-y-2 rounded-lg border border-line bg-base/50 p-3 text-sm">
              {(
                [
                  ['Banco', creds.name],
                  ['Usuário', creds.user],
                  ['Host', 'localhost'],
                  ['Tipo', creds.engine === 'postgres' ? 'PostgreSQL' : 'MariaDB'],
                ] as const
              ).map(([k, v]) => (
                <div key={k} className="flex items-center justify-between gap-3">
                  <span className="text-faint">{k}</span>
                  <span className="font-mono text-ink">{v}</span>
                </div>
              ))}
              <div className="flex items-center justify-between gap-3 border-t border-line pt-2">
                <span className="text-faint">Senha</span>
                <span className="flex items-center gap-2">
                  <code className="rounded bg-elevated px-2 py-1 font-mono text-accent">{creds.password}</code>
                  <button type="button" onClick={() => copy(creds.password)} className="text-muted hover:text-ink" title="Copiar">
                    <Copy className="h-4 w-4" />
                  </button>
                </span>
              </div>
            </div>
            <div className="flex justify-end">
              <Button onClick={() => setCreds(null)}>Entendi, anotei</Button>
            </div>
          </div>
        )}
      </Modal>

      {}
      <Modal open={!!pwTarget} onClose={() => setPwTarget(null)} title={pwTarget ? `Alterar senha — ${pwTarget.db_name}` : ''}>
        <form onSubmit={onResetPw} className="space-y-3">
          <p className="text-sm text-muted">Defina a nova senha do usuário do banco (8 a 128 caracteres).</p>
          <Field label="nova senha">
            <Input
              type="text"
              value={newPw}
              onChange={(e) => setNewPw(e.target.value)}
              placeholder="nova senha do banco"
              minLength={8}
              maxLength={128}
              required
              autoFocus
            />
          </Field>
          <div className="flex justify-end gap-2 pt-1">
            <Button type="button" variant="ghost" onClick={() => setPwTarget(null)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={resetPw.isPending}>
              {resetPw.isPending ? <Spinner /> : 'Alterar senha'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
