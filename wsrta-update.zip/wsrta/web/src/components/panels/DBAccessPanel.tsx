import { useState } from 'react'
import type { ReactNode } from 'react'
import { Copy, Database, ExternalLink, Eye, EyeOff, LayoutGrid, Lock } from 'lucide-react'

import { usePhpMyAdmin, usePostgres } from '../../api/resources'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'




export function DBAccessPanel({ root }: { root: string }) {
  const pma = usePhpMyAdmin(root)
  const pg = usePostgres(root)

  if (pma.isLoading || !pma.data || pg.isLoading || !pg.data) return <Spinner />

  return (
    <Card className="p-5">
      <h3 className="mb-1 flex items-center gap-2 text-sm font-medium text-ink">
        <Lock className="h-4 w-4 text-accent" /> Acesso aos bancos
      </h3>
      <p className="mb-4 text-xs text-faint">
        Abra o gerenciador e entre com o usuário e a senha mostrados abaixo. Esses dados servem só para o gerenciador
        (acesso aos bancos deste cliente); guarde-os com cuidado.
      </p>
      <div className="grid gap-3 sm:grid-cols-2">
        <ManagerCard
          icon={<Database className="h-4 w-4 flex-none text-accent" />}
          name="phpMyAdmin"
          enabled={pma.data.enabled}
          openURL={pma.data.open_url}
          user={pma.data.user}
          password={pma.data.password}
        />
        <ManagerCard
          icon={<LayoutGrid className="h-4 w-4 flex-none text-accent" />}
          name="phpPgAdmin"
          enabled={pg.data.phppgadmin_enabled}
          openURL={pg.data.phppgadmin_url}
          user={pg.data.ppa_user}
          password={pg.data.ppa_password}
        />
      </div>
    </Card>
  )
}

function ManagerCard({
  icon,
  name,
  enabled,
  openURL,
  user,
  password,
}: {
  icon: ReactNode
  name: string
  enabled: boolean
  openURL: string
  user: string
  password: string
}) {
  const toast = useToast()
  const [show, setShow] = useState(false)

  async function copy(value: string, label: string) {
    try {
      await navigator.clipboard.writeText(value)
      toast.push('success', `${label} copiado`)
    } catch {
      toast.push('error', 'não foi possível copiar')
    }
  }

  return (
    <div className="flex flex-col gap-3 rounded-xl border border-line bg-base/40 p-3">
      <div className="flex items-center gap-3">
        {icon}
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-ink">{name}</p>
          <p className="text-xs text-faint">{enabled ? 'liberado' : 'não liberado pelo admin'}</p>
        </div>
        <Button
          disabled={!enabled}
          onClick={() => window.open(openURL, '_blank', 'noopener')}
          className="px-3 py-1.5 text-xs"
        >
          <ExternalLink className="h-4 w-4" /> Abrir
        </Button>
      </div>

      {enabled && password && (
        <dl className="space-y-1.5 rounded-lg border border-line bg-base/60 p-2.5 text-xs">
          <CredField label="Usuário" value={user} onCopy={() => copy(user, 'Usuário')} mono />
          <div className="flex items-center gap-2">
            <dt className="w-16 flex-none text-faint">Senha</dt>
            <dd className="min-w-0 flex-1 truncate font-mono text-ink">{show ? password : '••••••••••'}</dd>
            <button
              type="button"
              title={show ? 'Ocultar' : 'Mostrar'}
              onClick={() => setShow((s) => !s)}
              className="flex-none rounded p-1 text-muted hover:bg-line hover:text-ink"
            >
              {show ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
            </button>
            <button
              type="button"
              title="Copiar senha"
              onClick={() => copy(password, 'Senha')}
              className="flex-none rounded p-1 text-muted hover:bg-line hover:text-ink"
            >
              <Copy className="h-3.5 w-3.5" />
            </button>
          </div>
        </dl>
      )}
      {enabled && !password && (
        <p className="text-xs text-faint">As credenciais aparecem após o daemon concluir a liberação (veja a Fila).</p>
      )}
    </div>
  )
}

function CredField({ label, value, onCopy, mono }: { label: string; value: string; onCopy: () => void; mono?: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <dt className="w-16 flex-none text-faint">{label}</dt>
      <dd className={`min-w-0 flex-1 truncate text-ink ${mono ? 'font-mono' : ''}`}>{value}</dd>
      <button type="button" title={`Copiar ${label}`} onClick={onCopy} className="flex-none rounded p-1 text-muted hover:bg-line hover:text-ink">
        <Copy className="h-3.5 w-3.5" />
      </button>
    </div>
  )
}
