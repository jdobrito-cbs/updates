import { useState } from 'react'
import type { ReactNode } from 'react'
import { Ban, Flame, Play, Plus, Power, RefreshCw, ShieldOff, Square, Unlock } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useFirewall, useFirewallAction } from '../../api/hooks'
import type { FirewallActionBody } from '../../api/hooks'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { useConfirm } from '../ui/ConfirmDialog'
import { Input } from '../ui/Input'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

const SERVICES: { unit: string; label: string }[] = [
  { unit: 'csf', label: 'CSF' },
  { unit: 'lfd', label: 'LFD' },
  { unit: 'fail2ban', label: 'fail2ban' },
]

export function FirewallPanel() {
  const { data, isLoading } = useFirewall()
  const act = useFirewallAction()
  const toast = useToast()
  const confirm = useConfirm()
  const [banJail, setBanJail] = useState('')
  const [banIP, setBanIP] = useState('')
  const [allowIP, setAllowIP] = useState('')
  const [denyIP, setDenyIP] = useState('')

  async function run(body: FirewallActionBody, ok: string) {
    try {
      await act.mutateAsync(body)
      toast.push('success', ok)
    } catch (e) {
      toast.push('error', msg(e))
    }
  }

  if (isLoading || !data) return <Spinner />

  const firstJail = data.jails[0]?.name ?? ''
  const jail = banJail || firstJail

  return (
    <div className="space-y-5">
      {}
      <Card className="p-5">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-medium text-ink">
          <Power className="h-4 w-4 text-accent" /> Serviços do firewall
        </h3>
        <div className="space-y-2">
          {SERVICES.map((s) => {
            const on = (data.status as Record<string, boolean>)[s.unit]
            return (
              <div key={s.unit} className="flex flex-wrap items-center gap-3 rounded-lg border border-line bg-elevated/40 px-3 py-2">
                <span className={`inline-flex items-center gap-1.5 text-sm font-medium ${on ? 'text-done' : 'text-faint'}`}>
                  <span className={`h-2 w-2 rounded-full ${on ? 'bg-done' : 'bg-faint'}`} /> {s.label}
                </span>
                <span className="text-xs text-faint">{on ? 'ativo' : 'inativo'}</span>
                <div className="ml-auto flex gap-1.5">
                  <Button variant="ghost" onClick={() => run({ kind: 'service', service: s.unit, op: 'restart' }, `${s.label} reiniciado`)}>
                    <RefreshCw className="h-3.5 w-3.5" /> Reiniciar
                  </Button>
                  <Button variant="ghost" onClick={() => run({ kind: 'service', service: s.unit, op: 'start' }, `${s.label} iniciado`)}>
                    <Play className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" onClick={() => run({ kind: 'service', service: s.unit, op: 'stop' }, `${s.label} parado`)}>
                    <Square className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            )
          })}
        </div>
      </Card>

      {}
      <Card className="p-5">
        <h3 className="mb-1 flex items-center gap-2 text-sm font-medium text-ink">
          <Ban className="h-4 w-4 text-accent" /> fail2ban — IPs banidos
        </h3>
        <p className="mb-3 text-xs text-faint">Desbloqueie um IP que foi banido por tentativas repetidas.</p>

        {data.jails.length === 0 && <p className="text-sm text-muted">Nenhuma jail ativa.</p>}
        <div className="space-y-3">
          {data.jails.map((j) => (
            <div key={j.name}>
              <div className="mb-1 flex items-center gap-2 text-xs uppercase tracking-wide text-faint">
                <Flame className="h-3.5 w-3.5" /> {j.name}{' '}
                <span className="text-faint/70">({j.banned.length})</span>
              </div>
              {j.banned.length === 0 ? (
                <p className="text-xs text-faint">— sem IPs banidos</p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {j.banned.map((ip) => (
                    <span key={ip} className="inline-flex items-center gap-2 rounded-lg border border-line bg-elevated/50 py-1 pl-3 pr-1 font-mono text-xs text-ink">
                      {ip}
                      <button
                        title={`Desbloquear ${ip}`}
                        onClick={() => run({ kind: 'unban', jail: j.name, ip }, `${ip} desbloqueado`)}
                        className="rounded-md p-1 text-muted hover:bg-done/15 hover:text-done"
                      >
                        <Unlock className="h-3.5 w-3.5" />
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-4 flex flex-wrap items-end gap-2 border-t border-line pt-3">
          <select
            value={jail}
            onChange={(e) => setBanJail(e.target.value)}
            className="h-9 rounded-lg border border-line bg-elevated px-2 text-sm text-ink"
          >
            {data.jails.map((j) => (
              <option key={j.name} value={j.name}>
                {j.name}
              </option>
            ))}
          </select>
          <Input
            className="max-w-[200px]"
            placeholder="banir IP (ex.: 203.0.113.9)"
            value={banIP}
            onChange={(e) => setBanIP(e.target.value)}
          />
          <Button
            variant="ghost"
            onClick={() => banIP && jail && run({ kind: 'ban', jail, ip: banIP }, `${banIP} banido`).then(() => setBanIP(''))}
          >
            <ShieldOff className="h-4 w-4" /> Banir
          </Button>
        </div>
      </Card>

      {}
      <Card className="p-5">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-medium text-ink">
          <Flame className="h-4 w-4 text-accent" /> CSF — regras de IP
        </h3>

        <CsfList
          title="Bloqueados (deny)"
          items={data.csf.deny}
          actionIcon={<Unlock className="h-3.5 w-3.5" />}
          actionTitle="Desbloquear"
          actionClass="hover:bg-done/15 hover:text-done"
          onAction={(ip) => run({ kind: 'unblock', ip }, `${ip} desbloqueado`)}
        />
        <CsfList title="Bloqueio temporário (LFD)" items={data.csf.temp} />
        <CsfList title="Permitidos (allow)" items={data.csf.allow} />

        <div className="mt-4 grid gap-2 border-t border-line pt-3 sm:grid-cols-2">
          <div className="flex items-end gap-2">
            <Input placeholder="bloquear IP/CIDR" value={denyIP} onChange={(e) => setDenyIP(e.target.value)} />
            <Button variant="ghost" onClick={() => denyIP && run({ kind: 'deny', ip: denyIP }, `${denyIP} bloqueado`).then(() => setDenyIP(''))}>
              <Ban className="h-4 w-4" /> Deny
            </Button>
          </div>
          <div className="flex items-end gap-2">
            <Input placeholder="permitir IP/CIDR" value={allowIP} onChange={(e) => setAllowIP(e.target.value)} />
            <Button variant="ghost" onClick={() => allowIP && run({ kind: 'allow', ip: allowIP }, `${allowIP} permitido`).then(() => setAllowIP(''))}>
              <Plus className="h-4 w-4" /> Allow
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )

  function CsfList({
    title,
    items,
    actionIcon,
    actionTitle,
    actionClass,
    onAction,
  }: {
    title: string
    items: string[]
    actionIcon?: ReactNode
    actionTitle?: string
    actionClass?: string
    onAction?: (ip: string) => void
  }) {
    return (
      <div className="mb-3">
        <p className="mb-1 text-xs uppercase tracking-wide text-faint">
          {title} <span className="text-faint/70">({items.length})</span>
        </p>
        {items.length === 0 ? (
          <p className="text-xs text-faint">— vazio</p>
        ) : (
          <div className="flex flex-wrap gap-2">
            {items.map((it) => {
              const ip = it.split(/[\s#]/)[0]
              return (
                <span key={it} className="inline-flex items-center gap-2 rounded-lg border border-line bg-elevated/50 py-1 pl-3 pr-1 font-mono text-xs text-ink">
                  {it}
                  {onAction && (
                    <button
                      title={`${actionTitle} ${ip}`}
                      onClick={async () => {
                        if (await confirm({ title: actionTitle || 'Confirmar', message: `${actionTitle} ${ip}?`, confirmLabel: actionTitle }))
                          onAction(ip)
                      }}
                      className={`rounded-md p-1 text-muted ${actionClass ?? ''}`}
                    >
                      {actionIcon}
                    </button>
                  )}
                </span>
              )
            })}
          </div>
        )}
      </div>
    )
  }
}
