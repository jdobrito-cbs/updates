import { useClientMonitoring } from '../../api/hooks'
import { C, DonutGauge } from '../charts/Charts'

function fmtBytes(n: number): string {
  if (n <= 0) return '0 B'
  const u = ['B', 'KB', 'MB', 'GB', 'TB']
  const i = Math.min(u.length - 1, Math.floor(Math.log(n) / Math.log(1024)))
  return `${(n / 1024 ** i).toFixed(i ? 1 : 0)} ${u[i]}`
}



export function SystemDonuts() {
  const { data } = useClientMonitoring()
  return (
    <div>
      <h2 className="mb-3 font-display text-lg text-ink">Uso do sistema</h2>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <DonutGauge
          label="CPU"
          value={data?.cpu ?? 0}
          color={C.accent}
          detail={
            data && (
              <>
                <span className="block truncate" title={data.cpu_info.model}>
                  {data.cpu_info.model}
                </span>
                <span className="text-faint">{data.cpu_info.cores} núcleos</span>
              </>
            )
          }
        />
        <DonutGauge
          label="Memória"
          value={data?.mem.percent ?? 0}
          color={C.running}
          detail={data ? `${fmtBytes((data.mem.used_kb ?? 0) * 1024)} / ${fmtBytes((data.mem.total_kb ?? 0) * 1024)}` : undefined}
        />
        <DonutGauge
          label="Disco"
          value={data?.disk.percent ?? 0}
          color={C.done}
          detail={data ? `${fmtBytes(data.disk.used_bytes ?? 0)} / ${fmtBytes(data.disk.total_bytes ?? 0)}` : undefined}
        />
      </div>
    </div>
  )
}
