import { useRef, useState } from 'react'
import { CheckCircle2, Globe, Power, RefreshCw, Trash2, Upload } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useWPManage, useWPManager, useWPSetURL, useWPUpload } from '../../api/resources'
import type { WPItem, WPManageBody, WordPressInstall } from '../../api/resources'
import { Button } from '../ui/Button'
import { useConfirm } from '../ui/ConfirmDialog'
import { Input } from '../ui/Input'
import { Modal } from '../ui/Modal'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

export function WordPressManager({
  root,
  install,
  onClose,
}: {
  root: string
  install: WordPressInstall
  onClose: () => void
}) {
  const { data, isLoading } = useWPManager(root, install.id)
  const manage = useWPManage(root, install.id)
  const upload = useWPUpload(root, install.id)
  const setURL = useWPSetURL(root, install.id)
  const toast = useToast()
  const confirm = useConfirm()
  const [pluginSlug, setPluginSlug] = useState('')
  const [themeSlug, setThemeSlug] = useState('')
  const [newURL, setNewURL] = useState('')

  async function run(body: WPManageBody, ok = 'feito') {
    try {
      await manage.mutateAsync(body)
      toast.push('success', ok)
    } catch (e) {
      toast.push('error', msg(e))
    }
  }

  async function onUpload(target: 'plugin' | 'theme', file: File) {
    try {
      await upload.mutateAsync({ target, file })
      toast.push('success', `${target === 'plugin' ? 'Plugin' : 'Tema'} instalado de ${file.name}`)
    } catch (e) {
      toast.push('error', msg(e))
    }
  }

  async function onSetURL() {
    const url = newURL.trim()
    if (!url) return
    if (
      !(await confirm({
        title: 'Trocar URL do site',
        message: `Trocar a URL do site para "${url}"? Isso altera as configurações e o conteúdo do WordPress (search-replace). Use após migrar de outro domínio.`,
        confirmLabel: 'Trocar',
      }))
    )
      return
    try {
      const r = await setURL.mutateAsync(url)
      toast.push('success', r.output)
      setNewURL('')
    } catch (e) {
      toast.push('error', msg(e))
    }
  }

  async function onDelete(target: 'plugin' | 'theme', slug: string) {
    if (!(await confirm({ title: `Excluir ${target}`, message: `Excluir "${slug}"?`, confirmLabel: 'Excluir', danger: true })))
      return
    run({ target, action: 'delete', slug }, 'removido')
  }

  return (
    <Modal open onClose={onClose} title={`WordPress Pro — ${install.fqdn}`} className="max-w-2xl">
      {isLoading || !data ? (
        <Spinner />
      ) : (
        <div className="max-h-[72vh] space-y-5 overflow-y-auto pr-1">
          {}
          <section className="flex items-center justify-between rounded-md border border-line bg-base px-4 py-3">
            <span className="text-sm text-muted">
              WordPress core <span className="font-mono text-ink">{data.core_version || '?'}</span>
              {data.core_update_version ? (
                <span className="font-mono text-running"> → {data.core_update_version}</span>
              ) : (
                <span className="ml-1 text-xs text-done">atualizado</span>
              )}
            </span>
            <Button
              variant="ghost"
              disabled={!data.core_update_version || manage.isPending}
              onClick={() => run({ target: 'core', action: 'update' }, 'core atualizado')}
            >
              <RefreshCw className="h-4 w-4" />{' '}
              {data.core_update_version ? `Atualizar para ${data.core_update_version}` : 'Atualizar core'}
            </Button>
          </section>

          {}
          <section className="space-y-2 rounded-md border border-line bg-base px-4 py-3">
            <div className="flex flex-wrap items-center gap-1.5 text-sm text-muted">
              <Globe className="h-4 w-4 text-accent" /> URL do site:{' '}
              <span className="font-mono text-ink">{data.site_url || '?'}</span>
            </div>
            <div className="flex gap-2">
              <Input value={newURL} onChange={(e) => setNewURL(e.target.value)} placeholder="nova URL (ex.: https://meudominio.com)" />
              <Button variant="ghost" onClick={onSetURL} disabled={setURL.isPending}>
                Trocar URL
              </Button>
            </div>
            <p className="text-xs text-faint">
              Troca a URL nas configurações e em todo o conteúdo (search-replace). Use após migrar de outro domínio.
            </p>
          </section>

          <ItemSection
            title="Plugins"
            target="plugin"
            items={data.plugins}
            slug={pluginSlug}
            setSlug={setPluginSlug}
            onInstall={() => pluginSlug && run({ target: 'plugin', action: 'install', slug: pluginSlug }, 'plugin instalado')}
            onUpload={(f) => onUpload('plugin', f)}
            onToggle={(it) =>
              run({ target: 'plugin', action: it.status === 'active' ? 'deactivate' : 'activate', slug: it.name }, 'feito')
            }
            onUpdate={(it) => run({ target: 'plugin', action: 'update', slug: it.name }, 'atualizado')}
            onDelete={(it) => onDelete('plugin', it.name)}
            canToggle
          />

          <ItemSection
            title="Temas"
            target="theme"
            items={data.themes}
            slug={themeSlug}
            setSlug={setThemeSlug}
            onInstall={() => themeSlug && run({ target: 'theme', action: 'install', slug: themeSlug }, 'tema instalado')}
            onUpload={(f) => onUpload('theme', f)}
            onToggle={(it) => run({ target: 'theme', action: 'activate', slug: it.name }, 'tema ativado')}
            onUpdate={(it) => run({ target: 'theme', action: 'update', slug: it.name }, 'atualizado')}
            onDelete={(it) => onDelete('theme', it.name)}
          />
        </div>
      )}
    </Modal>
  )
}

function ItemSection({
  title,
  target,
  items,
  slug,
  setSlug,
  onInstall,
  onUpload,
  onToggle,
  onUpdate,
  onDelete,
  canToggle,
}: {
  title: string
  target: 'plugin' | 'theme'
  items: WPItem[]
  slug: string
  setSlug: (s: string) => void
  onInstall: () => void
  onUpload: (file: File) => void
  onToggle: (it: WPItem) => void
  onUpdate: (it: WPItem) => void
  onDelete: (it: WPItem) => void
  canToggle?: boolean
}) {
  const fileRef = useRef<HTMLInputElement>(null)
  return (
    <section className="space-y-2">
      <h3 className="text-sm font-medium text-ink">{title}</h3>
      <div className="divide-y divide-line rounded-md border border-line">
        {items.length === 0 && <p className="px-4 py-3 text-xs text-faint">nenhum</p>}
        {items.map((it) => (
          <div key={it.name} className="flex items-center gap-2 px-3 py-2 text-sm">
            <span className="min-w-0 flex-1 truncate">
              {it.status === 'active' && <CheckCircle2 className="mr-1 inline h-3.5 w-3.5 text-done" />}
              <span className="font-mono text-ink">{it.name}</span>{' '}
              <span className="text-xs text-faint">{it.version}</span>
              {it.update === 'available' && it.update_version && (
                <span className="font-mono text-xs text-running"> → {it.update_version}</span>
              )}
            </span>
            {it.update === 'available' && (
              <button
                title={it.update_version ? `Atualizar para ${it.update_version}` : 'Atualizar'}
                onClick={() => onUpdate(it)}
                className="rounded p-1 text-running hover:bg-line"
              >
                <RefreshCw className="h-4 w-4" />
              </button>
            )}
            <button
              title={canToggle ? (it.status === 'active' ? 'Desativar' : 'Ativar') : 'Ativar'}
              onClick={() => onToggle(it)}
              className="rounded p-1 text-muted hover:bg-line hover:text-ink"
            >
              <Power className="h-4 w-4" />
            </button>
            <button title="Excluir" onClick={() => onDelete(it)} className="rounded p-1 text-muted hover:bg-failed/15 hover:text-failed">
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ))}
      </div>
      <div className="flex gap-2">
        <Input value={slug} onChange={(e) => setSlug(e.target.value)} placeholder={`instalar por slug (ex.: ${title === 'Plugins' ? 'wordfence' : 'astra'})`} />
        <Button variant="ghost" onClick={onInstall}>
          Instalar
        </Button>
      </div>
      {}
      <div className="flex items-center gap-2">
        <input
          ref={fileRef}
          type="file"
          accept=".zip"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0]
            if (f) onUpload(f)
            e.target.value = '' 
          }}
        />
        <Button variant="ghost" onClick={() => fileRef.current?.click()}>
          <Upload className="h-4 w-4" /> Enviar {target === 'plugin' ? 'plugin' : 'tema'} (.zip)
        </Button>
      </div>
    </section>
  )
}
