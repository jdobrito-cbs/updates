import { useState } from 'react'
import type { FormEvent } from 'react'
import { ExternalLink, KeyRound, Mail, Plus, Power, PowerOff, Trash2 } from 'lucide-react'

import { ApiError } from '../../api/client'
import {
  useCreateMailbox,
  useDeleteMailbox,
  useDisableEmail,
  useEmail,
  useEnableEmail,
  useSetMailboxPassword,
} from '../../api/email'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { useConfirm } from '../ui/ConfirmDialog'
import { Field } from '../ui/Field'
import { Input } from '../ui/Input'
import { Modal } from '../ui/Modal'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')




export function EmailPanel({ root }: { root: string }) {
  const { data, isLoading } = useEmail(root)
  const enable = useEnableEmail(root)
  const disable = useDisableEmail(root)
  const create = useCreateMailbox(root)
  const del = useDeleteMailbox(root)
  const setPwd = useSetMailboxPassword(root)
  const toast = useToast()
  const confirm = useConfirm()

  const [open, setOpen] = useState(false)
  const [domainId, setDomainId] = useState('')
  const [local, setLocal] = useState('')
  const [password, setPassword] = useState('')
  const [quota, setQuota] = useState('1024')
  const [pwdFor, setPwdFor] = useState<{ id: number; address: string } | null>(null)
  const [newPwd, setNewPwd] = useState('')

  if (isLoading || !data) return <Spinner />

  if (!data.configured) {
    return (
      <Card className="space-y-2 p-6 text-center">
        <Mail className="mx-auto h-9 w-9 text-faint" />
        <p className="text-ink">E-mail ainda não disponível</p>
        <p className="text-sm text-muted">O administrador precisa configurar o servidor de e-mail (mailcow).</p>
      </Card>
    )
  }

  const domains = data.domains ?? []
  const mailboxes = data.mailboxes ?? []
  const enabledDomains = domains.filter((d) => d.email_enabled)

  async function onToggle(d: { id: number; fqdn: string; email_enabled: boolean }) {
    try {
      if (d.email_enabled) {
        if (!(await confirm({ title: 'Desligar e-mail', message: `Desligar o e-mail de ${d.fqdn}? As caixas serão removidas.`, confirmLabel: 'Desligar', danger: true })))
          return
        await disable.mutateAsync(d.id)
        toast.push('success', 'e-mail desligado')
      } else {
        await enable.mutateAsync(d.id)
        toast.push('success', 'e-mail ligado (DNS sendo aplicado; acompanhe a Fila)')
      }
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  function openCreate() {
    setOpen(true)
    setDomainId(enabledDomains[0] ? String(enabledDomains[0].id) : '')
    setLocal('')
    setPassword('')
    setQuota('1024')
  }

  async function onCreate(e: FormEvent) {
    e.preventDefault()
    try {
      await create.mutateAsync({ domain_id: Number(domainId), local_part: local, password, quota_mb: Number(quota) || 1024 })
      toast.push('success', 'caixa criada')
      setOpen(false)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onDelete(id: number, address: string) {
    if (!(await confirm({ title: 'Excluir caixa', message: `Excluir ${address}? A caixa e as mensagens serão removidas.`, confirmLabel: 'Excluir', danger: true })))
      return
    try {
      await del.mutateAsync(id)
      toast.push('success', 'caixa excluída')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onSetPwd(e: FormEvent) {
    e.preventDefault()
    if (!pwdFor) return
    try {
      await setPwd.mutateAsync({ id: pwdFor.id, password: newPwd })
      toast.push('success', 'senha alterada')
      setPwdFor(null)
      setNewPwd('')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  const limitLabel = data.limit === 0 ? 'ilimitado' : `${data.used}/${data.limit}`

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="flex items-center gap-2 font-display text-lg text-ink">
          <Mail className="h-4 w-4 text-accent" /> E-mail
        </h2>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted">caixas: {limitLabel}</span>
          {data.webmail_url && (
            <a href={data.webmail_url} target="_blank" rel="noreferrer">
              <Button variant="ghost">
                <ExternalLink className="h-4 w-4" /> Webmail
              </Button>
            </a>
          )}
          <Button onClick={openCreate} disabled={enabledDomains.length === 0}>
            <Plus className="h-4 w-4" /> Nova caixa
          </Button>
        </div>
      </div>

      {}
      <Card className="overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-faint">
              <th className="px-4 py-3 font-medium">Domínio</th>
              <th className="px-4 py-3 font-medium">E-mail</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody>
            {domains.length === 0 && (
              <tr>
                <td colSpan={3} className="px-4 py-6 text-center text-sm text-faint">Nenhum domínio nesta VPS.</td>
              </tr>
            )}
            {domains.map((d) => (
              <tr key={d.id} className="border-b border-line/60 last:border-0">
                <td className="px-4 py-3 text-ink">{d.fqdn}</td>
                <td className="px-4 py-3">
                  <span className={`rounded-full px-2 py-0.5 text-xs ${d.email_enabled ? 'bg-done/15 text-done' : 'bg-elevated text-faint'}`}>
                    {d.email_enabled ? 'ligado' : 'desligado'}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  {d.email_enabled ? (
                    <Button variant="ghost" onClick={() => onToggle(d)} title="Desligar">
                      <PowerOff className="h-4 w-4" />
                    </Button>
                  ) : (
                    <Button variant="ghost" onClick={() => onToggle(d)} title="Ligar e-mail">
                      <Power className="h-4 w-4" />
                    </Button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      {}
      <div>
        <h3 className="mb-2 text-sm font-medium text-muted">Caixas</h3>
        {mailboxes.length === 0 ? (
          <p className="text-sm text-faint">Nenhuma caixa. Ligue o e-mail num domínio e crie a primeira.</p>
        ) : (
          <Card className="overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-faint">
                  <th className="px-4 py-3 font-medium">Endereço</th>
                  <th className="px-4 py-3 font-medium">Cota</th>
                  <th className="px-4 py-3" />
                </tr>
              </thead>
              <tbody>
                {mailboxes.map((m) => (
                  <tr key={m.id} className="border-b border-line/60 last:border-0">
                    <td className="px-4 py-3 text-ink">{m.address}</td>
                    <td className="px-4 py-3 text-xs text-muted">{m.quota_mb} MB</td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <Button variant="ghost" onClick={() => setPwdFor({ id: m.id, address: m.address })} title="Trocar senha">
                          <KeyRound className="h-4 w-4" />
                        </Button>
                        <Button variant="danger" onClick={() => onDelete(m.id, m.address)} title="Excluir">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        )}
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="Nova caixa de e-mail">
        <form onSubmit={onCreate} className="space-y-3">
          <Field label="domínio">
            <select value={domainId} onChange={(e) => setDomainId(e.target.value)} required className="w-full rounded-lg border border-line bg-base px-3 py-2 text-sm text-ink">
              {enabledDomains.map((d) => (
                <option key={d.id} value={d.id}>{d.fqdn}</option>
              ))}
            </select>
          </Field>
          <Field label="parte local (antes do @)">
            <Input value={local} onChange={(e) => setLocal(e.target.value)} placeholder="contato" required />
          </Field>
          <Field label="senha (mín. 8)">
            <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} autoComplete="new-password" />
          </Field>
          <Field label="cota (MB)">
            <Input type="number" min="64" step="64" value={quota} onChange={(e) => setQuota(e.target.value)} />
          </Field>
          <div className="flex justify-end gap-2 pt-1">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>Cancelar</Button>
            <Button type="submit" disabled={create.isPending}>{create.isPending ? <Spinner /> : 'Criar caixa'}</Button>
          </div>
        </form>
      </Modal>

      <Modal open={pwdFor !== null} onClose={() => setPwdFor(null)} title={pwdFor ? `Senha de ${pwdFor.address}` : ''}>
        <form onSubmit={onSetPwd} className="space-y-3">
          <Field label="nova senha (mín. 8)">
            <Input type="password" value={newPwd} onChange={(e) => setNewPwd(e.target.value)} required minLength={8} autoComplete="new-password" />
          </Field>
          <div className="flex justify-end gap-2 pt-1">
            <Button type="button" variant="ghost" onClick={() => setPwdFor(null)}>Cancelar</Button>
            <Button type="submit" disabled={setPwd.isPending}>{setPwd.isPending ? <Spinner /> : 'Alterar'}</Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
