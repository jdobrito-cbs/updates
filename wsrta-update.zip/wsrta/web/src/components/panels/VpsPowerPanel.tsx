import { useEffect, useState } from 'react'
import { Play, Power, RotateCcw, Square } from 'lucide-react'

import { ApiError } from '../../api/client'
import { usePowerClient, usePowerState } from '../../api/resources'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { useConfirm } from '../ui/ConfirmDialog'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')




export function VpsPowerPanel({ root, label }: { root: string; label?: string }) {
  const power = usePowerClient(root)
  const { data: pstate } = usePowerState(root)
  const toast = useToast()
  const confirm = useConfirm()
  
  
  
  const [pending, setPending] = useState<boolean | null>(null)
  useEffect(() => {
    if (pending === null) return
    if (pstate?.running === pending) {
      setPending(null)
      return
    }
    const t = setTimeout(() => setPending(null), 15000)
    return () => clearTimeout(t)
  }, [pending, pstate?.running])
  
  
  const running = pending ?? pstate?.running ?? true

  async function onPower(op: 'start' | 'stop' | 'restart') {
    const verbo = op === 'start' ? 'iniciar' : op === 'stop' ? 'parar' : 'reiniciar'
    if (op !== 'start') {
      const ok = await confirm({
        title: `Confirmar ${verbo}`,
        message:
          op === 'stop'
            ? `Parar a VPS derruba todos os sites e serviços ${label ?? 'desta VPS'} até ser iniciada de novo. Continuar?`
            : `Reiniciar a VPS interrompe os sites por alguns segundos. Continuar?`,
        confirmLabel: verbo,
        danger: op === 'stop',
      })
      if (!ok) return
    }
    try {
      await power.mutateAsync(op)
      
      setPending(op === 'stop' ? false : true)
      toast.push('success', `${verbo} da VPS enfileirado`)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="flex items-center gap-2 font-display text-lg text-ink">
        <Power className="h-4 w-4 text-accent" /> Energia da VPS
      </h2>
      <Card className="flex flex-wrap items-center justify-between gap-3 p-5">
        <p className="text-sm text-muted">
          Ligue, desligue ou reinicie {label ?? 'a sua VPS'}. A ação é enfileirada e executada
          pelo servidor; acompanhe pela Fila.
        </p>
        <div className="flex gap-2">
          <Button variant="ghost" onClick={() => onPower('start')} disabled={power.isPending || running}>
            <Play className="h-4 w-4" /> Iniciar
          </Button>
          <Button variant="ghost" onClick={() => onPower('restart')} disabled={power.isPending || !running}>
            <RotateCcw className="h-4 w-4" /> Reiniciar
          </Button>
          <Button variant="danger" onClick={() => onPower('stop')} disabled={power.isPending || !running}>
            <Square className="h-4 w-4" /> Parar
          </Button>
        </div>
      </Card>
    </div>
  )
}
