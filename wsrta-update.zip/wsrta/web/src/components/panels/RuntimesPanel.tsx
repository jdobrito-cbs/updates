import { useEffect, useState } from 'react'
import { Check, Code2, Save } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useRuntimes, useSetRuntimes } from '../../api/resources'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')



export function RuntimesPanel({ root, canManage = false }: { root: string; canManage?: boolean }) {
  const { data, isLoading } = useRuntimes(root)
  const setRt = useSetRuntimes(root)
  const toast = useToast()
  const [sel, setSel] = useState<Set<string>>(new Set())

  useEffect(() => {
    
    if (data) setSel(new Set(data.enabled ?? []))
  }, [data])

  if (isLoading || !data) return <Spinner />

  
  const enabled = data.enabled ?? []
  const available = data.available ?? []
  
  const shown = canManage ? available : available.filter((rt) => enabled.includes(rt.key))

  function toggle(key: string) {
    if (!canManage) return
    setSel((prev) => {
      const next = new Set(prev)
      if (next.has(key)) next.delete(key)
      else next.add(key)
      return next
    })
  }

  async function onSave() {
    try {
      await setRt.mutateAsync([...sel])
      toast.push('success', 'linguagens atualizadas — instalando no container (Fila)')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  const dirty = sel.size !== enabled.length || enabled.some((k) => !sel.has(k))

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 font-display text-lg text-ink">
          <Code2 className="h-4 w-4 text-accent" /> Linguagens
        </h2>
        {canManage && (
          <Button onClick={onSave} disabled={!dirty || setRt.isPending}>
            {setRt.isPending ? <Spinner /> : (<><Save className="h-4 w-4" /> Salvar</>)}
          </Button>
        )}
      </div>

      <p className="text-xs text-faint">
        {canManage
          ? 'Libere as linguagens para os domínios deste cliente. Ao salvar, o daemon instala os runtimes no container (acompanhe na Fila).'
          : 'Linguagens disponíveis para os seus domínios (liberadas pelo administrador).'}
      </p>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {}
        <Card className="flex items-center gap-3 p-3">
          <span className="grid h-9 w-9 flex-none place-items-center rounded-lg bg-done/15 text-done">
            <Code2 className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-medium text-ink">PHP</p>
            <p className="text-xs text-done">sempre ativo</p>
          </div>
          <Check className="h-4 w-4 text-done" />
        </Card>

        {shown.map((rt) => {
          const on = sel.has(rt.key)
          return (
            <button
              type="button"
              key={rt.key}
              onClick={() => toggle(rt.key)}
              disabled={!canManage}
              className={`flex items-center gap-3 rounded-xl border border-line bg-panel p-3 text-left shadow-sm transition-colors ${
                canManage ? 'hover:border-accent/60' : 'cursor-default'
              } ${on ? 'ring-1 ring-accent/40' : ''}`}
            >
              <span
                className={`grid h-9 w-9 flex-none place-items-center rounded-lg ${
                  on ? 'bg-accent/15 text-accent' : 'bg-elevated text-faint'
                }`}
              >
                <Code2 className="h-5 w-5" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-ink">{rt.label}</p>
                <p className={`text-xs ${on ? 'text-accent' : 'text-faint'}`}>{on ? 'liberado' : 'desativado'}</p>
              </div>
              {}
              {canManage ? (
                <span
                  className={`relative h-5 w-9 flex-none rounded-full transition-colors ${on ? 'bg-accent' : 'bg-elevated'}`}
                  aria-hidden="true"
                >
                  <span
                    className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-all ${on ? 'left-[1.125rem]' : 'left-0.5'}`}
                  />
                </span>
              ) : (
                on && <Check className="h-4 w-4 text-accent" />
              )}
            </button>
          )
        })}
      </div>

      {}
      {!canManage && shown.length === 0 && (
        <p className="text-sm text-muted">
          Nenhuma linguagem extra liberada ainda — apenas o PHP está ativo. Peça ao administrador para liberar as que
          você precisa.
        </p>
      )}
    </div>
  )
}
