import type { ReactNode } from 'react'
import { Cpu, Database, Globe, HardDrive, MemoryStick } from 'lucide-react'

import { useStats } from '../../api/resources'
import { Card } from '../ui/Card'
import { Spinner } from '../ui/Spinner'
import { StatusBadge } from '../ui/StatusBadge'

export function StatsPanel({ root }: { root: string }) {
  const { data, isLoading } = useStats(root)

  if (isLoading || !data) return <Spinner />

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 text-sm text-muted">
        Status do container: <StatusBadge status={data.status} />
      </div>
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        <StatCard icon={<Cpu className="h-4 w-4" />} label="vCPU" value={data.limits.cpu} />
        <StatCard icon={<MemoryStick className="h-4 w-4" />} label="RAM" value={`${data.limits.ram_mb} MB`} />
        <StatCard icon={<HardDrive className="h-4 w-4" />} label="Disco" value={`${data.limits.disk_mb} MB`} />
        <StatCard icon={<Globe className="h-4 w-4" />} label="Domínios" value={data.counts.domains} />
        <StatCard icon={<Database className="h-4 w-4" />} label="Bancos" value={data.counts.databases} />
      </div>
      <p className="text-xs text-faint">
        Uso vivo por container (CPU/RAM/disco em tempo real) chega quando o daemon coletar métricas.
      </p>
    </div>
  )
}

function StatCard({ icon, label, value }: { icon: ReactNode; label: string; value: ReactNode }) {
  return (
    <Card className="p-4">
      <div className="mb-2 flex items-center gap-1.5 text-xs uppercase tracking-wide text-faint">
        <span className="text-accent">{icon}</span> {label}
      </div>
      <div className="font-mono text-xl text-ink">{value}</div>
    </Card>
  )
}
