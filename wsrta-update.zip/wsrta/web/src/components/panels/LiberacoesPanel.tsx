import { Database, LayoutGrid, ShieldCheck } from 'lucide-react'

import { ApiError } from '../../api/client'
import {
  useDisablePhpMyAdmin,
  useEnablePhpMyAdmin,
  usePhpMyAdmin,
  usePostgres,
  useSetPhpPgAdmin,
  useSetPostgres,
} from '../../api/resources'
import { Card } from '../ui/Card'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

function Toggle({ on, onClick, disabled }: { on: boolean; onClick: () => void; disabled?: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-pressed={on}
      className={`relative h-6 w-11 flex-none rounded-full transition-colors ${on ? 'bg-accent' : 'bg-elevated'} ${
        disabled ? 'opacity-50' : ''
      }`}
    >
      <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${on ? 'left-[1.375rem]' : 'left-0.5'}`} />
    </button>
  )
}



export function LiberacoesPanel({ root }: { root: string }) {
  const pma = usePhpMyAdmin(root)
  const pmaEnable = useEnablePhpMyAdmin(root)
  const pmaDisable = useDisablePhpMyAdmin(root)
  const pg = usePostgres(root)
  const setPg = useSetPostgres(root)
  const setPga = useSetPhpPgAdmin(root)
  const toast = useToast()

  if (pma.isLoading || !pma.data || pg.isLoading || !pg.data) return <Spinner />

  async function togglePma() {
    try {
      pma.data!.enabled ? await pmaDisable.mutateAsync() : await pmaEnable.mutateAsync()
      toast.push('success', 'phpMyAdmin atualizado — aplicando (Fila)')
    } catch (e) {
      toast.push('error', msg(e))
    }
  }
  async function togglePg() {
    try {
      await setPg.mutateAsync(!pg.data!.postgres_enabled)
      toast.push('success', 'PostgreSQL atualizado — aplicando (Fila)')
    } catch (e) {
      toast.push('error', msg(e))
    }
  }
  async function togglePga() {
    try {
      await setPga.mutateAsync(!pg.data!.phppgadmin_enabled)
      toast.push('success', 'phpPgAdmin atualizado (Fila)')
    } catch (e) {
      toast.push('error', msg(e))
    }
  }

  return (
    <Card className="p-5">
      <h3 className="mb-1 flex items-center gap-2 text-sm font-medium text-ink">
        <ShieldCheck className="h-4 w-4 text-accent" /> Liberações
      </h3>
      <p className="mb-3 text-xs text-faint">Libere os gerenciadores e o PostgreSQL para este cliente.</p>
      <div className="space-y-3">
        <div className="flex items-center gap-3">
          <Database className="h-4 w-4 flex-none text-faint" />
          <div className="min-w-0 flex-1">
            <p className="text-sm text-ink">phpMyAdmin</p>
            <p className="text-xs text-faint">Painel web do MariaDB no container.</p>
          </div>
          <Toggle on={pma.data.enabled} onClick={togglePma} disabled={pmaEnable.isPending || pmaDisable.isPending} />
        </div>
        <div className="flex items-center gap-3 border-t border-line pt-3">
          <Database className="h-4 w-4 flex-none text-faint" />
          <div className="min-w-0 flex-1">
            <p className="text-sm text-ink">Servidor PostgreSQL</p>
            <p className="text-xs text-faint">Habilita o PostgreSQL no container — permite criar bancos Postgres.</p>
          </div>
          <Toggle on={pg.data.postgres_enabled} onClick={togglePg} disabled={setPg.isPending} />
        </div>
        <div className="flex items-center gap-3 border-t border-line pt-3">
          <LayoutGrid className="h-4 w-4 flex-none text-faint" />
          <div className="min-w-0 flex-1">
            <p className="text-sm text-ink">phpPgAdmin</p>
            <p className="text-xs text-faint">Painel web do PostgreSQL (requer o servidor ligado).</p>
          </div>
          <Toggle
            on={pg.data.phppgadmin_enabled}
            onClick={togglePga}
            disabled={setPga.isPending || !pg.data.postgres_enabled}
          />
        </div>
      </div>
    </Card>
  )
}
