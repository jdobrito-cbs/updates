import { Container, Play, Power, PowerOff, RotateCcw, Trash2 } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useDisableDocker, useDocker, useDockerControl, useEnableDocker } from '../../api/docker'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { useConfirm } from '../ui/ConfirmDialog'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')




export function DockerPanel({ root }: { root: string }) {
  const { data, isLoading } = useDocker(root)
  const enable = useEnableDocker(root)
  const disable = useDisableDocker(root)
  const control = useDockerControl(root)
  const toast = useToast()
  const confirm = useConfirm()

  if (isLoading || !data) return <Spinner />

  const containers = data.containers ?? []

  async function onEnable() {
    try {
      await enable.mutateAsync()
      toast.push('success', 'habilitando Docker (a VPS reinicia; acompanhe a Fila)')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onDisable() {
    if (!(await confirm({ title: 'Desligar Docker', message: 'Os containers param de rodar. Continuar?', confirmLabel: 'Desligar', danger: true })))
      return
    try {
      await disable.mutateAsync()
      toast.push('success', 'desabilitando Docker (acompanhe a Fila)')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onControl(op: 'start' | 'stop' | 'restart' | 'remove', name: string) {
    if (op !== 'start' && !(await confirm({ title: `${op} container`, message: `${op} ${name}?`, confirmLabel: op, danger: op !== 'restart' })))
      return
    try {
      await control.mutateAsync({ op, name })
      toast.push('success', `${op}: ok`)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-5">
      <h2 className="flex items-center gap-2 font-display text-lg text-ink">
        <Container className="h-4 w-4 text-accent" /> Docker
      </h2>

      <Card className="flex flex-wrap items-center justify-between gap-3 p-5">
        <div className="flex items-center gap-2 text-sm text-muted">
          Status{' '}
          <span className={`rounded-full px-2 py-0.5 text-xs ${data.enabled ? 'bg-done/15 text-done' : 'bg-elevated text-faint'}`}>
            {data.enabled ? 'ligado' : 'desligado'}
          </span>
        </div>
        {data.enabled ? (
          <Button variant="danger" onClick={onDisable} disabled={disable.isPending}>
            <PowerOff className="h-4 w-4" /> Desligar Docker
          </Button>
        ) : (
          <Button onClick={onEnable} disabled={enable.isPending}>
            {enable.isPending ? <Spinner /> : <Power className="h-4 w-4" />} Habilitar Docker
          </Button>
        )}
      </Card>

      {!data.enabled && (
        <p className="text-sm text-muted">
          Habilite o Docker para rodar apps em container (n8n, Evolution API) e gerenciá-los aqui. A VPS reinicia ao habilitar.
        </p>
      )}

      {data.enabled && (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-faint">
                <th className="px-4 py-3 font-medium">Container</th>
                <th className="px-4 py-3 font-medium">Estado</th>
                <th className="px-4 py-3 font-medium">Imagem</th>
                <th className="px-4 py-3 font-medium">Portas</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {containers.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-4 py-6 text-center text-sm text-faint">
                    Nenhum container. Instale um app Docker pela aba Apps.
                  </td>
                </tr>
              )}
              {containers.map((c) => (
                <tr key={c.name} className="border-b border-line/60 last:border-0">
                  <td className="px-4 py-3 text-ink">{c.name}</td>
                  <td className="px-4 py-3">
                    <span className={`rounded-full px-2 py-0.5 text-xs ${c.state === 'running' ? 'bg-done/15 text-done' : 'bg-failed/15 text-failed'}`}>
                      {c.state}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-muted">{c.image}</td>
                  <td className="px-4 py-3 font-mono text-xs text-muted">{c.ports || '—'}</td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-1">
                      <Button variant="ghost" onClick={() => onControl('start', c.name)} disabled={control.isPending} title="Iniciar">
                        <Play className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" onClick={() => onControl('restart', c.name)} disabled={control.isPending} title="Reiniciar">
                        <RotateCcw className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" onClick={() => onControl('stop', c.name)} disabled={control.isPending} title="Parar">
                        <PowerOff className="h-4 w-4" />
                      </Button>
                      <Button variant="danger" onClick={() => onControl('remove', c.name)} disabled={control.isPending} title="Remover">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </div>
  )
}
