import { useState } from 'react'
import type { FormEvent, ReactNode } from 'react'
import { FolderUp, Power } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useDisableSFTP, useEnableSFTP, useSFTPInfo } from '../../api/resources'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { useConfirm } from '../ui/ConfirmDialog'
import { EmptyState } from '../ui/EmptyState'
import { Field } from '../ui/Field'
import { Input } from '../ui/Input'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

export function SftpPanel({ root, canManage }: { root: string; canManage: boolean }) {
  const { data, isLoading } = useSFTPInfo(root)
  const enable = useEnableSFTP(root)
  const disable = useDisableSFTP(root)
  const toast = useToast()
  const confirm = useConfirm()

  const [user, setUser] = useState('site')
  const [password, setPassword] = useState('')

  if (isLoading || !data) return <Spinner />

  async function onEnable(e: FormEvent) {
    e.preventDefault()
    try {
      await enable.mutateAsync({ user, password })
      toast.push('success', 'SFTP sendo habilitado')
      setPassword('')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onDisable() {
    if (!(await confirm({ title: 'Desabilitar SFTP', message: 'Desabilitar o SFTP deste cliente?', confirmLabel: 'Desabilitar', danger: true }))) return
    try {
      await disable.mutateAsync()
      toast.push('success', 'SFTP sendo desabilitado')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="flex items-center gap-2 font-display text-lg text-ink">
        <FolderUp className="h-4 w-4 text-accent" /> SFTP
      </h2>

      {data.enabled ? (
        <Card className="space-y-3 p-5">
          <p className="text-sm text-muted">
            Envie os arquivos do site por <strong className="text-ink">SFTP</strong> com estes dados:
          </p>
          <dl className="grid grid-cols-[7rem_1fr] gap-y-2 text-sm">
            <Row label="Host" value={data.host} />
            <Row label="Porta" value={String(data.port)} />
            <Row label="Usuário" value={data.user} />
            <Row
              label="Senha"
              value={canManage ? 'a que você definiu ao habilitar' : 'a mesma que lhe foi informada'}
              plain
            />
            <Row label="Protocolo" value="SFTP" plain />
          </dl>
          {canManage && (
            <Button variant="danger" onClick={onDisable}>
              <Power className="h-4 w-4" /> Desabilitar SFTP
            </Button>
          )}
        </Card>
      ) : canManage ? (
        <Card className="p-5">
          <form onSubmit={onEnable} className="max-w-sm space-y-3">
            <p className="text-sm text-muted">
              Habilite o SFTP para o cliente enviar os arquivos do site (quando não usa WordPress).
            </p>
            <Field label="usuário">
              <Input value={user} onChange={(e) => setUser(e.target.value)} required />
            </Field>
            <Field label="senha (use a mesma que você deu ao cliente)">
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
              />
            </Field>
            <Button type="submit" disabled={enable.isPending}>
              {enable.isPending ? <Spinner /> : 'Habilitar SFTP'}
            </Button>
          </form>
        </Card>
      ) : (
        <EmptyState
          title="SFTP não habilitado"
          hint="Peça ao administrador para habilitar o SFTP do seu site."
        />
      )}
    </div>
  )
}

function Row({ label, value, plain }: { label: string; value: string; plain?: boolean }) {
  return (
    <>
      <dt className="text-faint">{label}</dt>
      <dd className={plain ? 'text-muted' : 'font-mono text-ink'}>{value as ReactNode}</dd>
    </>
  )
}
