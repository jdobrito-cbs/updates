import { useState } from 'react'
import type { FormEvent } from 'react'
import { Clock, Plus, Trash2 } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useCreateCron, useCron, useDeleteCron } from '../../api/resources'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { useConfirm } from '../ui/ConfirmDialog'
import { EmptyState } from '../ui/EmptyState'
import { Field } from '../ui/Field'
import { Input } from '../ui/Input'
import { Modal } from '../ui/Modal'
import { Spinner } from '../ui/Spinner'
import { StatusBadge } from '../ui/StatusBadge'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

export function CronPanel({ root }: { root: string }) {
  const { data: jobs, isLoading } = useCron(root)
  const create = useCreateCron(root)
  const del = useDeleteCron(root)
  const toast = useToast()
  const confirm = useConfirm()

  const [open, setOpen] = useState(false)
  const [schedule, setSchedule] = useState('0 3 * * *')
  const [command, setCommand] = useState('')
  const [enabled, setEnabled] = useState(true)

  async function onCreate(e: FormEvent) {
    e.preventDefault()
    try {
      await create.mutateAsync({ schedule, command, enabled })
      toast.push('success', 'cron criado')
      setOpen(false)
      setCommand('')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onDelete(id: number) {
    if (!(await confirm({ title: 'Remover cron job', message: 'Remover este cron job?', confirmLabel: 'Remover', danger: true }))) return
    try {
      await del.mutateAsync(id)
      toast.push('success', 'remoção enfileirada')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 font-display text-lg text-ink">
          <Clock className="h-4 w-4 text-accent" /> Cron jobs
        </h2>
        <Button onClick={() => setOpen(true)}>
          <Plus className="h-4 w-4" /> Novo cron
        </Button>
      </div>

      {isLoading && <Spinner />}
      {jobs && jobs.length === 0 && <EmptyState title="Nenhum cron job" hint="Agende um comando no container." />}

      {jobs && jobs.length > 0 && (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-faint">
                <th className="px-4 py-3 font-medium">Agenda</th>
                <th className="px-4 py-3 font-medium">Comando</th>
                <th className="px-4 py-3 font-medium">Estado</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {jobs.map((j) => (
                <tr key={j.id} className="border-b border-line/60 last:border-0">
                  <td className="px-4 py-3 font-mono text-ink">{j.schedule}</td>
                  <td className="max-w-xs truncate px-4 py-3 font-mono text-xs text-muted" title={j.command}>
                    {j.command}
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge status={j.enabled ? 'active' : 'suspended'} />
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Button variant="danger" onClick={() => onDelete(j.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Novo cron job">
        <form onSubmit={onCreate} className="space-y-3">
          <Field label="agenda (crontab ou @daily)">
            <Input value={schedule} onChange={(e) => setSchedule(e.target.value)} required />
          </Field>
          <Field label="comando">
            <Input value={command} onChange={(e) => setCommand(e.target.value)} placeholder="php /var/www/cron.php" required />
          </Field>
          <label className="flex items-center gap-2 text-sm text-muted">
            <input type="checkbox" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} />
            habilitado
          </label>
          <div className="flex justify-end gap-2 pt-1">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={create.isPending}>
              {create.isPending ? <Spinner /> : 'Criar'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
