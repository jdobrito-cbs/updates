import { useState } from 'react'
import type { FormEvent } from 'react'
import { Boxes, Container, Download, RefreshCw, Trash2 } from 'lucide-react'

import { ApiError } from '../../api/client'
import type { CatalogApp } from '../../api/apps'
import { useApps, useInstallApp, useRemoveApp, useUpdateApp } from '../../api/apps'
import { useDomains } from '../../api/resources'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { useConfirm } from '../ui/ConfirmDialog'
import { EmptyState } from '../ui/EmptyState'
import { Field } from '../ui/Field'
import { Input } from '../ui/Input'
import { Modal } from '../ui/Modal'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

function StatusPill({ status }: { status: string }) {
  const cls =
    status === 'active'
      ? 'bg-done/15 text-done'
      : status === 'failed'
        ? 'bg-failed/15 text-failed'
        : 'bg-pending/15 text-pending'
  return <span className={`rounded-full px-2 py-0.5 text-xs ${cls}`}>{status}</span>
}




export function AppsPanel({ root }: { root: string }) {
  const { data, isLoading } = useApps(root)
  const domains = useDomains(root)
  const install = useInstallApp(root)
  const remove = useRemoveApp(root)
  const update = useUpdateApp(root)
  const toast = useToast()
  const confirm = useConfirm()

  const [app, setApp] = useState<CatalogApp | null>(null)
  const [domainId, setDomainId] = useState('')
  const [path, setPath] = useState('')

  if (isLoading || !data) return <Spinner />

  const catalog = data.catalog ?? []
  const installed = data.installed ?? []
  const doms = domains.data ?? []

  function openInstall(a: CatalogApp) {
    setApp(a)
    setDomainId(doms[0] ? String(doms[0].id) : '')
    setPath('')
  }

  async function onInstall(e: FormEvent) {
    e.preventDefault()
    if (!app) return
    try {
      await install.mutateAsync({
        app_slug: app.slug,
        domain_id: app.kind === 'php' ? Number(domainId) || 0 : undefined,
        path: app.kind === 'php' ? path : undefined,
      })
      toast.push('success', `${app.name}: instalação enfileirada`)
      setApp(null)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  
  async function onInstallDocker(a: CatalogApp) {
    try {
      await install.mutateAsync({ app_slug: a.slug })
      toast.push('success', `${a.name}: instalação enfileirada`)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onUpdate(id: number, name: string) {
    try {
      await update.mutateAsync(id)
      toast.push('success', `${name}: atualização enfileirada`)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onRemove(id: number, name: string) {
    if (!(await confirm({ title: 'Remover app', message: `Remover ${name}? Arquivos e banco serão apagados.`, confirmLabel: 'Remover', danger: true })))
      return
    try {
      await remove.mutateAsync(id)
      toast.push('success', 'remoção enfileirada')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-5">
      <h2 className="flex items-center gap-2 font-display text-lg text-ink">
        <Boxes className="h-4 w-4 text-accent" /> Apps
      </h2>

      {catalog.length === 0 ? (
        <EmptyState title="Nenhum app liberado" hint="O administrador (ou a revenda) ainda não liberou apps para você." />
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {catalog.map((a) => (
            <Card key={a.slug} className="flex flex-col gap-2 p-4">
              <div className="flex items-center gap-2">
                {a.kind === 'docker' ? <Container className="h-4 w-4 text-accent" /> : <Boxes className="h-4 w-4 text-accent" />}
                <span className="font-medium text-ink">{a.name}</span>
                <span className="ml-auto rounded-full bg-elevated px-2 py-0.5 text-[10px] uppercase text-faint">{a.kind}</span>
              </div>
              <p className="text-xs text-muted">{a.description}</p>
              {a.kind === 'php' ? (
                <Button variant="ghost" className="mt-auto" onClick={() => openInstall(a)} disabled={doms.length === 0}>
                  <Download className="h-4 w-4" /> {doms.length === 0 ? 'crie um domínio antes' : 'Instalar'}
                </Button>
              ) : (
                <Button variant="ghost" className="mt-auto" onClick={() => onInstallDocker(a)} disabled={install.isPending}>
                  <Container className="h-4 w-4" /> Instalar (Docker)
                </Button>
              )}
            </Card>
          ))}
        </div>
      )}

      <div>
        <h3 className="mb-2 text-sm font-medium text-muted">Instalados</h3>
        {installed.length === 0 ? (
          <p className="text-sm text-faint">Nenhum app instalado.</p>
        ) : (
          <Card className="overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-faint">
                  <th className="px-4 py-3 font-medium">App</th>
                  <th className="px-4 py-3 font-medium">Onde</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3" />
                </tr>
              </thead>
              <tbody>
                {installed.map((i) => (
                  <tr key={i.id} className="border-b border-line/60 last:border-0">
                    <td className="px-4 py-3 text-ink">{i.app_slug}</td>
                    <td className="px-4 py-3 text-xs text-muted">
                      {i.kind === 'php' ? `${i.fqdn ?? ''}${i.path ? '/' + i.path : ''}` : i.container_name || 'docker'}
                    </td>
                    <td className="px-4 py-3"><StatusPill status={i.status} /></td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex justify-end gap-2">
                        {(i.kind === 'docker' || i.app_slug === 'phpbb') && (
                          <Button
                            variant="ghost"
                            onClick={() => onUpdate(i.id, i.app_slug)}
                            disabled={update.isPending}
                            title={i.kind === 'docker' ? 'Atualizar (pull da imagem + recria)' : 'Atualizar o phpBB (conclua a migração no navegador)'}
                          >
                            <RefreshCw className="h-4 w-4" /> Atualizar
                          </Button>
                        )}
                        <Button variant="danger" onClick={() => onRemove(i.id, i.app_slug)} title="Remover">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Card>
        )}
      </div>

      <Modal open={app !== null} onClose={() => setApp(null)} title={app ? `Instalar ${app.name}` : ''}>
        <form onSubmit={onInstall} className="space-y-3">
          <Field label="domínio">
            <select
              value={domainId}
              onChange={(e) => setDomainId(e.target.value)}
              className="w-full rounded-lg border border-line bg-base px-3 py-2 text-sm text-ink"
              required
            >
              {doms.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.fqdn}
                </option>
              ))}
            </select>
          </Field>
          <Field label="subpasta (opcional; vazio = raiz)">
            <Input value={path} onChange={(e) => setPath(e.target.value)} placeholder="forum" />
          </Field>
          <p className="text-xs text-faint">
            Após instalar, conclua a configuração do app pelo navegador (ex.: phpBB abre o assistente em /install).
          </p>
          <div className="flex justify-end gap-2 pt-1">
            <Button type="button" variant="ghost" onClick={() => setApp(null)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={install.isPending}>
              {install.isPending ? <Spinner /> : 'Instalar'}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
