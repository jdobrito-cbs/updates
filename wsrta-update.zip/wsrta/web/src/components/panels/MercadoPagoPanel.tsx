import { useState } from 'react'
import { CreditCard, ShoppingCart } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useMPConfig, useOrders, useSetMPToken } from '../../api/resources'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { Field } from '../ui/Field'
import { Input } from '../ui/Input'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')
const brl = (c: number) => (c / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
const statusColor: Record<string, string> = { paid: 'text-done', pending: 'text-running', failed: 'text-failed' }



export function MercadoPagoPanel({ root }: { root: string }) {
  const cfg = useMPConfig(root)
  const save = useSetMPToken(root)
  const orders = useOrders(root)
  const toast = useToast()
  const [token, setToken] = useState('')

  async function onSave() {
    try {
      await save.mutateAsync(token.trim())
      toast.push('success', 'token salvo')
      setToken('')
    } catch (e) {
      toast.push('error', msg(e))
    }
  }

  const list = orders.data ?? []

  return (
    <div className="space-y-4">
      <Card className="space-y-3 p-5">
        <h3 className="flex items-center gap-2 text-sm font-medium text-ink">
          <CreditCard className="h-4 w-4 text-accent" /> MercadoPago
          {cfg.data && (
            <span className={`ml-2 rounded-full px-2 py-0.5 text-[11px] ${cfg.data.configured ? 'bg-done/15 text-done' : 'bg-elevated text-muted'}`}>
              {cfg.data.configured ? 'configurado' : 'não configurado'}
            </span>
          )}
        </h3>
        <p className="text-xs text-faint">
          Cole o <strong>Access Token</strong> do MercadoPago (Suas integrações → credenciais de produção). Com ele, os
          botões "Assinar" da sua landpage levam o cliente ao checkout. Deixe vazio para desativar.
        </p>
        <div className="flex items-end gap-2">
          <Field label="Access Token">
            <Input type="password" value={token} onChange={(e) => setToken(e.target.value)} placeholder="APP_USR-…" autoComplete="off" />
          </Field>
          <Button onClick={onSave} disabled={save.isPending}>
            {save.isPending ? <Spinner /> : 'Salvar'}
          </Button>
        </div>
      </Card>

      <Card className="p-5">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-medium text-ink">
          <ShoppingCart className="h-4 w-4 text-accent" /> Vendas ({list.length})
        </h3>
        {orders.isLoading ? (
          <Spinner />
        ) : list.length === 0 ? (
          <p className="text-sm text-faint">Nenhuma venda ainda.</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-faint">
                <th className="px-2 py-2 font-medium">Cliente</th>
                <th className="px-2 py-2 font-medium">Pacote</th>
                <th className="px-2 py-2 font-medium">Valor</th>
                <th className="px-2 py-2 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {list.map((o) => (
                <tr key={o.id} className="border-b border-line/60 last:border-0">
                  <td className="px-2 py-2 text-muted">{o.buyer_email}</td>
                  <td className="px-2 py-2 text-ink">{o.package_name || '—'}</td>
                  <td className="px-2 py-2 font-mono text-xs text-muted">{brl(o.amount_cents)}</td>
                  <td className={`px-2 py-2 text-xs font-medium ${statusColor[o.status] ?? 'text-muted'}`}>{o.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </div>
  )
}
