import { useEffect, useState } from 'react'
import type { FormEvent } from 'react'
import { ExternalLink, KeyRound, Link2, LogIn, Newspaper, Plus, ShieldCheck, SlidersHorizontal, Trash2 } from 'lucide-react'

import { ApiError } from '../../api/client'
import {
  useAssociateWordPress,
  useDomains,
  useHardenWordPress,
  useInstallWordPress,
  useRemoveWordPress,
  useWordPress,
  useWPManager,
  useWPSetPassword,
} from '../../api/resources'
import type { WordPressInstall } from '../../api/resources'
import type { Domain } from '../../api/types'
import { formatTime } from '../../lib/format'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { useConfirm } from '../ui/ConfirmDialog'
import { EmptyState } from '../ui/EmptyState'
import { Field } from '../ui/Field'
import { Input } from '../ui/Input'
import { Modal } from '../ui/Modal'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'
import { WordPressManager } from './WordPressManager'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')
const selectCls = 'w-full rounded-md border border-line bg-base px-3 py-1.5 text-sm text-ink'

function siteURL(i: WordPressInstall): string {
  return `http://${i.fqdn}${i.path ? '/' + i.path : ''}`
}


function wpAdminURL(i: WordPressInstall): string {
  return `${siteURL(i)}/wp-admin/`
}

export function WordPressPanel({ root }: { root: string }) {
  const { data: installs, isLoading } = useWordPress(root)
  const { data: domains } = useDomains(root)
  const install = useInstallWordPress(root)
  const remove = useRemoveWordPress(root)
  const harden = useHardenWordPress(root)
  const toast = useToast()
  const confirm = useConfirm()

  const [open, setOpen] = useState(false)
  const [assocOpen, setAssocOpen] = useState(false)
  const [pwdInstall, setPwdInstall] = useState<WordPressInstall | null>(null)
  const [manageInstall, setManageInstall] = useState<WordPressInstall | null>(null)
  const [domainId, setDomainId] = useState(0)
  const [path, setPath] = useState('')
  const [title, setTitle] = useState('')
  const [adminUser, setAdminUser] = useState('admin')
  const [adminEmail, setAdminEmail] = useState('')
  const [adminPassword, setAdminPassword] = useState('')

  useEffect(() => {
    if (domainId === 0 && domains && domains.length > 0) setDomainId(domains[0].id)
  }, [domains, domainId])

  if (domains && domains.length === 0) {
    return <EmptyState title="Sem domínios" hint="Crie um domínio para instalar o WordPress." />
  }

  async function onInstall(e: FormEvent) {
    e.preventDefault()
    try {
      await install.mutateAsync({
        domain_id: domainId,
        path: path.trim(),
        title,
        admin_user: adminUser,
        admin_email: adminEmail,
        admin_password: adminPassword,
      })
      toast.push('success', 'instalação do WordPress enfileirada')
      setOpen(false)
      setPath('')
      setTitle('')
      setAdminPassword('')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onRemove(i: WordPressInstall) {
    if (
      !(await confirm({
        title: 'Remover WordPress',
        message: `Remover o WordPress de ${siteURL(i)}? Arquivos e banco serão apagados.`,
        confirmLabel: 'Remover',
        danger: true,
      }))
    )
      return
    try {
      await remove.mutateAsync(i.id)
      toast.push('success', 'remoção enfileirada')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 font-display text-lg text-ink">
          <Newspaper className="h-4 w-4 text-accent" /> WordPress
        </h2>
        <div className="flex gap-2">
          <Button variant="ghost" onClick={() => setAssocOpen(true)} title="Detectar um WordPress já existente (importado/recuperado) e gerenciá-lo">
            <Link2 className="h-4 w-4" /> Associar existente
          </Button>
          <Button onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4" /> Instalar
          </Button>
        </div>
      </div>

      {isLoading && <Spinner />}
      {installs && installs.length === 0 && (
        <EmptyState title="Nenhuma instalação" hint="Instale o WordPress na raiz ou numa subpasta do domínio." />
      )}

      {installs && installs.length > 0 && (
        <Card className="overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left text-xs uppercase tracking-wide text-faint">
                <th className="px-4 py-3 font-medium">Site</th>
                <th className="px-4 py-3 font-medium">Admin</th>
                <th className="px-4 py-3 font-medium">Criado</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {installs.map((i) => (
                <tr key={i.id} className="border-b border-line/60 last:border-0">
                  <td className="px-4 py-3">
                    <a
                      href={siteURL(i)}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 font-mono text-accent hover:underline"
                    >
                      {i.fqdn}
                      {i.path ? '/' + i.path : ''}
                      <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-muted">{i.admin_user}</td>
                  <td className="px-4 py-3 font-mono text-xs text-muted">{formatTime(i.created_at)}</td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-2">
                      <Button
                        variant="ghost"
                        title="Abrir a área de login do admin (wp-admin)"
                        onClick={() => window.open(wpAdminURL(i), '_blank', 'noopener,noreferrer')}
                      >
                        <LogIn className="h-4 w-4" /> wp-admin
                      </Button>
                      <Button variant="ghost" onClick={() => setPwdInstall(i)} title="Trocar a senha do admin do WordPress">
                        <KeyRound className="h-4 w-4" /> Senha
                      </Button>
                      <Button variant="ghost" onClick={() => setManageInstall(i)}>
                        <SlidersHorizontal className="h-4 w-4" /> Gerenciar
                      </Button>
                      <Button
                        variant="ghost"
                        title="Proteger contra enumeração de usuários (CVE-2017-5487)"
                        onClick={async () => {
                          try {
                            await harden.mutateAsync(i.id)
                            toast.push('success', 'proteção do WordPress enfileirada')
                          } catch (e) {
                            toast.push('error', msg(e))
                          }
                        }}
                      >
                        <ShieldCheck className="h-4 w-4" /> Proteger
                      </Button>
                      <Button variant="danger" onClick={() => onRemove(i)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Instalar WordPress">
        <form onSubmit={onInstall} className="space-y-3">
          <Field label="domínio">
            <select className={selectCls} value={domainId} onChange={(e) => setDomainId(Number(e.target.value))}>
              {(domains ?? []).map((d) => (
                <option key={d.id} value={d.id}>
                  {d.fqdn}
                </option>
              ))}
            </select>
          </Field>
          <Field label="subpasta (vazio = raiz)">
            <Input value={path} onChange={(e) => setPath(e.target.value)} placeholder="blog" />
          </Field>
          <Field label="título do site">
            <Input value={title} onChange={(e) => setTitle(e.target.value)} required />
          </Field>
          <Field label="usuário admin">
            <Input value={adminUser} onChange={(e) => setAdminUser(e.target.value)} required />
          </Field>
          <Field label="email do admin">
            <Input type="email" value={adminEmail} onChange={(e) => setAdminEmail(e.target.value)} required />
          </Field>
          <Field label="senha do admin">
            <Input type="password" value={adminPassword} onChange={(e) => setAdminPassword(e.target.value)} required minLength={6} />
          </Field>
          <div className="flex justify-end gap-2 pt-1">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={install.isPending}>
              {install.isPending ? <Spinner /> : 'Instalar'}
            </Button>
          </div>
        </form>
      </Modal>

      {assocOpen && (
        <WPAssociateModal root={root} domains={domains ?? []} onClose={() => setAssocOpen(false)} />
      )}

      {pwdInstall && (
        <WPPasswordModal root={root} install={pwdInstall} onClose={() => setPwdInstall(null)} />
      )}

      {manageInstall && (
        <WordPressManager root={root} install={manageInstall} onClose={() => setManageInstall(null)} />
      )}
    </div>
  )
}




function WPPasswordModal({ root, install, onClose }: { root: string; install: WordPressInstall; onClose: () => void }) {
  const { data: info, isLoading } = useWPManager(root, install.id)
  const setPwd = useWPSetPassword(root, install.id)
  const toast = useToast()
  const [login, setLogin] = useState(install.admin_user || '')
  const [password, setPassword] = useState('')
  const admins = info?.admins ?? []

  useEffect(() => {
    if (!login && admins.length > 0) setLogin(admins[0].user_login)
  }, [admins, login])

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    try {
      await setPwd.mutateAsync({ user_login: login.trim(), new_password: password })
      toast.push('success', 'senha do admin do WordPress atualizada')
      onClose()
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <Modal open onClose={onClose} title="Trocar senha do admin do WordPress">
      <form onSubmit={onSubmit} className="space-y-3">
        <p className="text-xs text-faint">{siteURL(install)}</p>
        <Field label="administrador">
          {admins.length > 0 ? (
            <select className={selectCls} value={login} onChange={(e) => setLogin(e.target.value)}>
              {admins.map((a) => (
                <option key={a.ID} value={a.user_login}>
                  {a.user_login}
                  {a.user_email ? ` (${a.user_email})` : ''}
                </option>
              ))}
            </select>
          ) : (
            <Input value={login} onChange={(e) => setLogin(e.target.value)} placeholder="admin" required />
          )}
        </Field>
        {isLoading && <p className="text-xs text-faint">carregando administradores…</p>}
        {!isLoading && admins.length === 0 && (
          <p className="text-xs text-faint">
            Não foi possível listar os administradores automaticamente — informe o usuário do WordPress manualmente.
          </p>
        )}
        <Field label="nova senha (mín. 6)">
          <Input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            minLength={6}
            autoComplete="new-password"
          />
        </Field>
        <div className="flex justify-end gap-2 pt-1">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancelar
          </Button>
          <Button type="submit" disabled={setPwd.isPending}>
            {setPwd.isPending ? <Spinner /> : 'Atualizar senha'}
          </Button>
        </div>
      </form>
    </Modal>
  )
}



function WPAssociateModal({ root, domains, onClose }: { root: string; domains: Domain[]; onClose: () => void }) {
  const assoc = useAssociateWordPress(root)
  const toast = useToast()
  const [domainId, setDomainId] = useState(domains[0]?.id ?? 0)
  const [path, setPath] = useState('')

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    try {
      await assoc.mutateAsync({ domain_id: domainId, path: path.trim() })
      toast.push('success', 'WordPress detectado e associado')
      onClose()
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <Modal open onClose={onClose} title="Associar WordPress existente">
      <form onSubmit={onSubmit} className="space-y-3">
        <p className="text-xs text-faint">
          Detecta um WordPress já presente no docroot (ex.: importado/recuperado) e o registra para gerenciá-lo.
        </p>
        <Field label="domínio">
          <select className={selectCls} value={domainId} onChange={(e) => setDomainId(Number(e.target.value))}>
            {domains.map((d) => (
              <option key={d.id} value={d.id}>
                {d.fqdn}
              </option>
            ))}
          </select>
        </Field>
        <Field label="subpasta (vazio = raiz)">
          <Input value={path} onChange={(e) => setPath(e.target.value)} placeholder="blog" />
        </Field>
        <div className="flex justify-end gap-2 pt-1">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancelar
          </Button>
          <Button type="submit" disabled={assoc.isPending}>
            {assoc.isPending ? <Spinner /> : 'Detectar e associar'}
          </Button>
        </div>
      </form>
    </Modal>
  )
}
