import { useEffect, useRef, useState } from 'react'
import type { FormEvent } from 'react'
import { createPortal } from 'react-dom'
import { Ban, Eye, Globe, Lock, Plus, Server, ShieldCheck, SlidersHorizontal, Trash2, Unlock, Waypoints, Wrench } from 'lucide-react'

import { ApiError } from '../../api/client'
import {
  useCreateDomain,
  useDeleteDomain,
  useDomains,
  useIssueSSL,
  useSetDomainOffline,
  useSetDomainPHP,
} from '../../api/resources'
import { formatTime } from '../../lib/format'
import type { Domain } from '../../api/types'
import { Button } from '../ui/Button'
import { Card } from '../ui/Card'
import { useConfirm } from '../ui/ConfirmDialog'
import { ForwardsEditor } from './ForwardsEditor'
import { SiteRulesEditor } from './SiteRulesEditor'
import { EmptyState } from '../ui/EmptyState'
import { Field } from '../ui/Field'
import { Input } from '../ui/Input'
import { Modal } from '../ui/Modal'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')





function domainURL(d: Domain): string {
  return `${d.ssl_enabled ? 'https' : 'http'}://${d.fqdn}`
}
function serverPreviewURL(d: Domain): string {
  return `${window.location.origin}/_preview/${d.fqdn}/`
}



function ViewMenu({ domain }: { domain: Domain }) {
  const [open, setOpen] = useState(false)
  const [pos, setPos] = useState({ top: 0, left: 0 })
  const wrapRef = useRef<HTMLDivElement>(null)
  const menuRef = useRef<HTMLDivElement>(null)
  const WIDTH = 244

  function toggle() {
    if (!open && wrapRef.current) {
      const r = wrapRef.current.getBoundingClientRect()
      setPos({ top: r.bottom + 6, left: Math.max(8, r.right - WIDTH) })
    }
    setOpen((o) => !o)
  }

  useEffect(() => {
    if (!open) return
    function onDoc(e: MouseEvent) {
      const t = e.target as Node
      if (menuRef.current?.contains(t) || wrapRef.current?.contains(t)) return
      setOpen(false)
    }
    function close() {
      setOpen(false)
    }
    document.addEventListener('mousedown', onDoc)
    window.addEventListener('resize', close)
    window.addEventListener('scroll', close, true)
    return () => {
      document.removeEventListener('mousedown', onDoc)
      window.removeEventListener('resize', close)
      window.removeEventListener('scroll', close, true)
    }
  }, [open])

  return (
    <div ref={wrapRef} className="inline-flex">
      <Button variant="ghost" className="px-2.5 py-1.5 text-xs" title="Visualizar" onClick={toggle}>
        <Eye className="h-3.5 w-3.5" /> Ver
      </Button>
      {open &&
        createPortal(
          <div
            ref={menuRef}
            style={{ position: 'fixed', top: pos.top, left: pos.left, width: WIDTH }}
            className="z-[100] overflow-hidden rounded-lg border border-line bg-panel shadow-2xl shadow-black/40"
          >
            <a
              href={domainURL(domain)}
              target="_blank"
              rel="noreferrer"
              onClick={() => setOpen(false)}
              className="flex items-start gap-2.5 px-3 py-2.5 text-left text-sm text-ink hover:bg-elevated"
            >
              <Globe className="mt-0.5 h-4 w-4 flex-none text-accent" />
              <span>
                Pelo domínio
                <span className="block truncate font-mono text-xs text-faint">{domain.fqdn}</span>
              </span>
            </a>
            <a
              href={serverPreviewURL(domain)}
              target="_blank"
              rel="noreferrer"
              onClick={() => setOpen(false)}
              className="flex items-start gap-2.5 border-t border-line px-3 py-2.5 text-left text-sm text-ink hover:bg-elevated"
            >
              <Server className="mt-0.5 h-4 w-4 flex-none text-accent" />
              <span>
                Pelo servidor (preview)
                <span className="block text-xs text-faint">redirecionamento interno, sem o DNS</span>
              </span>
            </a>
          </div>,
          document.body,
        )}
    </div>
  )
}


const PHP_VERSIONS = ['8.1', '8.2', '8.3', '8.4']



export function DomainsPanel({ root, canManage = false }: { root: string; canManage?: boolean }) {
  const { data: domains, isLoading } = useDomains(root)
  const create = useCreateDomain(root)
  const del = useDeleteDomain(root)
  const ssl = useIssueSSL(root)
  const php = useSetDomainPHP(root)
  const offline = useSetDomainOffline(root)
  const toast = useToast()
  const confirm = useConfirm()

  const [open, setOpen] = useState(false)
  const [fqdn, setFqdn] = useState('')
  const [upstream, setUpstream] = useState('')
  const [rulesDomain, setRulesDomain] = useState<Domain | null>(null)
  const [forwardsDomain, setForwardsDomain] = useState<Domain | null>(null)

  async function onCreate(e: FormEvent) {
    e.preventDefault()
    try {
      await create.mutateAsync({ fqdn, upstream: upstream.trim() || undefined })
      toast.push('success', `domínio ${fqdn} adicionado`)
      setOpen(false)
      setFqdn('')
      setUpstream('')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onDelete(id: number, name: string) {
    if (!(await confirm({ title: 'Remover domínio', message: `Remover o domínio ${name}? Os vhosts (proxy/site) são removidos.`, confirmLabel: 'Remover', danger: true }))) return
    
    const alsoFiles = await confirm({
      title: 'Apagar os arquivos do site?',
      message: `Apagar também a pasta do site (docroot) de ${name}? Isto é IRREVERSÍVEL. Escolha "Manter arquivos" para preservá-los.`,
      confirmLabel: 'Apagar arquivos',
      cancelLabel: 'Manter arquivos',
      danger: true,
    })
    try {
      await del.mutateAsync({ id, deleteFiles: alsoFiles })
      toast.push('success', alsoFiles ? 'remoção enfileirada (arquivos serão apagados)' : 'remoção enfileirada (arquivos preservados)')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onChangePHP(d: Domain, version: string) {
    if (version === d.php_version) return
    try {
      await php.mutateAsync({ id: d.id, version })
      toast.push('success', `PHP ${version} enfileirado para ${d.fqdn}`)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onOffline(d: Domain, mode: string) {
    try {
      await offline.mutateAsync({ id: d.id, mode })
      const label = mode === 'maintenance' ? 'manutenção' : mode === 'suspended' ? 'suspensão' : 'reativação'
      toast.push('success', `${label} de ${d.fqdn} enfileirada`)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onSSL(id: number, name: string) {
    try {
      await ssl.mutateAsync(id)
      toast.push('success', `emissão de SSL para ${name} enfileirada`)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 font-display text-lg text-ink">
          <Globe className="h-4 w-4 text-accent" /> Domínios
        </h2>
        {canManage && (
          <Button onClick={() => setOpen(true)}>
            <Plus className="h-4 w-4" /> Novo domínio
          </Button>
        )}
      </div>

      {isLoading && <Spinner />}
      {domains && domains.length === 0 && (
        <EmptyState
          title="Nenhum domínio"
          hint={
            canManage
              ? 'Adicione um domínio para criar o vhost e o reverse-proxy.'
              : 'Os domínios são criados pelo administrador. Quando houver um para você, ele aparece aqui.'
          }
        />
      )}

      {domains && domains.length > 0 && (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {domains.map((d) => (
            <Card
              key={d.id}
              className="flex flex-col gap-3 p-4 transition-all hover:-translate-y-0.5 hover:border-accent/40"
            >
              {}
              <div className="flex items-start gap-3">
                <div className="flex h-10 w-10 flex-none items-center justify-center rounded-xl bg-accent/15 text-accent">
                  <Globe className="h-5 w-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium text-ink" title={d.fqdn}>
                    {d.fqdn}
                  </p>
                  <p className="text-xs text-faint">criado {formatTime(d.created_at)}</p>
                </div>
              </div>

              {}
              {d.upstream_ip && (
                <div
                  className="flex items-center gap-1.5 rounded-lg bg-elevated px-2.5 py-1.5 text-xs text-accent"
                  title="Proxy para um servidor externo"
                >
                  <Waypoints className="h-3.5 w-3.5 flex-none" />
                  <span className="truncate font-mono">
                    → {d.upstream_ip}
                    {d.upstream_port && d.upstream_port !== 80 ? `:${d.upstream_port}` : ''}
                    {d.upstream_path}
                  </span>
                </div>
              )}

              {}
              <div className="flex flex-wrap items-center gap-2">
                {d.ssl_enabled ? (
                  <span className="inline-flex items-center gap-1 rounded-full bg-done/15 px-2.5 py-1 text-xs font-medium text-done">
                    <Lock className="h-3.5 w-3.5" /> SSL ativo
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 rounded-full bg-elevated px-2.5 py-1 text-xs font-medium text-faint">
                    <Unlock className="h-3.5 w-3.5" /> sem SSL
                  </span>
                )}
                <label
                  className="inline-flex items-center gap-1.5 rounded-full bg-elevated px-2.5 py-1 font-mono text-xs text-muted"
                  title="Trocar a versão do PHP deste domínio (instala sob demanda no container)"
                >
                  <span className="text-faint">PHP</span>
                  <select
                    value={d.php_version}
                    onChange={(e) => onChangePHP(d, e.target.value)}
                    className="cursor-pointer bg-transparent text-muted outline-none"
                  >
                    {!PHP_VERSIONS.includes(d.php_version) && d.php_version && (
                      <option value={d.php_version}>{d.php_version}</option>
                    )}
                    {PHP_VERSIONS.map((v) => (
                      <option key={v} value={v} className="bg-panel text-ink">
                        {v}
                      </option>
                    ))}
                  </select>
                </label>
                {d.offline_mode === 'maintenance' && (
                  <span className="inline-flex items-center gap-1 rounded-full bg-pending/15 px-2.5 py-1 text-xs font-medium text-pending">
                    <Wrench className="h-3.5 w-3.5" /> Em manutenção
                  </span>
                )}
                {d.offline_mode === 'suspended' && (
                  <span className="inline-flex items-center gap-1 rounded-full bg-failed/15 px-2.5 py-1 text-xs font-medium text-failed">
                    <Ban className="h-3.5 w-3.5" /> Suspenso
                  </span>
                )}
              </div>

              {}
              <div className="mt-auto flex flex-wrap items-center gap-1.5 border-t border-line pt-3">
                <ViewMenu domain={d} />
                <Button variant="ghost" className="px-2.5 py-1.5 text-xs" onClick={() => onSSL(d.id, d.fqdn)}>
                  <ShieldCheck className="h-3.5 w-3.5" /> SSL
                </Button>
                <Button variant="ghost" className="px-2.5 py-1.5 text-xs" onClick={() => setRulesDomain(d)}>
                  <SlidersHorizontal className="h-3.5 w-3.5" /> Regras
                </Button>
                <Button
                  variant="ghost"
                  className={`px-2.5 py-1.5 text-xs${d.offline_mode === 'maintenance' ? ' text-pending' : ''}`}
                  onClick={() => onOffline(d, d.offline_mode === 'maintenance' ? '' : 'maintenance')}
                  title="Coloca/tira o site em página de manutenção (503)"
                >
                  <Wrench className="h-3.5 w-3.5" /> Manutenção
                </Button>
                <Button
                  variant="ghost"
                  className={`px-2.5 py-1.5 text-xs${d.offline_mode === 'suspended' ? ' text-failed' : ''}`}
                  onClick={() => onOffline(d, d.offline_mode === 'suspended' ? '' : 'suspended')}
                  title="Suspende/reativa o site (página 503)"
                >
                  <Ban className="h-3.5 w-3.5" /> Suspensão
                </Button>
                {canManage && (
                  <Button
                    variant="ghost"
                    className="px-2.5 py-1.5 text-xs"
                    onClick={() => setForwardsDomain(d)}
                    title="Encaminhamentos por caminho"
                  >
                    <Waypoints className="h-3.5 w-3.5" /> Caminhos
                  </Button>
                )}
                {canManage && (
                  <Button
                    variant="danger"
                    className="ml-auto px-2.5 py-1.5 text-xs"
                    onClick={() => onDelete(d.id, d.fqdn)}
                    title="Remover domínio"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal open={open && canManage} onClose={() => setOpen(false)} title="Novo domínio">
        <form onSubmit={onCreate} className="space-y-3">
          <Field label="fqdn">
            <Input value={fqdn} onChange={(e) => setFqdn(e.target.value)} placeholder="exemplo.com" required />
          </Field>
          <div className="rounded-lg border border-line bg-elevated/40 p-3">
            <Field label="Servidor de destino (opcional)">
              <Input
                value={upstream}
                onChange={(e) => setUpstream(e.target.value)}
                placeholder="ex.: 10.0.0.5:8080, app.outro.com, outro.com/local"
              />
            </Field>
            <p className="mt-1 text-xs text-faint">
              Preencha para apontar este domínio/subdomínio a outro servidor em vez do container — pode ser um IP, um
              domínio, um subdomínio, com porta e/ou caminho (host[:porta][/caminho]). Cada subdomínio é um domínio
              próprio e pode ir para um destino diferente.
            </p>
          </div>
          <div className="flex justify-end gap-2 pt-1">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={create.isPending}>
              {create.isPending ? <Spinner /> : 'Adicionar'}
            </Button>
          </div>
        </form>
      </Modal>

      {forwardsDomain && (
        <ForwardsEditor root={root} domain={forwardsDomain} onClose={() => setForwardsDomain(null)} />
      )}

      {rulesDomain && (
        <SiteRulesEditor root={root} domain={rulesDomain} onClose={() => setRulesDomain(null)} />
      )}
    </div>
  )
}
