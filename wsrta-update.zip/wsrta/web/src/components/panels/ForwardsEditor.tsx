import { useState } from 'react'
import type { FormEvent } from 'react'
import { ArrowRight, Plus, Trash2 } from 'lucide-react'

import { ApiError } from '../../api/client'
import { useCreateForward, useDeleteForward, useForwards } from '../../api/resources'
import type { Domain } from '../../api/types'
import { Button } from '../ui/Button'
import { useConfirm } from '../ui/ConfirmDialog'
import { Field } from '../ui/Field'
import { Input } from '../ui/Input'
import { Modal } from '../ui/Modal'
import { Spinner } from '../ui/Spinner'
import { useToast } from '../ui/Toast'

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')



export function ForwardsEditor({ root, domain, onClose }: { root: string; domain: Domain; onClose: () => void }) {
  const { data: forwards, isLoading } = useForwards(root, domain.id)
  const create = useCreateForward(root, domain.id)
  const del = useDeleteForward(root, domain.id)
  const toast = useToast()
  const confirm = useConfirm()
  const [path, setPath] = useState('')
  const [target, setTarget] = useState('')
  const [internal, setInternal] = useState(false) 

  async function onAdd(e: FormEvent) {
    e.preventDefault()
    try {
      await create.mutateAsync({ path: path.trim(), target: target.trim(), internal })
      toast.push('success', 'encaminhamento criado — aplicando no nginx (Fila)')
      setPath('')
      setTarget('')
      setInternal(false)
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  async function onDelete(id: number, p: string) {
    if (!(await confirm({ title: 'Remover encaminhamento', message: `Remover ${p}?`, confirmLabel: 'Remover', danger: true }))) return
    try {
      await del.mutateAsync(id)
      toast.push('success', 'encaminhamento removido')
    } catch (err) {
      toast.push('error', msg(err))
    }
  }

  const list = forwards ?? []

  return (
    <Modal open onClose={onClose} title={`Encaminhamentos · ${domain.fqdn}`} className="max-w-2xl">
      <div className="space-y-4">
        <p className="text-xs text-faint">
          Direcione um caminho de <span className="font-mono text-muted">{domain.fqdn}</span> para outro destino. Ex.:{' '}
          <span className="font-mono">/loja</span> → <span className="font-mono">app.outro.com</span> ou{' '}
          <span className="font-mono">10.0.0.5:8080/app</span>.
        </p>

        {isLoading ? (
          <Spinner />
        ) : list.length === 0 ? (
          <p className="text-sm text-faint">Nenhum encaminhamento ainda.</p>
        ) : (
          <ul className="space-y-1">
            {list.map((f) => (
              <li
                key={f.id}
                className="flex items-center gap-2 rounded-md border border-line bg-elevated/50 px-3 py-2 text-sm"
              >
                <span className="font-mono text-ink">{f.path}</span>
                <ArrowRight className="h-3.5 w-3.5 flex-none text-faint" />
                <span className="min-w-0 flex-1 truncate font-mono text-accent">{f.target_domain_id > 0 ? f.target_fqdn || f.target : f.target}</span>
                {f.target_domain_id > 0 && (
                  <span className="flex-none rounded bg-elevated px-1.5 py-0.5 text-[10px] uppercase tracking-wide text-muted">interno</span>
                )}
                <Button variant="danger" onClick={() => onDelete(f.id, f.path)} title="Remover">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </li>
            ))}
          </ul>
        )}

        <form onSubmit={onAdd} className="space-y-3 border-t border-line pt-4">
          <label className="flex items-start gap-2 text-xs text-muted">
            <input
              type="checkbox"
              checked={internal}
              onChange={(e) => setInternal(e.target.checked)}
              className="mt-0.5"
            />
            <span>Destino é outro domínio <strong>deste servidor</strong> (roteia internamente, sem precisar de DNS público do alvo).</span>
          </label>
          <div className="grid gap-3 sm:grid-cols-[10rem_1fr]">
            <Field label="caminho">
              <Input value={path} onChange={(e) => setPath(e.target.value)} placeholder="/loja" required />
            </Field>
            <Field label={internal ? 'domínio alvo' : 'destino'}>
              <Input
                value={target}
                onChange={(e) => setTarget(e.target.value)}
                placeholder={internal ? 'healthtech.est.uea.edu.br' : 'app.outro.com'}
                required
              />
            </Field>
          </div>
          <p className="text-xs text-faint">
            {internal ? (
              'FQDN de um domínio já cadastrado no servidor (de qualquer cliente). O WSRTA entrega no container dele com o Host certo — funciona mesmo que o domínio ainda não responda pela internet.'
            ) : (
              <>
                Destino = IP, domínio ou subdomínio, com porta e/ou caminho (host[:porta][/caminho]). Ex.:{' '}
                <span className="font-mono">10.0.0.5:8080/app</span>.
              </>
            )}
          </p>
          <div className="flex justify-end">
            <Button type="submit" disabled={create.isPending}>
              {create.isPending ? <Spinner /> : (<><Plus className="h-4 w-4" /> Adicionar</>)}
            </Button>
          </div>
        </form>
      </div>
    </Modal>
  )
}
