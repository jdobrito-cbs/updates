import { useCallback, useEffect, useRef, useState } from 'react'
import {
  ChevronRight,
  Copy,
  Download,
  File as FileIcon,
  FilePlus,
  Folder,
  FolderInput,
  FolderPlus,
  Pencil,
  RefreshCw,
  Trash2,
  Upload,
} from 'lucide-react'

import { api, ApiError, apiDownload, apiUpload } from '../api/client'
import { Button } from './ui/Button'
import { Card } from './ui/Card'
import { useConfirm } from './ui/ConfirmDialog'
import { EmptyState } from './ui/EmptyState'
import { Input } from './ui/Input'
import { Modal } from './ui/Modal'
import { Spinner } from './ui/Spinner'
import { useToast } from './ui/Toast'

interface Entry {
  name: string
  is_dir: boolean
  size: number
  mtime: number
}

const msg = (e: unknown) => (e instanceof ApiError ? e.message : 'falha na operação')

const humanSize = (n: number) =>
  n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : n >= 1024 ? `${(n / 1024).toFixed(1)} KB` : `${n} B`

function joinPath(dir: string, name: string): string {
  if (dir === '/' || dir === '') return '/' + name
  return dir.replace(/\/$/, '') + '/' + name
}
function parentPath(p: string): string {
  if (p === '/' || p === '') return '/'
  const t = p.replace(/\/$/, '')
  const i = t.lastIndexOf('/')
  return i <= 0 ? '/' : t.slice(0, i)
}

type Prompt =
  | { kind: 'mkdir' | 'newfile'; value: string }
  | { kind: 'rename' | 'move' | 'copy'; target: Entry; value: string }

export function FileManager({ base }: { base: string }) {
  const [path, setPath] = useState('/')
  const [entries, setEntries] = useState<Entry[]>([])
  const [loading, setLoading] = useState(true)
  const [prompt, setPrompt] = useState<Prompt | null>(null)
  const [busy, setBusy] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const toast = useToast()
  const confirm = useConfirm()

  const load = useCallback(
    async (p: string) => {
      setLoading(true)
      try {
        const res = await api.post<{ path: string; entries: Entry[] | null }>(`${base}/list`, { path: p })
        setEntries(res.entries ?? [])
        setPath(p)
      } catch (e) {
        toast.push('error', msg(e))
      } finally {
        setLoading(false)
      }
    },
    [base, toast],
  )

  useEffect(() => {
    load('/')
  }, [load])

  async function onUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    setBusy(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      fd.append('path', path)
      await apiUpload(`${base}/upload`, fd)
      toast.push('success', 'arquivo enviado')
      await load(path)
    } catch (err) {
      toast.push('error', msg(err))
    } finally {
      setBusy(false)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  async function onDownload(en: Entry) {
    try {
      await apiDownload(`${base}/download?path=${encodeURIComponent(joinPath(path, en.name))}`, en.name)
    } catch (e) {
      toast.push('error', msg(e))
    }
  }

  async function onDelete(en: Entry) {
    if (
      !(await confirm({
        title: 'Excluir',
        message: `Excluir ${en.is_dir ? 'a pasta' : 'o arquivo'} "${en.name}"?${en.is_dir ? ' Todo o conteúdo será removido.' : ''}`,
        confirmLabel: 'Excluir',
        danger: true,
      }))
    )
      return
    try {
      await api.post(`${base}/delete`, { path: joinPath(path, en.name) })
      toast.push('success', 'removido')
      await load(path)
    } catch (e) {
      toast.push('error', msg(e))
    }
  }

  async function submitPrompt() {
    if (!prompt) return
    const v = prompt.value.trim()
    if (!v) return
    setBusy(true)
    try {
      if (prompt.kind === 'mkdir') {
        await api.post(`${base}/mkdir`, { path: joinPath(path, v) })
      } else if (prompt.kind === 'newfile') {
        await api.post(`${base}/newfile`, { path: joinPath(path, v) })
      } else if (prompt.kind === 'rename') {
        await api.post(`${base}/rename`, { path: joinPath(path, prompt.target.name), new_name: v })
      } else if (prompt.kind === 'move') {
        await api.post(`${base}/move`, { path: joinPath(path, prompt.target.name), dst_dir: v })
      } else if (prompt.kind === 'copy') {
        await api.post(`${base}/copy`, { path: joinPath(path, prompt.target.name), dst_dir: v })
      }
      toast.push('success', 'feito')
      setPrompt(null)
      await load(path)
    } catch (e) {
      toast.push('error', msg(e))
    } finally {
      setBusy(false)
    }
  }

  const promptTitle =
    prompt?.kind === 'mkdir'
      ? 'Nova pasta'
      : prompt?.kind === 'newfile'
        ? 'Novo arquivo'
        : prompt?.kind === 'rename'
          ? 'Renomear'
          : prompt?.kind === 'move'
            ? 'Mover para a pasta…'
            : 'Copiar para a pasta…'

  return (
    <div className="space-y-3">
      {}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1 font-mono text-sm text-muted">
          <button onClick={() => load('/')} className="hover:text-ink">
            raiz
          </button>
          {path !== '/' &&
            path
              .split('/')
              .filter(Boolean)
              .map((seg, i, arr) => {
                const full = '/' + arr.slice(0, i + 1).join('/')
                return (
                  <span key={full} className="flex items-center gap-1">
                    <ChevronRight className="h-3 w-3 text-faint" />
                    <button onClick={() => load(full)} className="hover:text-ink">
                      {seg}
                    </button>
                  </span>
                )
              })}
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="ghost" onClick={() => load(path)} title="Atualizar">
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
          <Button variant="ghost" onClick={() => setPrompt({ kind: 'mkdir', value: '' })}>
            <FolderPlus className="h-4 w-4" /> Pasta
          </Button>
          <Button variant="ghost" onClick={() => setPrompt({ kind: 'newfile', value: '' })}>
            <FilePlus className="h-4 w-4" /> Arquivo
          </Button>
          <input ref={fileRef} type="file" onChange={onUpload} className="hidden" />
          <Button onClick={() => fileRef.current?.click()} disabled={busy}>
            <Upload className="h-4 w-4" /> Enviar
          </Button>
        </div>
      </div>

      <Card className="p-0">
        {loading ? (
          <div className="p-6">
            <Spinner />
          </div>
        ) : (
          <div className="divide-y divide-line">
            {path !== '/' && (
              <button
                onClick={() => load(parentPath(path))}
                className="flex w-full items-center gap-2 px-4 py-2 text-left text-sm text-muted hover:bg-elevated"
              >
                <Folder className="h-4 w-4 text-faint" /> ..
              </button>
            )}
            {entries.length === 0 && path === '/' ? (
              <div className="p-6">
                <EmptyState title="Pasta vazia" hint="Envie um arquivo ou crie uma pasta." />
              </div>
            ) : (
              entries.map((en) => (
                <div key={en.name} className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-elevated">
                  <button
                    onClick={() => en.is_dir && load(joinPath(path, en.name))}
                    className={`flex min-w-0 flex-1 items-center gap-2 text-left ${en.is_dir ? 'text-ink' : 'text-muted'}`}
                    disabled={!en.is_dir}
                  >
                    {en.is_dir ? (
                      <Folder className="h-4 w-4 shrink-0 text-accent" />
                    ) : (
                      <FileIcon className="h-4 w-4 shrink-0 text-faint" />
                    )}
                    <span className="truncate">{en.name}</span>
                  </button>
                  <span className="hidden w-20 text-right text-xs text-faint sm:block">
                    {en.is_dir ? '' : humanSize(en.size)}
                  </span>
                  <span className="hidden w-36 text-right text-xs text-faint md:block">
                    {new Date(en.mtime * 1000).toLocaleString()}
                  </span>
                  <div className="flex shrink-0 gap-1">
                    {!en.is_dir && (
                      <IconBtn title="Baixar" onClick={() => onDownload(en)}>
                        <Download className="h-4 w-4" />
                      </IconBtn>
                    )}
                    <IconBtn title="Renomear" onClick={() => setPrompt({ kind: 'rename', target: en, value: en.name })}>
                      <Pencil className="h-4 w-4" />
                    </IconBtn>
                    <IconBtn title="Mover" onClick={() => setPrompt({ kind: 'move', target: en, value: path })}>
                      <FolderInput className="h-4 w-4" />
                    </IconBtn>
                    <IconBtn title="Copiar" onClick={() => setPrompt({ kind: 'copy', target: en, value: path })}>
                      <Copy className="h-4 w-4" />
                    </IconBtn>
                    <IconBtn title="Excluir" danger onClick={() => onDelete(en)}>
                      <Trash2 className="h-4 w-4" />
                    </IconBtn>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </Card>

      <Modal open={prompt !== null} onClose={() => setPrompt(null)} title={promptTitle}>
        {prompt && (
          <div className="space-y-3">
            <Input
              autoFocus
              value={prompt.value}
              onChange={(e) => setPrompt({ ...prompt, value: e.target.value })}
              onKeyDown={(e) => e.key === 'Enter' && submitPrompt()}
              placeholder={prompt.kind === 'move' || prompt.kind === 'copy' ? '/destino' : 'nome'}
            />
            <div className="flex justify-end gap-2">
              <Button variant="ghost" onClick={() => setPrompt(null)}>
                Cancelar
              </Button>
              <Button onClick={submitPrompt} disabled={busy}>
                {busy ? <Spinner /> : 'OK'}
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}

function IconBtn({
  children,
  title,
  onClick,
  danger,
}: {
  children: React.ReactNode
  title: string
  onClick: () => void
  danger?: boolean
}) {
  return (
    <button
      title={title}
      onClick={onClick}
      className={`rounded p-1.5 ${danger ? 'text-muted hover:bg-failed/15 hover:text-failed' : 'text-muted hover:bg-line hover:text-ink'}`}
    >
      {children}
    </button>
  )
}
