# WSRTA — Arquitetura

Painel de controle de hospedagem **self-hosted**, uso interno, dois papéis (admin e cliente).
Cada cliente roda isolado em um **container LXC/LXD** no host Ubuntu Server.

> Este documento consolida o plano do projeto. Decisões de design que **não** estavam na
> especificação original e foram tomadas aqui estão marcadas com **[Decisão]** e devem ser
> revisadas. A `docs/SECURITY.md` (a ser criada na Fase 1) detalha o modelo de ameaças.

---

## 1. Princípio de segurança central

> **A API web NUNCA executa comandos de sistema.**

A API valida a requisição, aplica regras de negócio e **enfileira uma ação** na tabela
`actions` (PostgreSQL). O **daemon orquestrador** — o único processo com `root` — consome a
fila, **valida de novo**, e executa. Uma falha/RCE na API web não vira root no host porque a
API não tem privilégios nem caminho direto para o sistema.

```
┌──────────────┐   enfileira ação    ┌──────────────┐   executa (root)   ┌───────────┐
│   API web    │ ──────────────────► │   actions    │ ◄───────────────── │  Daemon   │
│ (sem root)   │   (INSERT no PG)    │   (Postgres) │   FOR UPDATE        │ (root)    │
└──────────────┘   + nudge socket    └──────────────┘   SKIP LOCKED       └─────┬─────┘
                                                                                 │
                                              lxc exec / LXD API / nginx / acme  │
                                                                                 ▼
                                                                         HOST + containers
```

Garantias:

- A API e o daemon são **processos separados**, com usuários do SO diferentes. A API roda
  como usuário sem privilégios; o daemon roda como `root` (ou com capacidades mínimas).
- O **único canal** API→daemon é a tabela `actions` + um *nudge* opcional via **socket Unix
  local** (apenas para acordar o daemon mais rápido; não carrega dados de comando).
- O daemon **revalida** todo payload antes de agir e **nunca** monta comando de shell por
  concatenação de string — usa `exec` com argumentos separados (ver §7).

---

## 2. Topologia

```
HOST (Ubuntu Server)
├── Painel
│   ├── API web (Go, chi)            — sem privilégios, fala só com Postgres + socket nudge
│   ├── Daemon orquestrador (Go)     — root, única peça que toca o sistema
│   └── PostgreSQL                   — dados do painel (inclui a fila actions)
├── Serviços compartilhados no host
│   ├── Nginx                        — reverse proxy p/ containers, termina TLS
│   ├── PowerDNS (backend Postgres)  — autoritativo
│   └── acme.sh                      — emissão de certificados Let's Encrypt
└── Containers LXC (cli_<id>, um por cliente)
    └── nginx + php-fpm + mariadb + cron
```

**Fluxo de requisição de visitante:**
`visitante → Nginx do host (TLS termina aqui) → reverse proxy pelo hostname → Nginx/PHP-FPM
do container do cliente → resposta`.

---

## 3. Componentes

### 3.1 API web (Go)
- Router **chi** **[Decisão: chi em vez de gin — mais leve e 100% compatível com `net/http`]**.
- Responsabilidades: autenticação (JWT), autorização (RBAC admin/cliente), validação de
  input, regras de negócio, **enfileirar** ações, e expor o estado da fila/recursos.
- **Não** importa o cliente LXD, não chama `lxc`, não toca arquivos do sistema.

### 3.2 Daemon orquestrador (Go)
- Binário único. Integra nativamente com a API do LXD via `github.com/canonical/lxd/client`.
- Loop consumidor: reivindica uma ação `pending` com `SELECT ... FOR UPDATE SKIP LOCKED`,
  marca `running`, executa o **executor** correspondente, grava `done`/`failed` + `result`.
- Executores são **idempotentes**, com **rollback** quando possível, e **logam cada passo**
  (slog) com o `action_id` para rastreio ponta a ponta.

### 3.3 Frontend (React + TS + Tailwind + Vite)
- Login único → redireciona para `/admin` ou `/client` conforme a `role`.
- Client HTTP tipado; estados de loading/erro; **polling** do status das ações assíncronas.

### 3.4 PostgreSQL
- Dados do painel + a fila `actions`. Acesso via `pgx/v5`.
- Migrations versionadas com **golang-migrate** (`migrations/NNNN_*.up.sql` / `.down.sql`).

---

## 4. Comunicação API ↔ Daemon (a fila)

1. A API, dentro da transação da requisição, faz `INSERT INTO actions (...) VALUES (...)`
   com `status='pending'` e o `payload` (JSONB).
2. A API envia um *nudge* de 1 byte pelo **socket Unix** do daemon (best-effort). Se falhar,
   nada quebra: o daemon pega na próxima varredura.
3. O daemon: `SELECT ... FROM actions WHERE status='pending' ORDER BY created_at
   FOR UPDATE SKIP LOCKED LIMIT 1` → marca `running` → executa → grava resultado.
   **[Decisão]** `SKIP LOCKED` dá concorrência segura e permite múltiplos workers no futuro.
4. Fallback: o daemon também varre a cada ~1s, então o socket é só latência menor, não
   correção. A API segue funcionando mesmo com o daemon caído (ações ficam `pending`).

O frontend acompanha via `GET /api/admin/actions` (admin) ou pelo recurso afetado (cliente),
fazendo polling enquanto a ação estiver `pending`/`running`.

---

## 5. Modelo de dados (esquema inicial)

| Tabela | Campos principais |
|---|---|
| `users` | id, email, password_hash, role(`admin`\|`client`), status, created_at |
| `clients` | id, user_id→users, name, lxc_container_name, cpu_limit, ram_limit_mb, disk_quota_mb, status |
| `domains` | id, client_id→clients, fqdn, docroot, php_version, ssl_enabled, created_at |
| `databases` | id, client_id→clients, db_name, db_user (MariaDB dentro do container) |
| `dns_records` | id, domain_id→domains, type(A/AAAA/CNAME/MX/TXT/NS), name, content, ttl, prio |
| `cron_jobs` | id, client_id→clients, schedule, command, enabled |
| `ssl_certs` | id, domain_id→domains, issuer, expires_at, status |
| `actions` | id, type, payload(JSONB), status(`pending`\|`running`\|`done`\|`failed`), result, requested_by→users, created_at, finished_at |

Notas:
- `clients.lxc_container_name` segue o padrão `cli_<id>` e é **derivado/validado** pelo
  servidor — nunca aceito cru do cliente.
- Senhas de banco/serviço dos containers **não** são guardadas em texto; ver SECURITY.md.

---

## 6. Ações do daemon (tipos da tabela `actions`)

Cada executor é **idempotente**, loga cada passo e faz rollback quando possível.

| Ação | O que faz |
|---|---|
| `provision_client` | cria container LXC do template (Ubuntu + nginx + php-fpm + mariadb + cron), aplica limites CPU/RAM/disco, inicia |
| `deprovision_client` | para e destrói container; limpa vhosts do host, DNS e certificados |
| `add_domain` | container: docroot + vhost interno; host: vhost reverse-proxy no Nginx; reload Nginx |
| `remove_domain` | reverte o `add_domain` |
| `issue_ssl` | acme.sh emite cert (preferir **DNS-01 via PowerDNS**, fallback HTTP-01), instala no Nginx do host, reload |
| `create_database` / `drop_database` | via `lxc exec`, cria/remove DB + usuário MariaDB no container |
| `set_dns_record` / `delete_dns_record` | insere/remove no backend PostgreSQL do PowerDNS |
| `set_cron` / `remove_cron` | edita crontab dentro do container via `lxc exec` |

Na **Fase 1** todos esses tipos existem como **executores stub**: validam, logam e marcam
`done`, sem tocar o sistema. As implementações reais entram nas Fases 2–4.

---

## 7. Segurança (resumo; detalhe em SECURITY.md)

- **Separação de privilégios**: API sem root; só o daemon toca o sistema.
- **Sem injeção de shell**: toda chamada a `lxc exec`/processos usa `exec` com *args*
  separados (`exec.Command(name, arg1, arg2...)`), **nunca** string concatenada nem
  `sh -c "<interpolação>"`.
- **Validação em duas camadas**: a API valida na borda; o daemon **revalida** o payload.
- **Autorização (regra de ouro)**: todo endpoint de cliente confere no middleware que o
  recurso pertence ao `client_id` do token. IDs de URL/body **nunca** são confiáveis sem
  checagem de posse.
- **Senhas**: hashing com **argon2id** **[Decisão: argon2id em vez de bcrypt]**
  (`golang.org/x/crypto/argon2`).
- **JWT**: `github.com/golang-jwt/jwt/v5`; segredo via env; expiração curta.
- **Rate-limit** no `/api/auth/login`.
- **Segredos** só por variável de ambiente (`.env` em dev); nada hardcoded; nada sensível em
  query string.

---

## 8. Layout do monorepo

**[Decisão importante — confirmar]** Um **único módulo Go** na raiz, com dois binários e
código compartilhado em `internal/` no topo.

Motivo: API e daemon compartilham o **contrato da fila** (tipos de ação, payloads) e os
**modelos** das tabelas. A regra de `internal/` do Go impede que código em `api/internal/`
seja importado pelo `daemon/` (e vice-versa). Colocar o que é compartilhado em um
`internal/` **na raiz** torna-o importável por ambos, mas continua privado a módulos
externos. Dois módulos separados forçariam duplicação ou um terceiro módulo publicado.

```
/  (module github.com/jdobrito/wsrta)   ← [Decisão: ajuste o path do módulo se quiser]
├── go.mod
├── Makefile
├── docker-compose.dev.yml      # Postgres do painel + Postgres do PowerDNS (dev)
├── .env.example
├── README.md
├── docs/{ARCHITECTURE,SECURITY}.md
├── migrations/                 # SQL golang-migrate
├── internal/                   # COMPARTILHADO (api + daemon)
│   ├── core/                   # modelos das tabelas + tipos/constantes de Action
│   ├── config/                 # carregamento de env
│   ├── db/                     # pool pgx, helpers
│   └── queue/                  # Enqueue/Claim/MarkDone + socket nudge
├── api/                        # API web (sem root)
│   ├── cmd/api/main.go
│   └── internal/{server,handlers,auth,...}
├── daemon/                     # orquestrador (root)
│   ├── cmd/daemon/main.go
│   └── internal/{consumer,executors,lxd,services}
└── web/                        # React + TS (Fase 6)
```

---

## 9. Stack e dependências (todas reais, sem inventar)

| Camada | Escolha |
|---|---|
| Daemon / API | Go |
| Router HTTP | `github.com/go-chi/chi/v5` |
| Driver Postgres | `github.com/jackc/pgx/v5` |
| Migrations | `github.com/golang-migrate/migrate/v4` |
| LXD | `github.com/canonical/lxd/client` |
| JWT | `github.com/golang-jwt/jwt/v5` |
| Hash de senha | `golang.org/x/crypto/argon2` (argon2id) |
| Config / .env | `github.com/caarlos0/env/v11` + `github.com/joho/godotenv` (só dev) |
| Logging | `log/slog` (stdlib) |
| Frontend | React + TypeScript + Tailwind + Vite |
| DNS | PowerDNS (backend PostgreSQL) |
| SSL | acme.sh (Let's Encrypt) |

---

## 10. Roadmap em fases (com gate de revisão ao fim de cada uma)

1. ✅ **Fundação** — monorepo, migrations, modelos, esqueleto da fila (API enfileira, daemon
   consome) com **executores stub** que só logam.
2. ✅ **Provisionamento** — `provision_client`/`deprovision_client`, **imagem golden** LXD
   `wsrta-base`, driver real|fake por `WSRTA_LXD_DRIVER`.
3. ✅ **Web + SSL** — `add_domain`/`remove_domain`/`issue_ssl`, reverse proxy Nginx, acme.sh
   (HTTP-01; DNS-01 na Fase 4). Reverse-proxy aponta para o IP atual do container.
4. ✅ **DB, DNS, Cron** — `create_database`/`drop_database` (mysql via exec), DNS direto no
   Postgres do PowerDNS, cron via `/etc/cron.d`. SSL segue só HTTP-01 (DNS-01 não adotado).
4b. **WordPress** — instalação por cliente (raiz ou subpasta do domínio). Depende de domínio,
   banco e `Exec` no container. Ver §11.
5. ✅ **API completa + Auth/RBAC** — `/api` com JWT Bearer + argon2id, RBAC, posse por
   `client_id` (queries escopadas). API grava no painel e enfileira; debug removido.
6a. ✅ **Frontend admin** — React/TS/Tailwind/Vite, tema Console (escuro, status-forward),
   login + painel admin (clientes, fila, sistema). Auth JWT Bearer.
6b. **Frontend cliente** — domínios, editor de DNS, bancos, SSL, cron, stats.

Ao iniciar cada fase: listar os arquivos a criar/alterar **antes** de codar. Ao fim: atualizar
o `README.md` e parar para revisão.

---

## 11. WordPress por cliente (Fase 4b)

Requisito: cada cliente pode instalar o **WordPress** no seu ambiente web, **na raiz do site**
ou **em uma subpasta do domínio** (ex.: `exemplo.com` ou `exemplo.com/blog`).

Dependências: container provisionado (Fase 2) + domínio/docroot (Fase 3) + banco MariaDB no
container (Fase 4) + `Exec` no container (adicionado à interface `lxd.Client` na Fase 4).

Esboço (a detalhar quando a fase iniciar):

- **Ação nova** `install_wordpress` (e `remove_wordpress`), executada via `lxc exec` rodando
  **wp-cli** dentro do container — download, `wp-config`, criação das tabelas e do usuário
  admin. Sem injeção de shell: args separados (ver SECURITY.md).
- **Payload**: `domain_id`, `path` (vazio = raiz; ex.: `blog` = subpasta), dados do admin
  (usuário/email/título); senha do admin gerada e exibida uma única vez.
- **Banco**: decisão em aberto — criar automaticamente um DB+usuário dedicado por instalação
  (reusa o executor `create_database`) **ou** usar um banco existente escolhido pelo cliente.
- **Persistência**: tabela nova (ex.: `wordpress_installs`: domain_id, path, database_id,
  version, admin_user, status) para o painel listar/gerenciar as instalações.
- **Integridade**: validar o download do WordPress (wp-cli verifica checksums dos core files).
