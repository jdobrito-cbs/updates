# WSRTA — Segurança

Modelo de segurança do painel. Vive junto do código e deve ser atualizado a cada fase.

## 1. Modelo de privilégios (a base de tudo)

| Processo | Usuário | Pode tocar o sistema? |
|---|---|---|
| API web | sem privilégios | **Não.** Só fala com Postgres e dá *nudge* no socket. |
| Daemon orquestrador | root (ou capabilities mínimas) | **Sim.** Única peça que executa `lxc`, Nginx, acme.sh. |

A API **enfileira** ações na tabela `actions`; o daemon **consome e executa**. Um
comprometimento da API não concede root: não há caminho de código da API para o sistema.

## 2. Superfície de ataque e mitigações

- **Injeção de shell** (alto risco — `lxc exec`, acme.sh, Nginx reload): SEMPRE
  `exec.Command(name, args...)` com argumentos separados. Nunca `sh -c` com interpolação,
  nunca concatenar entrada do usuário em comando. *(Aplica-se a partir da Fase 2.)*
- **Validação em duas camadas**: a API valida na borda (tipos, formatos, limites); o daemon
  **revalida** o payload antes de agir (defesa em profundidade — não confia em quem enfileirou).
- **Autorização horizontal (regra de ouro)**: todo endpoint de cliente confere no middleware
  que o recurso pertence ao `client_id` do token JWT. IDs em URL/body nunca são confiados sem
  checar posse. Previne um cliente acessar recursos de outro. *(Fase 5.)*
- **Nomes derivados pelo servidor**: `lxc_container_name` (`cli_<id>`), nomes de DB/usuário,
  caminhos de docroot e vhost são gerados/validados pelo servidor — nunca aceitos crus.
- **Senhas**: hash com **argon2id**. *(Fase 5.)*
- **Sessão**: JWT HS256, método fixado no parse; expiração = logoff automático configurável.
  **Segredo obrigatório**: a API **aborta** se `WSRTA_JWT_SECRET` < 16 chars (evita tokens
  forjáveis). **Rate-limit** no `/api/auth/login` **e** no 2FA (`/2fa/enroll|verify`).
- **FQDN estrito** (`core.ValidFQDN`, hostname RFC-1123): validado na API e revalidado no
  daemon antes de ir para configs do nginx / caminhos de arquivo (impede injeção de config
  e path traversal via domínio).
- **Limites de entrada**: corpo JSON ≤ 1 MiB (`decodeJSON`); IP do rate-limit só confia em
  `X-Real-IP`/`X-Forwarded-For` quando o peer é loopback (proxy confiável) — sem spoofing.
- **Cabeçalhos**: `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy` na API; CSP
  no nginx do painel. **Firewall (ufw)** configurado pelo instalador.
- **Segredos**: só por variável de ambiente (`.env` em dev, fora do versionamento). Nada
  hardcoded. Nada sensível em query string (vai para logs/histórico) — usar corpo/headers.
- **Idempotência + rollback**: executores podem ser reexecutados sem efeito duplicado e
  desfazem o que aplicaram quando uma etapa falha — evita estado inconsistente explorável.

## 3. Isolamento entre clientes

Cada cliente roda em um **container LXC** próprio (`cli_<id>`): processos, rede, FS e MariaDB
isolados. O painel nunca dá a um cliente acesso de shell ao host. O Nginx do host termina TLS
e faz reverse-proxy por hostname para o container correto.

## 4. Observabilidade

Logging estruturado (slog). Cada ação é rastreável de ponta a ponta pelo `action_id`
(enfileirada na API → reivindicada/started → done/failed no daemon).

## 5. Itens em aberto (a endereçar nas fases seguintes)

- Endurecimento do container-template (Fase 2): usuários, firewall, limites.
- **Redação de segredos em `actions`** (Fase 4): a senha gerada no `create_database` é
  retornada uma vez via `actions.result` e persiste nessa coluna. Endurecer com redação/
  cifragem do campo (ou entrega out-of-band). Mesmo cuidado para a senha de admin do
  WordPress (Fase 4b). Injeção em cron/`lxc exec` já é mitigada: identificadores MySQL
  validados e `schedule`/`command` sem quebras de linha.
- Hardening do socket do daemon (permissões do arquivo, owner) e do serviço systemd.
- WordPress (Fase 4b): integridade do download (wp-cli verifica checksums), credenciais do
  admin geradas e exibidas uma única vez, e args separados no `lxc exec` (sem injeção).

## 6. Auditoria de segurança (correções aplicadas)

Auditoria completa do sistema web (AppSec, red team, redes/VPS). Achados e correções:

| ID | Severidade | Achado | Correção |
|---|---|---|---|
| C-1 | Crítico | Segredo JWT vazio só avisava → tokens de admin forjáveis | API **aborta** se `< 16` chars |
| A-1 | Alto | FQDN não validado → injeção de config nginx / path traversal | `core.ValidFQDN` na API + daemon |
| A-2 | Alto | `docroot` controlado pelo cliente → caminho arbitrário | derivado no servidor + clamp a `DocrootBase` |
| M-1 | Médio | 2FA sem rate-limit → brute-force de TOTP | rate-limit em `enroll`/`verify` |
| M-2 | Médio | `decodeJSON` sem limite → DoS de memória | `io.LimitReader` 1 MiB |
| M-3 | Médio | rate-limit por header spoofável | `realIP` confiável só de loopback |
| M-4 | Médio | restore usava campos do manifesto em paths | validação (db/fqdn) antes de compor caminho |
| B-2 | Baixo | mapa do rate-limiter sem evicção | purga periódica |
| B-3 | Baixo | sem cabeçalhos de segurança | headers na API + CSP no nginx |
| B-4 | Baixo | enumeração de usuário por timing | argon2 dummy no caminho "não existe" |
| B-5 | Baixo | vazamento de erro interno | mensagens genéricas + log |
| B-6 | Baixo | VPS sem firewall | `ufw` no instalador |

**Confirmado sem problema:** SQL 100% parametrizado (incl. PowerDNS); `Exec`/`exec.Command`
com args separados (sem shell injection); posse `GetXOwned` consistente (sem IDOR);
extração de tar sem zip-slip/symlink; `safeName` no vhost do host. A senha de banco em
`actions.result` (B-1) segue como caveat conhecido de entrega 1x (item da seção 5).

## 7. Auditoria das features novas (runtimes, postgres, banda, forwards, upstream, setup web)

Segunda auditoria (red team) cobrindo o que foi adicionado depois da §6. Achados e correções:

| ID | Severidade | Achado | Correção |
|---|---|---|---|
| N-1 | Alto | **SSRF**: `upstream_ip`/forwards aceitavam qualquer IP → metadados de nuvem (169.254.169.254) | `ValidUpstreamHost` bloqueia link-local/multicast/`0.0.0.0`/`::` (priv./loopback seguem por ser feature admin-only). Teste `TestValidUpstreamHostSSRF` |
| N-2 | Médio | **Corrida no setup**: `CountAdmins`+`CreateAdmin` não-atômico → 2 POSTs criavam 2 admins | `CreateFirstAdmin` atômico (`INSERT … WHERE NOT EXISTS`) → `ErrAdminExists`; + rate-limit no `/api/setup` |
| N-3 | Médio | **Segredo em log**: senha de login do cliente migrado ia para o slog estruturado | Removida do slog; exibida 1x no stdout do operador (CLI host-side) |
| N-4 | Baixo | `extractTarGz` ignorava symlink implicitamente | Checagem de prefixo explícita (containment) + `continue` em symlink/hardlink + teste `TestExtractTarGzSecurity` |
| N-5 | Baixo | `ListBackups` seguia symlink (`e.Info`) | `os.Lstat` + ignora entradas symlink |

**Revalidação em duas camadas confirmada nas features novas:** o daemon `writeForwards` revalida
cada `path`/`target` (`ValidUpstreamPath`/`ValidUpstreamTarget`) antes de gerar o nginx; identificadores
de banco (`validMySQLIdent`) e senha (`randomPassword` alfanumérica) validados antes de ir ao
`mysql -e`/`psql -c`; `sqlEscapeString` escapa `\` e `'` (ordem correta) no único valor livre (hash).

**Riscos aceitos (decisão de produto, documentados):** (a) proxy para IP privado/loopback é
PERMITIDO de propósito (caso de uso pedido; ação admin-only) — só link-local/metadados são bloqueados;
(b) JWT no `localStorage` mitigado por CSP + timeout de inatividade (mover p/ cookie httpOnly exigiria
CSRF token e refator maior); (c) CORS `*` em regras de site é configuração do próprio site do cliente.
