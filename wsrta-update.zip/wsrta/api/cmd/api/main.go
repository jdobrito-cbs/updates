

package main

import (
	"context"
	"errors"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/jdobrito/wsrta/api/internal/auth"
	"github.com/jdobrito/wsrta/api/internal/fileclient"
	"github.com/jdobrito/wsrta/api/internal/handlers"
	"github.com/jdobrito/wsrta/api/internal/monitor"
	"github.com/jdobrito/wsrta/api/internal/server"
	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/config"
	"github.com/jdobrito/wsrta/internal/db"
	"github.com/jdobrito/wsrta/internal/queue"
)

func main() {
	cfg, err := config.Load()
	if err != nil {
		slog.Error("config", slog.Any("err", err))
		os.Exit(1)
	}

	log := slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: cfg.SlogLevel()}))
	slog.SetDefault(log)
	
	
	if len(cfg.JWTSecret) < 16 {
		log.Error("WSRTA_JWT_SECRET ausente ou muito curto (mínimo 16 caracteres) — abortando")
		os.Exit(1)
	}

	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	pool, err := db.Open(ctx, cfg.DatabaseURL)
	if err != nil {
		log.Error("conectar ao banco", slog.Any("err", err))
		os.Exit(1)
	}
	defer pool.Close()

	tokens := auth.NewTokens(cfg.JWTSecret, time.Duration(cfg.JWTTTLMinutes)*time.Minute)
	st := store.New(pool)

	
	
	mon := monitor.New(st, log)
	go mon.Run(ctx)

	h := handlers.New(handlers.Config{
		Store:           st,
		Queue:           queue.New(pool),
		Tokens:          tokens,
		Rate:            auth.NewRateLimiter(cfg.LoginRatePerMin),
		DaemonSock:      cfg.DaemonSocket,
		TOTPIssuer:      cfg.TOTPIssuer,
		SFTPHost:        cfg.SFTPHost,
		SFTPBasePort:    cfg.SFTPBasePort,
		BackupDir:       cfg.BackupDir,
		MigrateStaging:  cfg.MigrateStaging,
		ClientBackupDir: cfg.ClientBackupDir,
		Files:           fileclient.New(cfg.FileAPISocket, cfg.FileAPIToken),
		PMABasePort:     cfg.PMABasePort,
		PMAURL:          cfg.PMAURL,
		PPABasePort:     cfg.PPABasePort,
		PPAURL:          cfg.PPAURL,
		Edition:         cfg.Edition,
		MailFake:        cfg.LXDDriver == "fake", 
		Monitor:         mon,
		Log:             log,
	})
	mw := auth.NewMiddleware(tokens)
	
	
	mw.SetSessionValidator(func(ctx context.Context, uid int64, iat time.Time) bool {
		ok, err := st.SessionValid(ctx, uid, iat)
		return err == nil && ok
	})
	handler := server.New(h, mw, log)

	srv := &http.Server{
		Addr:              cfg.APIAddr,
		Handler:           handler,
		ReadHeaderTimeout: 10 * time.Second,
	}

	go func() {
		<-ctx.Done()
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		_ = srv.Shutdown(shutdownCtx)
	}()

	log.Info("api ouvindo", slog.String("addr", cfg.APIAddr))
	if err := srv.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Error("servidor http", slog.Any("err", err))
		os.Exit(1)
	}
	log.Info("api encerrada")
}
