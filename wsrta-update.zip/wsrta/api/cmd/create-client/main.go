



package main

import (
	"context"
	"fmt"
	"os"

	"github.com/jdobrito/wsrta/api/internal/auth"
	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/config"
	"github.com/jdobrito/wsrta/internal/core"
	"github.com/jdobrito/wsrta/internal/db"
	"github.com/jdobrito/wsrta/internal/queue"
)

func main() {
	if len(os.Args) < 3 {
		fmt.Fprintln(os.Stderr, "uso: create-client <email> <senha> [nome]")
		os.Exit(2)
	}
	email, password := os.Args[1], os.Args[2]
	name := email
	if len(os.Args) > 3 {
		name = os.Args[3]
	}

	cfg, err := config.Load()
	if err != nil {
		fatal(err)
	}
	hash, err := auth.HashPassword(password)
	if err != nil {
		fatal(err)
	}

	ctx := context.Background()
	pool, err := db.Open(ctx, cfg.DatabaseURL)
	if err != nil {
		fatal(err)
	}
	defer pool.Close()

	clientID, err := store.New(pool).CreateClientWithUser(ctx, email, hash, name, 1, 512, 5120)
	if err != nil {
		fatal(err)
	}
	if _, err := queue.New(pool).Enqueue(ctx, core.ActionProvisionClient, core.ProvisionClientPayload{ClientID: clientID}, nil); err != nil {
		fatal(err)
	}
	queue.Nudge(cfg.DaemonSocket)

	fmt.Printf("cliente %q criado (id=%d) e provisionamento enfileirado\n", email, clientID)
}

func fatal(err error) {
	fmt.Fprintln(os.Stderr, "erro:", err)
	os.Exit(1)
}
