







package main

import (
	"context"
	"flag"
	"fmt"
	"log/slog"
	"os"

	"github.com/jdobrito/wsrta/api/internal/migrate"
	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/config"
	"github.com/jdobrito/wsrta/internal/db"
	"github.com/jdobrito/wsrta/internal/queue"
)

func main() {
	backup := flag.String("backup", "", "caminho do backup .tar.gz do CyberPanel")
	stage := flag.String("staging", "/var/lib/wsrta/migrate", "diretório de staging no host (legível pelo daemon)")
	dryRun := flag.Bool("dry-run", false, "apenas analisa o backup e mostra o que seria migrado")
	flag.Parse()

	if *backup == "" {
		fmt.Fprintln(os.Stderr, "uso: wsrta-migrate -backup <arquivo.tar.gz> [-staging <dir>]")
		os.Exit(2)
	}

	log := slog.New(slog.NewTextHandler(os.Stdout, nil))

	if err := os.MkdirAll(*stage, 0o755); err != nil {
		fatal(err)
	}

	w, err := migrate.ParseBackup(*backup, *stage, !*dryRun)
	if err != nil {
		fatal(err)
	}
	log.Info("backup lido",
		"domain", w.Domain, "php", w.PHP, "email", w.Email,
		"databases", len(w.Databases), "dns_records", len(w.DNS), "has_files", w.HasFiles)

	if *dryRun {
		for _, d := range w.Databases {
			log.Info("banco", "name", d.Name, "user", d.User, "tem_hash", d.PasswordHash != "", "tem_dump", d.DumpPath != "")
		}
		log.Info("dry-run: nada foi alterado")
		return
	}

	cfg, err := config.Load()
	if err != nil {
		fatal(err)
	}
	ctx := context.Background()
	pool, err := db.Open(ctx, cfg.DatabaseURL)
	if err != nil {
		fatal(err)
	}
	defer pool.Close()

	if err := migrate.MigrateWebsite(ctx, store.New(pool), queue.New(pool), cfg.DaemonSocket, *w, log); err != nil {
		fatal(err)
	}
	log.Info("migração enfileirada — acompanhe pela Fila no painel admin")
}

func fatal(err error) {
	fmt.Fprintln(os.Stderr, "erro:", err)
	os.Exit(1)
}
