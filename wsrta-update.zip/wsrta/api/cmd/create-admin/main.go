



package main

import (
	"context"
	"fmt"
	"os"

	"github.com/jdobrito/wsrta/api/internal/auth"
	"github.com/jdobrito/wsrta/internal/config"
	"github.com/jdobrito/wsrta/internal/db"
)

func main() {
	if len(os.Args) != 3 {
		fmt.Fprintln(os.Stderr, "uso: create-admin <email> <senha>")
		os.Exit(2)
	}
	email, password := os.Args[1], os.Args[2]

	cfg, err := config.Load()
	if err != nil {
		fatal(err)
	}
	hash, err := auth.HashPassword(password)
	if err != nil {
		fatal(err)
	}

	ctx := context.Background()
	pool, err := db.Open(ctx, cfg.DatabaseURL)
	if err != nil {
		fatal(err)
	}
	defer pool.Close()

	if _, err := pool.Exec(ctx,
		`INSERT INTO users (email, password_hash, role) VALUES ($1, $2, 'admin')
		 ON CONFLICT (email) DO UPDATE
		   SET password_hash = EXCLUDED.password_hash, role = 'admin', status = 'active'`,
		email, hash,
	); err != nil {
		fatal(err)
	}
	fmt.Printf("admin %q pronto\n", email)
}

func fatal(err error) {
	fmt.Fprintln(os.Stderr, "erro:", err)
	os.Exit(1)
}
