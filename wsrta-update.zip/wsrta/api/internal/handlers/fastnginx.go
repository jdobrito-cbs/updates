package handlers

import (
	"net/http"

	"github.com/jdobrito/wsrta/internal/core"
)


func (h *Handlers) EnableFastNginx(w http.ResponseWriter, r *http.Request) {
	h.setFastNginx(w, r, true)
}


func (h *Handlers) DisableFastNginx(w http.ResponseWriter, r *http.Request) {
	h.setFastNginx(w, r, false)
}

func (h *Handlers) setFastNginx(w http.ResponseWriter, r *http.Request, enabled bool) {
	id, err := idParam(r, "client_id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionSetFastNginx,
		core.SetFastNginxPayload{ClientID: id, Enabled: enabled}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}
