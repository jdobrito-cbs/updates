package handlers

import (
	"net/http"
	"strings"

	"github.com/jdobrito/wsrta/internal/core"
)


func (h *Handlers) RuntimesInfo(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	c, err := h.store.GetClient(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return
	}
	available := make([]map[string]string, 0, len(core.WebRuntimes))
	for _, rt := range core.WebRuntimes {
		available = append(available, map[string]string{"key": rt.Key, "label": rt.Label})
	}
	WriteJSON(w, http.StatusOK, map[string]any{
		"available": available,
		"enabled":   core.ParseRuntimes(c.Runtimes),
	})
}


func (h *Handlers) SetRuntimes(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	var req struct {
		Runtimes []string `json:"runtimes"`
	}
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	for _, k := range req.Runtimes {
		if core.RuntimeByKey(k) == nil {
			WriteError(w, http.StatusBadRequest, "linguagem desconhecida: "+k)
			return
		}
	}
	clean := core.ParseRuntimes(strings.Join(req.Runtimes, ",")) 
	if err := h.store.SetClientRuntimes(r.Context(), cid, strings.Join(clean, ",")); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionSetRuntimes, core.SetRuntimesPayload{ClientID: cid, Runtimes: clean}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "salvo, mas falhou ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"enabled": clean, "action_id": actionID})
}
