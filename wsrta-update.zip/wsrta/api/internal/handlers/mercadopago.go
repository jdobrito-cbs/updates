package handlers

import (
	"errors"
	"log/slog"
	"net/http"
	"regexp"
	"strconv"
	"strings"

	"github.com/jdobrito/wsrta/api/internal/mercadopago"
	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)


var mpNumericRe = regexp.MustCompile(`^[0-9]+$`)




func (h *Handlers) GetMPConfig(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	scope, ok := h.packageScope(w, r)
	if !ok {
		return
	}
	configured, err := h.store.MPConfigured(r.Context(), scope)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao ler config")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"configured": configured})
}


func (h *Handlers) SetMPConfig(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	scope, ok := h.packageScope(w, r)
	if !ok {
		return
	}
	var req struct {
		Token         string `json:"token"`
		WebhookSecret string `json:"webhook_secret"`
	}
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	token := strings.TrimSpace(req.Token)
	secret := strings.TrimSpace(req.WebhookSecret)
	if err := h.store.SetMPCreds(r.Context(), scope, token, secret); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar credenciais")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"configured": token != ""})
}


func (h *Handlers) ListOrders(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	scope, ok := h.packageScope(w, r)
	if !ok {
		return
	}
	list, err := h.store.ListOrders(r.Context(), scope)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar vendas")
		return
	}
	if list == nil {
		list = []core.Order{}
	}
	WriteJSON(w, http.StatusOK, list)
}






func (h *Handlers) PublicCheckout(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	if !h.rate.Allow(clientIP(r)) { 
		WriteError(w, http.StatusTooManyRequests, "muitas tentativas, tente novamente em instantes")
		return
	}
	var req struct {
		Scope     string `json:"scope"`
		PackageID int64  `json:"package_id"`
		Email     string `json:"email"`
	}
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if !validEmail(strings.TrimSpace(req.Email)) {
		WriteError(w, http.StatusBadRequest, "e-mail inválido")
		return
	}
	ctx := r.Context()
	var resellerID int64
	if s := strings.TrimSpace(req.Scope); s != "" && s != "admin" {
		rs, err := h.store.GetResellerBySlug(ctx, s)
		if errors.Is(err, store.ErrNotFound) {
			WriteError(w, http.StatusNotFound, "revenda não encontrada")
			return
		}
		if err != nil {
			WriteError(w, http.StatusInternalServerError, "erro ao carregar revenda")
			return
		}
		resellerID = rs.ID
	}
	pkg, err := h.store.GetPackageOwned(ctx, req.PackageID, resellerID)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusBadRequest, "pacote inválido")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar pacote")
		return
	}
	token, err := h.store.MPTokenForScope(ctx, resellerID)
	if err != nil || token == "" {
		WriteError(w, http.StatusUnprocessableEntity, "pagamento não configurado para esta loja")
		return
	}
	orderID, err := h.store.CreateOrder(ctx, resellerID, pkg.ID, strings.TrimSpace(req.Email), pkg.PriceCents)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao registrar o pedido")
		return
	}
	host := h.publicHost(ctx, r.Host)
	base := "https://" + host
	pref, err := mercadopago.CreatePreference(ctx, token, mercadopago.PreferenceRequest{
		Title:             pkg.Name,
		PriceCents:        pkg.PriceCents,
		BuyerEmail:        strings.TrimSpace(req.Email),
		ExternalReference: strconv.FormatInt(orderID, 10),
		NotificationURL:   base + "/api/public/mp/webhook?order=" + strconv.FormatInt(orderID, 10),
		BackURL:           base + "/site",
	})
	if err != nil {
		WriteError(w, http.StatusBadGateway, "falha no MercadoPago: "+err.Error())
		return
	}
	_ = h.store.SetOrderPreference(ctx, orderID, pref.ID)
	WriteJSON(w, http.StatusOK, map[string]any{"init_point": pref.InitPoint, "order_id": orderID})
}



func (h *Handlers) MPWebhook(w http.ResponseWriter, r *http.Request) {
	defer w.WriteHeader(http.StatusOK) 
	if !h.rate.Allow(clientIP(r)) {    
		return
	}
	q := r.URL.Query()
	orderID, _ := strconv.ParseInt(q.Get("order"), 10, 64)
	paymentID := q.Get("data.id")
	if paymentID == "" {
		paymentID = q.Get("id")
	}
	if paymentID == "" {
		var body struct {
			Data struct {
				ID string `json:"id"`
			} `json:"data"`
		}
		_ = decodeJSON(r, &body)
		paymentID = body.Data.ID
	}
	
	if orderID == 0 || !mpNumericRe.MatchString(paymentID) {
		return
	}
	ctx := r.Context()
	resellerID, err := h.store.OrderResellerID(ctx, orderID)
	if err != nil {
		return
	}
	token, secret, err := h.store.MPCredsForScope(ctx, resellerID)
	if err != nil || token == "" {
		return
	}
	
	if secret != "" && !mercadopago.ValidateWebhookSignature(secret, paymentID, r.Header.Get("x-request-id"), r.Header.Get("x-signature")) {
		h.log.WarnContext(ctx, "mp webhook: assinatura inválida", slog.Int64("order", orderID))
		return
	}
	pay, err := mercadopago.GetPayment(ctx, token, paymentID)
	if err != nil {
		return
	}
	
	
	if pay.ExternalReference != strconv.FormatInt(orderID, 10) {
		h.log.WarnContext(ctx, "mp webhook: external_reference não confere", slog.Int64("order", orderID))
		return
	}
	amountCents, curStatus, err := h.store.GetOrderForVerify(ctx, orderID)
	if err != nil {
		return
	}
	status := "pending"
	switch pay.Status {
	case "approved":
		
		if int64(pay.TransactionAmount*100+0.5) != amountCents {
			h.log.WarnContext(ctx, "mp webhook: valor diverge", slog.Int64("order", orderID))
			return
		}
		status = "paid"
	case "rejected", "cancelled", "refunded", "charged_back":
		status = "failed"
	}
	if curStatus == "pending" { 
		_ = h.store.MarkOrder(ctx, orderID, status, paymentID)
	}
}
