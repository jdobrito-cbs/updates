package handlers

import (
	"net/http"

	"github.com/jdobrito/wsrta/internal/core"
)


func (h *Handlers) GetSecurity(w http.ResponseWriter, r *http.Request) {
	st, err := h.store.GetSettings(r.Context())
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao ler configurações")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{
		"modsecurity":   st.SecModSecurity,
		"csf":           st.SecCSF,
		"fail2ban":      st.SecFail2ban,
		"ssl_autorenew": st.SecSSLAutoRenew,
	})
}

type securityRequest struct {
	ModSecurity  bool `json:"modsecurity"`
	CSF          bool `json:"csf"`
	Fail2ban     bool `json:"fail2ban"`
	SSLAutoRenew bool `json:"ssl_autorenew"`
}


func (h *Handlers) UpdateSecurity(w http.ResponseWriter, r *http.Request) {
	var req securityRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if err := h.store.UpdateSecurity(r.Context(), req.ModSecurity, req.CSF, req.Fail2ban, req.SSLAutoRenew); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionApplySecurity, core.ApplySecurityPayload{
		ModSecurity:  req.ModSecurity,
		CSF:          req.CSF,
		Fail2ban:     req.Fail2ban,
		SSLAutoRenew: req.SSLAutoRenew,
	}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "salvo, mas falhou ao enfileirar a aplicação")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}
