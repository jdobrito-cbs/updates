package handlers

import (
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	"net/http"
	"regexp"

	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)




func allCatalogSlugs() []string {
	out := make([]string, 0, len(core.AppCatalog))
	for _, a := range core.AppCatalog {
		out = append(out, a.Slug)
	}
	return out
}

func intersect(a, b []string) []string {
	set := map[string]bool{}
	for _, x := range b {
		set[x] = true
	}
	var out []string
	for _, x := range a {
		if set[x] {
			out = append(out, x)
		}
	}
	return out
}






func (h *Handlers) appsAllowedForClient(r *http.Request, c *core.Client) ([]string, error) {
	ctx := r.Context()
	if c.OwnerUserID != nil {
		if _, err := h.store.GetResellerByUserID(ctx, *c.OwnerUserID); err == nil {
			return h.store.ListAppAllowed(ctx, core.AppAudienceResellers, nil) 
		} else if errors.Is(err, store.ErrNotFound) {
			return allCatalogSlugs(), nil 
		} else {
			return nil, err
		}
	}
	if c.ResellerID != nil {
		byReseller, err := h.store.ListAppAllowed(ctx, core.AppAudienceResellerClients, c.ResellerID)
		if err != nil {
			return nil, err
		}
		byAdmin, err := h.store.ListAppAllowed(ctx, core.AppAudienceResellers, nil)
		if err != nil {
			return nil, err
		}
		return intersect(byReseller, byAdmin), nil 
	}
	return h.store.ListAppAllowed(ctx, core.AppAudienceAdminClients, nil) 
}


func catalogFor(slugs []string) []core.CatalogApp {
	allow := map[string]bool{}
	for _, s := range slugs {
		allow[s] = true
	}
	out := []core.CatalogApp{}
	for _, a := range core.AppCatalog {
		if allow[a.Slug] {
			out = append(out, a)
		}
	}
	return out
}



func (h *Handlers) AppsInfo(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	c, err := h.store.GetClient(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return
	}
	allowed, err := h.appsAllowedForClient(r, c)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao resolver apps liberados")
		return
	}
	installs, err := h.store.ListAppInstalls(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar instalações")
		return
	}
	if installs == nil {
		installs = []store.AppInstall{}
	}
	WriteJSON(w, http.StatusOK, map[string]any{"catalog": catalogFor(allowed), "installed": installs})
}

type installAppRequest struct {
	AppSlug  string `json:"app_slug"`
	DomainID int64  `json:"domain_id"`
	Path     string `json:"path"`
}




func (h *Handlers) InstallApp(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	var req installAppRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	app, ok := core.AppBySlug(req.AppSlug)
	if !ok {
		WriteError(w, http.StatusBadRequest, "app desconhecido")
		return
	}
	c, err := h.store.GetClient(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return
	}
	allowed, err := h.appsAllowedForClient(r, c)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao resolver apps liberados")
		return
	}
	if !contains(allowed, app.Slug) {
		WriteError(w, http.StatusForbidden, "este app não está liberado para você")
		return
	}
	
	if n, e := h.store.CountAppInstallBySlug(r.Context(), cid, app.Slug); e == nil && n > 0 {
		WriteError(w, http.StatusConflict, "este app já está instalado nesta VPS")
		return
	}

	
	if app.Kind == core.AppKindDocker {
		if !c.DockerEnabled {
			WriteError(w, http.StatusConflict, "habilite o Docker nesta VPS antes de instalar apps Docker")
			return
		}
		port, e := h.store.NextDockerHostPort(r.Context(), dockerHostPortBase)
		if e != nil {
			WriteError(w, http.StatusInternalServerError, "erro ao alocar porta")
			return
		}
		containerName := fmt.Sprintf("wsrta-%s-%d", app.Slug, cid)
		inst, e := h.store.CreateAppInstall(r.Context(), cid, app.Slug, core.AppKindDocker, nil, "", "", containerName, port)
		if isUniqueViolation(e) { 
			WriteError(w, http.StatusConflict, "tente novamente (conflito de instalação simultânea)")
			return
		}
		if e != nil {
			WriteError(w, http.StatusInternalServerError, "erro ao registrar instalação")
			return
		}
		actionID, e := h.enqueue(r.Context(), core.ActionInstallDockerApp, core.InstallDockerAppPayload{
			ClientID: cid, AppInstallID: inst.ID, Slug: app.Slug, ContainerName: containerName, HostPort: port,
		}, userID(r))
		if e != nil {
			
			_ = h.store.DeleteAppInstall(r.Context(), inst.ID)
			WriteError(w, http.StatusInternalServerError, "falha ao enfileirar; tente novamente")
			return
		}
		WriteJSON(w, http.StatusCreated, map[string]any{"install": inst, "action_id": actionID})
		return
	}

	
	if !validAppPath(req.Path) {
		WriteError(w, http.StatusBadRequest, "subpasta inválida")
		return
	}
	dom, err := h.store.GetDomainOwned(r.Context(), req.DomainID, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "domínio não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar domínio")
		return
	}
	dbName := randomAppDBName(app.Slug)
	domID := req.DomainID
	inst, err := h.store.CreateAppInstall(r.Context(), cid, app.Slug, core.AppKindPHP, &domID, req.Path, dbName, "", 0)
	if isUniqueViolation(err) {
		WriteError(w, http.StatusConflict, "este app já está instalado nesta VPS")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao registrar instalação")
		return
	}
	inst.FQDN = dom.FQDN

	actionID, err := h.enqueue(r.Context(), core.ActionInstallPhpBB, core.InstallPhpBBPayload{
		DomainID: req.DomainID, Path: req.Path, DBName: dbName,
	}, userID(r))
	if err != nil {
		_ = h.store.DeleteAppInstall(r.Context(), inst.ID) 
		WriteError(w, http.StatusInternalServerError, "falha ao enfileirar; tente novamente")
		return
	}
	WriteJSON(w, http.StatusCreated, map[string]any{"install": inst, "action_id": actionID})
}


var appPathRe = regexp.MustCompile(`^[a-z0-9][a-z0-9._-]{0,40}$`)

func validAppPath(p string) bool {
	return p == "" || appPathRe.MatchString(p)
}




func (h *Handlers) UpdateApp(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	inst, err := h.store.GetAppInstallOwned(r.Context(), id, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "instalação não encontrada")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar instalação")
		return
	}
	var actionID int64
	switch {
	case inst.Kind == core.AppKindDocker:
		
		actionID, err = h.enqueue(r.Context(), core.ActionUpdateDockerApp, core.InstallDockerAppPayload{
			ClientID: cid, AppInstallID: inst.ID, Slug: inst.AppSlug, ContainerName: inst.ContainerName, HostPort: inst.HostPort,
		}, userID(r))
	case inst.Kind == core.AppKindPHP && inst.AppSlug == "phpbb" && inst.DomainID != nil:
		
		actionID, err = h.enqueue(r.Context(), core.ActionUpdatePhpBB, core.UpdatePhpBBPayload{
			DomainID: *inst.DomainID, Path: inst.Path,
		}, userID(r))
	default:
		WriteError(w, http.StatusBadRequest, "este app não tem atualização automática")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar atualização")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}

func (h *Handlers) RemoveApp(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	inst, err := h.store.GetAppInstallOwned(r.Context(), id, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "instalação não encontrada")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar instalação")
		return
	}

	var actionID int64
	switch {
	case inst.Kind == core.AppKindPHP && inst.DomainID != nil:
		actionID, err = h.enqueue(r.Context(), core.ActionRemovePhpBB, core.RemovePhpBBPayload{
			DomainID: *inst.DomainID, Path: inst.Path, DBName: inst.DBName,
		}, userID(r))
	case inst.Kind == core.AppKindDocker:
		actionID, err = h.enqueue(r.Context(), core.ActionRemoveDockerApp, core.RemoveDockerAppPayload{
			ClientID: cid, ContainerName: inst.ContainerName, DeviceName: "dockerapp-" + inst.ContainerName,
		}, userID(r))
	case inst.Kind == core.AppKindPHP:
		
		
		h.log.Warn("remove app php sem domínio (registro órfão); apenas apaga a linha")
	default:
		
		WriteError(w, http.StatusInternalServerError, "tipo de app não suportado para remoção")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar remoção")
		return
	}
	if err := h.store.DeleteAppInstall(r.Context(), id); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao apagar registro")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}





func (h *Handlers) AdminAppPermissions(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	resellers, err := h.store.ListAppAllowed(r.Context(), core.AppAudienceResellers, nil)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar liberações")
		return
	}
	adminClients, err := h.store.ListAppAllowed(r.Context(), core.AppAudienceAdminClients, nil)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar liberações")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{
		"catalog":       core.AppCatalog,
		"resellers":     nonNil(resellers),
		"admin_clients": nonNil(adminClients),
	})
}

type adminAppPermsRequest struct {
	Resellers    []string `json:"resellers"`
	AdminClients []string `json:"admin_clients"`
}


func (h *Handlers) SetAdminAppPermissions(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	var req adminAppPermsRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	rs := validSlugs(req.Resellers)
	ac := validSlugs(req.AdminClients)
	if err := h.store.SetAppAllowed(r.Context(), core.AppAudienceResellers, nil, rs); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar liberações")
		return
	}
	if err := h.store.SetAppAllowed(r.Context(), core.AppAudienceAdminClients, nil, ac); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar liberações")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"ok": true})
}



func (h *Handlers) ResellerAppPermissions(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	rid, ok := h.resellerID(w, r)
	if !ok {
		return
	}
	byAdmin, err := h.store.ListAppAllowed(r.Context(), core.AppAudienceResellers, nil)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar liberações")
		return
	}
	mine, err := h.store.ListAppAllowed(r.Context(), core.AppAudienceResellerClients, &rid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar liberações")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{
		"catalog": catalogFor(byAdmin), 
		"clients": nonNil(intersect(mine, byAdmin)),
	})
}

type resellerAppPermsRequest struct {
	Clients []string `json:"clients"`
}



func (h *Handlers) SetResellerAppPermissions(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	rid, ok := h.resellerID(w, r)
	if !ok {
		return
	}
	var req resellerAppPermsRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	byAdmin, err := h.store.ListAppAllowed(r.Context(), core.AppAudienceResellers, nil)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar liberações")
		return
	}
	
	slugs := intersect(validSlugs(req.Clients), byAdmin)
	if err := h.store.SetAppAllowed(r.Context(), core.AppAudienceResellerClients, &rid, slugs); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar liberações")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"ok": true})
}


func validSlugs(in []string) []string {
	seen := map[string]bool{}
	var out []string
	for _, s := range in {
		if core.AppSlugValid(s) && !seen[s] {
			seen[s] = true
			out = append(out, s)
		}
	}
	return out
}

func contains(list []string, s string) bool {
	for _, x := range list {
		if x == s {
			return true
		}
	}
	return false
}

func nonNil(s []string) []string {
	if s == nil {
		return []string{}
	}
	return s
}

func randomAppDBName(slug string) string {
	b := make([]byte, 5)
	_, _ = rand.Read(b)
	prefix := "app_"
	if slug == "phpbb" {
		prefix = "phpbb_"
	}
	return prefix + hex.EncodeToString(b)
}
