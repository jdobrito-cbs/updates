package handlers

import (
	"errors"
	"net/http"

	"github.com/jdobrito/wsrta/api/internal/auth"
	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)




func (h *Handlers) SelfTenantStatus(w http.ResponseWriter, r *http.Request) {
	c, _ := auth.ClaimsFrom(r.Context())
	cid, err := h.store.SelfClientID(r.Context(), c.UserID)
	if errors.Is(err, store.ErrNotFound) {
		WriteJSON(w, http.StatusOK, map[string]any{"provisioned": false})
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao resolver VPS pessoal")
		return
	}
	client, err := h.store.GetClient(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar VPS pessoal")
		return
	}
	
	WriteJSON(w, http.StatusOK, map[string]any{
		"provisioned":     true,
		"client":          client,
		"can_edit_limits": c.Role == core.RoleAdmin,
	})
}




func (h *Handlers) ActivateSelfTenant(w http.ResponseWriter, r *http.Request) {
	if !h.selfAccessAllowed(w, r) { 
		return
	}
	c, _ := auth.ClaimsFrom(r.Context())
	name := "Minha VPS"
	if c.Role == core.RoleAdmin {
		name = "VPS do administrador"
	}
	cid, actionID, created, err := h.ensureSelfTenant(r.Context(), c.UserID, name,
		selfTenantDefaults.CPU, selfTenantDefaults.RAMMB, selfTenantDefaults.DiskMB,
		selfTenantDefaults.MaxDomains, selfTenantDefaults.MaxDatabases, selfTenantDefaults.BandwidthMB, c.UserID)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao ativar VPS pessoal")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"client_id": cid, "action_id": actionID, "created": created})
}

type selfLimitsRequest struct {
	CPULimit     float64 `json:"cpu_limit"`
	RAMLimitMB   int     `json:"ram_limit_mb"`
	DiskQuotaMB  int     `json:"disk_quota_mb"`
	MaxDomains   int     `json:"max_domains"`
	MaxDatabases int     `json:"max_databases"`
	BandwidthMB  int64   `json:"bandwidth_limit_mb"`
}




func (h *Handlers) SelfSetLimits(w http.ResponseWriter, r *http.Request) {
	c, _ := auth.ClaimsFrom(r.Context())
	if c.Role != core.RoleAdmin {
		WriteError(w, http.StatusForbidden, "os limites da sua VPS são definidos pelo administrador")
		return
	}
	cid, err := h.store.SelfClientID(r.Context(), c.UserID)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusConflict, "VPS pessoal ainda não ativada")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao resolver VPS pessoal")
		return
	}
	var req selfLimitsRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	req.CPULimit, req.RAMLimitMB, req.DiskQuotaMB = withLimitDefaults(req.CPULimit, req.RAMLimitMB, req.DiskQuotaMB)
	if !validatePositiveLimits(w, req.CPULimit, req.RAMLimitMB, req.DiskQuotaMB) {
		return
	}
	if req.MaxDomains < 0 || req.MaxDatabases < 0 || req.BandwidthMB < 0 {
		WriteError(w, http.StatusBadRequest, "limites não podem ser negativos")
		return
	}
	cur, err := h.store.GetClient(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar VPS pessoal")
		return
	}
	if err := h.store.UpdateClient(r.Context(), cid, cur.Name, req.CPULimit, req.RAMLimitMB, req.DiskQuotaMB, req.MaxDomains, req.MaxDatabases); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao atualizar limites")
		return
	}
	_ = h.store.SetClientBandwidthLimit(r.Context(), cid, req.BandwidthMB)
	actionID, err := h.enqueue(r.Context(), core.ActionApplyLimits,
		core.ApplyLimitsPayload{ClientID: cid, CPULimit: req.CPULimit, RAMLimitMB: req.RAMLimitMB, DiskQuotaMB: req.DiskQuotaMB}, c.UserID)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "limites salvos, mas falhou ao enfileirar o resize")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}
