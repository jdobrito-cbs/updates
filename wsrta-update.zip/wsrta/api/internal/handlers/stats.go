package handlers

import (
	"net/http"
)



func (h *Handlers) Stats(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}

	client, err := h.store.GetClient(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return
	}
	domains, databases, err := h.store.CountClientResources(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao contar recursos")
		return
	}

	WriteJSON(w, http.StatusOK, map[string]any{
		"status": client.Status,
		"limits": map[string]any{
			"cpu":     client.CPULimit,
			"ram_mb":  client.RAMLimitMB,
			"disk_mb": client.DiskQuotaMB,
		},
		"counts": map[string]any{
			"domains":   domains,
			"databases": databases,
		},
	})
}
