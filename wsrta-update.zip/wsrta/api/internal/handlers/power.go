package handlers

import (
	"errors"
	"net/http"

	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)

type powerClientRequest struct {
	Op string `json:"op"`
}




func (h *Handlers) PowerStatus(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	state, err := h.store.GetClientPowerState(r.Context(), cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "cliente não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao ler estado da VPS")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"state": state, "running": state != "stopped"})
}





func (h *Handlers) PowerClient(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	var req powerClientRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	switch req.Op {
	case "start", "stop", "restart":
	default:
		WriteError(w, http.StatusBadRequest, "op inválida (use start, stop ou restart)")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionPowerClient,
		core.PowerClientPayload{ClientID: cid, Op: req.Op}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}
