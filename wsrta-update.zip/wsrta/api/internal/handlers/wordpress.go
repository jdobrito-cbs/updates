package handlers

import (
	"crypto/rand"
	"encoding/hex"
	"errors"
	"net/http"

	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)


func (h *Handlers) ListWordPress(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	installs, err := h.store.ListWordPressInstalls(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar WordPress")
		return
	}
	WriteJSON(w, http.StatusOK, installs)
}

type installWordPressRequest struct {
	DomainID      int64  `json:"domain_id"`
	Path          string `json:"path"`
	AdminUser     string `json:"admin_user"`
	AdminEmail    string `json:"admin_email"`
	AdminPassword string `json:"admin_password"`
	Title         string `json:"title"`
}


func (h *Handlers) InstallWordPress(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	var req installWordPressRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if req.DomainID <= 0 || req.AdminUser == "" || req.AdminEmail == "" || req.AdminPassword == "" || req.Title == "" {
		WriteError(w, http.StatusBadRequest, "domain_id, admin_user, admin_email, admin_password e title são obrigatórios")
		return
	}

	
	dom, err := h.store.GetDomainOwned(r.Context(), req.DomainID, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "domínio não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar domínio")
		return
	}

	dbName := randomDBName()
	inst, err := h.store.CreateWordPressInstall(r.Context(), req.DomainID, req.Path, req.AdminUser, dbName)
	if isUniqueViolation(err) {
		WriteError(w, http.StatusConflict, "já existe WordPress neste caminho")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao registrar instalação")
		return
	}
	inst.FQDN = dom.FQDN

	actionID, err := h.enqueue(r.Context(), core.ActionInstallWordPress, core.InstallWordPressPayload{
		DomainID:      req.DomainID,
		Path:          req.Path,
		AdminUser:     req.AdminUser,
		AdminEmail:    req.AdminEmail,
		AdminPassword: req.AdminPassword,
		Title:         req.Title,
		DBName:        dbName,
	}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "instalação registrada, mas falhou ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusCreated, map[string]any{"install": inst, "action_id": actionID})
}


func (h *Handlers) RemoveWordPress(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	inst, err := h.store.GetWordPressInstallOwned(r.Context(), id, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "instalação não encontrada")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar instalação")
		return
	}

	actionID, err := h.enqueue(r.Context(), core.ActionRemoveWordPress, core.RemoveWordPressPayload{
		DomainID: inst.DomainID, Path: inst.Path, DBName: inst.DBName,
	}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar remoção")
		return
	}
	if err := h.store.DeleteWordPressInstall(r.Context(), id); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao apagar registro")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}

func randomDBName() string {
	b := make([]byte, 5)
	_, _ = rand.Read(b)
	return "wp_" + hex.EncodeToString(b)
}
