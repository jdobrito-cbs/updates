package handlers

import (
	"context"
	"fmt"
	"log/slog"
	"net"
	"net/http"
	"time"

	"github.com/jdobrito/wsrta/internal/core"
)



const autoBlockThreshold = 20



func isPublicIP(s string) bool {
	ip := net.ParseIP(s)
	if ip == nil {
		return false
	}
	return !(ip.IsLoopback() || ip.IsPrivate() || ip.IsLinkLocalUnicast() || ip.IsUnspecified() || ip.IsMulticast())
}


func (h *Handlers) ListSecurityEvents(w http.ResponseWriter, r *http.Request) {
	events, err := h.store.ListSecurityEvents(r.Context(), 200)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar eventos")
		return
	}
	if events == nil {
		events = []core.SecurityEvent{}
	}
	WriteJSON(w, http.StatusOK, events)
}



func (h *Handlers) recordAuthFailure(r *http.Request, eventType, email, detail string) {
	
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	ip := clientIP(r)
	ua := r.UserAgent()
	if _, err := h.store.LogSecurityEvent(ctx, core.SecurityEvent{
		EventType: eventType, Severity: core.VulnLow, IP: ip, Email: email, UserAgent: ua, Detail: detail,
	}); err != nil {
		h.log.Warn("registrar evento de segurança", slog.Any("err", err))
	}
	h.maybeAutoBlock(ctx, ip, email, ua)
}


func (h *Handlers) logSecurityEvent(r *http.Request, eventType, severity, email, detail string) {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	_, _ = h.store.LogSecurityEvent(ctx, core.SecurityEvent{
		EventType: eventType, Severity: severity, IP: clientIP(r), Email: email, UserAgent: r.UserAgent(), Detail: detail,
	})
}


func (h *Handlers) maybeAutoBlock(ctx context.Context, ip, email, ua string) {
	if !isPublicIP(ip) {
		return 
	}
	n, err := h.store.CountRecentAuthFailuresByIP(ctx, ip, time.Now().Add(-15*time.Minute))
	if err != nil || n < autoBlockThreshold {
		return
	}
	
	if blocked, _ := h.store.IPRecentlyAutoBlocked(ctx, ip, time.Now().Add(-6*time.Hour)); blocked {
		return
	}
	
	fwErr := h.files.FirewallAction(ctx, "deny", ip, "", "", "")
	detail := fmt.Sprintf("%d falhas de login/2FA em 15 min — IP bloqueado no firewall", n)
	if fwErr != nil {
		detail = fmt.Sprintf("%d falhas de login/2FA em 15 min — falha ao bloquear no firewall: %v", n, fwErr)
	}
	if _, err := h.store.LogSecurityEvent(ctx, core.SecurityEvent{
		EventType: "auto_blocked", Severity: core.VulnHigh, IP: ip, Email: email, UserAgent: ua,
		Detail: detail, Blocked: fwErr == nil,
	}); err != nil {
		h.log.Warn("registrar auto-bloqueio", slog.Any("err", err))
	}
	h.log.Warn("auto-bloqueio de IP por brute-force",
		slog.String("ip", ip), slog.Int("falhas", n), slog.Any("fw_err", fwErr))
}
