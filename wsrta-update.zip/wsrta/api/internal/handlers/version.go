package handlers

import (
	"net/http"

	"github.com/jdobrito/wsrta/internal/core"
)


func (h *Handlers) Version(w http.ResponseWriter, _ *http.Request) {
	WriteJSON(w, http.StatusOK, map[string]string{
		"version":    core.Version,
		"build_date": core.BuildDate,
	})
}
