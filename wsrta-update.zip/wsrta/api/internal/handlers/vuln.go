package handlers

import (
	"errors"
	"net/http"
	"strings"

	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)


func (h *Handlers) ListClientVulnScans(w http.ResponseWriter, r *http.Request) {
	id, err := idParam(r, "client_id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	scans, err := h.store.ListVulnScans(r.Context(), id, 20)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar scans")
		return
	}
	if scans == nil {
		scans = []core.VulnScan{}
	}
	WriteJSON(w, http.StatusOK, scans)
}


func (h *Handlers) CreateClientVulnScan(w http.ResponseWriter, r *http.Request) {
	id, err := idParam(r, "client_id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	if _, err := h.store.GetClient(r.Context(), id); errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "cliente não encontrado")
		return
	} else if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return
	}
	h.enqueueVulnScan(w, r, id)
}


func (h *Handlers) ListHostVulnScans(w http.ResponseWriter, r *http.Request) {
	scans, err := h.store.ListVulnScans(r.Context(), 0, 20)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar scans")
		return
	}
	if scans == nil {
		scans = []core.VulnScan{}
	}
	WriteJSON(w, http.StatusOK, scans)
}


func (h *Handlers) CreateHostVulnScan(w http.ResponseWriter, r *http.Request) {
	h.enqueueVulnScan(w, r, 0)
}


func (h *Handlers) enqueueVulnScan(w http.ResponseWriter, r *http.Request, clientID int64) {
	scanID, err := h.store.CreateVulnScan(r.Context(), clientID)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao criar o scan")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionScanVulnerabilities,
		
		
		core.ScanVulnerabilitiesPayload{ClientID: clientID, ScanID: scanID, Nikto: clientID > 0}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "scan criado, mas falhou ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"scan_id": scanID, "action_id": actionID})
}


func (h *Handlers) VulnScanFindings(w http.ResponseWriter, r *http.Request) {
	sid, err := idParam(r, "scan_id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	if _, err := h.store.GetVulnScan(r.Context(), sid); errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "scan não encontrado")
		return
	} else if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar o scan")
		return
	}
	fs, err := h.store.ListVulnFindings(r.Context(), sid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar achados")
		return
	}
	if fs == nil {
		fs = []core.VulnFinding{}
	}
	WriteJSON(w, http.StatusOK, fs)
}


func (h *Handlers) SetClientVulnSchedule(w http.ResponseWriter, r *http.Request) {
	id, err := idParam(r, "client_id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	var req struct {
		Schedule string `json:"schedule"`
	}
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	sched := strings.TrimSpace(req.Schedule)
	if sched != "" && sched != "daily" && sched != "weekly" {
		WriteError(w, http.StatusBadRequest, "agendamento inválido (use ''|daily|weekly)")
		return
	}
	if err := h.store.SetClientVulnSchedule(r.Context(), id, sched); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar o agendamento")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]string{"schedule": sched})
}
