package handlers

import (
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"strings"

	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)


func (h *Handlers) ListDomains(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	domains, err := h.store.ListDomains(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar domínios")
		return
	}
	WriteJSON(w, http.StatusOK, domains)
}

type createDomainRequest struct {
	FQDN       string `json:"fqdn"`
	PHPVersion string `json:"php_version"`
	
	
	
	
	Upstream string `json:"upstream"`
}



func parseUpstream(s string) (host string, port int, path string, err error) {
	s = strings.TrimSpace(s)
	s = strings.TrimPrefix(strings.TrimPrefix(s, "https://"), "http://")
	if s == "" {
		return "", 0, "", nil
	}
	hostport := s
	if i := strings.IndexByte(s, '/'); i >= 0 {
		hostport, path = s[:i], s[i:]
	}
	host = hostport
	if i := strings.IndexByte(hostport, ':'); i >= 0 {
		host = hostport[:i]
		p, e := strconv.Atoi(hostport[i+1:])
		if e != nil || p < 1 || p > 65535 {
			return "", 0, "", fmt.Errorf("porta inválida")
		}
		port = p
	}
	if err = core.ValidUpstreamHost(host); err != nil {
		return "", 0, "", err
	}
	if err = core.ValidUpstreamPath(path); err != nil {
		return "", 0, "", err
	}
	return host, port, path, nil
}


func (h *Handlers) CreateDomain(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	var req createDomainRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	fqdn := strings.ToLower(strings.TrimSpace(req.FQDN))
	if err := core.ValidFQDN(fqdn); err != nil {
		WriteError(w, http.StatusBadRequest, err.Error())
		return
	}

	
	upHost, upPort, upPath, err := parseUpstream(req.Upstream)
	if err != nil {
		WriteError(w, http.StatusBadRequest, "destino do servidor externo inválido: "+err.Error())
		return
	}

	if reached, err := h.domainLimitReached(r.Context(), cid); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao checar limite")
		return
	} else if reached {
		WriteError(w, http.StatusForbidden, "limite de domínios do cliente atingido")
		return
	}

	
	dom, err := h.store.CreateDomain(r.Context(), cid, fqdn, "", req.PHPVersion, upHost, upPort, upPath)
	if isUniqueViolation(err) {
		WriteError(w, http.StatusConflict, "domínio já cadastrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao criar domínio")
		return
	}

	actionID, err := h.enqueue(r.Context(), core.ActionAddDomain, core.AddDomainPayload{DomainID: dom.ID}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "domínio criado, mas falhou ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusCreated, map[string]any{"domain": dom, "action_id": actionID})
}


func (h *Handlers) DeleteDomain(w http.ResponseWriter, r *http.Request) {
	dom, ok := h.ownedDomain(w, r)
	if !ok {
		return
	}
	
	deleteFiles := r.URL.Query().Get("files") == "1"
	actionID, err := h.enqueue(r.Context(), core.ActionRemoveDomain,
		core.RemoveDomainPayload{DomainID: dom.ID, DeleteFiles: deleteFiles}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar remoção")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}


func (h *Handlers) IssueSSL(w http.ResponseWriter, r *http.Request) {
	dom, ok := h.ownedDomain(w, r)
	if !ok {
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionIssueSSL, core.IssueSSLPayload{DomainID: dom.ID}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar emissão de SSL")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}

type setDomainPHPRequest struct {
	Version string `json:"version"`
}




func (h *Handlers) SetDomainPHP(w http.ResponseWriter, r *http.Request) {
	dom, ok := h.ownedDomain(w, r)
	if !ok {
		return
	}
	var req setDomainPHPRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if !core.ValidPHPVersion(req.Version) {
		WriteError(w, http.StatusBadRequest, "versão de PHP inválida")
		return
	}
	
	
	actionID, err := h.enqueue(r.Context(), core.ActionSetDomainPHP,
		core.SetDomainPHPPayload{DomainID: dom.ID, PHPVersion: req.Version}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar a troca de PHP")
		return
	}
	if err := h.store.SetDomainPHPVersion(r.Context(), dom.ID, req.Version); err != nil {
		WriteError(w, http.StatusInternalServerError, "troca enfileirada, mas falhou ao gravar a versão no painel")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID, "php_version": req.Version})
}

type setDomainOfflineRequest struct {
	Mode string `json:"mode"`
}




func (h *Handlers) SetDomainOffline(w http.ResponseWriter, r *http.Request) {
	dom, ok := h.ownedDomain(w, r)
	if !ok {
		return
	}
	var req setDomainOfflineRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if !core.ValidOfflineMode(req.Mode) {
		WriteError(w, http.StatusBadRequest, "modo inválido (use '', 'maintenance' ou 'suspended')")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionSetDomainOffline,
		core.SetDomainOfflinePayload{DomainID: dom.ID, Mode: req.Mode}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	if err := h.store.SetDomainOfflineMode(r.Context(), dom.ID, req.Mode); err != nil {
		WriteError(w, http.StatusInternalServerError, "ação enfileirada, mas falhou ao gravar o modo")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID, "offline_mode": req.Mode})
}


func (h *Handlers) ownedDomain(w http.ResponseWriter, r *http.Request) (*core.Domain, bool) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return nil, false
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return nil, false
	}
	dom, err := h.store.GetDomainOwned(r.Context(), id, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "domínio não encontrado")
		return nil, false
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar domínio")
		return nil, false
	}
	return dom, true
}
