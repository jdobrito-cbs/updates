package handlers

import (
	"net/http"
	"strings"

	"github.com/jdobrito/wsrta/internal/core"
	"github.com/jdobrito/wsrta/internal/crypto"
)


func (h *Handlers) ClientCloudflareInfo(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	status, err := h.store.GetClientCloudflareStatus(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar status")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"status": status, "configured": status != ""})
}

type setCloudflareRequest struct {
	Token string `json:"token"`
}


func (h *Handlers) SetCloudflare(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	var req setCloudflareRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	token := strings.TrimSpace(req.Token)
	if len(token) < 20 || len(token) > 500 {
		WriteError(w, http.StatusBadRequest, "token inválido (cole o token do conector do túnel)")
		return
	}
	
	
	actionID, err := h.enqueue(r.Context(), core.ActionSetCloudflare,
		core.SetCloudflarePayload{ClientID: cid, Token: crypto.Encrypt(token)}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}

type controlCloudflareRequest struct {
	Op string `json:"op"`
}


func (h *Handlers) ControlCloudflare(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	var req controlCloudflareRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	switch req.Op {
	case "start", "stop", "restart":
	default:
		WriteError(w, http.StatusBadRequest, "op inválida (use start, stop ou restart)")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionControlCloudflare,
		core.ControlCloudflarePayload{ClientID: cid, Op: req.Op}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}
