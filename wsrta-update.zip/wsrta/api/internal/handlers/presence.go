package handlers

import (
	"net/http"
	"sync"
	"time"
)



var presenceTouched sync.Map 

const presenceThrottle = time.Minute




func (h *Handlers) TrackPresence(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if uid := userID(r); uid > 0 {
			now := time.Now()
			last, ok := presenceTouched.Load(uid)
			if !ok || now.Sub(last.(time.Time)) > presenceThrottle {
				presenceTouched.Store(uid, now)
				_ = h.store.TouchLastSeen(r.Context(), uid)
			}
		}
		next.ServeHTTP(w, r)
	})
}
