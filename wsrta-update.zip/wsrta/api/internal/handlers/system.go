package handlers

import (
	"os"
	"strconv"
	"strings"
)



func hostStats() map[string]any {
	out := map[string]any{}

	if b, err := os.ReadFile("/proc/loadavg"); err == nil {
		fields := strings.Fields(string(b))
		if len(fields) >= 3 {
			out["loadavg"] = map[string]string{"1m": fields[0], "5m": fields[1], "15m": fields[2]}
		}
	}

	if mem := readMeminfo(); mem != nil {
		out["memory_kb"] = mem
	}

	return out
}


func readMeminfo() map[string]int64 {
	b, err := os.ReadFile("/proc/meminfo")
	if err != nil {
		return nil
	}
	want := map[string]string{"MemTotal:": "total", "MemAvailable:": "available"}
	out := map[string]int64{}
	for _, line := range strings.Split(string(b), "\n") {
		fields := strings.Fields(line)
		if len(fields) < 2 {
			continue
		}
		if key, ok := want[fields[0]]; ok {
			if v, err := strconv.ParseInt(fields[1], 10, 64); err == nil {
				out[key] = v
			}
		}
	}
	if len(out) == 0 {
		return nil
	}
	return out
}
