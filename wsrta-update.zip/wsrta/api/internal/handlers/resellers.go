package handlers

import (
	"errors"
	"log/slog"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"

	"github.com/jdobrito/wsrta/api/internal/auth"
	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)



var LandingTemplates = map[string]bool{
	"aurora": true, "midnight": true, "sunset": true, "forest": true, "ocean": true,
	"royal": true, "ember": true, "slate": true, "neon": true, "sand": true, "rose": true, "mono": true,
}

var slugRe = regexp.MustCompile(`^[a-z0-9][a-z0-9-]{1,40}$`)

type resellerSiteRequest struct {
	Slug            string `json:"slug"`
	Template        string `json:"landing_template"`
	Headline        string `json:"landing_headline"`
	Subtitle        string `json:"landing_subtitle"`
	ExternalSiteURL string `json:"external_site_url"`
}



func (h *Handlers) UpdateResellerSite(w http.ResponseWriter, r *http.Request) {
	rid, ok := h.resellerID(w, r)
	if !ok {
		return
	}
	var req resellerSiteRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	slug := strings.ToLower(strings.TrimSpace(req.Slug))
	if slug != "" && !slugRe.MatchString(slug) {
		WriteError(w, http.StatusBadRequest, "slug inválida (minúsculas, números e hífen)")
		return
	}
	tpl := strings.TrimSpace(req.Template)
	if !LandingTemplates[tpl] {
		tpl = "aurora"
	}
	
	
	ext := strings.TrimSpace(req.ExternalSiteURL)
	if ext != "" {
		u, err := url.Parse(ext)
		if err != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Host == "" {
			WriteError(w, http.StatusBadRequest, "site externo inválido (use http(s)://dominio)")
			return
		}
	}
	if err := h.store.UpdateResellerSite(r.Context(), rid, slug, tpl,
		strings.TrimSpace(req.Headline), strings.TrimSpace(req.Subtitle), ext); isUniqueViolation(err) {
		WriteError(w, http.StatusConflict, "essa slug já está em uso")
		return
	} else if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "revendedor não encontrado")
		return
	} else if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar o site")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"ok": true})
}



func (h *Handlers) Edition(w http.ResponseWriter, _ *http.Request) {
	ed := h.edition
	if ed == "" {
		ed = core.EditionSimple
	}
	WriteJSON(w, http.StatusOK, map[string]any{
		"edition":  ed,
		"complete": ed == core.EditionComplete,
	})
}



func (h *Handlers) ResellerMe(w http.ResponseWriter, r *http.Request) {
	c, _ := auth.ClaimsFrom(r.Context())
	rs, err := h.store.GetResellerByUserID(r.Context(), c.UserID)
	if err != nil {
		WriteError(w, http.StatusNotFound, "revendedor não encontrado")
		return
	}
	WriteJSON(w, http.StatusOK, rs)
}

type resellerRequest struct {
	Email     string `json:"email"`
	Password  string `json:"password"`
	Name      string `json:"name"`
	ExpiresAt string `json:"expires_at"` 
	
	MaxClients int `json:"max_clients"`
	
	CPULimit     float64 `json:"cpu_limit"`
	RAMLimitMB   int     `json:"ram_limit_mb"`
	DiskQuotaMB  int     `json:"disk_quota_mb"`
	MaxDomains   int     `json:"max_domains"`
	MaxDatabases int     `json:"max_databases"`
	MaxMailboxes int     `json:"max_mailboxes"`
	BandwidthMB  int64   `json:"bandwidth_limit_mb"`
}


func parseExpiry(s string) (*time.Time, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return nil, nil
	}
	for _, layout := range []string{time.RFC3339, "2006-01-02"} {
		if t, err := time.Parse(layout, s); err == nil {
			return &t, nil
		}
	}
	return nil, errors.New("data de validade inválida")
}


func (h *Handlers) ListResellers(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	list, err := h.store.ListResellers(r.Context(), strings.TrimSpace(r.URL.Query().Get("q")))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar revendedores")
		return
	}
	if list == nil {
		list = []core.Reseller{}
	}
	WriteJSON(w, http.StatusOK, list)
}



func (h *Handlers) CreateReseller(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	var req resellerRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	req.Email = strings.TrimSpace(req.Email)
	req.Name = strings.TrimSpace(req.Name)
	if !validEmail(req.Email) || len(req.Password) < 8 || req.Name == "" {
		WriteError(w, http.StatusBadRequest, "email válido, name e password (>=8) são obrigatórios")
		return
	}
	expires, err := parseExpiry(req.ExpiresAt)
	if err != nil {
		WriteError(w, http.StatusBadRequest, err.Error())
		return
	}
	hash, err := auth.HashPassword(req.Password)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao processar senha")
		return
	}
	if req.MaxClients < 0 {
		req.MaxClients = 0
	}
	cpu, ram, disk := withLimitDefaults(req.CPULimit, req.RAMLimitMB, req.DiskQuotaMB)
	if !validatePositiveLimits(w, cpu, ram, disk) {
		return
	}
	if req.MaxDomains < 0 || req.MaxDatabases < 0 || req.BandwidthMB < 0 {
		WriteError(w, http.StatusBadRequest, "limites não podem ser negativos")
		return
	}
	id, ownerUserID, err := h.store.CreateResellerWithUser(r.Context(), req.Email, hash, req.Name, expires, req.MaxClients)
	if isUniqueViolation(err) {
		WriteError(w, http.StatusConflict, "email já cadastrado")
		return
	}
	if err != nil {
		h.log.Error("create reseller", slog.Any("err", err))
		WriteError(w, http.StatusInternalServerError, "erro ao criar revendedor")
		return
	}
	
	
	if selfID, _, _, e := h.ensureSelfTenant(r.Context(), ownerUserID, "VPS da revenda "+req.Name,
		cpu, ram, disk, req.MaxDomains, req.MaxDatabases, req.BandwidthMB, userID(r)); e != nil {
		
		h.log.Error("provisionar VPS pessoal da revenda", slog.Any("err", e))
	} else if req.MaxMailboxes > 0 {
		_ = h.store.SetClientMaxMailboxes(r.Context(), selfID, req.MaxMailboxes)
	}
	WriteJSON(w, http.StatusCreated, map[string]any{"reseller_id": id})
}


func (h *Handlers) UpdateReseller(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	var req resellerRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	req.Name = strings.TrimSpace(req.Name)
	if req.Name == "" {
		WriteError(w, http.StatusBadRequest, "name é obrigatório")
		return
	}
	expires, err := parseExpiry(req.ExpiresAt)
	if err != nil {
		WriteError(w, http.StatusBadRequest, err.Error())
		return
	}
	if req.MaxClients < 0 {
		req.MaxClients = 0
	}
	cpu, ram, disk := withLimitDefaults(req.CPULimit, req.RAMLimitMB, req.DiskQuotaMB)
	if !validatePositiveLimits(w, cpu, ram, disk) {
		return
	}
	if req.MaxDomains < 0 || req.MaxDatabases < 0 || req.BandwidthMB < 0 {
		WriteError(w, http.StatusBadRequest, "limites não podem ser negativos")
		return
	}
	rs, err := h.store.GetReseller(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "revendedor não encontrado")
		return
	} else if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar revendedor")
		return
	}
	if err := h.store.UpdateReseller(r.Context(), id, req.Name, expires, req.MaxClients); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao atualizar revendedor")
		return
	}
	
	
	if cid, e := h.store.SelfClientID(r.Context(), rs.UserID); e == nil {
		_ = h.store.UpdateClient(r.Context(), cid, "VPS da revenda "+req.Name, cpu, ram, disk, req.MaxDomains, req.MaxDatabases)
		if req.BandwidthMB >= 0 {
			_ = h.store.SetClientBandwidthLimit(r.Context(), cid, req.BandwidthMB)
		}
		if req.MaxMailboxes >= 0 {
			_ = h.store.SetClientMaxMailboxes(r.Context(), cid, req.MaxMailboxes)
		}
		_, _ = h.enqueue(r.Context(), core.ActionApplyLimits,
			core.ApplyLimitsPayload{ClientID: cid, CPULimit: cpu, RAMLimitMB: ram, DiskQuotaMB: disk}, userID(r))
	} else if errors.Is(e, store.ErrNotFound) {
		_, _, _, _ = h.ensureSelfTenant(r.Context(), rs.UserID, "VPS da revenda "+req.Name,
			cpu, ram, disk, req.MaxDomains, req.MaxDatabases, req.BandwidthMB, userID(r))
	}
	WriteJSON(w, http.StatusOK, map[string]any{"ok": true})
}


func (h *Handlers) setResellerStatus(w http.ResponseWriter, r *http.Request, status string) {
	if !h.requireComplete(w) {
		return
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	if err := h.store.SetResellerStatus(r.Context(), id, status); errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "revendedor não encontrado")
		return
	} else if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao alterar status")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"status": status})
}


func (h *Handlers) SuspendReseller(w http.ResponseWriter, r *http.Request) {
	h.setResellerStatus(w, r, "suspended")
}
func (h *Handlers) ResumeReseller(w http.ResponseWriter, r *http.Request) {
	h.setResellerStatus(w, r, "active")
}





func (h *Handlers) DeleteReseller(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	
	rs, err := h.store.GetReseller(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "revendedor não encontrado")
		return
	} else if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar revendedor")
		return
	}
	
	clients, err := h.store.ListClientsByReseller(r.Context(), id, "")
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar clientes da revenda")
		return
	}
	var enqueued []int64
	for _, c := range clients {
		actionID, e := h.enqueue(r.Context(), core.ActionDeprovisionClient,
			core.DeprovisionClientPayload{ClientID: c.ID}, userID(r))
		if e != nil {
			WriteError(w, http.StatusInternalServerError, "erro ao desprovisionar clientes da revenda")
			return
		}
		enqueued = append(enqueued, actionID)
	}
	
	
	
	
	if selfID, e := h.store.SelfClientID(r.Context(), rs.UserID); e == nil {
		if actionID, e2 := h.enqueue(r.Context(), core.ActionDeprovisionClient,
			core.DeprovisionClientPayload{ClientID: selfID}, userID(r)); e2 == nil {
			enqueued = append(enqueued, actionID)
		}
		_ = h.store.MarkClientDeleted(r.Context(), selfID)
	}
	if err := h.store.DeleteReseller(r.Context(), id); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao remover revendedor")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"deleted": id, "deprovisioned_clients": enqueued})
}
