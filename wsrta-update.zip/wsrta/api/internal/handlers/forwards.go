package handlers

import (
	"errors"
	"net/http"
	"strings"

	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)


func (h *Handlers) ListForwards(w http.ResponseWriter, r *http.Request) {
	dom, ok := h.ownedDomain(w, r)
	if !ok {
		return
	}
	fwds, err := h.store.ListForwards(r.Context(), dom.ID)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar encaminhamentos")
		return
	}
	if fwds == nil {
		fwds = []core.DomainForward{}
	}
	WriteJSON(w, http.StatusOK, fwds)
}



func (h *Handlers) CreateForward(w http.ResponseWriter, r *http.Request) {
	dom, ok := h.ownedDomain(w, r)
	if !ok {
		return
	}
	var req struct {
		Path     string `json:"path"`
		Target   string `json:"target"`
		Internal bool   `json:"internal"` 
	}
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	path := strings.TrimSpace(req.Path)
	if !strings.HasPrefix(path, "/") {
		path = "/" + path
	}
	if path == "/" || core.ValidUpstreamPath(path) != nil {
		WriteError(w, http.StatusBadRequest, "caminho inválido (ex.: /loja)")
		return
	}
	var (
		target         string
		targetDomainID int64
	)
	if req.Internal {
		
		
		
		fqdn := strings.ToLower(strings.TrimSpace(req.Target))
		if err := core.ValidFQDN(fqdn); err != nil {
			WriteError(w, http.StatusBadRequest, "domínio alvo inválido")
			return
		}
		td, err := h.store.DomainByFQDN(r.Context(), fqdn)
		if errors.Is(err, store.ErrNotFound) {
			WriteError(w, http.StatusBadRequest, "domínio não encontrado no servidor")
			return
		}
		if err != nil {
			WriteError(w, http.StatusInternalServerError, "erro ao buscar o domínio alvo")
			return
		}
		if td.ID == dom.ID {
			WriteError(w, http.StatusBadRequest, "o destino não pode ser o próprio domínio")
			return
		}
		target = td.FQDN
		targetDomainID = td.ID
	} else {
		target = strings.TrimPrefix(strings.TrimPrefix(strings.TrimSpace(req.Target), "https://"), "http://")
		if err := core.ValidUpstreamTarget(target); err != nil {
			WriteError(w, http.StatusBadRequest, "destino inválido: "+err.Error())
			return
		}
	}
	f, err := h.store.CreateForward(r.Context(), dom.ID, path, target, targetDomainID)
	if isUniqueViolation(err) {
		WriteError(w, http.StatusConflict, "já existe um encaminhamento para esse caminho")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao criar encaminhamento")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionSetDomainForwards, core.SetDomainForwardsPayload{DomainID: dom.ID}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "encaminhamento criado, mas falhou ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusCreated, map[string]any{"forward": f, "action_id": actionID})
}


func (h *Handlers) DeleteForward(w http.ResponseWriter, r *http.Request) {
	dom, ok := h.ownedDomain(w, r)
	if !ok {
		return
	}
	fwid, err := idParam(r, "forward_id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	if err := h.store.DeleteForward(r.Context(), fwid, dom.ID); errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "encaminhamento não encontrado")
		return
	} else if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao remover encaminhamento")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionSetDomainForwards, core.SetDomainForwardsPayload{DomainID: dom.ID}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "removido, mas falhou ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"action_id": actionID})
}
