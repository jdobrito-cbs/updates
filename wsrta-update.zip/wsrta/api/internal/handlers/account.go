package handlers

import (
	"errors"
	"net/http"

	"github.com/jdobrito/wsrta/api/internal/auth"
	"github.com/jdobrito/wsrta/api/internal/store"
)

const minPasswordLen = 8



func (h *Handlers) ChangeOwnPassword(w http.ResponseWriter, r *http.Request) {
	var req struct {
		CurrentPassword string `json:"current_password"`
		NewPassword     string `json:"new_password"`
	}
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if len(req.NewPassword) < minPasswordLen {
		WriteError(w, http.StatusBadRequest, "a nova senha deve ter ao menos 8 caracteres")
		return
	}
	uid := userID(r)
	user, err := h.store.GetUserByID(r.Context(), uid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar usuário")
		return
	}
	if ok, _ := auth.VerifyPassword(req.CurrentPassword, user.PasswordHash); !ok {
		WriteError(w, http.StatusUnauthorized, "senha atual incorreta")
		return
	}
	hash, err := auth.HashPassword(req.NewPassword)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao processar a senha")
		return
	}
	if err := h.store.UpdatePassword(r.Context(), uid, hash); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar a senha")
		return
	}
	
	_ = h.store.InvalidateUserTokens(r.Context(), uid)
	WriteJSON(w, http.StatusOK, map[string]bool{"ok": true})
}



func (h *Handlers) AdminSetClientPassword(w http.ResponseWriter, r *http.Request) {
	id, err := idParam(r, "client_id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "client_id inválido")
		return
	}
	var req struct {
		NewPassword string `json:"new_password"`
	}
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if len(req.NewPassword) < minPasswordLen {
		WriteError(w, http.StatusBadRequest, "a nova senha deve ter ao menos 8 caracteres")
		return
	}
	uid, err := h.store.ClientUserID(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "cliente não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar o cliente")
		return
	}
	hash, err := auth.HashPassword(req.NewPassword)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao processar a senha")
		return
	}
	if err := h.store.UpdatePassword(r.Context(), uid, hash); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar a senha")
		return
	}
	
	_ = h.store.InvalidateUserTokens(r.Context(), uid)
	WriteJSON(w, http.StatusOK, map[string]bool{"ok": true})
}
