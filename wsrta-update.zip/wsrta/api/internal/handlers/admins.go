package handlers

import (
	"errors"
	"net/http"
	"strings"

	"github.com/jdobrito/wsrta/api/internal/auth"
	"github.com/jdobrito/wsrta/api/internal/store"
)



func validEmail(s string) bool {
	s = strings.TrimSpace(s)
	if len(s) < 3 || len(s) > 254 || strings.ContainsAny(s, " \t\r\n") {
		return false
	}
	at := strings.IndexByte(s, '@')
	return at > 0 && strings.IndexByte(s[at+1:], '.') > 0
}



func (h *Handlers) ListAdmins(w http.ResponseWriter, r *http.Request) {
	q := strings.TrimSpace(r.URL.Query().Get("q"))
	admins, err := h.store.ListAdmins(r.Context(), q)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar admins")
		return
	}
	if admins == nil {
		admins = []store.AdminInfo{}
	}
	WriteJSON(w, http.StatusOK, map[string]any{"admins": admins, "current": userID(r)})
}


func (h *Handlers) CreateAdmin(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Email          string `json:"email"`
		Name           string `json:"name"`
		Password       string `json:"password"`
		SessionMinutes int    `json:"session_timeout_minutes"`
	}
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	req.Email = strings.TrimSpace(req.Email)
	req.Name = strings.TrimSpace(req.Name)
	if !validEmail(req.Email) {
		WriteError(w, http.StatusBadRequest, "email inválido")
		return
	}
	if req.Name == "" || len(req.Name) > 80 {
		WriteError(w, http.StatusBadRequest, "informe o nome do admin (até 80 caracteres)")
		return
	}
	if len(req.Password) < minPasswordLen {
		WriteError(w, http.StatusBadRequest, "a senha deve ter ao menos 8 caracteres")
		return
	}
	if !validSessionMinutes(req.SessionMinutes) {
		WriteError(w, http.StatusBadRequest, "limite de sessão inválido (0 = global, ou 1 a 1440)")
		return
	}
	hash, err := auth.HashPassword(req.Password)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao processar a senha")
		return
	}
	id, err := h.store.CreateAdmin(r.Context(), req.Email, req.Name, hash, req.SessionMinutes)
	if isUniqueViolation(err) {
		WriteError(w, http.StatusConflict, "já existe um usuário com esse email")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao criar o admin")
		return
	}
	WriteJSON(w, http.StatusCreated, map[string]any{"id": id})
}


func (h *Handlers) UpdateAdmin(w http.ResponseWriter, r *http.Request) {
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	var req struct {
		Email          string `json:"email"`
		Name           string `json:"name"`
		Password       string `json:"password"`
		SessionMinutes int    `json:"session_timeout_minutes"`
	}
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	req.Email = strings.TrimSpace(req.Email)
	req.Name = strings.TrimSpace(req.Name)
	if !validEmail(req.Email) {
		WriteError(w, http.StatusBadRequest, "email inválido")
		return
	}
	if req.Name == "" || len(req.Name) > 80 {
		WriteError(w, http.StatusBadRequest, "informe o nome do admin (até 80 caracteres)")
		return
	}
	if !validSessionMinutes(req.SessionMinutes) {
		WriteError(w, http.StatusBadRequest, "limite de sessão inválido (0 = global, ou 1 a 1440)")
		return
	}
	hash := ""
	if req.Password != "" {
		if len(req.Password) < minPasswordLen {
			WriteError(w, http.StatusBadRequest, "a senha deve ter ao menos 8 caracteres")
			return
		}
		if hash, err = auth.HashPassword(req.Password); err != nil {
			WriteError(w, http.StatusInternalServerError, "erro ao processar a senha")
			return
		}
	}
	err = h.store.UpdateAdmin(r.Context(), id, req.Email, req.Name, hash, req.SessionMinutes)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "admin não encontrado")
		return
	}
	if isUniqueViolation(err) {
		WriteError(w, http.StatusConflict, "já existe um usuário com esse email")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar o admin")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]bool{"ok": true})
}



func (h *Handlers) setAdminBlock(w http.ResponseWriter, r *http.Request, block bool) {
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	if block && id == userID(r) {
		WriteError(w, http.StatusBadRequest, "não é possível bloquear o seu próprio usuário")
		return
	}
	status := "active"
	if block {
		status = "blocked"
	}
	err = h.store.SetAdminStatus(r.Context(), id, status)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "admin não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao alterar o status do admin")
		return
	}
	
	if block {
		_ = h.store.InvalidateUserTokens(r.Context(), id)
	}
	WriteJSON(w, http.StatusOK, map[string]bool{"ok": true})
}


func (h *Handlers) BlockAdmin(w http.ResponseWriter, r *http.Request) { h.setAdminBlock(w, r, true) }


func (h *Handlers) UnblockAdmin(w http.ResponseWriter, r *http.Request) { h.setAdminBlock(w, r, false) }




func (h *Handlers) DeleteAdmin(w http.ResponseWriter, r *http.Request) {
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	if id == userID(r) {
		WriteError(w, http.StatusBadRequest, "não é possível excluir o seu próprio usuário; entre com outro admin para fazê-lo")
		return
	}
	n, err := h.store.CountAdmins(r.Context())
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao contar admins")
		return
	}
	if n <= 1 {
		WriteError(w, http.StatusBadRequest, "deve existir ao menos um admin")
		return
	}
	err = h.store.DeleteAdmin(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "admin não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao excluir o admin")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]bool{"ok": true})
}
