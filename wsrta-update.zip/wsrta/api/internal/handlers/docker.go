package handlers

import (
	"net/http"
	"regexp"
	"strings"

	"github.com/jdobrito/wsrta/internal/core"
)


var dockerNameRe = regexp.MustCompile(`^[A-Za-z0-9][A-Za-z0-9_.-]{0,63}$`)



const dockerHostPortBase = 41000


type DockerContainer struct {
	Name  string `json:"name"`
	State string `json:"state"`
	Image string `json:"image"`
	Ports string `json:"ports"`
}


func (h *Handlers) dockerContainer(w http.ResponseWriter, r *http.Request) (cid int64, container string, enabled bool, ok bool) {
	cid, k := h.targetClientID(w, r)
	if !k {
		return 0, "", false, false
	}
	c, err := h.store.GetClient(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return 0, "", false, false
	}
	return cid, c.LXCContainerName, c.DockerEnabled, true
}


func (h *Handlers) DockerInfo(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	_, container, enabled, ok := h.dockerContainer(w, r)
	if !ok {
		return
	}
	containers := []DockerContainer{}
	if enabled {
		res, err := h.files.Docker(r.Context(), container,
			[]string{"ps", "-a", "--no-trunc", "--format", "{{.Names}}\t{{.State}}\t{{.Image}}\t{{.Ports}}"})
		if err == nil && res.Exit == 0 {
			for _, line := range strings.Split(strings.TrimSpace(res.Stdout), "\n") {
				if line == "" {
					continue
				}
				f := strings.SplitN(line, "\t", 4)
				dc := DockerContainer{Name: f[0]}
				if len(f) > 1 {
					dc.State = f[1]
				}
				if len(f) > 2 {
					dc.Image = f[2]
				}
				if len(f) > 3 {
					dc.Ports = f[3]
				}
				containers = append(containers, dc)
			}
		}
	}
	WriteJSON(w, http.StatusOK, map[string]any{"enabled": enabled, "containers": containers})
}


func (h *Handlers) EnableDocker(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionEnableDocker, core.DockerTogglePayload{ClientID: cid}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}


func (h *Handlers) DisableDocker(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionDisableDocker, core.DockerTogglePayload{ClientID: cid}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}

type dockerControlRequest struct {
	Op   string `json:"op"`   
	Name string `json:"name"` 
}



func (h *Handlers) DockerControl(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	_, container, enabled, ok := h.dockerContainer(w, r)
	if !ok {
		return
	}
	if !enabled {
		WriteError(w, http.StatusConflict, "Docker não está habilitado nesta VPS")
		return
	}
	var req dockerControlRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if !dockerNameRe.MatchString(req.Name) {
		WriteError(w, http.StatusBadRequest, "nome de container inválido")
		return
	}
	var args []string
	switch req.Op {
	case "start", "stop", "restart":
		args = []string{req.Op, req.Name}
	case "remove":
		args = []string{"rm", "-f", req.Name}
	default:
		WriteError(w, http.StatusBadRequest, "op inválida (use start, stop, restart ou remove)")
		return
	}
	res, err := h.files.Docker(r.Context(), container, args)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao falar com o daemon")
		return
	}
	if res.Exit != 0 {
		WriteError(w, http.StatusUnprocessableEntity, strings.TrimSpace(res.Stderr))
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"ok": true})
}
