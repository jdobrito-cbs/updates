package handlers

import (
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"strings"
	"time"

	"github.com/jdobrito/wsrta/api/internal/auth"
	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)

const recoveryCodeCount = 8


const defaultSessionMinutes = 60

var errPre2FA = errors.New("token de 2FA inválido")



var dummyPasswordHash, _ = auth.HashPassword("wsrta-timing-equalizer")

type loginRequest struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}




func (h *Handlers) Login(w http.ResponseWriter, r *http.Request) {
	if !h.rate.Allow(clientIP(r)) {
		h.logSecurityEvent(r, "rate_limited", core.VulnLow, "", "rate-limit atingido no login")
		WriteError(w, http.StatusTooManyRequests, "muitas tentativas; tente novamente em instantes")
		return
	}

	var req loginRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}

	
	maxAtt, lockDur := h.loginPolicy(r.Context())
	if maxAtt > 0 {
		if rem := loginLocked(req.Email); rem > 0 {
			h.logSecurityEvent(r, "account_locked", core.VulnMedium, req.Email, "conta temporariamente bloqueada por tentativas repetidas")
			WriteError(w, http.StatusForbidden, fmt.Sprintf("muitas tentativas — conta bloqueada por %d min", int(rem.Minutes())+1))
			return
		}
	}

	user, err := h.store.GetUserByEmail(r.Context(), req.Email)
	if errors.Is(err, store.ErrNotFound) {
		_, _ = auth.VerifyPassword(req.Password, dummyPasswordHash) 
		loginFail(req.Email, maxAtt, lockDur)
		h.recordAuthFailure(r, "login_failed", req.Email, "e-mail não encontrado")
		WriteError(w, http.StatusUnauthorized, "credenciais inválidas")
		return
	}
	if err != nil {
		h.log.Error("login: buscar usuário", slog.Any("err", err))
		WriteError(w, http.StatusInternalServerError, "erro interno")
		return
	}

	if ok, _ := auth.VerifyPassword(req.Password, user.PasswordHash); !ok {
		loginFail(req.Email, maxAtt, lockDur)
		h.recordAuthFailure(r, "login_failed", req.Email, "senha incorreta")
		WriteError(w, http.StatusUnauthorized, "credenciais inválidas")
		return
	}
	if user.Status != "active" {
		WriteError(w, http.StatusForbidden, "conta suspensa")
		return
	}
	
	loginReset(req.Email)

	pre, err := h.tokens.IssuePre2FA(user.ID)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao iniciar sessão")
		return
	}

	if !user.TOTPEnabled {
		secret, url, err := auth.GenerateTOTP(h.totpIssuer, user.Email)
		if err != nil {
			WriteError(w, http.StatusInternalServerError, "erro ao gerar 2FA")
			return
		}
		if err := h.store.SetTOTPSecret(r.Context(), user.ID, secret); err != nil {
			WriteError(w, http.StatusInternalServerError, "erro ao salvar 2FA")
			return
		}
		WriteJSON(w, http.StatusOK, map[string]any{
			"stage":       "enroll",
			"token":       pre,
			"otpauth_url": url,
			"secret":      secret,
		})
		return
	}

	WriteJSON(w, http.StatusOK, map[string]any{"stage": "mfa", "token": pre})
}

type twoFARequest struct {
	Token string `json:"token"`
	Code  string `json:"code"`
}

func (h *Handlers) pre2faUserID(token string) (int64, error) {
	claims, err := h.tokens.Parse(token)
	if err != nil || claims.Stage != auth.StagePre2FA {
		return 0, errPre2FA
	}
	return claims.UserID, nil
}



func (h *Handlers) Enroll2FA(w http.ResponseWriter, r *http.Request) {
	if !h.rate.Allow(clientIP(r)) {
		WriteError(w, http.StatusTooManyRequests, "muitas tentativas; tente novamente em instantes")
		return
	}
	var req twoFARequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	uid, err := h.pre2faUserID(req.Token)
	if err != nil {
		WriteError(w, http.StatusUnauthorized, "sessão de 2FA inválida")
		return
	}
	user, err := h.store.GetUserByID(r.Context(), uid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar usuário")
		return
	}
	if user.TOTPSecret == nil || !auth.ValidateTOTP(*user.TOTPSecret, strings.TrimSpace(req.Code)) {
		WriteError(w, http.StatusUnauthorized, "código inválido")
		return
	}
	if err := h.store.EnableTOTP(r.Context(), uid); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao ativar 2FA")
		return
	}
	plain, hashes, err := auth.GenerateRecoveryCodes(recoveryCodeCount)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao gerar códigos")
		return
	}
	if err := h.store.ReplaceRecoveryCodes(r.Context(), uid, hashes); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar códigos")
		return
	}
	h.issueSession(w, r, user, plain)
}


func (h *Handlers) Verify2FA(w http.ResponseWriter, r *http.Request) {
	if !h.rate.Allow(clientIP(r)) {
		WriteError(w, http.StatusTooManyRequests, "muitas tentativas; tente novamente em instantes")
		return
	}
	var req twoFARequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	uid, err := h.pre2faUserID(req.Token)
	if err != nil {
		WriteError(w, http.StatusUnauthorized, "sessão de 2FA inválida")
		return
	}
	user, err := h.store.GetUserByID(r.Context(), uid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar usuário")
		return
	}
	if user.TOTPSecret == nil || !user.TOTPEnabled {
		WriteError(w, http.StatusBadRequest, "2FA não configurado")
		return
	}

	code := strings.TrimSpace(req.Code)
	verified := auth.ValidateTOTP(*user.TOTPSecret, code)
	if !verified {
		consumed, err := h.store.ConsumeRecoveryCode(r.Context(), uid, auth.HashRecoveryCode(code))
		if err != nil {
			WriteError(w, http.StatusInternalServerError, "erro ao validar código")
			return
		}
		verified = consumed
	}
	if !verified {
		h.recordAuthFailure(r, "2fa_failed", user.Email, "código 2FA inválido")
		WriteError(w, http.StatusUnauthorized, "código inválido")
		return
	}
	h.issueSession(w, r, user, nil)
}


func (h *Handlers) issueSession(w http.ResponseWriter, r *http.Request, user *core.User, recoveryCodes []string) {
	cid, err := h.store.ClientIDByUserID(r.Context(), user.ID)
	if err != nil {
		h.log.Error("login: client id", slog.Any("err", err))
		WriteError(w, http.StatusInternalServerError, "erro interno")
		return
	}
	
	
	mins := user.SessionTimeoutMinutes
	if mins <= 0 {
		mins = defaultSessionMinutes
	}
	token, err := h.tokens.IssueWithTTL(user.ID, user.Role, cid, time.Duration(mins)*time.Minute)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao emitir token")
		return
	}
	resp := map[string]any{
		"stage":                   "done",
		"token":                   token,
		"role":                    user.Role,
		"client_id":               cid,
		"session_timeout_minutes": mins,
	}
	if recoveryCodes != nil {
		resp["recovery_codes"] = recoveryCodes
	}
	WriteJSON(w, http.StatusOK, resp)
}


func (h *Handlers) Logout(w http.ResponseWriter, r *http.Request) {
	
	
	_ = h.store.InvalidateUserTokens(r.Context(), userID(r))
	WriteJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}



func (h *Handlers) Me(w http.ResponseWriter, r *http.Request) {
	c, _ := auth.ClaimsFrom(r.Context())
	mins := defaultSessionMinutes
	if u, err := h.store.GetUserByID(r.Context(), c.UserID); err == nil && u.SessionTimeoutMinutes > 0 {
		mins = u.SessionTimeoutMinutes
	}
	ed := h.edition
	if ed == "" {
		ed = core.EditionSimple
	}
	WriteJSON(w, http.StatusOK, map[string]any{
		"user_id":                 c.UserID,
		"role":                    c.Role,
		"client_id":               c.ClientID,
		"session_timeout_minutes": mins,
		"edition":                 ed,
	})
}






func (h *Handlers) RefreshSession(w http.ResponseWriter, r *http.Request) {
	c, ok := auth.ClaimsFrom(r.Context())
	if !ok {
		WriteError(w, http.StatusUnauthorized, "não autenticado")
		return
	}
	mins := defaultSessionMinutes
	if u, err := h.store.GetUserByID(r.Context(), c.UserID); err == nil && u.SessionTimeoutMinutes > 0 {
		mins = u.SessionTimeoutMinutes
	}
	token, err := h.tokens.IssueWithTTL(c.UserID, c.Role, c.ClientID, time.Duration(mins)*time.Minute)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao emitir token")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{
		"token":                   token,
		"session_timeout_minutes": mins,
	})
}
