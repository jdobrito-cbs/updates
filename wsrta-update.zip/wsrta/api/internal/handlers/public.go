package handlers

import (
	"errors"
	"net/http"

	"github.com/go-chi/chi/v5"

	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)


type publicPackage struct {
	ID               int64   `json:"id"`
	Name             string  `json:"name"`
	PriceCents       int64   `json:"price_cents"`
	CPULimit         float64 `json:"cpu_limit"`
	RAMLimitMB       int     `json:"ram_limit_mb"`
	DiskQuotaMB      int     `json:"disk_quota_mb"`
	MaxDomains       int     `json:"max_domains"`
	MaxDatabases     int     `json:"max_databases"`
	BandwidthLimitMB int64   `json:"bandwidth_limit_mb"`
	DurationDays     int     `json:"duration_days"`
}

func toPublicPackages(in []core.Package) []publicPackage {
	out := make([]publicPackage, 0, len(in))
	for _, p := range in {
		out = append(out, publicPackage{
			ID: p.ID, Name: p.Name, PriceCents: p.PriceCents, CPULimit: p.CPULimit,
			RAMLimitMB: p.RAMLimitMB, DiskQuotaMB: p.DiskQuotaMB, MaxDomains: p.MaxDomains,
			MaxDatabases: p.MaxDatabases, BandwidthLimitMB: p.BandwidthLimitMB, DurationDays: p.DurationDays,
		})
	}
	return out
}



func (h *Handlers) PublicSite(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	company := "WSRTA"
	if st, err := h.store.GetSettings(r.Context()); err == nil && st.CompanyName != "" {
		company = st.CompanyName
	}
	pkgs, err := h.store.ListPackages(r.Context(), 0) 
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar pacotes")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{
		"company_name": company,
		"packages":     toPublicPackages(pkgs),
	})
}



func (h *Handlers) PublicResellerSite(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	slug := chi.URLParam(r, "slug")
	rs, err := h.store.GetResellerBySlug(r.Context(), slug)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "revenda não encontrada")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao carregar a revenda")
		return
	}
	pkgs, err := h.store.ListPackages(r.Context(), rs.ID)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar pacotes")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{
		"company_name":      rs.Name,
		"template":          rs.LandingTemplate,
		"headline":          rs.LandingHeadline,
		"subtitle":          rs.LandingSubtitle,
		"external_site_url": rs.ExternalSiteURL,
		"packages":          toPublicPackages(pkgs),
	})
}
