package handlers

import (
	"fmt"
	"net/http"

	"github.com/jdobrito/wsrta/internal/core"
)


func (h *Handlers) PostgresInfo(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	c, err := h.store.GetClient(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{
		"postgres_enabled":   c.PostgresEnabled,
		"phppgadmin_enabled": c.PhpPgAdminEnabled,
		
		"phppgadmin_url": fmt.Sprintf("%swsrta-login.php?server=%d", h.ppaURL, cid),
		
		"ppa_user":     "wsrta_ppa",
		"ppa_password": c.PhpPgAdminPassword,
	})
}


func (h *Handlers) ppaPort(clientID int64) int { return h.ppaBasePort + int(clientID) }

func (h *Handlers) setPostgres(w http.ResponseWriter, r *http.Request, enabled bool) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	if err := h.store.SetClientPostgres(r.Context(), cid, enabled); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionSetPostgres, core.SetPostgresPayload{ClientID: cid, Enabled: enabled}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "salvo, mas falhou ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"enabled": enabled, "action_id": actionID})
}


func (h *Handlers) EnablePostgres(w http.ResponseWriter, r *http.Request) { h.setPostgres(w, r, true) }
func (h *Handlers) DisablePostgres(w http.ResponseWriter, r *http.Request) {
	h.setPostgres(w, r, false)
}

func (h *Handlers) setPhpPgAdmin(w http.ResponseWriter, r *http.Request, enabled bool) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	if err := h.store.SetClientPhpPgAdmin(r.Context(), cid, enabled); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar")
		return
	}
	port := 0
	if enabled {
		port = h.ppaPort(cid)
	}
	actionID, err := h.enqueue(r.Context(), core.ActionSetPhpPgAdmin,
		core.SetPhpPgAdminPayload{ClientID: cid, Enabled: enabled, Port: port}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "salvo, mas falhou ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"enabled": enabled, "action_id": actionID})
}


func (h *Handlers) EnablePhpPgAdmin(w http.ResponseWriter, r *http.Request) {
	h.setPhpPgAdmin(w, r, true)
}
func (h *Handlers) DisablePhpPgAdmin(w http.ResponseWriter, r *http.Request) {
	h.setPhpPgAdmin(w, r, false)
}
