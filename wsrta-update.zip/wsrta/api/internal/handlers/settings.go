package handlers

import (
	"context"
	"net"
	"net/http"
	"strings"
	"time"

	"github.com/jdobrito/wsrta/internal/core"
)


func (h *Handlers) sessionMinutes(ctx context.Context) int {
	if st, err := h.store.GetSettings(ctx); err == nil && st.SessionTimeoutMinutes > 0 {
		return st.SessionTimeoutMinutes
	}
	return 60
}


func (h *Handlers) sessionTTL(ctx context.Context) time.Duration {
	return time.Duration(h.sessionMinutes(ctx)) * time.Minute
}


func validSessionMinutes(m int) bool { return m == 0 || (m >= 1 && m <= 1440) }





func (h *Handlers) publicHost(ctx context.Context, reqHost string) string {
	if st, err := h.store.GetSettings(ctx); err == nil && st.PanelDomain != "" {
		return st.PanelDomain
	}
	if reqHost != "" {
		if hostOnly, _, err := net.SplitHostPort(reqHost); err == nil && hostOnly != "" {
			return hostOnly
		}
		return reqHost
	}
	return h.sftpHost
}



func (h *Handlers) Branding(w http.ResponseWriter, r *http.Request) {
	name := ""
	if st, err := h.store.GetSettings(r.Context()); err == nil {
		name = st.CompanyName
	}
	WriteJSON(w, http.StatusOK, map[string]string{"company_name": name})
}


func (h *Handlers) GetSystemSettings(w http.ResponseWriter, r *http.Request) {
	st, err := h.store.GetSettings(r.Context())
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao ler configurações")
		return
	}
	WriteJSON(w, http.StatusOK, st)
}


func (h *Handlers) UpdateSystemSettings(w http.ResponseWriter, r *http.Request) {
	var req core.Settings
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	
	if req.MaxDomainsPerClient < 0 || req.MaxDatabasesPerClient < 0 {
		WriteError(w, http.StatusBadRequest, "limites não podem ser negativos (0 = ilimitado)")
		return
	}
	if req.MaxLoginAttempts < 0 || req.MaxLoginAttempts > 100 {
		WriteError(w, http.StatusBadRequest, "tentativas de login deve estar entre 0 (desativado) e 100")
		return
	}
	if req.LockoutMinutes < 1 || req.LockoutMinutes > 1440 {
		WriteError(w, http.StatusBadRequest, "minutos de bloqueio deve estar entre 1 e 1440")
		return
	}
	req.CompanyName = strings.TrimSpace(req.CompanyName)
	if len(req.CompanyName) > 60 {
		req.CompanyName = req.CompanyName[:60]
	}
	if err := h.store.UpdateSettings(r.Context(), req); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar configurações")
		return
	}
	WriteJSON(w, http.StatusOK, req)
}
