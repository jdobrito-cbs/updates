package handlers

import (
	"errors"
	"log/slog"
	"net/http"
	"strings"
	"time"

	"github.com/jdobrito/wsrta/api/internal/auth"
	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)



func (h *Handlers) ListClients(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query().Get("q")
	c, _ := auth.ClaimsFrom(r.Context())
	var (
		clients []core.Client
		err     error
	)
	if c.Role == core.RoleReseller {
		rid, ok := h.resellerID(w, r)
		if !ok {
			return
		}
		clients, err = h.store.ListClientsByReseller(r.Context(), rid, q)
	} else {
		clients, err = h.store.ListClients(r.Context(), q)
	}
	if err != nil {
		h.log.Error("list clients", slog.Any("err", err))
		WriteError(w, http.StatusInternalServerError, "erro ao listar clientes")
		return
	}
	WriteJSON(w, http.StatusOK, clients)
}


func (h *Handlers) GetClientDetail(w http.ResponseWriter, r *http.Request) {
	id, err := idParam(r, "client_id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	c, err := h.store.GetClient(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "cliente não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return
	}
	WriteJSON(w, http.StatusOK, c)
}

type createClientRequest struct {
	Email          string  `json:"email"`
	Password       string  `json:"password"`
	Name           string  `json:"name"`
	CPULimit       float64 `json:"cpu_limit"`
	RAMLimitMB     int     `json:"ram_limit_mb"`
	DiskQuotaMB    int     `json:"disk_quota_mb"`
	SessionMinutes int     `json:"session_timeout_minutes"`
	BandwidthMB    int64   `json:"bandwidth_limit_mb"`
	MaxMailboxes   int     `json:"max_mailboxes"` 
	PackageID      int64   `json:"package_id"`    
}


func (h *Handlers) CreateClient(w http.ResponseWriter, r *http.Request) {
	var req createClientRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if req.Email == "" || len(req.Password) < 8 || req.Name == "" {
		WriteError(w, http.StatusBadRequest, "email, name e password (>=8) são obrigatórios")
		return
	}
	if !validSessionMinutes(req.SessionMinutes) {
		WriteError(w, http.StatusBadRequest, "limite de sessão inválido (0 = global, ou 1 a 1440)")
		return
	}
	req.CPULimit, req.RAMLimitMB, req.DiskQuotaMB = withLimitDefaults(req.CPULimit, req.RAMLimitMB, req.DiskQuotaMB)

	
	var resellerScope int64
	if c, _ := auth.ClaimsFrom(r.Context()); c.Role == core.RoleReseller {
		rid, ok := h.resellerID(w, r)
		if !ok {
			return
		}
		resellerScope = rid
		
		if rs, e := h.store.GetReseller(r.Context(), rid); e == nil && rs.MaxClients > 0 {
			if n, e2 := h.store.CountResellerClients(r.Context(), rid); e2 == nil && n >= rs.MaxClients {
				WriteError(w, http.StatusForbidden, "limite de clientes da revenda atingido")
				return
			}
		}
	}

	
	var appliedPkg *core.Package
	if req.PackageID > 0 {
		pkg, err := h.store.GetPackageOwned(r.Context(), req.PackageID, resellerScope)
		if errors.Is(err, store.ErrNotFound) {
			WriteError(w, http.StatusBadRequest, "pacote não encontrado")
			return
		}
		if err != nil {
			WriteError(w, http.StatusInternalServerError, "erro ao buscar pacote")
			return
		}
		req.CPULimit, req.RAMLimitMB, req.DiskQuotaMB, req.BandwidthMB = pkg.CPULimit, pkg.RAMLimitMB, pkg.DiskQuotaMB, pkg.BandwidthLimitMB
		appliedPkg = pkg
	}

	hash, err := auth.HashPassword(req.Password)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao processar senha")
		return
	}

	cid, err := h.store.CreateClientWithUser(r.Context(), req.Email, hash, req.Name, req.CPULimit, req.RAMLimitMB, req.DiskQuotaMB)
	if isUniqueViolation(err) {
		WriteError(w, http.StatusConflict, "email já cadastrado")
		return
	}
	if err != nil {
		h.log.Error("create client", slog.Any("err", err))
		WriteError(w, http.StatusInternalServerError, "erro ao criar cliente")
		return
	}
	if resellerScope > 0 {
		_ = h.store.SetClientReseller(r.Context(), cid, resellerScope)
	}
	if appliedPkg != nil {
		var exp time.Time
		if appliedPkg.DurationDays > 0 {
			exp = time.Now().AddDate(0, 0, appliedPkg.DurationDays)
		}
		_ = h.store.SetClientPackageInfo(r.Context(), cid, appliedPkg.ID, exp, appliedPkg.MaxDomains, appliedPkg.MaxDatabases)
	}
	
	if req.SessionMinutes > 0 {
		if uid, e := h.store.ClientUserID(r.Context(), cid); e == nil {
			_ = h.store.SetUserSessionTimeout(r.Context(), uid, req.SessionMinutes)
		}
	}
	
	if req.BandwidthMB > 0 {
		_ = h.store.SetClientBandwidthLimit(r.Context(), cid, req.BandwidthMB)
	}
	
	maxMailboxes := req.MaxMailboxes
	if appliedPkg != nil {
		maxMailboxes = appliedPkg.MaxMailboxes
	}
	if maxMailboxes > 0 {
		_ = h.store.SetClientMaxMailboxes(r.Context(), cid, maxMailboxes)
	}

	actionID, err := h.enqueue(r.Context(), core.ActionProvisionClient, core.ProvisionClientPayload{ClientID: cid}, userID(r))
	if err != nil {
		h.log.Error("enfileirar provision", slog.Any("err", err))
		WriteError(w, http.StatusInternalServerError, "cliente criado, mas falhou ao enfileirar provisionamento")
		return
	}
	WriteJSON(w, http.StatusCreated, map[string]any{"client_id": cid, "action_id": actionID})
}

type updateClientRequest struct {
	Name           string  `json:"name"`
	CPULimit       float64 `json:"cpu_limit"`
	RAMLimitMB     int     `json:"ram_limit_mb"`
	DiskQuotaMB    int     `json:"disk_quota_mb"`
	MaxDomains     int     `json:"max_domains"`
	MaxDatabases   int     `json:"max_databases"`
	MaxMailboxes   int     `json:"max_mailboxes"`
	SessionMinutes int     `json:"session_timeout_minutes"`
	BandwidthMB    int64   `json:"bandwidth_limit_mb"`
}




func (h *Handlers) UpdateClient(w http.ResponseWriter, r *http.Request) {
	id, err := idParam(r, "client_id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	var req updateClientRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if req.Name == "" {
		WriteError(w, http.StatusBadRequest, "name é obrigatório")
		return
	}
	req.CPULimit, req.RAMLimitMB, req.DiskQuotaMB = withLimitDefaults(req.CPULimit, req.RAMLimitMB, req.DiskQuotaMB)

	if req.MaxDomains < 0 || req.MaxDatabases < 0 {
		WriteError(w, http.StatusBadRequest, "limites não podem ser negativos (0 = usar o padrão global)")
		return
	}
	if !validSessionMinutes(req.SessionMinutes) {
		WriteError(w, http.StatusBadRequest, "limite de sessão inválido (0 = global, ou 1 a 1440)")
		return
	}

	err = h.store.UpdateClient(r.Context(), id, req.Name, req.CPULimit, req.RAMLimitMB, req.DiskQuotaMB, req.MaxDomains, req.MaxDatabases)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "cliente não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao atualizar cliente")
		return
	}
	
	if uid, e := h.store.ClientUserID(r.Context(), id); e == nil {
		_ = h.store.SetUserSessionTimeout(r.Context(), uid, req.SessionMinutes)
	}
	if req.MaxMailboxes >= 0 {
		_ = h.store.SetClientMaxMailboxes(r.Context(), id, req.MaxMailboxes)
	}
	if req.BandwidthMB >= 0 {
		_ = h.store.SetClientBandwidthLimit(r.Context(), id, req.BandwidthMB)
	}
	WriteJSON(w, http.StatusOK, map[string]string{"status": "atualizado"})
}


func (h *Handlers) DeleteClient(w http.ResponseWriter, r *http.Request) {
	id, err := idParam(r, "client_id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	c, err := h.store.GetClient(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "cliente não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionDeprovisionClient, core.DeprovisionClientPayload{ClientID: c.ID}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar desprovisionamento")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}


func (h *Handlers) SuspendClient(w http.ResponseWriter, r *http.Request) {
	h.lifecycleAction(w, r, core.ActionSuspendClient)
}


func (h *Handlers) ResumeClient(w http.ResponseWriter, r *http.Request) {
	h.lifecycleAction(w, r, core.ActionResumeClient)
}


func (h *Handlers) lifecycleAction(w http.ResponseWriter, r *http.Request, t core.ActionType) {
	id, err := idParam(r, "client_id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	c, err := h.store.GetClient(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "cliente não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return
	}
	var payload any
	if t == core.ActionSuspendClient {
		payload = core.SuspendClientPayload{ClientID: c.ID}
	} else {
		payload = core.ResumeClientPayload{ClientID: c.ID}
	}
	actionID, err := h.enqueue(r.Context(), t, payload, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	
	if t == core.ActionSuspendClient {
		_ = h.store.InvalidateTokensByClientID(r.Context(), c.ID)
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}


func (h *Handlers) ResetClient2FA(w http.ResponseWriter, r *http.Request) {
	id, err := idParam(r, "client_id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	uid, err := h.store.ClientUserID(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "cliente não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return
	}
	if err := h.store.ClearTOTP(r.Context(), uid); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao resetar 2FA")
		return
	}
	
	_ = h.store.InvalidateUserTokens(r.Context(), uid)
	WriteJSON(w, http.StatusOK, map[string]string{"status": "2fa resetado"})
}


func (h *Handlers) ListActions(w http.ResponseWriter, r *http.Request) {
	
	
	actionType := strings.TrimSpace(r.URL.Query().Get("type"))
	actions, err := h.store.ListActionsByType(r.Context(), actionType, 100)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar ações")
		return
	}
	WriteJSON(w, http.StatusOK, actions)
}



func (h *Handlers) UpdateClientPackages(w http.ResponseWriter, r *http.Request) {
	id, err := idParam(r, "client_id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	if _, err := h.store.GetClient(r.Context(), id); errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "cliente não encontrado")
		return
	} else if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionUpdateClientPackages,
		core.UpdateClientPackagesPayload{ClientID: id}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}


func (h *Handlers) System(w http.ResponseWriter, _ *http.Request) {
	WriteJSON(w, http.StatusOK, hostStats())
}

func withLimitDefaults(cpu float64, ram, disk int) (float64, int, int) {
	if cpu == 0 {
		cpu = 1
	}
	if ram == 0 {
		ram = 512
	}
	if disk == 0 {
		disk = 5120
	}
	return cpu, ram, disk
}
