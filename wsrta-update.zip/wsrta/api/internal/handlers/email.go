package handlers

import (
	"errors"
	"net/http"
	"net/url"
	"regexp"
	"strings"

	"github.com/jdobrito/wsrta/api/internal/mailcow"
	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)

var mailLocalRe = regexp.MustCompile(`^[a-z0-9][a-z0-9._-]{0,63}$`)



const maxMailboxQuotaMB = 51200



func (h *Handlers) mailcowFor(w http.ResponseWriter, r *http.Request) (mailcow.Manager, string, bool) {
	if h.mailFake {
		return mailcow.NewFake(), "https://mail.local", true
	}
	url, key, err := h.store.MailcowConfig(r.Context())
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao ler config de e-mail")
		return nil, "", false
	}
	if url == "" || key == "" {
		WriteError(w, http.StatusConflict, "o e-mail (mailcow) ainda não foi configurado pelo administrador")
		return nil, "", false
	}
	return mailcow.NewReal(url, key), url, true
}


func mailHost(mailcowURL string) string {
	if u, err := url.Parse(mailcowURL); err == nil && u.Host != "" {
		return u.Hostname()
	}
	return strings.TrimSpace(mailcowURL)
}




func (h *Handlers) GetMailcowConfig(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	url, key, err := h.store.MailcowConfig(r.Context())
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao ler config")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"configured": url != "" && key != "", "url": url})
}


func (h *Handlers) SetMailcowConfig(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	var req struct {
		URL    string `json:"url"`
		APIKey string `json:"api_key"`
	}
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	req.URL = strings.TrimSpace(req.URL)
	if req.URL != "" {
		if u, err := url.Parse(req.URL); err != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Host == "" {
			WriteError(w, http.StatusBadRequest, "URL do mailcow inválida (use https://...)")
			return
		}
	}
	if err := h.store.SetMailcowConfig(r.Context(), req.URL, strings.TrimSpace(req.APIKey)); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar config")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"configured": req.URL != "" && strings.TrimSpace(req.APIKey) != ""})
}





func (h *Handlers) EmailInfo(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	mcURL, _, _ := h.store.MailcowConfig(r.Context())
	configured := h.mailFake || mcURL != ""
	webmail := ""
	if mcURL != "" {
		webmail = strings.TrimRight(mcURL, "/") + "/SOGo"
	}
	domains, err := h.store.ListDomains(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar domínios")
		return
	}
	mailboxes, err := h.store.ListMailboxesByClient(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar caixas")
		return
	}
	if mailboxes == nil {
		mailboxes = []store.Mailbox{}
	}
	c, _ := h.store.GetClient(r.Context(), cid)
	limit := 0
	if c != nil {
		limit = c.MaxMailboxes
	}
	WriteJSON(w, http.StatusOK, map[string]any{
		"configured":  configured,
		"webmail_url": webmail,
		"domains":     domains,
		"mailboxes":   mailboxes,
		"limit":       limit, 
		"used":        len(mailboxes),
	})
}



func (h *Handlers) EnableEmail(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	dom, ok := h.emailDomain(w, r)
	if !ok {
		return
	}
	mc, mcURL, ok := h.mailcowFor(w, r)
	if !ok {
		return
	}
	if err := mc.AddDomain(r.Context(), dom.FQDN); err != nil {
		
		h.log.Warn("mailcow add domain", "fqdn", dom.FQDN, "err", err.Error())
	}
	txt, selector, err := mc.DKIM(r.Context(), dom.FQDN)
	if err != nil {
		WriteError(w, http.StatusBadGateway, "e-mail registrado, mas o DKIM não pôde ser obtido")
		return
	}
	
	if !dom.EmailEnabled {
		h.createEmailDNS(r, dom.ID, dom.FQDN, mailHost(mcURL), txt, selector)
	}
	_ = h.store.SetDomainEmailEnabled(r.Context(), dom.ID, true)
	WriteJSON(w, http.StatusOK, map[string]any{"enabled": true})
}


func (h *Handlers) createEmailDNS(r *http.Request, domainID int64, fqdn, host, dkimTxt, selector string) {
	p10 := 10
	recs := []struct {
		rtype, name, content string
		prio                 *int
	}{
		{"MX", fqdn, host, &p10},
		{"TXT", fqdn, `"v=spf1 mx ~all"`, nil},
		{"TXT", "_dmarc." + fqdn, `"v=DMARC1; p=quarantine; rua=mailto:postmaster@` + fqdn + `"`, nil},
		
		{"TXT", selector + "._domainkey." + fqdn, chunkTXT(dkimTxt), nil},
	}
	for _, rec := range recs {
		dr, err := h.store.CreateDNSRecord(r.Context(), domainID, rec.rtype, rec.name, rec.content, 3600, rec.prio)
		if err != nil {
			h.log.Warn("criar registro de e-mail", "type", rec.rtype, "name", rec.name, "err", err.Error())
			continue
		}
		_, _ = h.enqueue(r.Context(), core.ActionSetDNSRecord, core.SetDNSRecordPayload{DNSRecordID: dr.ID}, userID(r))
	}
}


func quoteTXT(v string) string {
	v = strings.TrimSpace(v)
	if strings.HasPrefix(v, `"`) {
		return v
	}
	return `"` + strings.ReplaceAll(v, `"`, `\"`) + `"`
}




func chunkTXT(v string) string {
	v = strings.TrimSpace(strings.Trim(strings.TrimSpace(v), `"`))
	if v == "" {
		return `""`
	}
	v = strings.ReplaceAll(v, `"`, `\"`)
	var parts []string
	for len(v) > 255 {
		parts = append(parts, `"`+v[:255]+`"`)
		v = v[255:]
	}
	parts = append(parts, `"`+v+`"`)
	return strings.Join(parts, " ")
}



func (h *Handlers) DisableEmail(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	dom, ok := h.emailDomain(w, r)
	if !ok {
		return
	}
	mc, _, ok := h.mailcowFor(w, r)
	if !ok {
		return
	}
	if err := mc.RemoveDomain(r.Context(), dom.FQDN); err != nil {
		h.log.Warn("mailcow remove domain", "fqdn", dom.FQDN, "err", err.Error())
	}
	_ = h.store.DeleteMailboxesByDomain(r.Context(), dom.ID) 
	_ = h.store.SetDomainEmailEnabled(r.Context(), dom.ID, false)
	WriteJSON(w, http.StatusOK, map[string]any{"enabled": false})
}



type createMailboxRequest struct {
	DomainID  int64  `json:"domain_id"`
	LocalPart string `json:"local_part"`
	Password  string `json:"password"`
	QuotaMB   int    `json:"quota_mb"`
}


func (h *Handlers) CreateMailbox(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	var req createMailboxRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	req.LocalPart = strings.ToLower(strings.TrimSpace(req.LocalPart))
	if !mailLocalRe.MatchString(req.LocalPart) {
		WriteError(w, http.StatusBadRequest, "parte local inválida (use letras/números . _ -)")
		return
	}
	if len(req.Password) < 8 {
		WriteError(w, http.StatusBadRequest, "a senha deve ter ao menos 8 caracteres")
		return
	}
	
	
	if req.QuotaMB <= 0 {
		req.QuotaMB = 1024
	}
	if req.QuotaMB < 64 {
		req.QuotaMB = 64
	}
	if req.QuotaMB > maxMailboxQuotaMB {
		req.QuotaMB = maxMailboxQuotaMB
	}
	dom, err := h.store.GetDomainOwned(r.Context(), req.DomainID, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "domínio não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar domínio")
		return
	}
	if !dom.EmailEnabled {
		WriteError(w, http.StatusConflict, "ative o e-mail neste domínio antes de criar caixas")
		return
	}
	
	if c, e := h.store.GetClient(r.Context(), cid); e == nil && c.MaxMailboxes > 0 {
		if n, e2 := h.store.CountClientMailboxes(r.Context(), cid); e2 == nil && n >= c.MaxMailboxes {
			WriteError(w, http.StatusForbidden, "cota de caixas de e-mail atingida")
			return
		}
	}
	mc, _, ok := h.mailcowFor(w, r)
	if !ok {
		return
	}
	
	
	box, err := h.store.CreateMailbox(r.Context(), dom.ID, req.LocalPart, req.QuotaMB)
	if isUniqueViolation(err) {
		WriteError(w, http.StatusConflict, "essa caixa já existe")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao registrar a caixa")
		return
	}
	if err := mc.AddMailbox(r.Context(), dom.FQDN, req.LocalPart, req.Password, req.QuotaMB); err != nil {
		_ = h.store.DeleteMailbox(r.Context(), box.ID) 
		h.log.Warn("mailcow add mailbox", "addr", box.Address, "err", err.Error())
		WriteError(w, http.StatusBadGateway, "erro ao criar a caixa no servidor de e-mail")
		return
	}
	WriteJSON(w, http.StatusCreated, box)
}


func (h *Handlers) DeleteMailbox(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	box, err := h.store.GetMailboxOwned(r.Context(), id, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "caixa não encontrada")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar caixa")
		return
	}
	mc, _, ok := h.mailcowFor(w, r)
	if !ok {
		return
	}
	if err := mc.DeleteMailbox(r.Context(), box.FQDN, box.LocalPart); err != nil {
		h.log.Warn("mailcow delete mailbox", "addr", box.Address, "err", err.Error())
	}
	if err := h.store.DeleteMailbox(r.Context(), id); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao apagar registro")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"deleted": id})
}


func (h *Handlers) SetMailboxPassword(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	var req struct {
		Password string `json:"password"`
	}
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if len(req.Password) < 8 {
		WriteError(w, http.StatusBadRequest, "a senha deve ter ao menos 8 caracteres")
		return
	}
	box, err := h.store.GetMailboxOwned(r.Context(), id, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "caixa não encontrada")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar caixa")
		return
	}
	mc, _, ok := h.mailcowFor(w, r)
	if !ok {
		return
	}
	if err := mc.SetPassword(r.Context(), box.FQDN, box.LocalPart, req.Password); err != nil {
		WriteError(w, http.StatusBadGateway, "erro ao trocar a senha no servidor de e-mail")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"ok": true})
}



func (h *Handlers) emailDomain(w http.ResponseWriter, r *http.Request) (*core.Domain, bool) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return nil, false
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return nil, false
	}
	dom, err := h.store.GetDomainOwned(r.Context(), id, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "domínio não encontrado")
		return nil, false
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar domínio")
		return nil, false
	}
	return dom, true
}
