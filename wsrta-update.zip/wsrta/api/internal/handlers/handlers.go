


package handlers

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net"
	"net/http"
	"strconv"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/jackc/pgx/v5/pgconn"

	"github.com/jdobrito/wsrta/api/internal/auth"
	"github.com/jdobrito/wsrta/api/internal/fileclient"
	"github.com/jdobrito/wsrta/api/internal/monitor"
	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
	"github.com/jdobrito/wsrta/internal/queue"
)


type Handlers struct {
	store           *store.Store
	queue           *queue.Queue
	tokens          *auth.Tokens
	rate            *auth.RateLimiter
	daemonSock      string
	totpIssuer      string
	sftpHost        string
	sftpBasePort    int
	backupDir       string
	migrateStaging  string
	clientBackupDir string
	files           *fileclient.Client
	pmaBasePort     int
	pmaURL          string
	ppaBasePort     int
	ppaURL          string
	edition         string 
	mailFake        bool   
	monitor         *monitor.Sampler
	log             *slog.Logger
}


type Config struct {
	Store           *store.Store
	Queue           *queue.Queue
	Tokens          *auth.Tokens
	Rate            *auth.RateLimiter
	DaemonSock      string
	TOTPIssuer      string
	SFTPHost        string
	SFTPBasePort    int
	BackupDir       string
	MigrateStaging  string
	ClientBackupDir string
	Files           *fileclient.Client
	PMABasePort     int
	PMAURL          string
	PPABasePort     int
	PPAURL          string
	Edition         string
	MailFake        bool
	Monitor         *monitor.Sampler
	Log             *slog.Logger
}


func New(c Config) *Handlers {
	return &Handlers{
		store:           c.Store,
		queue:           c.Queue,
		tokens:          c.Tokens,
		rate:            c.Rate,
		daemonSock:      c.DaemonSock,
		totpIssuer:      c.TOTPIssuer,
		sftpHost:        c.SFTPHost,
		sftpBasePort:    c.SFTPBasePort,
		backupDir:       c.BackupDir,
		migrateStaging:  c.MigrateStaging,
		clientBackupDir: c.ClientBackupDir,
		files:           c.Files,
		pmaBasePort:     c.PMABasePort,
		pmaURL:          c.PMAURL,
		ppaBasePort:     c.PPABasePort,
		ppaURL:          c.PPAURL,
		edition:         c.Edition,
		mailFake:        c.MailFake,
		monitor:         c.Monitor,
		log:             c.Log,
	}
}


func (h *Handlers) completeEdition() bool { return h.edition == core.EditionComplete }



func (h *Handlers) requireComplete(w http.ResponseWriter) bool {
	if !h.completeEdition() {
		WriteError(w, http.StatusNotFound, "recurso disponível apenas no VPS Completo")
		return false
	}
	return true
}


func (h *Handlers) enqueue(ctx context.Context, t core.ActionType, payload any, requestedBy int64) (int64, error) {
	id, err := h.queue.Enqueue(ctx, t, payload, &requestedBy)
	if err != nil {
		return 0, err
	}
	queue.Nudge(h.daemonSock)
	return id, nil
}


type selfCtxKey struct{}

func withSelfClientID(ctx context.Context, cid int64) context.Context {
	return context.WithValue(ctx, selfCtxKey{}, cid)
}

func selfClientIDFrom(ctx context.Context) (int64, bool) {
	cid, ok := ctx.Value(selfCtxKey{}).(int64)
	return cid, ok
}





func (h *Handlers) targetClientID(w http.ResponseWriter, r *http.Request) (int64, bool) {
	if cid, ok := selfClientIDFrom(r.Context()); ok {
		return cid, true
	}
	c, _ := auth.ClaimsFrom(r.Context())
	
	
	if c.Role == core.RoleAdmin || c.Role == core.RoleReseller {
		id, err := idParam(r, "client_id")
		if err != nil {
			WriteError(w, http.StatusBadRequest, "client_id inválido")
			return 0, false
		}
		return id, true
	}
	if c.ClientID == nil {
		WriteError(w, http.StatusForbidden, "sem cliente associado")
		return 0, false
	}
	return *c.ClientID, true
}



func (h *Handlers) resellerID(w http.ResponseWriter, r *http.Request) (int64, bool) {
	c, _ := auth.ClaimsFrom(r.Context())
	rs, err := h.store.GetResellerByUserID(r.Context(), c.UserID)
	if err != nil {
		WriteError(w, http.StatusForbidden, "revendedor não encontrado")
		return 0, false
	}
	
	
	if rs.Status != "active" || (rs.ExpiresAt != nil && rs.ExpiresAt.Before(time.Now())) {
		WriteError(w, http.StatusForbidden, "revenda suspensa ou com plano vencido")
		return 0, false
	}
	return rs.ID, true
}



func (h *Handlers) RequireCompleteEdition(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !h.completeEdition() {
			WriteError(w, http.StatusNotFound, "recurso disponível apenas no VPS Completo")
			return
		}
		next.ServeHTTP(w, r)
	})
}



func (h *Handlers) ResellerOwnsClient(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		rid, ok := h.resellerID(w, r)
		if !ok {
			return
		}
		cid, err := idParam(r, "client_id")
		if err != nil {
			WriteError(w, http.StatusBadRequest, "client_id inválido")
			return
		}
		owned, err := h.store.ClientBelongsToReseller(r.Context(), cid, rid)
		if err != nil {
			WriteError(w, http.StatusInternalServerError, "erro ao verificar posse")
			return
		}
		if !owned {
			WriteError(w, http.StatusNotFound, "cliente não encontrado")
			return
		}
		next.ServeHTTP(w, r)
	})
}






func (h *Handlers) WithSelfTenant(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !h.selfAccessAllowed(w, r) {
			return
		}
		c, _ := auth.ClaimsFrom(r.Context())
		cid, err := h.store.SelfClientID(r.Context(), c.UserID)
		if errors.Is(err, store.ErrNotFound) {
			WriteError(w, http.StatusConflict, "VPS pessoal ainda não ativada")
			return
		}
		if err != nil {
			WriteError(w, http.StatusInternalServerError, "erro ao resolver VPS pessoal")
			return
		}
		next.ServeHTTP(w, r.WithContext(withSelfClientID(r.Context(), cid)))
	})
}





func (h *Handlers) selfAccessAllowed(w http.ResponseWriter, r *http.Request) bool {
	c, _ := auth.ClaimsFrom(r.Context())
	if c.Role != core.RoleReseller {
		return true
	}
	rs, err := h.store.GetResellerByUserID(r.Context(), c.UserID)
	if err != nil {
		WriteError(w, http.StatusForbidden, "revendedor não encontrado")
		return false
	}
	if rs.Status != "active" || (rs.ExpiresAt != nil && rs.ExpiresAt.Before(time.Now())) {
		WriteError(w, http.StatusForbidden, "revenda suspensa ou com plano vencido")
		return false
	}
	return true
}



func validatePositiveLimits(w http.ResponseWriter, cpu float64, ramMB, diskMB int) bool {
	if cpu <= 0 || ramMB <= 0 || diskMB <= 0 {
		WriteError(w, http.StatusBadRequest, "limites de cpu/ram/disco devem ser positivos")
		return false
	}
	return true
}



var selfTenantDefaults = struct {
	CPU                                     float64
	RAMMB, DiskMB, MaxDomains, MaxDatabases int
	BandwidthMB                             int64
}{CPU: 2, RAMMB: 2048, DiskMB: 20480, MaxDomains: 0, MaxDatabases: 0, BandwidthMB: 0}




func (h *Handlers) ensureSelfTenant(ctx context.Context, ownerUserID int64, name string, cpu float64, ramMB, diskMB, maxDomains, maxDatabases int, bandwidthMB int64, requestedBy int64) (int64, int64, bool, error) {
	if cid, err := h.store.SelfClientID(ctx, ownerUserID); err == nil {
		return cid, 0, false, nil
	} else if !errors.Is(err, store.ErrNotFound) {
		return 0, 0, false, err
	}
	
	supportEmail := fmt.Sprintf("self-%d@vps.local", ownerUserID)
	rawPwd, err := randomToken(24)
	if err != nil {
		return 0, 0, false, err
	}
	hash, err := auth.HashPassword(rawPwd)
	if err != nil {
		return 0, 0, false, err
	}
	cid, err := h.store.CreateSelfTenant(ctx, ownerUserID, name, supportEmail, hash, cpu, ramMB, diskMB, maxDomains, maxDatabases, bandwidthMB)
	if err != nil {
		return 0, 0, false, err
	}
	actionID, err := h.enqueue(ctx, core.ActionProvisionClient, core.ProvisionClientPayload{ClientID: cid}, requestedBy)
	if err != nil {
		return cid, 0, true, err
	}
	return cid, actionID, true, nil
}


func randomToken(n int) (string, error) {
	b := make([]byte, n)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}


func userID(r *http.Request) int64 {
	c, _ := auth.ClaimsFrom(r.Context())
	return c.UserID
}



const maxJSONBody = 1 << 20 

func decodeJSON(r *http.Request, v any) error {
	return json.NewDecoder(io.LimitReader(r.Body, maxJSONBody)).Decode(v)
}

func idParam(r *http.Request, name string) (int64, error) {
	return strconv.ParseInt(chi.URLParam(r, name), 10, 64)
}

func clientIP(r *http.Request) string {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}


func isUniqueViolation(err error) bool {
	var pgErr *pgconn.PgError
	return errors.As(err, &pgErr) && pgErr.Code == "23505"
}
