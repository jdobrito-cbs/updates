package handlers

import (
	"encoding/json"
	"fmt"
	"net/http"
	"regexp"
	"strings"

	"github.com/jdobrito/wsrta/internal/core"
)

var phpKeyRe = regexp.MustCompile(`^[A-Za-z0-9_.]{1,64}$`)
var headerNameRe = regexp.MustCompile(`^[A-Za-z0-9-]{1,64}$`)


type siteRulesConfig struct {
	PHP     []struct{ Key, Value string }  `json:"php"`
	Headers []struct{ Name, Value string } `json:"headers"`
	CORS    struct {
		Enabled bool   `json:"enabled"`
		Origin  string `json:"origin"`
	} `json:"cors"`
}

func badValue(s string) bool { return strings.ContainsAny(s, "\n\r\"") }


func buildSiteRules(c siteRulesConfig) (userINI, vhostExtra string, err error) {
	var ini strings.Builder
	for _, d := range c.PHP {
		if !phpKeyRe.MatchString(d.Key) {
			return "", "", fmt.Errorf("diretiva PHP inválida: %q", d.Key)
		}
		if badValue(d.Value) {
			return "", "", fmt.Errorf("valor inválido para %q", d.Key)
		}
		fmt.Fprintf(&ini, "%s = %s\n", d.Key, d.Value)
	}

	var ng strings.Builder
	for _, hh := range c.Headers {
		if !headerNameRe.MatchString(hh.Name) {
			return "", "", fmt.Errorf("header inválido: %q", hh.Name)
		}
		if badValue(hh.Value) {
			return "", "", fmt.Errorf("valor de header inválido: %q", hh.Name)
		}
		fmt.Fprintf(&ng, "    add_header \"%s\" \"%s\" always;\n", hh.Name, hh.Value)
	}
	if c.CORS.Enabled {
		origin := c.CORS.Origin
		if origin == "" {
			origin = "*"
		}
		if badValue(origin) {
			return "", "", fmt.Errorf("origin de CORS inválido")
		}
		fmt.Fprintf(&ng, "    add_header \"Access-Control-Allow-Origin\" \"%s\" always;\n", origin)
		ng.WriteString("    add_header \"Access-Control-Allow-Methods\" \"GET, POST, PUT, DELETE, OPTIONS\" always;\n")
		ng.WriteString("    add_header \"Access-Control-Allow-Headers\" \"Content-Type, Authorization\" always;\n")
	}
	return ini.String(), ng.String(), nil
}


func (h *Handlers) GetSiteRules(w http.ResponseWriter, r *http.Request) {
	dom, ok := h.ownedDomain(w, r)
	if !ok {
		return
	}
	cfg, err := h.store.GetSiteRules(r.Context(), dom.ID)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao ler regras")
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(cfg)
}


func (h *Handlers) UpdateSiteRules(w http.ResponseWriter, r *http.Request) {
	dom, ok := h.ownedDomain(w, r)
	if !ok {
		return
	}
	var cfg siteRulesConfig
	if err := decodeJSON(r, &cfg); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	userINI, vhostExtra, err := buildSiteRules(cfg)
	if err != nil {
		WriteError(w, http.StatusBadRequest, err.Error())
		return
	}
	raw, _ := json.Marshal(cfg)
	if err := h.store.UpsertSiteRules(r.Context(), dom.ID, raw); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar regras")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionApplySiteRules, core.ApplySiteRulesPayload{
		DomainID: dom.ID, UserINI: userINI, VHostExtra: vhostExtra,
	}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "salvo, mas falhou ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}
