package handlers

import (
	"bytes"
	"mime"
	"net/http"
	"path"
	"strings"

	"github.com/go-chi/chi/v5"

	"github.com/jdobrito/wsrta/api/internal/fileclient"
	"github.com/jdobrito/wsrta/internal/core"
)








func (h *Handlers) Preview(w http.ResponseWriter, r *http.Request) {
	fqdn := strings.ToLower(strings.TrimSpace(chi.URLParam(r, "fqdn")))
	if core.ValidFQDN(fqdn) != nil {
		http.NotFound(w, r)
		return
	}
	container, err := h.store.ContainerByFQDN(r.Context(), fqdn)
	if err != nil {
		http.NotFound(w, r)
		return
	}
	
	rest := path.Clean("/" + chi.URLParam(r, "*"))
	if rest == "/" || strings.HasSuffix(chi.URLParam(r, "*"), "/") {
		rest = strings.TrimSuffix(rest, "/") + "/index.html"
	}
	
	scope := fileclient.Scope{Mode: "container", Container: container, Path: fqdn + rest}
	var buf bytes.Buffer
	if err := h.files.Download(r.Context(), scope, &buf); err != nil {
		http.NotFound(w, r)
		return
	}
	ct := mime.TypeByExtension(path.Ext(rest))
	if ct == "" {
		ct = "application/octet-stream"
	}
	w.Header().Set("Content-Type", ct)
	w.Header().Set("X-Content-Type-Options", "nosniff")
	
	
	
	w.Header().Set("Content-Security-Policy", "sandbox")
	w.Header().Set("X-Frame-Options", "DENY")
	_, _ = w.Write(buf.Bytes())
}
