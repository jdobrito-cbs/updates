package handlers

import (
	"errors"
	"net/http"

	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)

var allowedDNSTypes = map[string]bool{
	"A": true, "AAAA": true, "CNAME": true, "MX": true, "TXT": true, "NS": true,
}

type dnsRecordRequest struct {
	Type    string `json:"type"`
	Name    string `json:"name"`
	Content string `json:"content"`
	TTL     int    `json:"ttl"`
	Prio    *int   `json:"prio"`
}


func (h *Handlers) ListRecords(w http.ResponseWriter, r *http.Request) {
	domainID, ok := h.ownedDomainByParam(w, r, "domain_id")
	if !ok {
		return
	}
	records, err := h.store.ListDNSRecords(r.Context(), domainID)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar registros")
		return
	}
	WriteJSON(w, http.StatusOK, records)
}


func (h *Handlers) CreateRecord(w http.ResponseWriter, r *http.Request) {
	domainID, ok := h.ownedDomainByParam(w, r, "domain_id")
	if !ok {
		return
	}
	var req dnsRecordRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if !allowedDNSTypes[req.Type] || req.Name == "" || req.Content == "" {
		WriteError(w, http.StatusBadRequest, "type (A/AAAA/CNAME/MX/TXT/NS), name e content são obrigatórios")
		return
	}

	rec, err := h.store.CreateDNSRecord(r.Context(), domainID, req.Type, req.Name, req.Content, req.TTL, req.Prio)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao criar registro")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionSetDNSRecord, core.SetDNSRecordPayload{DNSRecordID: rec.ID}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "registro criado, mas falhou ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusCreated, map[string]any{"record": rec, "action_id": actionID})
}


func (h *Handlers) UpdateRecord(w http.ResponseWriter, r *http.Request) {
	domainID, ok := h.ownedDomainByParam(w, r, "domain_id")
	if !ok {
		return
	}
	recID, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	var req dnsRecordRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if !allowedDNSTypes[req.Type] || req.Name == "" || req.Content == "" {
		WriteError(w, http.StatusBadRequest, "type, name e content são obrigatórios")
		return
	}

	err = h.store.UpdateDNSRecord(r.Context(), recID, domainID, req.Type, req.Name, req.Content, req.TTL, req.Prio)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "registro não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao atualizar registro")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionSetDNSRecord, core.SetDNSRecordPayload{DNSRecordID: recID}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "registro atualizado, mas falhou ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"action_id": actionID})
}


func (h *Handlers) DeleteRecord(w http.ResponseWriter, r *http.Request) {
	domainID, ok := h.ownedDomainByParam(w, r, "domain_id")
	if !ok {
		return
	}
	recID, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	if _, err := h.store.GetDNSRecordInDomain(r.Context(), recID, domainID); errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "registro não encontrado")
		return
	} else if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar registro")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionDeleteDNSRecord, core.DeleteDNSRecordPayload{DNSRecordID: recID}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar remoção")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}


func (h *Handlers) ownedDomainByParam(w http.ResponseWriter, r *http.Request, param string) (int64, bool) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return 0, false
	}
	domainID, err := idParam(r, param)
	if err != nil {
		WriteError(w, http.StatusBadRequest, "domain_id inválido")
		return 0, false
	}
	if _, err := h.store.GetDomainOwned(r.Context(), domainID, cid); errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "domínio não encontrado")
		return 0, false
	} else if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar domínio")
		return 0, false
	}
	return domainID, true
}
