package handlers

import (
	"crypto/rand"
	"errors"
	"math/big"
	"net/http"

	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)


func (h *Handlers) ListDatabases(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	dbs, err := h.store.ListDatabases(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar bancos")
		return
	}
	WriteJSON(w, http.StatusOK, dbs)
}

type createDatabaseRequest struct {
	DBName string `json:"db_name"`
	DBUser string `json:"db_user"`
	Engine string `json:"engine"` 
}


func (h *Handlers) CreateDatabase(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	var req createDatabaseRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if req.DBName == "" || req.DBUser == "" {
		WriteError(w, http.StatusBadRequest, "db_name e db_user são obrigatórios")
		return
	}
	engine := req.Engine
	if engine == "" {
		engine = "mariadb"
	}
	if engine != "mariadb" && engine != "postgres" {
		WriteError(w, http.StatusBadRequest, "engine inválido (mariadb | postgres)")
		return
	}
	if engine == "postgres" {
		c, err := h.store.GetClient(r.Context(), cid)
		if err != nil {
			WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
			return
		}
		if !c.PostgresEnabled {
			WriteError(w, http.StatusForbidden, "PostgreSQL não está habilitado para este cliente")
			return
		}
	}

	
	if reached, err := h.databaseLimitReached(r.Context(), cid); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao checar limite")
		return
	} else if reached {
		WriteError(w, http.StatusForbidden, "limite de bancos do cliente atingido")
		return
	}

	db, err := h.store.CreateDatabase(r.Context(), cid, req.DBName, req.DBUser, engine)
	if isUniqueViolation(err) {
		WriteError(w, http.StatusConflict, "banco já existe para este cliente")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao criar banco")
		return
	}

	
	
	pass := genDBPassword()
	actionID, err := h.enqueue(r.Context(), core.ActionCreateDatabase, core.CreateDatabasePayload{DatabaseID: db.ID, Password: pass}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "banco criado, mas falhou ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusCreated, map[string]any{"database": db, "action_id": actionID, "password": pass})
}



func (h *Handlers) ResetDatabasePassword(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	db, err := h.store.GetDatabaseOwned(r.Context(), id, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "banco não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar banco")
		return
	}
	var req struct {
		Password string `json:"password"`
	}
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if len(req.Password) < 8 || len(req.Password) > 128 {
		WriteError(w, http.StatusBadRequest, "a senha deve ter de 8 a 128 caracteres")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionResetDBPassword,
		core.ResetDBPasswordPayload{DatabaseID: db.ID, Password: req.Password}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}


const dbPwAlphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"


func genDBPassword() string {
	b := make([]byte, 20)
	for i := range b {
		n, err := rand.Int(rand.Reader, big.NewInt(int64(len(dbPwAlphabet))))
		if err != nil {
			
			b[i] = dbPwAlphabet[0]
			continue
		}
		b[i] = dbPwAlphabet[n.Int64()]
	}
	return string(b)
}


func (h *Handlers) DeleteDatabase(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	db, err := h.store.GetDatabaseOwned(r.Context(), id, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "banco não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar banco")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionDropDatabase, core.DropDatabasePayload{DatabaseID: db.ID}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar remoção")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}
