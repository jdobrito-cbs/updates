package handlers

import (
	"errors"
	"net/http"
	"strings"

	"github.com/jdobrito/wsrta/api/internal/auth"
	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)



func (h *Handlers) packageScope(w http.ResponseWriter, r *http.Request) (int64, bool) {
	c, _ := auth.ClaimsFrom(r.Context())
	if c.Role == core.RoleReseller {
		return h.resellerID(w, r)
	}
	return 0, true
}

type packageRequest struct {
	Name             string  `json:"name"`
	PriceCents       int64   `json:"price_cents"`
	CPULimit         float64 `json:"cpu_limit"`
	RAMLimitMB       int     `json:"ram_limit_mb"`
	DiskQuotaMB      int     `json:"disk_quota_mb"`
	MaxDomains       int     `json:"max_domains"`
	MaxDatabases     int     `json:"max_databases"`
	MaxMailboxes     int     `json:"max_mailboxes"`
	BandwidthLimitMB int64   `json:"bandwidth_limit_mb"`
	DurationDays     int     `json:"duration_days"`
}


func (req packageRequest) toPackage() (core.Package, error) {
	name := strings.TrimSpace(req.Name)
	if name == "" {
		return core.Package{}, errors.New("nome é obrigatório")
	}
	p := core.Package{
		Name: name, PriceCents: req.PriceCents, CPULimit: req.CPULimit, RAMLimitMB: req.RAMLimitMB,
		DiskQuotaMB: req.DiskQuotaMB, MaxDomains: req.MaxDomains, MaxDatabases: req.MaxDatabases,
		MaxMailboxes: req.MaxMailboxes, BandwidthLimitMB: req.BandwidthLimitMB, DurationDays: req.DurationDays,
	}
	if p.CPULimit <= 0 {
		p.CPULimit = 1
	}
	if p.RAMLimitMB <= 0 {
		p.RAMLimitMB = 1024
	}
	if p.DiskQuotaMB <= 0 {
		p.DiskQuotaMB = 10240
	}
	if p.DurationDays < 0 {
		p.DurationDays = 0
	}
	return p, nil
}


func (h *Handlers) ListPackages(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	scope, ok := h.packageScope(w, r)
	if !ok {
		return
	}
	list, err := h.store.ListPackages(r.Context(), scope)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar pacotes")
		return
	}
	if list == nil {
		list = []core.Package{}
	}
	WriteJSON(w, http.StatusOK, list)
}


func (h *Handlers) CreatePackage(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	scope, ok := h.packageScope(w, r)
	if !ok {
		return
	}
	var req packageRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	p, err := req.toPackage()
	if err != nil {
		WriteError(w, http.StatusBadRequest, err.Error())
		return
	}
	id, err := h.store.CreatePackage(r.Context(), scope, p)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao criar pacote")
		return
	}
	WriteJSON(w, http.StatusCreated, map[string]any{"package_id": id})
}


func (h *Handlers) UpdatePackage(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	scope, ok := h.packageScope(w, r)
	if !ok {
		return
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	var req packageRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	p, err := req.toPackage()
	if err != nil {
		WriteError(w, http.StatusBadRequest, err.Error())
		return
	}
	if err := h.store.UpdatePackage(r.Context(), id, scope, p); errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "pacote não encontrado")
		return
	} else if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao atualizar pacote")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"ok": true})
}


func (h *Handlers) DeletePackage(w http.ResponseWriter, r *http.Request) {
	if !h.requireComplete(w) {
		return
	}
	scope, ok := h.packageScope(w, r)
	if !ok {
		return
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	if err := h.store.DeletePackage(r.Context(), id, scope); errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "pacote não encontrado")
		return
	} else if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao remover pacote")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"deleted": id})
}
