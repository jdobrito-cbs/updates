package handlers

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"regexp"
	"strings"

	"github.com/jdobrito/wsrta/api/internal/fileclient"
	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)

var wpSlugRe = regexp.MustCompile(`^[a-z0-9][a-z0-9.-]{0,80}$`)


func (h *Handlers) wpTarget(w http.ResponseWriter, r *http.Request) (dir, container string, ok bool) {
	cid, k := h.targetClientID(w, r)
	if !k {
		return "", "", false
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return "", "", false
	}
	inst, err := h.store.GetWordPressInstallOwned(r.Context(), id, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "instalação não encontrada")
		return "", "", false
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar instalação")
		return "", "", false
	}
	c, err := h.store.GetClient(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return "", "", false
	}
	dir = "/var/www/" + inst.FQDN
	if p := strings.Trim(inst.Path, "/"); p != "" {
		dir += "/" + p
	}
	return dir, c.LXCContainerName, true
}

func (h *Handlers) wpJSON(ctx context.Context, container, dir string, args []string) json.RawMessage {
	res, err := h.files.WP(ctx, container, dir, args)
	if err != nil || res.Exit != 0 || !json.Valid([]byte(res.Stdout)) {
		return json.RawMessage("[]")
	}
	return json.RawMessage(res.Stdout)
}


func (h *Handlers) WPManagerInfo(w http.ResponseWriter, r *http.Request) {
	dir, container, ok := h.wpTarget(w, r)
	if !ok {
		return
	}
	ctx := r.Context()
	var coreVer string
	if res, err := h.files.WP(ctx, container, dir, []string{"core", "version"}); err == nil {
		coreVer = strings.TrimSpace(res.Stdout)
	}
	
	
	coreUpdate := h.wpCoreUpdateVersion(ctx, container, dir)
	var siteURL string
	if res, err := h.files.WP(ctx, container, dir, []string{"option", "get", "siteurl"}); err == nil && res.Exit == 0 {
		siteURL = strings.TrimSpace(res.Stdout)
	}
	WriteJSON(w, http.StatusOK, map[string]any{
		"core_version":        coreVer,
		"core_update_version": coreUpdate,
		"site_url":            siteURL,
		
		"plugins": h.wpJSON(ctx, container, dir, []string{"plugin", "list", "--fields=name,status,update,version,update_version", "--format=json"}),
		"themes":  h.wpJSON(ctx, container, dir, []string{"theme", "list", "--fields=name,status,update,version,update_version", "--format=json"}),
		
		"admins": h.wpJSON(ctx, container, dir, []string{"user", "list", "--role=administrator", "--fields=ID,user_login,user_email", "--format=json"}),
	})
}


func (h *Handlers) wpCoreUpdateVersion(ctx context.Context, container, dir string) string {
	res, err := h.files.WP(ctx, container, dir, []string{"core", "check-update", "--fields=version", "--format=json"})
	if err != nil || res.Exit != 0 || !json.Valid([]byte(res.Stdout)) {
		return ""
	}
	var ups []struct {
		Version string `json:"version"`
	}
	if json.Unmarshal([]byte(res.Stdout), &ups) != nil || len(ups) == 0 {
		return ""
	}
	return strings.TrimSpace(ups[0].Version)
}



func (h *Handlers) wpAdminLogins(ctx context.Context, container, dir string) []string {
	res, err := h.files.WP(ctx, container, dir, []string{"user", "list", "--role=administrator", "--field=user_login", "--format=json"})
	if err != nil || res.Exit != 0 || !json.Valid([]byte(res.Stdout)) {
		return nil
	}
	var logins []string
	_ = json.Unmarshal([]byte(res.Stdout), &logins)
	return logins
}


var wpLoginRe = regexp.MustCompile(`^[a-zA-Z0-9 ._@-]{1,60}$`)

type wpPasswordRequest struct {
	UserLogin   string `json:"user_login"`
	NewPassword string `json:"new_password"`
}




func (h *Handlers) WPSetPassword(w http.ResponseWriter, r *http.Request) {
	dir, container, ok := h.wpTarget(w, r)
	if !ok {
		return
	}
	var req wpPasswordRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	req.UserLogin = strings.TrimSpace(req.UserLogin)
	if !wpLoginRe.MatchString(req.UserLogin) {
		WriteError(w, http.StatusBadRequest, "usuário inválido")
		return
	}
	if len(req.NewPassword) < 6 || strings.ContainsAny(req.NewPassword, "\n\r\t") {
		WriteError(w, http.StatusBadRequest, "a senha deve ter ao menos 6 caracteres")
		return
	}
	
	found := false
	for _, a := range h.wpAdminLogins(r.Context(), container, dir) {
		if a == req.UserLogin {
			found = true
			break
		}
	}
	if !found {
		WriteError(w, http.StatusNotFound, "administrador não encontrado neste WordPress")
		return
	}
	
	res, err := h.files.WP(r.Context(), container, dir, []string{"user", "update", req.UserLogin, "--user_pass=" + req.NewPassword})
	if err != nil {
		fileErr(w, err)
		return
	}
	if res.Exit != 0 {
		out := res.Stderr
		if out == "" {
			out = res.Stdout
		}
		WriteError(w, http.StatusUnprocessableEntity, "wp-cli: "+strings.TrimSpace(out))
		return
	}
	WriteJSON(w, http.StatusOK, map[string]string{"output": "senha do administrador atualizada"})
}


var wpURLRe = regexp.MustCompile(`^https?://[a-zA-Z0-9.-]+(:[0-9]{1,5})?(/[^\s]*)?$`)

type wpSetURLRequest struct {
	NewURL string `json:"new_url"`
}





func (h *Handlers) WPSetSiteURL(w http.ResponseWriter, r *http.Request) {
	dir, container, ok := h.wpTarget(w, r)
	if !ok {
		return
	}
	var req wpSetURLRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	newURL := strings.TrimRight(strings.TrimSpace(req.NewURL), "/")
	if !wpURLRe.MatchString(newURL) {
		WriteError(w, http.StatusBadRequest, "URL inválida (use http(s)://dominio)")
		return
	}
	cur, err := h.files.WP(r.Context(), container, dir, []string{"option", "get", "siteurl"})
	if err != nil {
		fileErr(w, err)
		return
	}
	old := strings.TrimRight(strings.TrimSpace(cur.Stdout), "/")
	if cur.Exit != 0 || old == "" {
		WriteError(w, http.StatusUnprocessableEntity, "não foi possível ler a URL atual do WordPress")
		return
	}
	if old == newURL {
		WriteJSON(w, http.StatusOK, map[string]string{"output": "a URL do site já é " + newURL})
		return
	}
	
	res, err := h.files.WP(r.Context(), container, dir,
		[]string{"search-replace", old, newURL, "--skip-columns=guid", "--report-changed-only"})
	if err != nil {
		fileErr(w, err)
		return
	}
	if res.Exit != 0 {
		out := res.Stderr
		if out == "" {
			out = res.Stdout
		}
		WriteError(w, http.StatusUnprocessableEntity, "wp-cli: "+strings.TrimSpace(out))
		return
	}
	
	_, _ = h.files.WP(r.Context(), container, dir, []string{"option", "update", "siteurl", newURL})
	_, _ = h.files.WP(r.Context(), container, dir, []string{"option", "update", "home", newURL})
	WriteJSON(w, http.StatusOK, map[string]string{"output": "URL trocada de " + old + " para " + newURL})
}

var wpPathRe = regexp.MustCompile(`^[a-zA-Z0-9._/-]*$`)

type wpAssociateRequest struct {
	DomainID int64  `json:"domain_id"`
	Path     string `json:"path"`
}




func (h *Handlers) AssociateWordPress(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	var req wpAssociateRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	path := strings.Trim(req.Path, "/")
	if req.DomainID <= 0 || !wpPathRe.MatchString(path) || strings.Contains(path, "..") {
		WriteError(w, http.StatusBadRequest, "domain_id/path inválido")
		return
	}
	dom, err := h.store.GetDomainOwned(r.Context(), req.DomainID, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "domínio não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar domínio")
		return
	}
	c, err := h.store.GetClient(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return
	}
	dir := "/var/www/" + dom.FQDN
	if path != "" {
		dir += "/" + path
	}
	
	res, err := h.files.WP(r.Context(), c.LXCContainerName, dir, []string{"core", "is-installed"})
	if err != nil {
		fileErr(w, err)
		return
	}
	if res.Exit != 0 {
		WriteError(w, http.StatusUnprocessableEntity, "nenhum WordPress detectado neste local")
		return
	}
	adminUser := ""
	if logins := h.wpAdminLogins(r.Context(), c.LXCContainerName, dir); len(logins) > 0 {
		adminUser = logins[0]
	}
	dbName := ""
	if r2, err := h.files.WP(r.Context(), c.LXCContainerName, dir, []string{"config", "get", "DB_NAME"}); err == nil && r2.Exit == 0 {
		dbName = strings.TrimSpace(r2.Stdout)
	}
	inst, err := h.store.CreateWordPressInstall(r.Context(), req.DomainID, path, adminUser, dbName)
	if isUniqueViolation(err) {
		WriteError(w, http.StatusConflict, "este WordPress já está registrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao registrar o WordPress")
		return
	}
	inst.FQDN = dom.FQDN
	WriteJSON(w, http.StatusCreated, inst)
}



func (h *Handlers) HardenWordPress(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	inst, err := h.store.GetWordPressInstallOwned(r.Context(), id, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "instalação não encontrada")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar instalação")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionHardenWordPress,
		core.HardenWordPressPayload{DomainID: inst.DomainID, Path: inst.Path}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}


func (h *Handlers) HardenAllWordPress(w http.ResponseWriter, r *http.Request) {
	installs, err := h.store.ListAllWordPressInstalls(r.Context())
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar instalações")
		return
	}
	uid := userID(r)
	queued := 0
	for _, in := range installs {
		if _, err := h.enqueue(r.Context(), core.ActionHardenWordPress,
			core.HardenWordPressPayload{DomainID: in.DomainID, Path: in.Path}, uid); err == nil {
			queued++
		}
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"queued": queued})
}

type wpManageRequest struct {
	Target string `json:"target"` 
	Action string `json:"action"` 
	Slug   string `json:"slug"`
}


func wpArgs(req wpManageRequest) ([]string, error) {
	needSlug := func() error {
		if !wpSlugRe.MatchString(req.Slug) {
			return fmt.Errorf("slug inválido")
		}
		return nil
	}
	switch req.Target {
	case "plugin":
		switch req.Action {
		case "activate", "deactivate", "delete", "update":
			if err := needSlug(); err != nil {
				return nil, err
			}
			return []string{"plugin", req.Action, req.Slug}, nil
		case "install":
			if err := needSlug(); err != nil {
				return nil, err
			}
			return []string{"plugin", "install", req.Slug, "--activate"}, nil
		}
	case "theme":
		switch req.Action {
		case "activate", "delete", "update":
			if err := needSlug(); err != nil {
				return nil, err
			}
			return []string{"theme", req.Action, req.Slug}, nil
		case "install":
			if err := needSlug(); err != nil {
				return nil, err
			}
			return []string{"theme", "install", req.Slug}, nil
		}
	case "core":
		if req.Action == "update" {
			return []string{"core", "update"}, nil
		}
	}
	return nil, fmt.Errorf("operação não suportada")
}


func (h *Handlers) WPManage(w http.ResponseWriter, r *http.Request) {
	dir, container, ok := h.wpTarget(w, r)
	if !ok {
		return
	}
	var req wpManageRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	args, err := wpArgs(req)
	if err != nil {
		WriteError(w, http.StatusBadRequest, err.Error())
		return
	}
	res, err := h.files.WP(r.Context(), container, dir, args)
	if err != nil {
		fileErr(w, err)
		return
	}
	if res.Exit != 0 {
		out := res.Stderr
		if out == "" {
			out = res.Stdout
		}
		WriteError(w, http.StatusUnprocessableEntity, "wp-cli: "+strings.TrimSpace(out))
		return
	}
	WriteJSON(w, http.StatusOK, map[string]string{"output": strings.TrimSpace(res.Stdout)})
}




func (h *Handlers) WPUploadInstall(w http.ResponseWriter, r *http.Request) {
	dir, container, ok := h.wpTarget(w, r)
	if !ok {
		return
	}
	if err := r.ParseMultipartForm(20 << 20); err != nil {
		WriteError(w, http.StatusBadRequest, "formulário inválido")
		return
	}
	target := r.FormValue("target")
	if target != "plugin" && target != "theme" {
		WriteError(w, http.StatusBadRequest, "tipo inválido (plugin | theme)")
		return
	}
	file, hdr, err := r.FormFile("file")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "envie o arquivo .zip no campo 'file'")
		return
	}
	defer file.Close()
	if !strings.HasSuffix(strings.ToLower(hdr.Filename), ".zip") {
		WriteError(w, http.StatusBadRequest, "o arquivo deve ser um .zip")
		return
	}
	id, _ := idParam(r, "id")
	tmp := fmt.Sprintf("/var/www/.wsrta-wpupload-%d.zip", id) 
	scope := fileclient.Scope{Mode: "container", Container: container, Path: tmp}
	if err := h.files.Upload(r.Context(), scope, file); err != nil {
		fileErr(w, err)
		return
	}
	defer h.files.Delete(context.Background(), scope) 
	args := []string{target, "install", tmp, "--force"}
	if target == "plugin" {
		args = append(args, "--activate")
	}
	res, err := h.files.WP(r.Context(), container, dir, args)
	if err != nil {
		fileErr(w, err)
		return
	}
	if res.Exit != 0 {
		out := res.Stderr
		if out == "" {
			out = res.Stdout
		}
		WriteError(w, http.StatusUnprocessableEntity, "wp-cli: "+strings.TrimSpace(out))
		return
	}
	WriteJSON(w, http.StatusOK, map[string]string{"output": strings.TrimSpace(res.Stdout)})
}
