package handlers

import (
	"fmt"
	"net/http"

	"github.com/jdobrito/wsrta/internal/core"
)

func (h *Handlers) pmaPort(clientID int64) int { return h.pmaBasePort + int(clientID) }


func (h *Handlers) PhpMyAdminInfo(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	c, err := h.store.GetClient(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{
		"enabled":  c.PhpMyAdminEnabled,
		"open_url": fmt.Sprintf("%s?server=%d", h.pmaURL, cid),
		
		"user":     "wsrta_pma",
		"password": c.PhpMyAdminPassword,
	})
}


func (h *Handlers) EnablePhpMyAdmin(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionSetPhpMyAdmin,
		core.SetPhpMyAdminPayload{ClientID: cid, Enabled: true, Port: h.pmaPort(cid)}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}


func (h *Handlers) DisablePhpMyAdmin(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionSetPhpMyAdmin,
		core.SetPhpMyAdminPayload{ClientID: cid, Enabled: false}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}
