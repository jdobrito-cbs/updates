package handlers

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/jdobrito/wsrta/api/internal/migrate"
	"github.com/jdobrito/wsrta/api/internal/store"
)



type nginxSite struct {
	FQDNs        []string `json:"fqdns"`
	UpstreamIP   string   `json:"upstream_ip"`
	UpstreamPort int      `json:"upstream_port"`
	ProxyTarget  string   `json:"proxy_target"`
	Root         string   `json:"root"`
	File         string   `json:"file"`
	Known        bool     `json:"known"`
}




func (h *Handlers) NginxImport(w http.ResponseWriter, r *http.Request) {
	raw, err := h.files.NginxScan(r.Context())
	if err != nil {
		fileErr(w, err)
		return
	}
	var body struct {
		Sites []nginxSite `json:"sites"`
	}
	if err := json.Unmarshal(raw, &body); err != nil {
		WriteError(w, http.StatusInternalServerError, "resposta inválida do scan")
		return
	}
	known, err := h.store.AllDomainFQDNs(r.Context())
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar domínios")
		return
	}
	for i := range body.Sites {
		for _, f := range body.Sites[i].FQDNs {
			if _, ok := known[strings.ToLower(f)]; ok {
				body.Sites[i].Known = true
				break
			}
		}
	}
	if body.Sites == nil {
		body.Sites = []nginxSite{}
	}
	WriteJSON(w, http.StatusOK, map[string]any{"sites": body.Sites})
}

type backupFile struct {
	Name   string `json:"name"`
	SizeMB int64  `json:"size_mb"`
}


func (h *Handlers) ListBackups(w http.ResponseWriter, r *http.Request) {
	entries, err := os.ReadDir(h.backupDir)
	if err != nil {
		
		WriteJSON(w, http.StatusOK, map[string]any{"dir": h.backupDir, "backups": []backupFile{}})
		return
	}
	out := []backupFile{}
	for _, e := range entries {
		if e.IsDir() || !strings.HasSuffix(e.Name(), ".tar.gz") {
			continue
		}
		
		
		info, err := os.Lstat(filepath.Join(h.backupDir, e.Name()))
		if err != nil || info.Mode()&os.ModeSymlink != 0 {
			continue
		}
		out = append(out, backupFile{Name: e.Name(), SizeMB: info.Size() / (1024 * 1024)})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Name < out[j].Name })
	WriteJSON(w, http.StatusOK, map[string]any{"dir": h.backupDir, "backups": out})
}






func (h *Handlers) UploadBackup(w http.ResponseWriter, r *http.Request) {
	mr, err := r.MultipartReader()
	if err != nil {
		WriteError(w, http.StatusBadRequest, "envie o arquivo como multipart/form-data")
		return
	}
	if err := os.MkdirAll(h.backupDir, 0o755); err != nil {
		WriteError(w, http.StatusInternalServerError, "não foi possível preparar o diretório de backups")
		return
	}
	for {
		part, err := mr.NextPart()
		if err == io.EOF {
			break
		}
		if err != nil {
			WriteError(w, http.StatusBadRequest, "upload inválido")
			return
		}
		if part.FormName() != "file" {
			continue
		}
		
		
		name := filepath.Base(part.FileName())
		if name == "" || !strings.HasSuffix(name, ".tar.gz") || strings.HasPrefix(name, ".") {
			WriteError(w, http.StatusBadRequest, "o arquivo deve ser um .tar.gz")
			return
		}
		dest := filepath.Join(h.backupDir, name)
		tmp := dest + ".part"
		f, err := os.Create(tmp)
		if err != nil {
			WriteError(w, http.StatusInternalServerError, "não foi possível gravar o arquivo")
			return
		}
		if _, err := io.Copy(f, part); err != nil {
			f.Close()
			_ = os.Remove(tmp)
			WriteError(w, http.StatusInternalServerError, "falha ao receber o arquivo")
			return
		}
		if err := f.Close(); err != nil {
			_ = os.Remove(tmp)
			WriteError(w, http.StatusInternalServerError, "falha ao finalizar o arquivo")
			return
		}
		if err := os.Rename(tmp, dest); err != nil {
			_ = os.Remove(tmp)
			WriteError(w, http.StatusInternalServerError, "falha ao finalizar o upload")
			return
		}
		WriteJSON(w, http.StatusOK, map[string]any{"name": name})
		return
	}
	WriteError(w, http.StatusBadRequest, "nenhum arquivo enviado (campo 'file')")
}




func (h *Handlers) DeleteBackup(w http.ResponseWriter, r *http.Request) {
	var req importRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	p, ok := h.resolveBackup(req.File)
	if !ok {
		WriteError(w, http.StatusBadRequest, "arquivo inválido ou inexistente")
		return
	}
	if err := os.Remove(p); err != nil {
		WriteError(w, http.StatusInternalServerError, "falha ao apagar o arquivo")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"deleted": req.File})
}


func (h *Handlers) resolveBackup(name string) (string, bool) {
	if name == "" || name != filepath.Base(name) || !strings.HasSuffix(name, ".tar.gz") {
		return "", false
	}
	p := filepath.Join(h.backupDir, name)
	if _, err := os.Stat(p); err != nil {
		return "", false
	}
	return p, true
}

type importRequest struct {
	File     string `json:"file"`
	ClientID int64  `json:"client_id"` 
	Email    string `json:"email"`     
}


func (h *Handlers) PreviewBackup(w http.ResponseWriter, r *http.Request) {
	var req importRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	p, ok := h.resolveBackup(req.File)
	if !ok {
		WriteError(w, http.StatusBadRequest, "arquivo inválido ou inexistente")
		return
	}
	web, err := migrate.InspectBackup(p)
	if err != nil {
		WriteError(w, http.StatusUnprocessableEntity, err.Error())
		return
	}
	WriteJSON(w, http.StatusOK, previewFromWebsite(web))
}

func previewFromWebsite(web *migrate.Website) map[string]any {
	dbs := make([]map[string]any, 0, len(web.Databases))
	for _, d := range web.Databases {
		dbs = append(dbs, map[string]any{"name": d.Name, "user": d.User, "has_hash": d.PasswordHash != ""})
	}
	return map[string]any{
		"domain":    web.Domain,
		"email":     emailOr(web),
		"php":       web.PHP,
		"has_files": web.HasFiles,
		"databases": dbs,
	}
}




func (h *Handlers) ImportBackup(w http.ResponseWriter, r *http.Request) {
	var req importRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	p, ok := h.resolveBackup(req.File)
	if !ok {
		WriteError(w, http.StatusBadRequest, "arquivo inválido ou inexistente")
		return
	}
	web, err := migrate.InspectBackup(p)
	if err != nil {
		WriteError(w, http.StatusUnprocessableEntity, err.Error())
		return
	}

	ctx := context.Background()
	var (
		clientID, domainID int64
		loginPassword      string
	)
	if req.ClientID > 0 {
		
		if _, e := h.store.GetClient(ctx, req.ClientID); errors.Is(e, store.ErrNotFound) {
			WriteError(w, http.StatusNotFound, "cliente não encontrado")
			return
		} else if e != nil {
			WriteError(w, http.StatusInternalServerError, "erro ao buscar o cliente")
			return
		}
		clientID = req.ClientID
		domainID, err = migrate.PrepareExistingClient(ctx, h.store, h.queue, h.daemonSock, *web, clientID, h.log)
		if err != nil {
			WriteError(w, http.StatusInternalServerError, "falha ao configurar o site no cliente: "+err.Error())
			return
		}
	} else {
		
		
		if e := strings.TrimSpace(req.Email); e != "" {
			if !validEmail(e) {
				WriteError(w, http.StatusBadRequest, "e-mail inválido")
				return
			}
			web.Email = e
		}
		clientID, domainID, loginPassword, err = migrate.PrepareClient(ctx, h.store, h.queue, h.daemonSock, *web, h.log)
		if isUniqueViolation(err) {
			WriteError(w, http.StatusConflict, "já existe um usuário com esse e-mail — informe outro e-mail para o cliente")
			return
		}
		if err != nil {
			WriteError(w, http.StatusInternalServerError, "falha ao criar o cliente: "+err.Error())
			return
		}
	}

	
	stage := filepath.Join(h.migrateStaging, sanitizePath(web.Domain))
	go func() {
		if err := os.MkdirAll(stage, 0o755); err != nil {
			h.log.Error("import: criar staging", "err", err)
			return
		}
		full, err := migrate.ParseBackup(p, stage, true)
		if err != nil {
			h.log.Error("import: extrair backup", "domain", web.Domain, "err", err)
			return
		}
		
		if full.IsWordPress {
			dbName := ""
			if len(full.Databases) > 0 {
				dbName = full.Databases[0].Name
			}
			if _, e := h.store.CreateWordPressInstall(context.Background(), domainID, "", "(importado)", dbName); e != nil {
				h.log.Warn("import: registrar WordPress", "domain", web.Domain, "err", e)
			} else {
				h.log.Info("import: WordPress detectado e associado", "domain", web.Domain)
			}
		}
		if err := migrate.EnqueueRestores(context.Background(), h.queue, h.daemonSock, *full, clientID, domainID); err != nil {
			h.log.Error("import: enfileirar restores", "domain", web.Domain, "err", err)
		}
		h.log.Info("import: restores enfileirados", "domain", web.Domain, "client_id", clientID)
	}()

	resp := map[string]any{"client_id": clientID, "domain": web.Domain}
	if loginPassword != "" {
		resp["login_email"] = emailOr(web)
		resp["login_password"] = loginPassword
	}
	WriteJSON(w, http.StatusAccepted, resp)
}

func emailOr(web *migrate.Website) string {
	if web.Email != "" {
		return web.Email
	}
	return "admin@" + web.Domain
}

func sanitizePath(s string) string {
	return strings.Map(func(r rune) rune {
		if (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9') || r == '.' || r == '-' {
			return r
		}
		return '_'
	}, s)
}
