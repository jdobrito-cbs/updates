package handlers

import (
	"errors"
	"log/slog"
	"net/http"
	"strings"

	"github.com/jdobrito/wsrta/api/internal/auth"
	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/sysinfo"
)



func (h *Handlers) SetupStatus(w http.ResponseWriter, r *http.Request) {
	n, err := h.store.CountAdmins(r.Context())
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao checar o sistema")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{
		"needs_setup": n == 0,
		"server_ip":   sysinfo.PrimaryIP(),
	})
}



func (h *Handlers) Setup(w http.ResponseWriter, r *http.Request) {
	
	if !h.rate.Allow(clientIP(r)) {
		WriteError(w, http.StatusTooManyRequests, "muitas tentativas; tente novamente em instantes")
		return
	}
	
	
	if n, err := h.store.CountAdmins(r.Context()); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao checar o sistema")
		return
	} else if n > 0 {
		WriteError(w, http.StatusConflict, "o sistema já foi configurado")
		return
	}

	var req struct {
		AdminName     string `json:"admin_name"`
		AdminEmail    string `json:"admin_email"`
		AdminPassword string `json:"admin_password"`
		CompanyName   string `json:"company_name"`
		PanelDomain   string `json:"panel_domain"`
	}
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	req.AdminName = strings.TrimSpace(req.AdminName)
	req.AdminEmail = strings.TrimSpace(req.AdminEmail)
	req.CompanyName = strings.TrimSpace(req.CompanyName)
	req.PanelDomain = strings.TrimSpace(req.PanelDomain)
	if !validEmail(req.AdminEmail) {
		WriteError(w, http.StatusBadRequest, "email do admin inválido")
		return
	}
	if req.AdminName == "" || len(req.AdminName) > 80 {
		WriteError(w, http.StatusBadRequest, "informe o nome do admin (até 80 caracteres)")
		return
	}
	if len(req.AdminPassword) < minPasswordLen {
		WriteError(w, http.StatusBadRequest, "a senha do admin deve ter ao menos 8 caracteres")
		return
	}
	if len(req.CompanyName) > 60 {
		req.CompanyName = req.CompanyName[:60]
	}

	hash, err := auth.HashPassword(req.AdminPassword)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao processar a senha")
		return
	}
	
	adminUserID, err := h.store.CreateFirstAdmin(r.Context(), req.AdminEmail, req.AdminName, hash)
	if err != nil {
		if errors.Is(err, store.ErrAdminExists) {
			WriteError(w, http.StatusConflict, "o sistema já foi configurado")
			return
		}
		if isUniqueViolation(err) {
			WriteError(w, http.StatusConflict, "já existe um usuário com esse email")
			return
		}
		WriteError(w, http.StatusInternalServerError, "erro ao criar o administrador")
		return
	}
	
	
	if _, _, _, e := h.ensureSelfTenant(r.Context(), adminUserID, "VPS do administrador",
		selfTenantDefaults.CPU, selfTenantDefaults.RAMMB, selfTenantDefaults.DiskMB,
		selfTenantDefaults.MaxDomains, selfTenantDefaults.MaxDatabases, selfTenantDefaults.BandwidthMB, adminUserID); e != nil {
		h.log.Error("provisionar VPS pessoal do admin", slog.Any("err", e))
	}

	
	if st, err := h.store.GetSettings(r.Context()); err == nil {
		st.CompanyName = req.CompanyName
		st.PanelDomain = req.PanelDomain
		_ = h.store.UpdateSettings(r.Context(), *st)
	}

	WriteJSON(w, http.StatusCreated, map[string]bool{"ok": true})
}
