package handlers

import (
	"errors"
	"net/http"

	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)


func (h *Handlers) sftpPort(clientID int64) int {
	return h.sftpBasePort + int(clientID)
}

type enableSFTPRequest struct {
	User     string `json:"user"`
	Password string `json:"password"`
}


func (h *Handlers) EnableSFTP(w http.ResponseWriter, r *http.Request) {
	id, err := idParam(r, "client_id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	if _, err := h.store.GetClient(r.Context(), id); errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "cliente não encontrado")
		return
	} else if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return
	}

	var req enableSFTPRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if req.User == "" || len(req.Password) < 6 {
		WriteError(w, http.StatusBadRequest, "user e password (>=6) são obrigatórios")
		return
	}

	port := h.sftpPort(id)
	actionID, err := h.enqueue(r.Context(), core.ActionEnableSFTP, core.EnableSFTPPayload{
		ClientID: id, User: req.User, Password: req.Password, HostPort: port,
	}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	
	
	
	_ = h.store.SetClientSFTP(r.Context(), id, true, port, req.User)
	WriteJSON(w, http.StatusAccepted, map[string]any{
		"action_id": actionID,
		"host":      h.publicHost(r.Context(), r.Host),
		"port":      port,
		"user":      req.User,
	})
}


func (h *Handlers) DisableSFTP(w http.ResponseWriter, r *http.Request) {
	id, err := idParam(r, "client_id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	c, err := h.store.GetClient(r.Context(), id)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "cliente não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionDisableSFTP, core.DisableSFTPPayload{
		ClientID: id, User: c.SFTPUser,
	}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	
	
	_ = h.store.SetClientSFTP(r.Context(), id, false, 0, "")
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}


func (h *Handlers) ClientSFTPInfo(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	c, err := h.store.GetClient(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{
		"enabled": c.SFTPEnabled,
		"host":    h.publicHost(r.Context(), r.Host),
		"port":    c.SFTPPort,
		"user":    c.SFTPUser,
	})
}
