package handlers

import (
	"context"
	"fmt"
	"net/http"
	"path"
	"strings"

	"github.com/jdobrito/wsrta/api/internal/fileclient"
)

type fsModeKey struct{}


func (h *Handlers) WithFSHost(next http.Handler) http.Handler { return fsMode(next, "host") }


func (h *Handlers) WithFSContainer(next http.Handler) http.Handler { return fsMode(next, "container") }

func fsMode(next http.Handler, mode string) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		next.ServeHTTP(w, r.WithContext(context.WithValue(r.Context(), fsModeKey{}, mode)))
	})
}


func (h *Handlers) baseScope(w http.ResponseWriter, r *http.Request) (fileclient.Scope, bool) {
	mode, _ := r.Context().Value(fsModeKey{}).(string)
	if mode == "host" {
		return fileclient.Scope{Mode: "host"}, true
	}
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return fileclient.Scope{}, false
	}
	c, err := h.store.GetClient(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cliente")
		return fileclient.Scope{}, false
	}
	return fileclient.Scope{Mode: "container", Container: c.LXCContainerName}, true
}

func fileErr(w http.ResponseWriter, err error) {
	if ae, ok := err.(*fileclient.APIError); ok {
		WriteError(w, ae.Status, ae.Message)
		return
	}
	WriteError(w, http.StatusBadGateway, "serviço de arquivos indisponível")
}

type fsPathReq struct {
	Path string `json:"path"`
}


func (h *Handlers) FilesList(w http.ResponseWriter, r *http.Request) {
	sc, ok := h.baseScope(w, r)
	if !ok {
		return
	}
	var req fsPathReq
	_ = decodeJSON(r, &req)
	sc.Path = req.Path
	entries, err := h.files.List(r.Context(), sc)
	if err != nil {
		fileErr(w, err)
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{"path": req.Path, "entries": entries})
}


func (h *Handlers) scopeFileOp(fn func(context.Context, fileclient.Scope) error) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		sc, ok := h.baseScope(w, r)
		if !ok {
			return
		}
		var req fsPathReq
		if err := decodeJSON(r, &req); err != nil {
			WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
			return
		}
		sc.Path = req.Path
		if err := fn(r.Context(), sc); err != nil {
			fileErr(w, err)
			return
		}
		WriteJSON(w, http.StatusOK, map[string]string{"status": "ok"})
	}
}


func (h *Handlers) FilesMkdir(w http.ResponseWriter, r *http.Request) {
	h.scopeFileOp(h.files.Mkdir)(w, r)
}
func (h *Handlers) FilesNewFile(w http.ResponseWriter, r *http.Request) {
	h.scopeFileOp(h.files.NewFile)(w, r)
}
func (h *Handlers) FilesDelete(w http.ResponseWriter, r *http.Request) {
	h.scopeFileOp(h.files.Delete)(w, r)
}
func (h *Handlers) FilesMove(w http.ResponseWriter, r *http.Request) { h.fsMoveCopy(false)(w, r) }
func (h *Handlers) FilesCopy(w http.ResponseWriter, r *http.Request) { h.fsMoveCopy(true)(w, r) }


func (h *Handlers) FilesRename(w http.ResponseWriter, r *http.Request) {
	sc, ok := h.baseScope(w, r)
	if !ok {
		return
	}
	var req struct {
		Path    string `json:"path"`
		NewName string `json:"new_name"`
	}
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	sc.Path = req.Path
	if err := h.files.Rename(r.Context(), sc, req.NewName); err != nil {
		fileErr(w, err)
		return
	}
	WriteJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}


func (h *Handlers) fsMoveCopy(isCopy bool) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		sc, ok := h.baseScope(w, r)
		if !ok {
			return
		}
		var req struct {
			Path   string `json:"path"`
			DstDir string `json:"dst_dir"`
		}
		if err := decodeJSON(r, &req); err != nil {
			WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
			return
		}
		sc.Path = req.Path
		var err error
		if isCopy {
			err = h.files.Copy(r.Context(), sc, req.DstDir)
		} else {
			err = h.files.Move(r.Context(), sc, req.DstDir)
		}
		if err != nil {
			fileErr(w, err)
			return
		}
		WriteJSON(w, http.StatusOK, map[string]string{"status": "ok"})
	}
}


func (h *Handlers) FilesDownload(w http.ResponseWriter, r *http.Request) {
	sc, ok := h.baseScope(w, r)
	if !ok {
		return
	}
	p := r.URL.Query().Get("path")
	sc.Path = p
	name := path.Base(p)
	if name == "" || name == "/" || name == "." {
		name = "download"
	}
	w.Header().Set("Content-Type", "application/octet-stream")
	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=%q", name))
	if err := h.files.Download(r.Context(), sc, w); err != nil {
		fileErr(w, err)
		return
	}
}


func (h *Handlers) FilesUpload(w http.ResponseWriter, r *http.Request) {
	sc, ok := h.baseScope(w, r)
	if !ok {
		return
	}
	file, header, err := r.FormFile("file")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "envie o arquivo no campo 'file'")
		return
	}
	defer file.Close()
	dir := r.FormValue("path")
	if strings.ContainsAny(header.Filename, "/\\") {
		WriteError(w, http.StatusBadRequest, "nome de arquivo inválido")
		return
	}
	sc.Path = path.Join("/"+strings.TrimPrefix(dir, "/"), header.Filename)
	if err := h.files.Upload(r.Context(), sc, file); err != nil {
		fileErr(w, err)
		return
	}
	WriteJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}
