package handlers

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"time"

	"github.com/jdobrito/wsrta/api/internal/migrate"
	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)


var dbNameRe = regexp.MustCompile(`^[A-Za-z0-9_]{1,64}$`)


func (h *Handlers) ListClientBackups(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	backups, err := h.store.ListBackups(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar backups")
		return
	}
	sched, _ := h.store.GetClientBackupSchedule(r.Context(), cid)
	if backups == nil {
		backups = []core.Backup{}
	}
	WriteJSON(w, http.StatusOK, map[string]any{"schedule": sched, "backups": backups})
}


func (h *Handlers) CreateClientBackup(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	id, err := h.store.CreateBackup(r.Context(), cid, "manual")
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao criar backup")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionBackupClient,
		core.BackupClientPayload{ClientID: cid, BackupID: id}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"backup_id": id, "action_id": actionID})
}


func (h *Handlers) DownloadBackup(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	b, err := h.store.GetBackupOwned(r.Context(), id, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "backup não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar backup")
		return
	}
	if b.Status != "done" || b.Filename == "" || b.Filename != filepath.Base(b.Filename) {
		WriteError(w, http.StatusConflict, "backup não está pronto")
		return
	}
	p := filepath.Join(h.clientBackupDir, b.Filename)
	f, err := os.Open(p)
	if err != nil {
		WriteError(w, http.StatusNotFound, "arquivo do backup não encontrado")
		return
	}
	defer f.Close()
	w.Header().Set("Content-Type", "application/gzip")
	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=%q", b.Filename))
	_, _ = io.Copy(w, f)
}

type scheduleRequest struct {
	Schedule string `json:"schedule"`
}


func (h *Handlers) SetBackupSchedule(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	var req scheduleRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if req.Schedule != "" && req.Schedule != "daily" && req.Schedule != "weekly" {
		WriteError(w, http.StatusBadRequest, "agendamento inválido (use '', daily ou weekly)")
		return
	}
	if err := h.store.SetClientBackupSchedule(r.Context(), cid, req.Schedule); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar agendamento")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}


func (h *Handlers) RestoreClientBackup(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	b, err := h.store.GetBackupOwned(r.Context(), id, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "backup não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar backup")
		return
	}
	if b.Status != "done" || b.Filename == "" || b.Filename != filepath.Base(b.Filename) {
		WriteError(w, http.StatusConflict, "backup não está pronto")
		return
	}
	n, err := h.restoreArchive(r.Context(), cid, filepath.Join(h.clientBackupDir, b.Filename), userID(r))
	if err != nil {
		WriteError(w, http.StatusUnprocessableEntity, err.Error())
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"actions": n})
}


func (h *Handlers) RestoreUpload(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	file, _, err := r.FormFile("file")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "envie o arquivo no campo 'file'")
		return
	}
	defer file.Close()

	if err := os.MkdirAll(h.migrateStaging, 0o755); err != nil {
		WriteError(w, http.StatusInternalServerError, "erro de staging")
		return
	}
	tmp := filepath.Join(h.migrateStaging, fmt.Sprintf("upload-%d-%d.tar.gz", cid, time.Now().UnixNano()))
	dst, err := os.Create(tmp)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao salvar upload")
		return
	}
	if _, err := io.Copy(dst, file); err != nil {
		dst.Close()
		WriteError(w, http.StatusInternalServerError, "erro ao gravar upload")
		return
	}
	dst.Close()

	n, err := h.restoreArchive(r.Context(), cid, tmp, userID(r))
	if err != nil {
		WriteError(w, http.StatusUnprocessableEntity, err.Error())
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"actions": n})
}




func (h *Handlers) restoreArchive(ctx context.Context, clientID int64, archivePath string, uid int64) (int, error) {
	stage := filepath.Join(h.migrateStaging, fmt.Sprintf("restore-%d-%d", clientID, time.Now().UnixNano()))
	if err := os.MkdirAll(stage, 0o755); err != nil {
		h.log.Error("restore: criar staging", slog.Any("err", err))
		return 0, fmt.Errorf("falha ao preparar a restauração")
	}
	if err := migrate.ExtractTarGz(archivePath, stage); err != nil {
		h.log.Error("restore: extrair backup", slog.Any("err", err))
		return 0, fmt.Errorf("falha ao extrair o backup (arquivo inválido?)")
	}
	mb, err := os.ReadFile(filepath.Join(stage, "manifest.json"))
	if err != nil {
		return 0, fmt.Errorf("backup inválido (manifest.json ausente)")
	}
	var m core.BackupManifest
	if err := json.Unmarshal(mb, &m); err != nil {
		return 0, fmt.Errorf("manifesto inválido: %w", err)
	}

	count := 0
	for _, db := range m.Databases {
		
		if !dbNameRe.MatchString(db.Name) {
			continue
		}
		dump := filepath.Join(stage, "db", db.Name+".sql")
		if _, err := os.Stat(dump); err != nil {
			continue
		}
		
		if _, err := h.store.GetDatabaseByName(ctx, clientID, db.Name); errors.Is(err, store.ErrNotFound) {
			_, _ = h.store.CreateDatabase(ctx, clientID, db.Name, db.User, "mariadb")
		}
		if _, err := h.enqueue(ctx, core.ActionRestoreDatabase, core.RestoreDatabasePayload{
			ClientID: clientID, DBName: db.Name, DBUser: db.User, DBPasswordHash: db.PasswordHash, DumpPath: dump,
		}, uid); err != nil {
			return count, err
		}
		count++
	}
	for _, dom := range m.Domains {
		
		if core.ValidFQDN(dom.FQDN) != nil {
			continue
		}
		files := filepath.Join(stage, "files", dom.FQDN+".tar.gz")
		if _, err := os.Stat(files); err != nil {
			continue
		}
		d, err := h.store.GetDomainByFQDN(ctx, clientID, dom.FQDN)
		if errors.Is(err, store.ErrNotFound) {
			d, err = h.store.CreateDomain(ctx, clientID, dom.FQDN, dom.Docroot, dom.PHP, "", 0, "")
			if err != nil {
				return count, err
			}
			if _, err := h.enqueue(ctx, core.ActionAddDomain, core.AddDomainPayload{DomainID: d.ID}, uid); err != nil {
				return count, err
			}
			count++
		} else if err != nil {
			return count, err
		}
		if _, err := h.enqueue(ctx, core.ActionRestoreFiles, core.RestoreFilesPayload{
			DomainID: d.ID, ArchivePath: files,
		}, uid); err != nil {
			return count, err
		}
		count++
	}
	return count, nil
}
