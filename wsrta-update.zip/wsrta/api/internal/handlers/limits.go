package handlers

import "context"





func (h *Handlers) domainLimitReached(ctx context.Context, clientID int64) (bool, error) {
	c, err := h.store.GetClient(ctx, clientID)
	if err != nil {
		return false, err
	}
	if c.MaxDomains <= 0 {
		return false, nil 
	}
	n, err := h.store.CountClientDomains(ctx, clientID)
	if err != nil {
		return false, err
	}
	return n >= c.MaxDomains, nil
}


func (h *Handlers) databaseLimitReached(ctx context.Context, clientID int64) (bool, error) {
	c, err := h.store.GetClient(ctx, clientID)
	if err != nil {
		return false, err
	}
	if c.MaxDatabases <= 0 {
		return false, nil
	}
	n, err := h.store.CountClientDatabases(ctx, clientID)
	if err != nil {
		return false, err
	}
	return n >= c.MaxDatabases, nil
}
