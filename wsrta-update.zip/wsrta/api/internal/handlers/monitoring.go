package handlers

import (
	"net/http"

	"github.com/jdobrito/wsrta/api/internal/monitor"
	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
	"github.com/jdobrito/wsrta/internal/sysinfo"
)

func (h *Handlers) snap() monitor.Snapshot {
	if h.monitor == nil {
		return monitor.Snapshot{}
	}
	return h.monitor.Snapshot()
}


func (h *Handlers) Monitoring(w http.ResponseWriter, _ *http.Request) {
	s := h.snap()
	WriteJSON(w, http.StatusOK, map[string]any{
		"os":       sysinfo.OS(),
		"cpu_info": sysinfo.CPUDesc(),
		"network":  sysinfo.Network(),
		"cpu":      s.CPU,
		"mem":      sysinfo.Mem(),
		"disk":     sysinfo.Disk("/"),
		"net":      map[string]float64{"rx_bps": s.RxBps, "tx_bps": s.TxBps},
	})
}


func (h *Handlers) MonitoringBandwidth(w http.ResponseWriter, r *http.Request) {
	days, err := h.store.ListBandwidth(r.Context(), 30)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao ler banda")
		return
	}
	WriteJSON(w, http.StatusOK, days)
}


func (h *Handlers) ClientBandwidth(w http.ResponseWriter, r *http.Request) {
	list, err := h.store.ListClientBandwidth(r.Context())
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao ler banda por cliente")
		return
	}
	if list == nil {
		list = []store.ClientBandwidth{}
	}
	WriteJSON(w, http.StatusOK, list)
}


func (h *Handlers) ClientMonitoring(w http.ResponseWriter, _ *http.Request) {
	WriteJSON(w, http.StatusOK, map[string]any{
		"cpu":      h.snap().CPU,
		"cpu_info": sysinfo.CPUDesc(),
		"mem":      sysinfo.Mem(),
		"disk":     sysinfo.Disk("/"),
	})
}


func (h *Handlers) UpdateSystemOS(w http.ResponseWriter, r *http.Request) {
	id, err := h.enqueue(r.Context(), core.ActionSystemUpdate, core.SystemUpdatePayload{}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": id})
}


func (h *Handlers) RestartService(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Service string `json:"service"`
	}
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	p := core.RestartServicePayload{Service: req.Service}
	if err := p.Validate(); err != nil {
		WriteError(w, http.StatusBadRequest, err.Error())
		return
	}
	id, err := h.enqueue(r.Context(), core.ActionRestartService, p, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": id})
}


func (h *Handlers) UpdatePanel(w http.ResponseWriter, r *http.Request) {
	id, err := h.enqueue(r.Context(), core.ActionPanelUpdate, core.PanelUpdatePayload{}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": id})
}
