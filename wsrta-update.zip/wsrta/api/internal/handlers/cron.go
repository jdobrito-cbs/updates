package handlers

import (
	"errors"
	"net/http"

	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)


func (h *Handlers) ListCron(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	jobs, err := h.store.ListCronJobs(r.Context(), cid)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao listar cron jobs")
		return
	}
	WriteJSON(w, http.StatusOK, jobs)
}

type createCronRequest struct {
	Schedule string `json:"schedule"`
	Command  string `json:"command"`
	Enabled  *bool  `json:"enabled"`
}


func (h *Handlers) CreateCron(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	var req createCronRequest
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}
	if req.Schedule == "" || req.Command == "" {
		WriteError(w, http.StatusBadRequest, "schedule e command são obrigatórios")
		return
	}
	enabled := true
	if req.Enabled != nil {
		enabled = *req.Enabled
	}

	job, err := h.store.CreateCronJob(r.Context(), cid, req.Schedule, req.Command, enabled)
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao criar cron job")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionSetCron, core.SetCronPayload{CronJobID: job.ID}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "cron criado, mas falhou ao enfileirar")
		return
	}
	WriteJSON(w, http.StatusCreated, map[string]any{"cron_job": job, "action_id": actionID})
}


func (h *Handlers) DeleteCron(w http.ResponseWriter, r *http.Request) {
	cid, ok := h.targetClientID(w, r)
	if !ok {
		return
	}
	id, err := idParam(r, "id")
	if err != nil {
		WriteError(w, http.StatusBadRequest, "id inválido")
		return
	}
	job, err := h.store.GetCronOwned(r.Context(), id, cid)
	if errors.Is(err, store.ErrNotFound) {
		WriteError(w, http.StatusNotFound, "cron job não encontrado")
		return
	}
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao buscar cron job")
		return
	}
	actionID, err := h.enqueue(r.Context(), core.ActionRemoveCron, core.RemoveCronPayload{CronJobID: job.ID}, userID(r))
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao enfileirar remoção")
		return
	}
	WriteJSON(w, http.StatusAccepted, map[string]any{"action_id": actionID})
}
