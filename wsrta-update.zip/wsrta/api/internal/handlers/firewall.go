package handlers

import (
	"net"
	"net/http"
	"regexp"
)

var jailRe = regexp.MustCompile(`^[A-Za-z0-9_.-]{1,64}$`)
var fwServices = map[string]bool{"csf": true, "lfd": true, "fail2ban": true}
var fwOps = map[string]bool{"start": true, "stop": true, "restart": true}

func validIPOrCIDR(s string) bool {
	if net.ParseIP(s) != nil {
		return true
	}
	_, _, err := net.ParseCIDR(s)
	return err == nil
}


func (h *Handlers) FirewallState(w http.ResponseWriter, r *http.Request) {
	raw, err := h.files.FirewallState(r.Context())
	if err != nil {
		fileErr(w, err)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write(raw)
}



func (h *Handlers) FirewallAction(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Kind    string `json:"kind"`
		IP      string `json:"ip"`
		Jail    string `json:"jail"`
		Service string `json:"service"`
		Op      string `json:"op"`
	}
	if err := decodeJSON(r, &req); err != nil {
		WriteError(w, http.StatusBadRequest, "corpo JSON inválido")
		return
	}

	switch req.Kind {
	case "unban", "ban":
		if !jailRe.MatchString(req.Jail) {
			WriteError(w, http.StatusBadRequest, "jail inválida")
			return
		}
		if net.ParseIP(req.IP) == nil {
			WriteError(w, http.StatusBadRequest, "IP inválido")
			return
		}
	case "allow", "deny", "unblock":
		if !validIPOrCIDR(req.IP) {
			WriteError(w, http.StatusBadRequest, "IP/CIDR inválido")
			return
		}
	case "service":
		if !fwServices[req.Service] || !fwOps[req.Op] {
			WriteError(w, http.StatusBadRequest, "serviço/operação não permitidos")
			return
		}
	default:
		WriteError(w, http.StatusBadRequest, "ação desconhecida")
		return
	}

	if err := h.files.FirewallAction(r.Context(), req.Kind, req.IP, req.Jail, req.Service, req.Op); err != nil {
		fileErr(w, err)
		return
	}
	WriteJSON(w, http.StatusOK, map[string]bool{"ok": true})
}
