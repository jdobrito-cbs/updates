package handlers

import (
	"context"
	"strings"
	"sync"
	"time"
)




type lockEntry struct {
	count int
	last  time.Time
	until time.Time
}

var (
	lockoutMu sync.Mutex
	lockouts  = map[string]*lockEntry{}
)

func lockoutKey(email string) string { return strings.ToLower(strings.TrimSpace(email)) }


func (h *Handlers) loginPolicy(ctx context.Context) (max int, dur time.Duration) {
	st, err := h.store.GetSettings(ctx)
	if err != nil || st.MaxLoginAttempts <= 0 {
		return 0, 0
	}
	d := st.LockoutMinutes
	if d <= 0 {
		d = 15
	}
	return st.MaxLoginAttempts, time.Duration(d) * time.Minute
}


func loginLocked(email string) time.Duration {
	lockoutMu.Lock()
	defer lockoutMu.Unlock()
	if e := lockouts[lockoutKey(email)]; e != nil {
		if rem := time.Until(e.until); rem > 0 {
			return rem
		}
	}
	return 0
}



func loginFail(email string, max int, dur time.Duration) {
	if max <= 0 {
		return
	}
	lockoutMu.Lock()
	defer lockoutMu.Unlock()
	k := lockoutKey(email)
	now := time.Now()
	e := lockouts[k]
	if e == nil {
		e = &lockEntry{}
		lockouts[k] = e
	}
	if now.Sub(e.last) > dur {
		e.count = 0
	}
	e.last = now
	e.count++
	if e.count >= max {
		e.until = now.Add(dur)
	}
}


func loginReset(email string) {
	lockoutMu.Lock()
	defer lockoutMu.Unlock()
	delete(lockouts, lockoutKey(email))
}
