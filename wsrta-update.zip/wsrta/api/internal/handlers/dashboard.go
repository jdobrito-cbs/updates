package handlers

import (
	"net/http"

	"github.com/jdobrito/wsrta/internal/sysinfo"
)


func (h *Handlers) AdminDashboard(w http.ResponseWriter, r *http.Request) {
	data, err := h.store.Dashboard(r.Context())
	if err != nil {
		WriteError(w, http.StatusInternalServerError, "erro ao montar o dashboard")
		return
	}
	WriteJSON(w, http.StatusOK, map[string]any{
		"server_ip":       sysinfo.PrimaryIP(),
		"total_domains":   data.TotalDomains,
		"total_databases": data.TotalDatabases,
		"total_wordpress": data.TotalWordPress,
		"clients":         data.Clients,
	})
}
