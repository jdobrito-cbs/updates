



package mailcow

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)


type Manager interface {
	
	AddDomain(ctx context.Context, fqdn string) error
	
	RemoveDomain(ctx context.Context, fqdn string) error
	
	AddMailbox(ctx context.Context, fqdn, localPart, password string, quotaMB int) error
	
	DeleteMailbox(ctx context.Context, fqdn, localPart string) error
	
	SetPassword(ctx context.Context, fqdn, localPart, password string) error
	
	DKIM(ctx context.Context, fqdn string) (txt, selector string, err error)
}



type real struct {
	baseURL string
	apiKey  string
	http    *http.Client
}


func NewReal(baseURL, apiKey string) Manager {
	return &real{
		baseURL: strings.TrimRight(baseURL, "/"),
		apiKey:  apiKey,
		http:    &http.Client{Timeout: 20 * time.Second},
	}
}



func (c *real) do(ctx context.Context, method, path string, body any, out any) error {
	var rdr io.Reader
	if body != nil {
		b, _ := json.Marshal(body)
		rdr = bytes.NewReader(b)
	}
	req, err := http.NewRequestWithContext(ctx, method, c.baseURL+path, rdr)
	if err != nil {
		return err
	}
	req.Header.Set("X-API-Key", c.apiKey)
	req.Header.Set("Content-Type", "application/json")
	res, err := c.http.Do(req)
	if err != nil {
		return fmt.Errorf("mailcow: %w", err)
	}
	defer res.Body.Close()
	raw, _ := io.ReadAll(io.LimitReader(res.Body, 1<<20))
	if res.StatusCode/100 != 2 {
		return fmt.Errorf("mailcow: status %d: %s", res.StatusCode, strings.TrimSpace(string(raw)))
	}
	if out != nil {
		_ = json.Unmarshal(raw, out)
	}
	return checkMailcowResult(raw)
}



func checkMailcowResult(raw []byte) error {
	var arr []struct {
		Type string          `json:"type"`
		Msg  json.RawMessage `json:"msg"`
	}
	if err := json.Unmarshal(raw, &arr); err != nil {
		return nil 
	}
	for _, r := range arr {
		if r.Type == "danger" || r.Type == "error" {
			return fmt.Errorf("mailcow: %s", strings.TrimSpace(string(r.Msg)))
		}
	}
	return nil
}

func (c *real) AddDomain(ctx context.Context, fqdn string) error {
	
	
	return c.do(ctx, http.MethodPost, "/api/v1/add/domain", map[string]any{
		"domain": fqdn, "active": "1", "restart_sogo": "1",
	}, nil)
}

func (c *real) RemoveDomain(ctx context.Context, fqdn string) error {
	return c.do(ctx, http.MethodPost, "/api/v1/delete/domain", []string{fqdn}, nil)
}

func (c *real) AddMailbox(ctx context.Context, fqdn, localPart, password string, quotaMB int) error {
	if quotaMB <= 0 {
		quotaMB = 1024
	}
	return c.do(ctx, http.MethodPost, "/api/v1/add/mailbox", map[string]any{
		"local_part": localPart, "domain": fqdn,
		"password": password, "password2": password,
		"quota": quotaMB, "active": "1", "name": localPart,
	}, nil)
}

func (c *real) DeleteMailbox(ctx context.Context, fqdn, localPart string) error {
	return c.do(ctx, http.MethodPost, "/api/v1/delete/mailbox", []string{localPart + "@" + fqdn}, nil)
}

func (c *real) SetPassword(ctx context.Context, fqdn, localPart, password string) error {
	return c.do(ctx, http.MethodPost, "/api/v1/edit/mailbox", map[string]any{
		"items": []string{localPart + "@" + fqdn},
		"attr":  map[string]any{"password": password, "password2": password},
	}, nil)
}

func (c *real) DKIM(ctx context.Context, fqdn string) (string, string, error) {
	
	get := func() (string, string) {
		var d struct {
			DKIMTxt  string `json:"dkim_txt"`
			Selector string `json:"dkim_selector"`
		}
		_ = c.do(ctx, http.MethodGet, "/api/v1/get/dkim/"+fqdn, nil, &d)
		return d.DKIMTxt, d.Selector
	}
	txt, sel := get()
	if txt == "" {
		_ = c.do(ctx, http.MethodPost, "/api/v1/add/dkim", map[string]any{
			"domains": fqdn, "dkim_selector": "dkim", "key_size": 2048,
		}, nil)
		txt, sel = get()
	}
	if sel == "" {
		sel = "dkim"
	}
	if txt == "" {
		return "", "", fmt.Errorf("mailcow: DKIM indisponível para %s", fqdn)
	}
	return txt, sel, nil
}



type fake struct{}



func NewFake() Manager { return &fake{} }

func (f *fake) AddDomain(context.Context, string) error                       { return nil }
func (f *fake) RemoveDomain(context.Context, string) error                    { return nil }
func (f *fake) AddMailbox(context.Context, string, string, string, int) error { return nil }
func (f *fake) DeleteMailbox(context.Context, string, string) error           { return nil }
func (f *fake) SetPassword(context.Context, string, string, string) error     { return nil }
func (f *fake) DKIM(_ context.Context, fqdn string) (string, string, error) {
	return "v=DKIM1; k=rsa; p=FAKEKEYFORDEV", "dkim", nil
}
