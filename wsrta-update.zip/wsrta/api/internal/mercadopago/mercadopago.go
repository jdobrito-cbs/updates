

package mercadopago

import (
	"bytes"
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"
)

const apiBase = "https://api.mercadopago.com"


type PreferenceRequest struct {
	Title             string
	PriceCents        int64
	BuyerEmail        string
	ExternalReference string 
	NotificationURL   string 
	BackURL           string 
}


type Preference struct {
	ID        string `json:"id"`
	InitPoint string `json:"init_point"`
}

func httpClient() *http.Client { return &http.Client{Timeout: 20 * time.Second} }


func CreatePreference(ctx context.Context, token string, p PreferenceRequest) (*Preference, error) {
	if token == "" {
		return nil, fmt.Errorf("mercadopago: token não configurado")
	}
	body := map[string]any{
		"items": []map[string]any{{
			"title":       p.Title,
			"quantity":    1,
			"unit_price":  float64(p.PriceCents) / 100,
			"currency_id": "BRL",
		}},
		"external_reference": p.ExternalReference,
		"payer":              map[string]any{"email": p.BuyerEmail},
	}
	if p.NotificationURL != "" {
		body["notification_url"] = p.NotificationURL
	}
	if p.BackURL != "" {
		body["back_urls"] = map[string]any{"success": p.BackURL, "pending": p.BackURL, "failure": p.BackURL}
	}
	raw, _ := json.Marshal(body)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, apiBase+"/checkout/preferences", bytes.NewReader(raw))
	if err != nil {
		return nil, err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Authorization", "Bearer "+token)
	res, err := httpClient().Do(req)
	if err != nil {
		return nil, fmt.Errorf("mercadopago: %w", err)
	}
	defer res.Body.Close()
	data, _ := io.ReadAll(res.Body)
	if res.StatusCode/100 != 2 {
		return nil, fmt.Errorf("mercadopago: criar preferência falhou (%d): %s", res.StatusCode, string(data))
	}
	var out Preference
	if err := json.Unmarshal(data, &out); err != nil {
		return nil, fmt.Errorf("mercadopago: resposta inválida: %w", err)
	}
	return &out, nil
}


type Payment struct {
	Status            string  `json:"status"`             
	ExternalReference string  `json:"external_reference"` 
	TransactionAmount float64 `json:"transaction_amount"` 
}




func ValidateWebhookSignature(secret, dataID, requestID, xSignature string) bool {
	if secret == "" || xSignature == "" {
		return false
	}
	var ts, v1 string
	for _, p := range strings.Split(xSignature, ",") {
		kv := strings.SplitN(strings.TrimSpace(p), "=", 2)
		if len(kv) != 2 {
			continue
		}
		switch strings.TrimSpace(kv[0]) {
		case "ts":
			ts = strings.TrimSpace(kv[1])
		case "v1":
			v1 = strings.TrimSpace(kv[1])
		}
	}
	if ts == "" || v1 == "" {
		return false
	}
	manifest := fmt.Sprintf("id:%s;request-id:%s;ts:%s;", strings.ToLower(dataID), requestID, ts)
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(manifest))
	return hmac.Equal([]byte(hex.EncodeToString(mac.Sum(nil))), []byte(v1))
}


func GetPayment(ctx context.Context, token, paymentID string) (*Payment, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, apiBase+"/v1/payments/"+paymentID, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", "Bearer "+token)
	res, err := httpClient().Do(req)
	if err != nil {
		return nil, fmt.Errorf("mercadopago: %w", err)
	}
	defer res.Body.Close()
	data, _ := io.ReadAll(res.Body)
	if res.StatusCode/100 != 2 {
		return nil, fmt.Errorf("mercadopago: consultar pagamento falhou (%d)", res.StatusCode)
	}
	var out Payment
	if err := json.Unmarshal(data, &out); err != nil {
		return nil, fmt.Errorf("mercadopago: resposta inválida: %w", err)
	}
	return &out, nil
}
