package auth

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"
	"time"

	"github.com/jdobrito/wsrta/internal/core"
)


type Middleware struct {
	tokens *Tokens
	
	
	
	sessionValid func(ctx context.Context, userID int64, issuedAt time.Time) bool
}


func NewMiddleware(tokens *Tokens) *Middleware {
	return &Middleware{tokens: tokens}
}



func (m *Middleware) SetSessionValidator(fn func(ctx context.Context, userID int64, issuedAt time.Time) bool) {
	m.sessionValid = fn
}


func (m *Middleware) RequireAuth(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		tokenStr := bearerToken(r)
		if tokenStr == "" {
			writeErr(w, http.StatusUnauthorized, "credenciais ausentes")
			return
		}
		claims, err := m.tokens.Parse(tokenStr)
		if err != nil {
			writeErr(w, http.StatusUnauthorized, "token inválido")
			return
		}
		if claims.Stage != "" {
			
			writeErr(w, http.StatusUnauthorized, "2FA não concluído")
			return
		}
		
		if m.sessionValid != nil && claims.IssuedAt != nil && !m.sessionValid(r.Context(), claims.UserID, claims.IssuedAt.Time) {
			writeErr(w, http.StatusUnauthorized, "sessão revogada")
			return
		}
		next.ServeHTTP(w, r.WithContext(WithClaims(r.Context(), claims)))
	})
}


func (m *Middleware) RequireAdmin(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		c, ok := ClaimsFrom(r.Context())
		if !ok || c.Role != core.RoleAdmin {
			writeErr(w, http.StatusForbidden, "acesso restrito ao admin")
			return
		}
		next.ServeHTTP(w, r)
	})
}


func (m *Middleware) RequireReseller(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		c, ok := ClaimsFrom(r.Context())
		if !ok || c.Role != core.RoleReseller {
			writeErr(w, http.StatusForbidden, "acesso restrito ao revendedor")
			return
		}
		next.ServeHTTP(w, r)
	})
}




func (m *Middleware) RequireAdminOrReseller(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		c, ok := ClaimsFrom(r.Context())
		if !ok || (c.Role != core.RoleAdmin && c.Role != core.RoleReseller) {
			writeErr(w, http.StatusForbidden, "acesso restrito ao admin ou revendedor")
			return
		}
		next.ServeHTTP(w, r)
	})
}


func (m *Middleware) RequireClient(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		c, ok := ClaimsFrom(r.Context())
		if !ok || c.Role != core.RoleClient || c.ClientID == nil {
			writeErr(w, http.StatusForbidden, "acesso restrito ao cliente")
			return
		}
		next.ServeHTTP(w, r)
	})
}

func bearerToken(r *http.Request) string {
	h := r.Header.Get("Authorization")
	if h == "" {
		return ""
	}
	prefix := "Bearer "
	if len(h) > len(prefix) && strings.EqualFold(h[:len(prefix)], prefix) {
		return strings.TrimSpace(h[len(prefix):])
	}
	return ""
}

func writeErr(w http.ResponseWriter, code int, msg string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(map[string]string{"error": msg})
}
