package auth_test

import (
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/jdobrito/wsrta/api/internal/auth"
	"github.com/jdobrito/wsrta/internal/core"
)

func okHandler() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	})
}

func serve(h http.Handler, token string) int {
	req := httptest.NewRequest(http.MethodGet, "/", nil)
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	return rec.Code
}

func TestRequireAuth(t *testing.T) {
	tk := auth.NewTokens("segredo", time.Hour)
	mw := auth.NewMiddleware(tk)
	h := mw.RequireAuth(okHandler())

	if code := serve(h, ""); code != http.StatusUnauthorized {
		t.Fatalf("sem token: %d, esperava 401", code)
	}
	if code := serve(h, "lixo"); code != http.StatusUnauthorized {
		t.Fatalf("token inválido: %d, esperava 401", code)
	}
	valid, _ := tk.Issue(1, core.RoleClient, ptrInt64(5))
	if code := serve(h, valid); code != http.StatusOK {
		t.Fatalf("token válido: %d, esperava 200", code)
	}
}

func TestRequireAdmin(t *testing.T) {
	tk := auth.NewTokens("segredo", time.Hour)
	mw := auth.NewMiddleware(tk)
	h := mw.RequireAuth(mw.RequireAdmin(okHandler()))

	clientTok, _ := tk.Issue(1, core.RoleClient, ptrInt64(5))
	if code := serve(h, clientTok); code != http.StatusForbidden {
		t.Fatalf("cliente em rota admin: %d, esperava 403", code)
	}
	adminTok, _ := tk.Issue(2, core.RoleAdmin, nil)
	if code := serve(h, adminTok); code != http.StatusOK {
		t.Fatalf("admin em rota admin: %d, esperava 200", code)
	}
}

func TestRequireClient(t *testing.T) {
	tk := auth.NewTokens("segredo", time.Hour)
	mw := auth.NewMiddleware(tk)
	h := mw.RequireAuth(mw.RequireClient(okHandler()))

	adminTok, _ := tk.Issue(2, core.RoleAdmin, nil)
	if code := serve(h, adminTok); code != http.StatusForbidden {
		t.Fatalf("admin em rota de cliente: %d, esperava 403", code)
	}
	clientTok, _ := tk.Issue(1, core.RoleClient, ptrInt64(5))
	if code := serve(h, clientTok); code != http.StatusOK {
		t.Fatalf("cliente em rota de cliente: %d, esperava 200", code)
	}
}
