package auth_test

import (
	"strings"
	"testing"
	"time"

	"github.com/pquerna/otp/totp"

	"github.com/jdobrito/wsrta/api/internal/auth"
)

func TestTOTPRoundtrip(t *testing.T) {
	secret, url, err := auth.GenerateTOTP("WSRTA", "a@b.c")
	if err != nil {
		t.Fatalf("generate: %v", err)
	}
	if secret == "" || !strings.HasPrefix(url, "otpauth://") {
		t.Fatalf("segredo/url inválidos: %q %q", secret, url)
	}

	code, err := totp.GenerateCode(secret, time.Now())
	if err != nil {
		t.Fatalf("gerar código: %v", err)
	}
	if !auth.ValidateTOTP(secret, code) {
		t.Fatal("código atual deveria validar")
	}

	old, _ := totp.GenerateCode(secret, time.Now().Add(-10*time.Minute))
	if auth.ValidateTOTP(secret, old) {
		t.Fatal("código antigo deveria falhar")
	}
}

func TestRecoveryCodes(t *testing.T) {
	plain, hashes, err := auth.GenerateRecoveryCodes(8)
	if err != nil {
		t.Fatalf("gerar: %v", err)
	}
	if len(plain) != 8 || len(hashes) != 8 {
		t.Fatalf("quantidades: %d/%d", len(plain), len(hashes))
	}
	if auth.HashRecoveryCode(plain[0]) != hashes[0] {
		t.Fatal("hash não corresponde ao código")
	}
	
	if auth.HashRecoveryCode(strings.ToUpper(plain[0])) != hashes[0] {
		t.Fatal("hash deveria ser case-insensitive")
	}
}
