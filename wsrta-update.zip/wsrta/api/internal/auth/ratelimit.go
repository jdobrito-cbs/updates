package auth

import (
	"sync"
	"time"
)


type RateLimiter struct {
	mu        sync.Mutex
	hits      map[string][]time.Time
	limit     int
	window    time.Duration
	lastClean time.Time
}


func NewRateLimiter(perMinute int) *RateLimiter {
	if perMinute <= 0 {
		perMinute = 10
	}
	return &RateLimiter{hits: make(map[string][]time.Time), limit: perMinute, window: time.Minute}
}


func (rl *RateLimiter) Allow(key string) bool {
	now := time.Now()
	cutoff := now.Add(-rl.window)

	rl.mu.Lock()
	defer rl.mu.Unlock()

	
	if now.Sub(rl.lastClean) > rl.window {
		for k, ts := range rl.hits {
			stale := true
			for _, t := range ts {
				if t.After(cutoff) {
					stale = false
					break
				}
			}
			if stale {
				delete(rl.hits, k)
			}
		}
		rl.lastClean = now
	}

	recent := rl.hits[key][:0]
	for _, t := range rl.hits[key] {
		if t.After(cutoff) {
			recent = append(recent, t)
		}
	}
	if len(recent) >= rl.limit {
		rl.hits[key] = recent
		return false
	}
	rl.hits[key] = append(recent, now)
	return true
}
