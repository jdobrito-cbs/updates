package auth_test

import (
	"testing"
	"time"

	"github.com/jdobrito/wsrta/api/internal/auth"
	"github.com/jdobrito/wsrta/internal/core"
)

func ptrInt64(v int64) *int64 { return &v }

func TestIssueParseRoundtrip(t *testing.T) {
	tk := auth.NewTokens("segredo", time.Hour)
	s, err := tk.Issue(1, core.RoleClient, ptrInt64(7))
	if err != nil {
		t.Fatalf("issue: %v", err)
	}
	claims, err := tk.Parse(s)
	if err != nil {
		t.Fatalf("parse: %v", err)
	}
	if claims.UserID != 1 || claims.Role != core.RoleClient || claims.ClientID == nil || *claims.ClientID != 7 {
		t.Fatalf("claims inesperadas: %+v", claims)
	}
}

func TestParseRejectsTamperedAndWrongSecret(t *testing.T) {
	tk := auth.NewTokens("segredo", time.Hour)
	s, _ := tk.Issue(1, core.RoleAdmin, nil)

	if _, err := tk.Parse(s + "x"); err == nil {
		t.Fatal("token adulterado deveria falhar")
	}
	other := auth.NewTokens("outro-segredo", time.Hour)
	if _, err := other.Parse(s); err == nil {
		t.Fatal("token com segredo errado deveria falhar")
	}
}

func TestParseRejectsExpired(t *testing.T) {
	tk := auth.NewTokens("segredo", -time.Hour) 
	s, _ := tk.Issue(1, core.RoleAdmin, nil)
	if _, err := tk.Parse(s); err == nil {
		t.Fatal("token expirado deveria falhar")
	}
}
