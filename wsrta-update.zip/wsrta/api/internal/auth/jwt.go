package auth

import (
	"errors"
	"time"

	"github.com/golang-jwt/jwt/v5"

	"github.com/jdobrito/wsrta/internal/core"
)



const StagePre2FA = "pre2fa"



const (
	jwtIssuer   = "wsrta"
	jwtAudience = "wsrta-panel"
)


type Claims struct {
	UserID   int64     `json:"uid"`
	Role     core.Role `json:"role"`
	ClientID *int64    `json:"cid,omitempty"`
	Stage    string    `json:"stg,omitempty"`
	jwt.RegisteredClaims
}


type Tokens struct {
	secret []byte
	ttl    time.Duration
}


func NewTokens(secret string, ttl time.Duration) *Tokens {
	return &Tokens{secret: []byte(secret), ttl: ttl}
}


func (t *Tokens) Issue(userID int64, role core.Role, clientID *int64) (string, error) {
	return t.IssueWithTTL(userID, role, clientID, t.ttl)
}


func (t *Tokens) IssueWithTTL(userID int64, role core.Role, clientID *int64, ttl time.Duration) (string, error) {
	if ttl <= 0 {
		ttl = t.ttl
	}
	now := time.Now()
	claims := Claims{
		UserID:   userID,
		Role:     role,
		ClientID: clientID,
		RegisteredClaims: jwt.RegisteredClaims{
			Issuer:    jwtIssuer,
			Audience:  jwt.ClaimStrings{jwtAudience},
			IssuedAt:  jwt.NewNumericDate(now),
			ExpiresAt: jwt.NewNumericDate(now.Add(ttl)),
		},
	}
	return jwt.NewWithClaims(jwt.SigningMethodHS256, claims).SignedString(t.secret)
}


func (t *Tokens) IssuePre2FA(userID int64) (string, error) {
	now := time.Now()
	claims := Claims{
		UserID: userID,
		Stage:  StagePre2FA,
		RegisteredClaims: jwt.RegisteredClaims{
			Issuer:    jwtIssuer,
			Audience:  jwt.ClaimStrings{jwtAudience},
			IssuedAt:  jwt.NewNumericDate(now),
			ExpiresAt: jwt.NewNumericDate(now.Add(5 * time.Minute)),
		},
	}
	return jwt.NewWithClaims(jwt.SigningMethodHS256, claims).SignedString(t.secret)
}


var ErrInvalidToken = errors.New("auth: token inválido")


func (t *Tokens) Parse(tokenStr string) (*Claims, error) {
	claims := &Claims{}
	tok, err := jwt.ParseWithClaims(tokenStr, claims, func(tok *jwt.Token) (any, error) {
		if _, ok := tok.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, ErrInvalidToken
		}
		return t.secret, nil
	}, jwt.WithIssuer(jwtIssuer), jwt.WithAudience(jwtAudience))
	if err != nil || !tok.Valid {
		return nil, ErrInvalidToken
	}
	return claims, nil
}
