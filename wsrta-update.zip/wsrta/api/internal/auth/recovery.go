package auth

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"math/big"
	"strings"
)


const recoveryAlphabet = "abcdefghjkmnpqrstuvwxyz23456789"



func GenerateRecoveryCodes(n int) (plain []string, hashes []string, err error) {
	for i := 0; i < n; i++ {
		code, err := randomCode()
		if err != nil {
			return nil, nil, err
		}
		plain = append(plain, code)
		hashes = append(hashes, HashRecoveryCode(code))
	}
	return plain, hashes, nil
}


func HashRecoveryCode(code string) string {
	sum := sha256.Sum256([]byte(strings.TrimSpace(strings.ToLower(code))))
	return hex.EncodeToString(sum[:])
}

func randomCode() (string, error) {
	const length = 10
	max := big.NewInt(int64(len(recoveryAlphabet)))
	b := make([]byte, length)
	for i := range b {
		idx, err := rand.Int(rand.Reader, max)
		if err != nil {
			return "", err
		}
		b[i] = recoveryAlphabet[idx.Int64()]
	}
	return string(b[:5]) + "-" + string(b[5:]), nil
}
