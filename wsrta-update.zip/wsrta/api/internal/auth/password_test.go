package auth_test

import (
	"testing"

	"github.com/jdobrito/wsrta/api/internal/auth"
)

func TestHashVerifyRoundtrip(t *testing.T) {
	hash, err := auth.HashPassword("s3nha-forte")
	if err != nil {
		t.Fatalf("hash: %v", err)
	}
	ok, err := auth.VerifyPassword("s3nha-forte", hash)
	if err != nil || !ok {
		t.Fatalf("verify correta: ok=%v err=%v", ok, err)
	}
	bad, err := auth.VerifyPassword("errada", hash)
	if err != nil || bad {
		t.Fatalf("verify errada deveria falhar: ok=%v err=%v", bad, err)
	}
}

func TestHashIsSalted(t *testing.T) {
	h1, _ := auth.HashPassword("igual")
	h2, _ := auth.HashPassword("igual")
	if h1 == h2 {
		t.Fatal("hashes da mesma senha deveriam diferir (salt aleatório)")
	}
}

func TestVerifyInvalidHash(t *testing.T) {
	if _, err := auth.VerifyPassword("x", "não-é-phc"); err == nil {
		t.Fatal("esperava erro de hash inválido")
	}
}
