package store

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"

	"github.com/jdobrito/wsrta/internal/core"
)


func (s *Store) ListBackups(ctx context.Context, clientID int64) ([]core.Backup, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT id, client_id, filename, size_bytes, status, note, created_at, finished_at
		   FROM backups WHERE client_id = $1 ORDER BY created_at DESC`, clientID)
	if err != nil {
		return nil, fmt.Errorf("store: list backups: %w", err)
	}
	defer rows.Close()
	var out []core.Backup
	for rows.Next() {
		var b core.Backup
		if err := rows.Scan(&b.ID, &b.ClientID, &b.Filename, &b.SizeBytes, &b.Status, &b.Note, &b.CreatedAt, &b.FinishedAt); err != nil {
			return nil, fmt.Errorf("store: scan backup: %w", err)
		}
		out = append(out, b)
	}
	return out, rows.Err()
}


func (s *Store) CreateBackup(ctx context.Context, clientID int64, note string) (int64, error) {
	var id int64
	err := s.pool.QueryRow(ctx,
		`INSERT INTO backups (client_id, note, status) VALUES ($1, $2, 'pending') RETURNING id`,
		clientID, note).Scan(&id)
	if err != nil {
		return 0, fmt.Errorf("store: create backup: %w", err)
	}
	return id, nil
}


func (s *Store) GetBackupOwned(ctx context.Context, id, clientID int64) (*core.Backup, error) {
	var b core.Backup
	err := s.pool.QueryRow(ctx,
		`SELECT id, client_id, filename, size_bytes, status, note, created_at, finished_at
		   FROM backups WHERE id = $1 AND client_id = $2`, id, clientID,
	).Scan(&b.ID, &b.ClientID, &b.Filename, &b.SizeBytes, &b.Status, &b.Note, &b.CreatedAt, &b.FinishedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get backup: %w", err)
	}
	return &b, nil
}


func (s *Store) GetClientBackupSchedule(ctx context.Context, clientID int64) (string, error) {
	var sched string
	err := s.pool.QueryRow(ctx, `SELECT backup_schedule FROM clients WHERE id = $1`, clientID).Scan(&sched)
	if errors.Is(err, pgx.ErrNoRows) {
		return "", ErrNotFound
	}
	if err != nil {
		return "", fmt.Errorf("store: get schedule: %w", err)
	}
	return sched, nil
}


func (s *Store) SetClientBackupSchedule(ctx context.Context, clientID int64, schedule string) error {
	tag, err := s.pool.Exec(ctx, `UPDATE clients SET backup_schedule = $2 WHERE id = $1`, clientID, schedule)
	if err != nil {
		return fmt.Errorf("store: set schedule: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}


func (s *Store) GetDomainByFQDN(ctx context.Context, clientID int64, fqdn string) (*core.Domain, error) {
	var d core.Domain
	err := s.pool.QueryRow(ctx,
		`SELECT id, client_id, fqdn, docroot, php_version, ssl_enabled, created_at
		   FROM domains WHERE client_id = $1 AND fqdn = $2`, clientID, fqdn,
	).Scan(&d.ID, &d.ClientID, &d.FQDN, &d.Docroot, &d.PHPVersion, &d.SSLEnabled, &d.CreatedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get domain by fqdn: %w", err)
	}
	return &d, nil
}


func (s *Store) GetDatabaseByName(ctx context.Context, clientID int64, name string) (*core.Database, error) {
	var d core.Database
	err := s.pool.QueryRow(ctx,
		`SELECT id, client_id, db_name, db_user, created_at
		   FROM databases WHERE client_id = $1 AND db_name = $2`, clientID, name,
	).Scan(&d.ID, &d.ClientID, &d.DBName, &d.DBUser, &d.CreatedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get database by name: %w", err)
	}
	return &d, nil
}
