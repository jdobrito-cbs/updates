package store

import (
	"context"
	"fmt"

	"github.com/jdobrito/wsrta/internal/core"
)


func (s *Store) ListActions(ctx context.Context, limit int) ([]core.Action, error) {
	return s.listActions(ctx, "", limit)
}





func (s *Store) ListActionsByType(ctx context.Context, actionType string, limit int) ([]core.Action, error) {
	return s.listActions(ctx, actionType, limit)
}



func (s *Store) listActions(ctx context.Context, actionType string, limit int) ([]core.Action, error) {
	if limit <= 0 || limit > 500 {
		limit = 100
	}
	q := `SELECT id, type, payload, status, result, requested_by, created_at, started_at, finished_at, progress, progress_stage
		   FROM actions`
	args := []any{}
	if actionType != "" {
		args = append(args, actionType)
		q += fmt.Sprintf(" WHERE type = $%d", len(args))
	}
	args = append(args, limit)
	q += fmt.Sprintf(" ORDER BY id DESC LIMIT $%d", len(args))
	rows, err := s.pool.Query(ctx, q, args...)
	if err != nil {
		return nil, fmt.Errorf("store: list actions: %w", err)
	}
	defer rows.Close()

	var out []core.Action
	for rows.Next() {
		var a core.Action
		var typeStr, statusStr string
		var payload []byte
		if err := rows.Scan(&a.ID, &typeStr, &payload, &statusStr, &a.Result,
			&a.RequestedBy, &a.CreatedAt, &a.StartedAt, &a.FinishedAt, &a.Progress, &a.ProgressStage); err != nil {
			return nil, fmt.Errorf("store: scan action: %w", err)
		}
		a.Type = core.ActionType(typeStr)
		a.Status = core.ActionStatus(statusStr)
		a.Payload = payload
		out = append(out, a)
	}
	return out, rows.Err()
}


func (s *Store) CountClientResources(ctx context.Context, clientID int64) (domains, databases int, err error) {
	if err = s.pool.QueryRow(ctx, `SELECT count(*) FROM domains WHERE client_id = $1`, clientID).Scan(&domains); err != nil {
		return 0, 0, fmt.Errorf("store: contar domínios: %w", err)
	}
	if err = s.pool.QueryRow(ctx, `SELECT count(*) FROM databases WHERE client_id = $1`, clientID).Scan(&databases); err != nil {
		return 0, 0, fmt.Errorf("store: contar bancos: %w", err)
	}
	return domains, databases, nil
}
