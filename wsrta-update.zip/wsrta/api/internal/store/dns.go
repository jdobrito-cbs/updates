package store

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"

	"github.com/jdobrito/wsrta/internal/core"
)


func (s *Store) ListDNSRecords(ctx context.Context, domainID int64) ([]core.DNSRecord, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT id, domain_id, type, name, content, ttl, prio, created_at
		   FROM dns_records WHERE domain_id = $1 ORDER BY id`, domainID)
	if err != nil {
		return nil, fmt.Errorf("store: list dns: %w", err)
	}
	defer rows.Close()

	var out []core.DNSRecord
	for rows.Next() {
		var r core.DNSRecord
		if err := rows.Scan(&r.ID, &r.DomainID, &r.Type, &r.Name, &r.Content, &r.TTL, &r.Prio, &r.CreatedAt); err != nil {
			return nil, fmt.Errorf("store: scan dns: %w", err)
		}
		out = append(out, r)
	}
	return out, rows.Err()
}


func (s *Store) GetDNSRecordInDomain(ctx context.Context, id, domainID int64) (*core.DNSRecord, error) {
	var r core.DNSRecord
	err := s.pool.QueryRow(ctx,
		`SELECT id, domain_id, type, name, content, ttl, prio, created_at
		   FROM dns_records WHERE id = $1 AND domain_id = $2`, id, domainID,
	).Scan(&r.ID, &r.DomainID, &r.Type, &r.Name, &r.Content, &r.TTL, &r.Prio, &r.CreatedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get dns: %w", err)
	}
	return &r, nil
}


func (s *Store) CreateDNSRecord(ctx context.Context, domainID int64, rtype, name, content string, ttl int, prio *int) (*core.DNSRecord, error) {
	if ttl <= 0 {
		ttl = 3600
	}
	var r core.DNSRecord
	err := s.pool.QueryRow(ctx,
		`INSERT INTO dns_records (domain_id, type, name, content, ttl, prio)
		 VALUES ($1, $2, $3, $4, $5, $6)
		 RETURNING id, domain_id, type, name, content, ttl, prio, created_at`,
		domainID, rtype, name, content, ttl, prio,
	).Scan(&r.ID, &r.DomainID, &r.Type, &r.Name, &r.Content, &r.TTL, &r.Prio, &r.CreatedAt)
	if err != nil {
		return nil, fmt.Errorf("store: create dns: %w", err)
	}
	return &r, nil
}


func (s *Store) UpdateDNSRecord(ctx context.Context, id, domainID int64, rtype, name, content string, ttl int, prio *int) error {
	if ttl <= 0 {
		ttl = 3600
	}
	tag, err := s.pool.Exec(ctx,
		`UPDATE dns_records SET type=$3, name=$4, content=$5, ttl=$6, prio=$7
		  WHERE id = $1 AND domain_id = $2`,
		id, domainID, rtype, name, content, ttl, prio)
	if err != nil {
		return fmt.Errorf("store: update dns: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}
