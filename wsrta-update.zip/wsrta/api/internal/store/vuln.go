package store

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"

	"github.com/jdobrito/wsrta/internal/core"
)


func (s *Store) CreateVulnScan(ctx context.Context, clientID int64) (int64, error) {
	var cid any
	if clientID > 0 {
		cid = clientID
	}
	var id int64
	if err := s.pool.QueryRow(ctx,
		`INSERT INTO vuln_scans (client_id, status) VALUES ($1, 'pending') RETURNING id`, cid).Scan(&id); err != nil {
		return 0, fmt.Errorf("store: create vuln scan: %w", err)
	}
	return id, nil
}


func (s *Store) ListVulnScans(ctx context.Context, clientID int64, limit int) ([]core.VulnScan, error) {
	if limit <= 0 || limit > 100 {
		limit = 20
	}
	q := `SELECT id, COALESCE(client_id, 0), status, high, medium, low, info, summary, created_at, finished_at
	        FROM vuln_scans WHERE `
	args := []any{}
	if clientID > 0 {
		args = append(args, clientID)
		q += "client_id = $1"
	} else {
		q += "client_id IS NULL"
	}
	q += fmt.Sprintf(" ORDER BY id DESC LIMIT $%d", len(args)+1)
	args = append(args, limit)

	rows, err := s.pool.Query(ctx, q, args...)
	if err != nil {
		return nil, fmt.Errorf("store: list vuln scans: %w", err)
	}
	defer rows.Close()
	var out []core.VulnScan
	for rows.Next() {
		var v core.VulnScan
		if err := rows.Scan(&v.ID, &v.ClientID, &v.Status, &v.High, &v.Medium, &v.Low, &v.Info,
			&v.Summary, &v.CreatedAt, &v.FinishedAt); err != nil {
			return nil, err
		}
		out = append(out, v)
	}
	return out, rows.Err()
}


func (s *Store) GetVulnScan(ctx context.Context, scanID int64) (*core.VulnScan, error) {
	var v core.VulnScan
	err := s.pool.QueryRow(ctx,
		`SELECT id, COALESCE(client_id, 0), status, high, medium, low, info, summary, created_at, finished_at
		   FROM vuln_scans WHERE id = $1`, scanID).
		Scan(&v.ID, &v.ClientID, &v.Status, &v.High, &v.Medium, &v.Low, &v.Info, &v.Summary, &v.CreatedAt, &v.FinishedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get vuln scan: %w", err)
	}
	return &v, nil
}


func (s *Store) ListVulnFindings(ctx context.Context, scanID int64) ([]core.VulnFinding, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT id, scan_id, fqdn, severity, category, title, detail, remediation
		   FROM vuln_findings WHERE scan_id = $1
		  ORDER BY CASE severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 WHEN 'low' THEN 2 ELSE 3 END, id`, scanID)
	if err != nil {
		return nil, fmt.Errorf("store: list vuln findings: %w", err)
	}
	defer rows.Close()
	var out []core.VulnFinding
	for rows.Next() {
		var f core.VulnFinding
		if err := rows.Scan(&f.ID, &f.ScanID, &f.FQDN, &f.Severity, &f.Category, &f.Title, &f.Detail, &f.Remediation); err != nil {
			return nil, err
		}
		out = append(out, f)
	}
	return out, rows.Err()
}


func (s *Store) SetClientVulnSchedule(ctx context.Context, clientID int64, schedule string) error {
	_, err := s.pool.Exec(ctx, `UPDATE clients SET vuln_schedule = $2 WHERE id = $1`, clientID, schedule)
	if err != nil {
		return fmt.Errorf("store: set vuln schedule: %w", err)
	}
	return nil
}
