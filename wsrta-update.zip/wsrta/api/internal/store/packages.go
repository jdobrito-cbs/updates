package store

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"

	"github.com/jdobrito/wsrta/internal/core"
)

const pkgCols = `id, reseller_id, name, price_cents, cpu_limit, ram_limit_mb, disk_quota_mb,
	max_domains, max_databases, max_mailboxes, bandwidth_limit_mb, duration_days, created_at`

func scanPackage(s interface{ Scan(...any) error }, p *core.Package) error {
	return s.Scan(&p.ID, &p.ResellerID, &p.Name, &p.PriceCents, &p.CPULimit, &p.RAMLimitMB,
		&p.DiskQuotaMB, &p.MaxDomains, &p.MaxDatabases, &p.MaxMailboxes, &p.BandwidthLimitMB, &p.DurationDays, &p.CreatedAt)
}



func pkgWhere(resellerID int64, n int) (string, []any) {
	if resellerID > 0 {
		return fmt.Sprintf("reseller_id = $%d", n), []any{resellerID}
	}
	return "reseller_id IS NULL", nil
}


func (s *Store) ListPackages(ctx context.Context, resellerID int64) ([]core.Package, error) {
	where, args := pkgWhere(resellerID, 1)
	rows, err := s.pool.Query(ctx, `SELECT `+pkgCols+` FROM packages WHERE `+where+` ORDER BY price_cents, id`, args...)
	if err != nil {
		return nil, fmt.Errorf("store: list packages: %w", err)
	}
	defer rows.Close()
	var out []core.Package
	for rows.Next() {
		var p core.Package
		if err := scanPackage(rows, &p); err != nil {
			return nil, fmt.Errorf("store: scan package: %w", err)
		}
		out = append(out, p)
	}
	return out, rows.Err()
}


func (s *Store) GetPackageOwned(ctx context.Context, id, resellerID int64) (*core.Package, error) {
	where, scopeArgs := pkgWhere(resellerID, 2)
	args := append([]any{id}, scopeArgs...)
	var p core.Package
	err := scanPackage(s.pool.QueryRow(ctx, `SELECT `+pkgCols+` FROM packages WHERE id = $1 AND `+where, args...), &p)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get package: %w", err)
	}
	return &p, nil
}


func (s *Store) CreatePackage(ctx context.Context, resellerID int64, p core.Package) (int64, error) {
	var rid any
	if resellerID > 0 {
		rid = resellerID
	}
	var id int64
	err := s.pool.QueryRow(ctx,
		`INSERT INTO packages (reseller_id, name, price_cents, cpu_limit, ram_limit_mb, disk_quota_mb,
			max_domains, max_databases, max_mailboxes, bandwidth_limit_mb, duration_days)
		 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
		rid, p.Name, p.PriceCents, p.CPULimit, p.RAMLimitMB, p.DiskQuotaMB,
		p.MaxDomains, p.MaxDatabases, p.MaxMailboxes, p.BandwidthLimitMB, p.DurationDays).Scan(&id)
	if err != nil {
		return 0, fmt.Errorf("store: create package: %w", err)
	}
	return id, nil
}


func (s *Store) UpdatePackage(ctx context.Context, id, resellerID int64, p core.Package) error {
	q := `UPDATE packages SET name=$2, price_cents=$3, cpu_limit=$4, ram_limit_mb=$5, disk_quota_mb=$6,
		max_domains=$7, max_databases=$8, max_mailboxes=$9, bandwidth_limit_mb=$10, duration_days=$11 WHERE id=$1 AND `
	args := []any{id, p.Name, p.PriceCents, p.CPULimit, p.RAMLimitMB, p.DiskQuotaMB,
		p.MaxDomains, p.MaxDatabases, p.MaxMailboxes, p.BandwidthLimitMB, p.DurationDays}
	where, scopeArgs := pkgWhere(resellerID, 12)
	q += where
	args = append(args, scopeArgs...)
	tag, err := s.pool.Exec(ctx, q, args...)
	if err != nil {
		return fmt.Errorf("store: update package: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}


func (s *Store) DeletePackage(ctx context.Context, id, resellerID int64) error {
	where, scopeArgs := pkgWhere(resellerID, 2)
	args := append([]any{id}, scopeArgs...)
	tag, err := s.pool.Exec(ctx, `DELETE FROM packages WHERE id = $1 AND `+where, args...)
	if err != nil {
		return fmt.Errorf("store: delete package: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}



func (s *Store) SetClientPackageInfo(ctx context.Context, clientID, packageID int64, expiresAt time.Time, maxDomains, maxDatabases int) error {
	var exp any
	if !expiresAt.IsZero() {
		exp = expiresAt
	}
	_, err := s.pool.Exec(ctx,
		`UPDATE clients SET package_id=$2, expires_at=$3, max_domains=$4, max_databases=$5 WHERE id=$1`,
		clientID, packageID, exp, maxDomains, maxDatabases)
	if err != nil {
		return fmt.Errorf("store: set client package: %w", err)
	}
	return nil
}
