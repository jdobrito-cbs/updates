package store

import (
	"context"
	"errors"
	"fmt"
	"strings"

	"github.com/jackc/pgx/v5"

	"github.com/jdobrito/wsrta/internal/core"
)


func (s *Store) ListDomains(ctx context.Context, clientID int64) ([]core.Domain, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT id, client_id, fqdn, docroot, php_version, ssl_enabled, created_at, upstream_ip, upstream_port, upstream_path, email_enabled, offline_mode
		   FROM domains WHERE client_id = $1 ORDER BY id`, clientID)
	if err != nil {
		return nil, fmt.Errorf("store: list domains: %w", err)
	}
	defer rows.Close()

	var out []core.Domain
	for rows.Next() {
		var d core.Domain
		if err := rows.Scan(&d.ID, &d.ClientID, &d.FQDN, &d.Docroot, &d.PHPVersion, &d.SSLEnabled, &d.CreatedAt, &d.UpstreamIP, &d.UpstreamPort, &d.UpstreamPath, &d.EmailEnabled, &d.OfflineMode); err != nil {
			return nil, fmt.Errorf("store: scan domain: %w", err)
		}
		out = append(out, d)
	}
	return out, rows.Err()
}



func (s *Store) ContainerByFQDN(ctx context.Context, fqdn string) (string, error) {
	var container string
	err := s.pool.QueryRow(ctx,
		`SELECT c.lxc_container_name FROM domains d JOIN clients c ON c.id = d.client_id WHERE d.fqdn = $1`,
		fqdn).Scan(&container)
	if errors.Is(err, pgx.ErrNoRows) {
		return "", ErrNotFound
	}
	if err != nil {
		return "", fmt.Errorf("store: container by fqdn: %w", err)
	}
	return container, nil
}



func (s *Store) AllDomainFQDNs(ctx context.Context) (map[string]struct{}, error) {
	rows, err := s.pool.Query(ctx, `SELECT fqdn FROM domains`)
	if err != nil {
		return nil, fmt.Errorf("store: list fqdns: %w", err)
	}
	defer rows.Close()
	set := map[string]struct{}{}
	for rows.Next() {
		var f string
		if err := rows.Scan(&f); err != nil {
			return nil, err
		}
		set[strings.ToLower(f)] = struct{}{}
	}
	return set, rows.Err()
}


func (s *Store) SetDomainPHPVersion(ctx context.Context, id int64, version string) error {
	if _, err := s.pool.Exec(ctx, `UPDATE domains SET php_version = $2 WHERE id = $1`, id, version); err != nil {
		return fmt.Errorf("store: set domain php: %w", err)
	}
	return nil
}


func (s *Store) SetDomainOfflineMode(ctx context.Context, id int64, mode string) error {
	if _, err := s.pool.Exec(ctx, `UPDATE domains SET offline_mode = $2 WHERE id = $1`, id, mode); err != nil {
		return fmt.Errorf("store: set domain offline: %w", err)
	}
	return nil
}


func (s *Store) GetDomainOwned(ctx context.Context, id, clientID int64) (*core.Domain, error) {
	var d core.Domain
	err := s.pool.QueryRow(ctx,
		`SELECT id, client_id, fqdn, docroot, php_version, ssl_enabled, created_at, upstream_ip, upstream_port, upstream_path, email_enabled, offline_mode
		   FROM domains WHERE id = $1 AND client_id = $2`, id, clientID,
	).Scan(&d.ID, &d.ClientID, &d.FQDN, &d.Docroot, &d.PHPVersion, &d.SSLEnabled, &d.CreatedAt, &d.UpstreamIP, &d.UpstreamPort, &d.UpstreamPath, &d.EmailEnabled, &d.OfflineMode)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get domain owned: %w", err)
	}
	return &d, nil
}




func (s *Store) CreateDomain(ctx context.Context, clientID int64, fqdn, docroot, phpVersion, upstreamIP string, upstreamPort int, upstreamPath string) (*core.Domain, error) {
	if docroot == "" {
		docroot = "/var/www/" + fqdn
	}
	if phpVersion == "" {
		phpVersion = "8.3"
	}
	var d core.Domain
	err := s.pool.QueryRow(ctx,
		`INSERT INTO domains (client_id, fqdn, docroot, php_version, upstream_ip, upstream_port, upstream_path)
		 VALUES ($1, $2, $3, $4, $5, $6, $7)
		 RETURNING id, client_id, fqdn, docroot, php_version, ssl_enabled, created_at, upstream_ip, upstream_port, upstream_path, email_enabled, offline_mode`,
		clientID, fqdn, docroot, phpVersion, upstreamIP, upstreamPort, upstreamPath,
	).Scan(&d.ID, &d.ClientID, &d.FQDN, &d.Docroot, &d.PHPVersion, &d.SSLEnabled, &d.CreatedAt, &d.UpstreamIP, &d.UpstreamPort, &d.UpstreamPath, &d.EmailEnabled, &d.OfflineMode)
	if err != nil {
		return nil, fmt.Errorf("store: create domain: %w", err)
	}
	return &d, nil
}
