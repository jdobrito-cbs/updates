package store

import (
	"context"
	"fmt"
)


type BandwidthDay struct {
	Day     string `json:"day"`
	RxBytes int64  `json:"rx_bytes"`
	TxBytes int64  `json:"tx_bytes"`
}


func (s *Store) AddBandwidth(ctx context.Context, rx, tx int64) error {
	_, err := s.pool.Exec(ctx,
		`INSERT INTO bandwidth_daily (day, rx_bytes, tx_bytes) VALUES (CURRENT_DATE, $1, $2)
		 ON CONFLICT (day) DO UPDATE
		   SET rx_bytes = bandwidth_daily.rx_bytes + EXCLUDED.rx_bytes,
		       tx_bytes = bandwidth_daily.tx_bytes + EXCLUDED.tx_bytes`, rx, tx)
	if err != nil {
		return fmt.Errorf("store: add bandwidth: %w", err)
	}
	return nil
}


func (s *Store) ListBandwidth(ctx context.Context, days int) ([]BandwidthDay, error) {
	if days <= 0 {
		days = 30
	}
	rows, err := s.pool.Query(ctx,
		`SELECT to_char(day, 'YYYY-MM-DD'), rx_bytes, tx_bytes
		   FROM bandwidth_daily
		  WHERE day > CURRENT_DATE - $1::int
		  ORDER BY day`, days)
	if err != nil {
		return nil, fmt.Errorf("store: list bandwidth: %w", err)
	}
	defer rows.Close()
	out := []BandwidthDay{}
	for rows.Next() {
		var d BandwidthDay
		if err := rows.Scan(&d.Day, &d.RxBytes, &d.TxBytes); err != nil {
			return nil, err
		}
		out = append(out, d)
	}
	return out, rows.Err()
}
