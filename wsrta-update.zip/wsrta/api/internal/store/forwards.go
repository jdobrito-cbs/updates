package store

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"

	"github.com/jdobrito/wsrta/internal/core"
)



func (s *Store) ListForwards(ctx context.Context, domainID int64) ([]core.DomainForward, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT f.id, f.domain_id, f.path, f.target, COALESCE(f.target_domain_id, 0),
		        COALESCE(td.fqdn, ''), f.created_at
		   FROM domain_forwards f
		   LEFT JOIN domains td ON td.id = f.target_domain_id
		  WHERE f.domain_id = $1 ORDER BY f.path`, domainID)
	if err != nil {
		return nil, fmt.Errorf("store: list forwards: %w", err)
	}
	defer rows.Close()
	var out []core.DomainForward
	for rows.Next() {
		var f core.DomainForward
		if err := rows.Scan(&f.ID, &f.DomainID, &f.Path, &f.Target, &f.TargetDomainID, &f.TargetFQDN, &f.CreatedAt); err != nil {
			return nil, fmt.Errorf("store: scan forward: %w", err)
		}
		out = append(out, f)
	}
	return out, rows.Err()
}



func (s *Store) CreateForward(ctx context.Context, domainID int64, path, target string, targetDomainID int64) (*core.DomainForward, error) {
	var tdi any 
	if targetDomainID > 0 {
		tdi = targetDomainID
	}
	var f core.DomainForward
	err := s.pool.QueryRow(ctx,
		`INSERT INTO domain_forwards (domain_id, path, target, target_domain_id) VALUES ($1, $2, $3, $4)
		 RETURNING id, domain_id, path, target, COALESCE(target_domain_id, 0), created_at`,
		domainID, path, target, tdi).Scan(&f.ID, &f.DomainID, &f.Path, &f.Target, &f.TargetDomainID, &f.CreatedAt)
	if err != nil {
		return nil, err
	}
	return &f, nil
}


func (s *Store) DomainByFQDN(ctx context.Context, fqdn string) (*core.Domain, error) {
	var d core.Domain
	err := s.pool.QueryRow(ctx,
		`SELECT id, client_id, fqdn, docroot, php_version, ssl_enabled, created_at
		   FROM domains WHERE lower(fqdn) = lower($1)`, fqdn).
		Scan(&d.ID, &d.ClientID, &d.FQDN, &d.Docroot, &d.PHPVersion, &d.SSLEnabled, &d.CreatedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: domain by fqdn: %w", err)
	}
	return &d, nil
}


func (s *Store) DeleteForward(ctx context.Context, id, domainID int64) error {
	tag, err := s.pool.Exec(ctx, `DELETE FROM domain_forwards WHERE id = $1 AND domain_id = $2`, id, domainID)
	if err != nil {
		return fmt.Errorf("store: delete forward: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}
