package store

import "github.com/jdobrito/wsrta/internal/crypto"




func encryptSecret(plain string) string  { return crypto.Encrypt(plain) }
func decryptSecret(stored string) string { return crypto.Decrypt(stored) }
