package store

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
)


type AppInstall struct {
	ID            int64     `json:"id"`
	ClientID      int64     `json:"client_id"`
	AppSlug       string    `json:"app_slug"`
	Kind          string    `json:"kind"`
	DomainID      *int64    `json:"domain_id,omitempty"`
	FQDN          string    `json:"fqdn,omitempty"`
	Path          string    `json:"path"`
	DBName        string    `json:"db_name"`
	ContainerName string    `json:"container_name"`
	HostPort      int       `json:"host_port"`
	Status        string    `json:"status"`
	CreatedAt     time.Time `json:"created_at"`
}

const appInstallCols = `a.id, a.client_id, a.app_slug, a.kind, a.domain_id, d.fqdn, a.path, a.db_name, a.container_name, a.host_port, a.status, a.created_at`

func scanAppInstall(s interface{ Scan(...any) error }, a *AppInstall) error {
	var fqdn *string
	if err := s.Scan(&a.ID, &a.ClientID, &a.AppSlug, &a.Kind, &a.DomainID, &fqdn, &a.Path,
		&a.DBName, &a.ContainerName, &a.HostPort, &a.Status, &a.CreatedAt); err != nil {
		return err
	}
	if fqdn != nil {
		a.FQDN = *fqdn
	}
	return nil
}


func (s *Store) ListAppInstalls(ctx context.Context, clientID int64) ([]AppInstall, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT `+appInstallCols+` FROM app_installs a LEFT JOIN domains d ON d.id = a.domain_id
		  WHERE a.client_id = $1 ORDER BY a.id`, clientID)
	if err != nil {
		return nil, fmt.Errorf("store: list app installs: %w", err)
	}
	defer rows.Close()
	var out []AppInstall
	for rows.Next() {
		var a AppInstall
		if err := scanAppInstall(rows, &a); err != nil {
			return nil, fmt.Errorf("store: scan app install: %w", err)
		}
		out = append(out, a)
	}
	return out, rows.Err()
}



func (s *Store) CreateAppInstall(ctx context.Context, clientID int64, slug, kind string, domainID *int64, path, dbName, containerName string, hostPort int) (*AppInstall, error) {
	var id int64
	err := s.pool.QueryRow(ctx,
		`INSERT INTO app_installs (client_id, app_slug, kind, domain_id, path, db_name, container_name, host_port)
		 VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id`,
		clientID, slug, kind, domainID, path, dbName, containerName, hostPort).Scan(&id)
	if err != nil {
		return nil, fmt.Errorf("store: create app install: %w", err)
	}
	return s.GetAppInstallOwned(ctx, id, clientID)
}


func (s *Store) GetAppInstallOwned(ctx context.Context, id, clientID int64) (*AppInstall, error) {
	var a AppInstall
	err := scanAppInstall(s.pool.QueryRow(ctx,
		`SELECT `+appInstallCols+` FROM app_installs a LEFT JOIN domains d ON d.id = a.domain_id
		  WHERE a.id = $1 AND a.client_id = $2`, id, clientID), &a)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get app install: %w", err)
	}
	return &a, nil
}



func (s *Store) NextDockerHostPort(ctx context.Context, base int) (int, error) {
	var port int
	err := s.pool.QueryRow(ctx,
		`SELECT COALESCE(MAX(host_port), $1 - 1) + 1 FROM app_installs WHERE kind = 'docker'`, base).Scan(&port)
	if err != nil {
		return 0, fmt.Errorf("store: next docker host port: %w", err)
	}
	if port < base {
		port = base
	}
	return port, nil
}



func (s *Store) CountAppInstallBySlug(ctx context.Context, clientID int64, slug string) (int, error) {
	var n int
	err := s.pool.QueryRow(ctx,
		`SELECT count(*) FROM app_installs WHERE client_id = $1 AND app_slug = $2 AND status <> 'failed'`, clientID, slug).Scan(&n)
	if err != nil {
		return 0, fmt.Errorf("store: count app install: %w", err)
	}
	return n, nil
}


func (s *Store) SetAppInstallStatus(ctx context.Context, id int64, status string) error {
	_, err := s.pool.Exec(ctx, `UPDATE app_installs SET status = $2 WHERE id = $1`, id, status)
	if err != nil {
		return fmt.Errorf("store: set app install status: %w", err)
	}
	return nil
}


func (s *Store) DeleteAppInstall(ctx context.Context, id int64) error {
	tag, err := s.pool.Exec(ctx, `DELETE FROM app_installs WHERE id = $1`, id)
	if err != nil {
		return fmt.Errorf("store: delete app install: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}





func (s *Store) ListAppAllowed(ctx context.Context, audience string, resellerID *int64) ([]string, error) {
	var rows pgx.Rows
	var err error
	if resellerID == nil {
		rows, err = s.pool.Query(ctx,
			`SELECT app_slug FROM app_allowed WHERE audience = $1 AND reseller_id IS NULL ORDER BY app_slug`, audience)
	} else {
		rows, err = s.pool.Query(ctx,
			`SELECT app_slug FROM app_allowed WHERE audience = $1 AND reseller_id = $2 ORDER BY app_slug`, audience, *resellerID)
	}
	if err != nil {
		return nil, fmt.Errorf("store: list app allowed: %w", err)
	}
	defer rows.Close()
	var out []string
	for rows.Next() {
		var slug string
		if err := rows.Scan(&slug); err != nil {
			return nil, fmt.Errorf("store: scan app allowed: %w", err)
		}
		out = append(out, slug)
	}
	return out, rows.Err()
}



func (s *Store) SetAppAllowed(ctx context.Context, audience string, resellerID *int64, slugs []string) error {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("store: begin: %w", err)
	}
	defer tx.Rollback(ctx)

	if resellerID == nil {
		_, err = tx.Exec(ctx, `DELETE FROM app_allowed WHERE audience = $1 AND reseller_id IS NULL`, audience)
	} else {
		_, err = tx.Exec(ctx, `DELETE FROM app_allowed WHERE audience = $1 AND reseller_id = $2`, audience, *resellerID)
	}
	if err != nil {
		return fmt.Errorf("store: limpar app allowed: %w", err)
	}
	for _, slug := range slugs {
		if _, err := tx.Exec(ctx,
			`INSERT INTO app_allowed (audience, reseller_id, app_slug) VALUES ($1, $2, $3)`,
			audience, resellerID, slug); err != nil {
			return fmt.Errorf("store: inserir app allowed: %w", err)
		}
	}
	return tx.Commit(ctx)
}
