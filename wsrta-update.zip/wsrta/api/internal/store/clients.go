package store

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"

	"github.com/jdobrito/wsrta/internal/core"
)



const clientColumns = `c.id, c.user_id, c.name, c.lxc_container_name, c.cpu_limit, c.ram_limit_mb, c.disk_quota_mb, c.status, c.sftp_enabled, c.sftp_port, c.sftp_user, c.max_domains, c.max_databases, c.phpmyadmin_enabled, c.fast_nginx_enabled, c.created_at, COALESCE(u.last_seen > now() - interval '5 minutes', false) AS online, u.last_seen, COALESCE(u.session_timeout_minutes, 0), c.runtimes, c.postgres_enabled, c.phppgadmin_enabled, c.bandwidth_limit_mb, c.phpmyadmin_password, c.phppgadmin_password, c.reseller_id, c.package_id, c.expires_at, c.owner_user_id, c.docker_enabled, c.max_mailboxes, c.vuln_schedule`

const clientFrom = ` FROM clients c LEFT JOIN users u ON u.id = c.user_id`

func scanClient(s interface{ Scan(...any) error }, c *core.Client) error {
	return s.Scan(&c.ID, &c.UserID, &c.Name, &c.LXCContainerName,
		&c.CPULimit, &c.RAMLimitMB, &c.DiskQuotaMB, &c.Status, &c.SFTPEnabled, &c.SFTPPort, &c.SFTPUser,
		&c.MaxDomains, &c.MaxDatabases, &c.PhpMyAdminEnabled, &c.FastNginxEnabled, &c.CreatedAt, &c.Online, &c.LastSeen,
		&c.SessionTimeoutMinutes, &c.Runtimes, &c.PostgresEnabled, &c.PhpPgAdminEnabled, &c.BandwidthLimitMB,
		&c.PhpMyAdminPassword, &c.PhpPgAdminPassword, &c.ResellerID, &c.PackageID, &c.ExpiresAt, &c.OwnerUserID, &c.DockerEnabled, &c.MaxMailboxes, &c.VulnSchedule)
}



func (s *Store) SetClientSFTP(ctx context.Context, id int64, enabled bool, port int, user string) error {
	_, err := s.pool.Exec(ctx,
		`UPDATE clients SET sftp_enabled = $2, sftp_port = $3, sftp_user = $4 WHERE id = $1`,
		id, enabled, port, user)
	if err != nil {
		return fmt.Errorf("store: set sftp: %w", err)
	}
	return nil
}


func (s *Store) GetClientPowerState(ctx context.Context, clientID int64) (string, error) {
	var state string
	err := s.pool.QueryRow(ctx, `SELECT power_state FROM clients WHERE id = $1`, clientID).Scan(&state)
	if errors.Is(err, pgx.ErrNoRows) {
		return "", ErrNotFound
	}
	if err != nil {
		return "", fmt.Errorf("store: get power state: %w", err)
	}
	return state, nil
}


func (s *Store) SetClientBandwidthLimit(ctx context.Context, id int64, mb int64) error {
	if _, err := s.pool.Exec(ctx, `UPDATE clients SET bandwidth_limit_mb = $2 WHERE id = $1`, id, mb); err != nil {
		return fmt.Errorf("store: set bandwidth limit: %w", err)
	}
	return nil
}


type ClientBandwidth struct {
	ClientID  int64  `json:"client_id"`
	Name      string `json:"name"`
	UsedBytes int64  `json:"used_bytes"`
	LimitMB   int64  `json:"limit_mb"`
	Suspended bool   `json:"suspended"`
}


func (s *Store) ListClientBandwidth(ctx context.Context) ([]ClientBandwidth, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT c.id, c.name, c.bandwidth_limit_mb, c.status = 'suspended',
		        COALESCE((SELECT SUM(rx_bytes + tx_bytes) FROM bandwidth_client_daily b
		                   WHERE b.client_id = c.id AND b.day >= date_trunc('month', CURRENT_DATE)), 0)
		   FROM clients c WHERE c.status <> 'deleted' AND c.owner_user_id IS NULL ORDER BY c.id`)
	if err != nil {
		return nil, fmt.Errorf("store: list client bandwidth: %w", err)
	}
	defer rows.Close()
	var out []ClientBandwidth
	for rows.Next() {
		var b ClientBandwidth
		if err := rows.Scan(&b.ClientID, &b.Name, &b.LimitMB, &b.Suspended, &b.UsedBytes); err != nil {
			return nil, fmt.Errorf("store: scan client bandwidth: %w", err)
		}
		out = append(out, b)
	}
	return out, rows.Err()
}


func (s *Store) SetClientRuntimes(ctx context.Context, id int64, runtimes string) error {
	tag, err := s.pool.Exec(ctx, `UPDATE clients SET runtimes = $2 WHERE id = $1`, id, runtimes)
	if err != nil {
		return fmt.Errorf("store: set runtimes: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}


func (s *Store) SetClientPostgres(ctx context.Context, id int64, enabled bool) error {
	if _, err := s.pool.Exec(ctx, `UPDATE clients SET postgres_enabled = $2 WHERE id = $1`, id, enabled); err != nil {
		return fmt.Errorf("store: set postgres: %w", err)
	}
	return nil
}


func (s *Store) SetClientPhpPgAdmin(ctx context.Context, id int64, enabled bool) error {
	if _, err := s.pool.Exec(ctx, `UPDATE clients SET phppgadmin_enabled = $2 WHERE id = $1`, id, enabled); err != nil {
		return fmt.Errorf("store: set phppgadmin: %w", err)
	}
	return nil
}


func (s *Store) ListClients(ctx context.Context, search string) ([]core.Client, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT `+clientColumns+clientFrom+
			` WHERE c.status <> 'deleted' AND c.owner_user_id IS NULL
			    AND ($1 = '' OR c.name ILIKE '%' || $1 || '%' OR c.lxc_container_name ILIKE '%' || $1 || '%')
		  ORDER BY c.id`, search)
	if err != nil {
		return nil, fmt.Errorf("store: list clients: %w", err)
	}
	defer rows.Close()

	var out []core.Client
	for rows.Next() {
		var c core.Client
		if err := scanClient(rows, &c); err != nil {
			return nil, fmt.Errorf("store: scan client: %w", err)
		}
		out = append(out, c)
	}
	return out, rows.Err()
}


func (s *Store) ListClientsByReseller(ctx context.Context, resellerID int64, search string) ([]core.Client, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT `+clientColumns+clientFrom+
			` WHERE c.status <> 'deleted' AND c.reseller_id = $1
			    AND ($2 = '' OR c.name ILIKE '%' || $2 || '%' OR c.lxc_container_name ILIKE '%' || $2 || '%')
			  ORDER BY c.id`, resellerID, search)
	if err != nil {
		return nil, fmt.Errorf("store: list clients by reseller: %w", err)
	}
	defer rows.Close()
	var out []core.Client
	for rows.Next() {
		var c core.Client
		if err := scanClient(rows, &c); err != nil {
			return nil, fmt.Errorf("store: scan client: %w", err)
		}
		out = append(out, c)
	}
	return out, rows.Err()
}


func (s *Store) SetClientMaxMailboxes(ctx context.Context, id int64, n int) error {
	if _, err := s.pool.Exec(ctx, `UPDATE clients SET max_mailboxes = $2 WHERE id = $1`, id, n); err != nil {
		return fmt.Errorf("store: set max mailboxes: %w", err)
	}
	return nil
}




func (s *Store) MarkClientDeleted(ctx context.Context, id int64) error {
	if _, err := s.pool.Exec(ctx, `UPDATE clients SET status = 'deleted' WHERE id = $1`, id); err != nil {
		return fmt.Errorf("store: marcar cliente deletado: %w", err)
	}
	return nil
}


func (s *Store) ClientBelongsToReseller(ctx context.Context, clientID, resellerID int64) (bool, error) {
	var n int
	err := s.pool.QueryRow(ctx,
		`SELECT count(*) FROM clients WHERE id = $1 AND reseller_id = $2 AND status <> 'deleted' AND owner_user_id IS NULL`,
		clientID, resellerID).Scan(&n)
	if err != nil {
		return false, fmt.Errorf("store: client belongs to reseller: %w", err)
	}
	return n > 0, nil
}


func (s *Store) SetClientReseller(ctx context.Context, clientID, resellerID int64) error {
	var rid any
	if resellerID > 0 {
		rid = resellerID
	}
	if _, err := s.pool.Exec(ctx, `UPDATE clients SET reseller_id = $2 WHERE id = $1`, clientID, rid); err != nil {
		return fmt.Errorf("store: set client reseller: %w", err)
	}
	return nil
}


func (s *Store) GetClient(ctx context.Context, id int64) (*core.Client, error) {
	var c core.Client
	err := scanClient(s.pool.QueryRow(ctx, `SELECT `+clientColumns+clientFrom+` WHERE c.id = $1`, id), &c)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get client: %w", err)
	}
	return &c, nil
}


func (s *Store) UpdateClient(ctx context.Context, id int64, name string, cpu float64, ramMB, diskMB, maxDomains, maxDatabases int) error {
	tag, err := s.pool.Exec(ctx,
		`UPDATE clients SET name = $2, cpu_limit = $3, ram_limit_mb = $4, disk_quota_mb = $5,
		        max_domains = $6, max_databases = $7 WHERE id = $1`,
		id, name, cpu, ramMB, diskMB, maxDomains, maxDatabases)
	if err != nil {
		return fmt.Errorf("store: update client: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}


func (s *Store) CountClientDomains(ctx context.Context, clientID int64) (int, error) {
	var n int
	err := s.pool.QueryRow(ctx, `SELECT count(*) FROM domains WHERE client_id = $1`, clientID).Scan(&n)
	return n, err
}


func (s *Store) CountClientDatabases(ctx context.Context, clientID int64) (int, error) {
	var n int
	err := s.pool.QueryRow(ctx, `SELECT count(*) FROM databases WHERE client_id = $1`, clientID).Scan(&n)
	return n, err
}





func (s *Store) CreateClientWithUser(ctx context.Context, email, passwordHash, name string, cpu float64, ramMB, diskMB int) (int64, error) {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return 0, fmt.Errorf("store: begin: %w", err)
	}
	defer tx.Rollback(ctx)

	var userID int64
	if err := tx.QueryRow(ctx,
		`INSERT INTO users (email, password_hash, role) VALUES ($1, $2, 'client') RETURNING id`,
		email, passwordHash,
	).Scan(&userID); err != nil {
		return 0, fmt.Errorf("store: criar usuário: %w", err)
	}

	
	tempName := fmt.Sprintf("pending-%d", userID)
	var clientID int64
	if err := tx.QueryRow(ctx,
		`INSERT INTO clients (user_id, name, lxc_container_name, cpu_limit, ram_limit_mb, disk_quota_mb)
		 VALUES ($1, $2, $3, $4, $5, $6) RETURNING id`,
		userID, name, tempName, cpu, ramMB, diskMB,
	).Scan(&clientID); err != nil {
		return 0, fmt.Errorf("store: criar cliente: %w", err)
	}

	if _, err := tx.Exec(ctx,
		`UPDATE clients SET lxc_container_name = $2 WHERE id = $1`,
		clientID, fmt.Sprintf("cli-%d", clientID),
	); err != nil {
		return 0, fmt.Errorf("store: definir nome do container: %w", err)
	}

	if err := tx.Commit(ctx); err != nil {
		return 0, fmt.Errorf("store: commit: %w", err)
	}
	return clientID, nil
}




func (s *Store) SelfClientID(ctx context.Context, ownerUserID int64) (int64, error) {
	var id int64
	err := s.pool.QueryRow(ctx,
		`SELECT id FROM clients WHERE owner_user_id = $1 AND status <> 'deleted'`, ownerUserID).Scan(&id)
	if errors.Is(err, pgx.ErrNoRows) {
		return 0, ErrNotFound
	}
	if err != nil {
		return 0, fmt.Errorf("store: self client id: %w", err)
	}
	return id, nil
}






func (s *Store) CreateSelfTenant(ctx context.Context, ownerUserID int64, name, supportEmail, passwordHash string, cpu float64, ramMB, diskMB, maxDomains, maxDatabases int, bandwidthMB int64) (int64, error) {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return 0, fmt.Errorf("store: begin: %w", err)
	}
	defer tx.Rollback(ctx)

	
	
	var supportUserID int64
	if err := tx.QueryRow(ctx,
		`INSERT INTO users (email, password_hash, role, status) VALUES ($1, $2, 'client', 'suspended') RETURNING id`,
		supportEmail, passwordHash,
	).Scan(&supportUserID); err != nil {
		return 0, fmt.Errorf("store: criar usuário de apoio: %w", err)
	}

	tempName := fmt.Sprintf("pending-self-%d", supportUserID)
	var clientID int64
	if err := tx.QueryRow(ctx,
		`INSERT INTO clients (user_id, owner_user_id, name, lxc_container_name, cpu_limit, ram_limit_mb, disk_quota_mb, max_domains, max_databases, bandwidth_limit_mb)
		 VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING id`,
		supportUserID, ownerUserID, name, tempName, cpu, ramMB, diskMB, maxDomains, maxDatabases, bandwidthMB,
	).Scan(&clientID); err != nil {
		return 0, fmt.Errorf("store: criar VPS pessoal: %w", err)
	}
	if _, err := tx.Exec(ctx,
		`UPDATE clients SET lxc_container_name = $2 WHERE id = $1`,
		clientID, fmt.Sprintf("cli-%d", clientID),
	); err != nil {
		return 0, fmt.Errorf("store: definir nome do container: %w", err)
	}
	if err := tx.Commit(ctx); err != nil {
		return 0, fmt.Errorf("store: commit: %w", err)
	}
	return clientID, nil
}
