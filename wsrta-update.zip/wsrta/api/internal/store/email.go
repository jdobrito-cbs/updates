package store

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
)




func (s *Store) SetMailcowConfig(ctx context.Context, url, apiKey string) error {
	if _, err := s.pool.Exec(ctx,
		`UPDATE settings SET mailcow_url = $1, mailcow_api_key = $2`,
		url, encryptSecret(apiKey)); err != nil {
		return fmt.Errorf("store: set mailcow config: %w", err)
	}
	return nil
}


func (s *Store) MailcowConfig(ctx context.Context) (url, apiKey string, err error) {
	var stored string
	if err = s.pool.QueryRow(ctx, `SELECT mailcow_url, mailcow_api_key FROM settings LIMIT 1`).Scan(&url, &stored); err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return "", "", nil
		}
		return "", "", fmt.Errorf("store: mailcow config: %w", err)
	}
	return url, decryptSecret(stored), nil
}




func (s *Store) SetDomainEmailEnabled(ctx context.Context, domainID int64, enabled bool) error {
	if _, err := s.pool.Exec(ctx, `UPDATE domains SET email_enabled = $2 WHERE id = $1`, domainID, enabled); err != nil {
		return fmt.Errorf("store: set domain email: %w", err)
	}
	return nil
}




type Mailbox struct {
	ID        int64     `json:"id"`
	DomainID  int64     `json:"domain_id"`
	FQDN      string    `json:"fqdn"`
	LocalPart string    `json:"local_part"`
	Address   string    `json:"address"`
	QuotaMB   int       `json:"quota_mb"`
	CreatedAt time.Time `json:"created_at"`
}

const mailboxCols = `m.id, m.domain_id, d.fqdn, m.local_part, m.quota_mb, m.created_at`

func scanMailbox(s interface{ Scan(...any) error }, m *Mailbox) error {
	if err := s.Scan(&m.ID, &m.DomainID, &m.FQDN, &m.LocalPart, &m.QuotaMB, &m.CreatedAt); err != nil {
		return err
	}
	m.Address = m.LocalPart + "@" + m.FQDN
	return nil
}


func (s *Store) ListMailboxesByClient(ctx context.Context, clientID int64) ([]Mailbox, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT `+mailboxCols+` FROM mailboxes m JOIN domains d ON d.id = m.domain_id
		  WHERE d.client_id = $1 ORDER BY m.id`, clientID)
	if err != nil {
		return nil, fmt.Errorf("store: list mailboxes: %w", err)
	}
	defer rows.Close()
	var out []Mailbox
	for rows.Next() {
		var m Mailbox
		if err := scanMailbox(rows, &m); err != nil {
			return nil, fmt.Errorf("store: scan mailbox: %w", err)
		}
		out = append(out, m)
	}
	return out, rows.Err()
}


func (s *Store) CountClientMailboxes(ctx context.Context, clientID int64) (int, error) {
	var n int
	err := s.pool.QueryRow(ctx,
		`SELECT count(*) FROM mailboxes m JOIN domains d ON d.id = m.domain_id WHERE d.client_id = $1`,
		clientID).Scan(&n)
	if err != nil {
		return 0, fmt.Errorf("store: count mailboxes: %w", err)
	}
	return n, nil
}


func (s *Store) CreateMailbox(ctx context.Context, domainID int64, localPart string, quotaMB int) (*Mailbox, error) {
	var id int64
	err := s.pool.QueryRow(ctx,
		`INSERT INTO mailboxes (domain_id, local_part, quota_mb) VALUES ($1, $2, $3) RETURNING id`,
		domainID, localPart, quotaMB).Scan(&id)
	if err != nil {
		return nil, fmt.Errorf("store: create mailbox: %w", err)
	}
	return s.GetMailboxByID(ctx, id)
}


func (s *Store) GetMailboxByID(ctx context.Context, id int64) (*Mailbox, error) {
	var m Mailbox
	err := scanMailbox(s.pool.QueryRow(ctx,
		`SELECT `+mailboxCols+` FROM mailboxes m JOIN domains d ON d.id = m.domain_id WHERE m.id = $1`, id), &m)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get mailbox: %w", err)
	}
	return &m, nil
}


func (s *Store) GetMailboxOwned(ctx context.Context, id, clientID int64) (*Mailbox, error) {
	var m Mailbox
	err := scanMailbox(s.pool.QueryRow(ctx,
		`SELECT `+mailboxCols+` FROM mailboxes m JOIN domains d ON d.id = m.domain_id
		  WHERE m.id = $1 AND d.client_id = $2`, id, clientID), &m)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get mailbox owned: %w", err)
	}
	return &m, nil
}



func (s *Store) DeleteMailboxesByDomain(ctx context.Context, domainID int64) error {
	if _, err := s.pool.Exec(ctx, `DELETE FROM mailboxes WHERE domain_id = $1`, domainID); err != nil {
		return fmt.Errorf("store: delete mailboxes by domain: %w", err)
	}
	return nil
}


func (s *Store) DeleteMailbox(ctx context.Context, id int64) error {
	tag, err := s.pool.Exec(ctx, `DELETE FROM mailboxes WHERE id = $1`, id)
	if err != nil {
		return fmt.Errorf("store: delete mailbox: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}
