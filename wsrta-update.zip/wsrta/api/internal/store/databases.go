package store

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"

	"github.com/jdobrito/wsrta/internal/core"
)


func (s *Store) ListDatabases(ctx context.Context, clientID int64) ([]core.Database, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT id, client_id, db_name, db_user, engine, created_at
		   FROM databases WHERE client_id = $1 ORDER BY id`, clientID)
	if err != nil {
		return nil, fmt.Errorf("store: list databases: %w", err)
	}
	defer rows.Close()

	var out []core.Database
	for rows.Next() {
		var d core.Database
		if err := rows.Scan(&d.ID, &d.ClientID, &d.DBName, &d.DBUser, &d.Engine, &d.CreatedAt); err != nil {
			return nil, fmt.Errorf("store: scan database: %w", err)
		}
		out = append(out, d)
	}
	return out, rows.Err()
}


func (s *Store) GetDatabaseOwned(ctx context.Context, id, clientID int64) (*core.Database, error) {
	var d core.Database
	err := s.pool.QueryRow(ctx,
		`SELECT id, client_id, db_name, db_user, engine, created_at
		   FROM databases WHERE id = $1 AND client_id = $2`, id, clientID,
	).Scan(&d.ID, &d.ClientID, &d.DBName, &d.DBUser, &d.Engine, &d.CreatedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get database owned: %w", err)
	}
	return &d, nil
}


func (s *Store) CreateDatabase(ctx context.Context, clientID int64, dbName, dbUser, engine string) (*core.Database, error) {
	if engine == "" {
		engine = "mariadb"
	}
	var d core.Database
	err := s.pool.QueryRow(ctx,
		`INSERT INTO databases (client_id, db_name, db_user, engine)
		 VALUES ($1, $2, $3, $4)
		 RETURNING id, client_id, db_name, db_user, engine, created_at`,
		clientID, dbName, dbUser, engine,
	).Scan(&d.ID, &d.ClientID, &d.DBName, &d.DBUser, &d.Engine, &d.CreatedAt)
	if err != nil {
		return nil, fmt.Errorf("store: create database: %w", err)
	}
	return &d, nil
}
