package store

import (
	"context"
	"fmt"
)


type ClientCounts struct {
	ID        int64  `json:"id"`
	Name      string `json:"name"`
	Domains   int    `json:"domains"`
	Databases int    `json:"databases"`
}


type DashboardData struct {
	TotalDomains   int            `json:"total_domains"`
	TotalDatabases int            `json:"total_databases"`
	TotalWordPress int            `json:"total_wordpress"`
	Clients        []ClientCounts `json:"clients"`
}


func (s *Store) Dashboard(ctx context.Context) (*DashboardData, error) {
	d := &DashboardData{Clients: []ClientCounts{}}

	
	
	err := s.pool.QueryRow(ctx, `
		SELECT (SELECT count(*) FROM domains dm JOIN clients c ON c.id = dm.client_id
		          WHERE c.owner_user_id IS NULL AND c.status <> 'deleted'),
		       (SELECT count(*) FROM databases db JOIN clients c ON c.id = db.client_id
		          WHERE c.owner_user_id IS NULL AND c.status <> 'deleted'),
		       (SELECT count(*) FROM wordpress_installs wp JOIN domains dm ON dm.id = wp.domain_id
		          JOIN clients c ON c.id = dm.client_id
		          WHERE c.owner_user_id IS NULL AND c.status <> 'deleted')`).
		Scan(&d.TotalDomains, &d.TotalDatabases, &d.TotalWordPress)
	if err != nil {
		return nil, fmt.Errorf("store: dashboard totais: %w", err)
	}

	rows, err := s.pool.Query(ctx, `
		SELECT c.id, c.name,
		       (SELECT count(*) FROM domains d WHERE d.client_id = c.id),
		       (SELECT count(*) FROM databases db WHERE db.client_id = c.id)
		  FROM clients c WHERE c.status <> 'deleted' AND c.owner_user_id IS NULL ORDER BY c.id`)
	if err != nil {
		return nil, fmt.Errorf("store: dashboard clientes: %w", err)
	}
	defer rows.Close()
	for rows.Next() {
		var c ClientCounts
		if err := rows.Scan(&c.ID, &c.Name, &c.Domains, &c.Databases); err != nil {
			return nil, fmt.Errorf("store: dashboard scan: %w", err)
		}
		d.Clients = append(d.Clients, c)
	}
	return d, rows.Err()
}
