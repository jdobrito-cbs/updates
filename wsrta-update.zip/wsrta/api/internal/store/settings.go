package store

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"

	"github.com/jdobrito/wsrta/internal/core"
)


func (s *Store) GetSettings(ctx context.Context) (*core.Settings, error) {
	var st core.Settings
	err := s.pool.QueryRow(ctx,
		`SELECT session_timeout_minutes, panel_domain, company_name, max_domains_per_client, max_databases_per_client,
		        max_login_attempts, lockout_minutes,
		        sec_modsecurity, sec_csf, sec_fail2ban, sec_ssl_autorenew
		   FROM settings WHERE id = 1`,
	).Scan(&st.SessionTimeoutMinutes, &st.PanelDomain, &st.CompanyName, &st.MaxDomainsPerClient, &st.MaxDatabasesPerClient,
		&st.MaxLoginAttempts, &st.LockoutMinutes,
		&st.SecModSecurity, &st.SecCSF, &st.SecFail2ban, &st.SecSSLAutoRenew)
	if err != nil {
		return nil, fmt.Errorf("store: get settings: %w", err)
	}
	return &st, nil
}


func (s *Store) UpdateSecurity(ctx context.Context, modsec, csf, fail2ban, sslRenew bool) error {
	_, err := s.pool.Exec(ctx,
		`UPDATE settings SET sec_modsecurity = $1, sec_csf = $2, sec_fail2ban = $3, sec_ssl_autorenew = $4
		   WHERE id = 1`, modsec, csf, fail2ban, sslRenew)
	if err != nil {
		return fmt.Errorf("store: update security: %w", err)
	}
	return nil
}


func (s *Store) UpdateSettings(ctx context.Context, st core.Settings) error {
	_, err := s.pool.Exec(ctx,
		`UPDATE settings SET session_timeout_minutes = $1, panel_domain = $2, company_name = $3,
		        max_domains_per_client = $4, max_databases_per_client = $5,
		        max_login_attempts = $6, lockout_minutes = $7 WHERE id = 1`,
		st.SessionTimeoutMinutes, st.PanelDomain, st.CompanyName, st.MaxDomainsPerClient, st.MaxDatabasesPerClient,
		st.MaxLoginAttempts, st.LockoutMinutes)
	if err != nil {
		return fmt.Errorf("store: update settings: %w", err)
	}
	return nil
}



func (s *Store) GetClientCloudflareStatus(ctx context.Context, clientID int64) (string, error) {
	var status string
	err := s.pool.QueryRow(ctx, `SELECT cloudflare_status FROM clients WHERE id = $1`, clientID).Scan(&status)
	if errors.Is(err, pgx.ErrNoRows) {
		return "", ErrNotFound
	}
	if err != nil {
		return "", fmt.Errorf("store: get cloudflare status: %w", err)
	}
	return status, nil
}
