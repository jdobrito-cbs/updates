

package store

import (
	"errors"

	"github.com/jackc/pgx/v5/pgxpool"
)


var ErrNotFound = errors.New("store: não encontrado")



var ErrAdminExists = errors.New("store: admin já existe")


type Store struct {
	pool *pgxpool.Pool
}


func New(pool *pgxpool.Pool) *Store {
	return &Store{pool: pool}
}
