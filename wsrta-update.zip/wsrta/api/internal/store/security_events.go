package store

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/jdobrito/wsrta/internal/core"
)



func (s *Store) LogSecurityEvent(ctx context.Context, ev core.SecurityEvent) (int64, error) {
	san := func(x string) string {
		x = strings.ToValidUTF8(x, "")
		if len(x) > 500 {
			x = x[:500]
		}
		return x
	}
	if ev.Severity == "" {
		ev.Severity = core.VulnLow
	}
	var id int64
	err := s.pool.QueryRow(ctx,
		`INSERT INTO security_events (event_type, severity, ip, email, user_agent, detail, blocked)
		 VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`,
		san(ev.EventType), ev.Severity, san(ev.IP), san(ev.Email), san(ev.UserAgent), san(ev.Detail), ev.Blocked).Scan(&id)
	if err != nil {
		return 0, fmt.Errorf("store: log security event: %w", err)
	}
	return id, nil
}


func (s *Store) ListSecurityEvents(ctx context.Context, limit int) ([]core.SecurityEvent, error) {
	if limit <= 0 || limit > 500 {
		limit = 100
	}
	rows, err := s.pool.Query(ctx,
		`SELECT id, event_type, severity, ip, email, user_agent, detail, blocked, created_at
		   FROM security_events ORDER BY id DESC LIMIT $1`, limit)
	if err != nil {
		return nil, fmt.Errorf("store: list security events: %w", err)
	}
	defer rows.Close()
	var out []core.SecurityEvent
	for rows.Next() {
		var e core.SecurityEvent
		if err := rows.Scan(&e.ID, &e.EventType, &e.Severity, &e.IP, &e.Email, &e.UserAgent, &e.Detail, &e.Blocked, &e.CreatedAt); err != nil {
			return nil, err
		}
		out = append(out, e)
	}
	return out, rows.Err()
}


func (s *Store) CountRecentAuthFailuresByIP(ctx context.Context, ip string, since time.Time) (int, error) {
	var n int
	err := s.pool.QueryRow(ctx,
		`SELECT count(*) FROM security_events
		  WHERE ip = $1 AND created_at >= $2 AND event_type IN ('login_failed', '2fa_failed')`,
		ip, since).Scan(&n)
	if err != nil {
		return 0, fmt.Errorf("store: count auth failures: %w", err)
	}
	return n, nil
}


func (s *Store) IPRecentlyAutoBlocked(ctx context.Context, ip string, since time.Time) (bool, error) {
	var n int
	err := s.pool.QueryRow(ctx,
		`SELECT count(*) FROM security_events
		  WHERE ip = $1 AND created_at >= $2 AND event_type = 'auto_blocked'`, ip, since).Scan(&n)
	if err != nil {
		return false, fmt.Errorf("store: check auto-block: %w", err)
	}
	return n > 0, nil
}
