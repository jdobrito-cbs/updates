package store

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"

	"github.com/jdobrito/wsrta/internal/core"
)

const userColumns = `id, email, password_hash, role, status, totp_secret, totp_enabled, created_at, session_timeout_minutes`

func scanUser(row pgx.Row) (*core.User, error) {
	var u core.User
	err := row.Scan(&u.ID, &u.Email, &u.PasswordHash, &u.Role, &u.Status,
		&u.TOTPSecret, &u.TOTPEnabled, &u.CreatedAt, &u.SessionTimeoutMinutes)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: scan user: %w", err)
	}
	return &u, nil
}


func (s *Store) GetUserByEmail(ctx context.Context, email string) (*core.User, error) {
	return scanUser(s.pool.QueryRow(ctx, `SELECT `+userColumns+` FROM users WHERE email = $1`, email))
}


func (s *Store) GetUserByID(ctx context.Context, id int64) (*core.User, error) {
	return scanUser(s.pool.QueryRow(ctx, `SELECT `+userColumns+` FROM users WHERE id = $1`, id))
}



func (s *Store) SessionValid(ctx context.Context, userID int64, issuedAt time.Time) (bool, error) {
	var status string
	var inv *time.Time
	err := s.pool.QueryRow(ctx,
		`SELECT status, tokens_invalidated_at FROM users WHERE id = $1`, userID).Scan(&status, &inv)
	if errors.Is(err, pgx.ErrNoRows) {
		return false, nil 
	}
	if err != nil {
		return false, fmt.Errorf("store: session valid: %w", err)
	}
	
	
	if status != "active" {
		return false, nil
	}
	if inv == nil {
		return true, nil
	}
	return issuedAt.After(*inv), nil
}



func (s *Store) InvalidateUserTokens(ctx context.Context, userID int64) error {
	_, err := s.pool.Exec(ctx, `UPDATE users SET tokens_invalidated_at = now() WHERE id = $1`, userID)
	if err != nil {
		return fmt.Errorf("store: invalidate user tokens: %w", err)
	}
	return nil
}



func (s *Store) InvalidateTokensByClientID(ctx context.Context, clientID int64) error {
	_, err := s.pool.Exec(ctx,
		`UPDATE users SET tokens_invalidated_at = now() WHERE id = (SELECT user_id FROM clients WHERE id = $1)`, clientID)
	if err != nil {
		return fmt.Errorf("store: invalidate client tokens: %w", err)
	}
	return nil
}


func (s *Store) ClientIDByUserID(ctx context.Context, userID int64) (*int64, error) {
	var id int64
	err := s.pool.QueryRow(ctx, `SELECT id FROM clients WHERE user_id = $1`, userID).Scan(&id)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("store: client id by user: %w", err)
	}
	return &id, nil
}


func (s *Store) SetTOTPSecret(ctx context.Context, userID int64, secret string) error {
	_, err := s.pool.Exec(ctx, `UPDATE users SET totp_secret = $2, totp_enabled = false WHERE id = $1`, userID, secret)
	if err != nil {
		return fmt.Errorf("store: set totp secret: %w", err)
	}
	return nil
}


func (s *Store) EnableTOTP(ctx context.Context, userID int64) error {
	_, err := s.pool.Exec(ctx, `UPDATE users SET totp_enabled = true WHERE id = $1`, userID)
	if err != nil {
		return fmt.Errorf("store: enable totp: %w", err)
	}
	return nil
}


func (s *Store) ClearTOTP(ctx context.Context, userID int64) error {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("store: begin: %w", err)
	}
	defer tx.Rollback(ctx)
	if _, err := tx.Exec(ctx, `DELETE FROM recovery_codes WHERE user_id = $1`, userID); err != nil {
		return fmt.Errorf("store: limpar recovery: %w", err)
	}
	if _, err := tx.Exec(ctx, `UPDATE users SET totp_secret = NULL, totp_enabled = false WHERE id = $1`, userID); err != nil {
		return fmt.Errorf("store: limpar totp: %w", err)
	}
	return tx.Commit(ctx)
}


func (s *Store) ReplaceRecoveryCodes(ctx context.Context, userID int64, hashes []string) error {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("store: begin: %w", err)
	}
	defer tx.Rollback(ctx)
	if _, err := tx.Exec(ctx, `DELETE FROM recovery_codes WHERE user_id = $1`, userID); err != nil {
		return fmt.Errorf("store: limpar recovery: %w", err)
	}
	for _, h := range hashes {
		if _, err := tx.Exec(ctx, `INSERT INTO recovery_codes (user_id, code_hash) VALUES ($1, $2)`, userID, h); err != nil {
			return fmt.Errorf("store: inserir recovery: %w", err)
		}
	}
	return tx.Commit(ctx)
}


func (s *Store) ConsumeRecoveryCode(ctx context.Context, userID int64, codeHash string) (bool, error) {
	tag, err := s.pool.Exec(ctx,
		`UPDATE recovery_codes SET used = true
		  WHERE id = (SELECT id FROM recovery_codes
		               WHERE user_id = $1 AND code_hash = $2 AND used = false
		               LIMIT 1)`,
		userID, codeHash)
	if err != nil {
		return false, fmt.Errorf("store: consumir recovery: %w", err)
	}
	return tag.RowsAffected() > 0, nil
}


func (s *Store) UpdatePassword(ctx context.Context, userID int64, hash string) error {
	tag, err := s.pool.Exec(ctx, `UPDATE users SET password_hash = $2 WHERE id = $1`, userID, hash)
	if err != nil {
		return fmt.Errorf("store: update password: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}




type AdminInfo struct {
	ID                    int64      `json:"id"`
	Email                 string     `json:"email"`
	Name                  string     `json:"name"`
	Status                string     `json:"status"` 
	CreatedAt             time.Time  `json:"created_at"`
	Online                bool       `json:"online"` 
	LastSeen              *time.Time `json:"last_seen,omitempty"`
	SessionTimeoutMinutes int        `json:"session_timeout_minutes"` 
}


func (s *Store) ListAdmins(ctx context.Context, q string) ([]AdminInfo, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT id, email, name, status, created_at,
		        COALESCE(last_seen > now() - interval '5 minutes', false) AS online, last_seen,
		        session_timeout_minutes
		   FROM users
		  WHERE role = 'admin'
		    AND ($1 = '' OR email ILIKE '%'||$1||'%' OR name ILIKE '%'||$1||'%')
		  ORDER BY id`, q)
	if err != nil {
		return nil, fmt.Errorf("store: listar admins: %w", err)
	}
	defer rows.Close()
	var out []AdminInfo
	for rows.Next() {
		var a AdminInfo
		if err := rows.Scan(&a.ID, &a.Email, &a.Name, &a.Status, &a.CreatedAt, &a.Online, &a.LastSeen, &a.SessionTimeoutMinutes); err != nil {
			return nil, fmt.Errorf("store: scan admin: %w", err)
		}
		out = append(out, a)
	}
	return out, rows.Err()
}



func (s *Store) SetUserSessionTimeout(ctx context.Context, userID int64, minutes int) error {
	if _, err := s.pool.Exec(ctx, `UPDATE users SET session_timeout_minutes = $2 WHERE id = $1`, userID, minutes); err != nil {
		return fmt.Errorf("store: set session timeout: %w", err)
	}
	return nil
}


func (s *Store) TouchLastSeen(ctx context.Context, userID int64) error {
	_, err := s.pool.Exec(ctx, `UPDATE users SET last_seen = now() WHERE id = $1`, userID)
	if err != nil {
		return fmt.Errorf("store: touch last_seen: %w", err)
	}
	return nil
}


func (s *Store) CountAdmins(ctx context.Context) (int, error) {
	var n int
	if err := s.pool.QueryRow(ctx, `SELECT count(*) FROM users WHERE role='admin'`).Scan(&n); err != nil {
		return 0, fmt.Errorf("store: contar admins: %w", err)
	}
	return n, nil
}




func (s *Store) CreateFirstAdmin(ctx context.Context, email, name, hash string) (int64, error) {
	var id int64
	err := s.pool.QueryRow(ctx,
		`INSERT INTO users (email, name, password_hash, role, status, session_timeout_minutes)
		 SELECT $1, $2, $3, 'admin', 'active', 0
		 WHERE NOT EXISTS (SELECT 1 FROM users WHERE role = 'admin')
		 RETURNING id`,
		email, name, hash).Scan(&id)
	if errors.Is(err, pgx.ErrNoRows) {
		return 0, ErrAdminExists
	}
	if err != nil {
		return 0, err
	}
	return id, nil
}



func (s *Store) CreateAdmin(ctx context.Context, email, name, hash string, session int) (int64, error) {
	var id int64
	err := s.pool.QueryRow(ctx,
		`INSERT INTO users (email, name, password_hash, role, status, session_timeout_minutes)
		 VALUES ($1, $2, $3, 'admin', 'active', $4) RETURNING id`,
		email, name, hash, session).Scan(&id)
	if err != nil {
		return 0, err
	}
	return id, nil
}



func (s *Store) UpdateAdmin(ctx context.Context, id int64, email, name, hash string, session int) error {
	q := `UPDATE users SET email = $2, name = $3, session_timeout_minutes = $4 WHERE id = $1 AND role = 'admin'`
	args := []any{id, email, name, session}
	if hash != "" {
		q = `UPDATE users SET email = $2, name = $3, session_timeout_minutes = $4, password_hash = $5 WHERE id = $1 AND role = 'admin'`
		args = append(args, hash)
	}
	tag, err := s.pool.Exec(ctx, q, args...)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}


func (s *Store) SetAdminStatus(ctx context.Context, id int64, status string) error {
	tag, err := s.pool.Exec(ctx, `UPDATE users SET status = $2 WHERE id = $1 AND role = 'admin'`, id, status)
	if err != nil {
		return fmt.Errorf("store: status do admin: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}


func (s *Store) DeleteAdmin(ctx context.Context, id int64) error {
	tag, err := s.pool.Exec(ctx, `DELETE FROM users WHERE id = $1 AND role = 'admin'`, id)
	if err != nil {
		return fmt.Errorf("store: excluir admin: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}


func (s *Store) ClientUserID(ctx context.Context, clientID int64) (int64, error) {
	var uid int64
	err := s.pool.QueryRow(ctx, `SELECT user_id FROM clients WHERE id = $1`, clientID).Scan(&uid)
	if errors.Is(err, pgx.ErrNoRows) {
		return 0, ErrNotFound
	}
	if err != nil {
		return 0, fmt.Errorf("store: client user id: %w", err)
	}
	return uid, nil
}
