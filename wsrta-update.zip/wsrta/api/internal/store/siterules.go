package store

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
)


func (s *Store) GetSiteRules(ctx context.Context, domainID int64) (json.RawMessage, error) {
	var cfg []byte
	err := s.pool.QueryRow(ctx, `SELECT config FROM site_rules WHERE domain_id = $1`, domainID).Scan(&cfg)
	if errors.Is(err, pgx.ErrNoRows) {
		return json.RawMessage("{}"), nil
	}
	if err != nil {
		return nil, fmt.Errorf("store: get site rules: %w", err)
	}
	return json.RawMessage(cfg), nil
}


func (s *Store) UpsertSiteRules(ctx context.Context, domainID int64, config json.RawMessage) error {
	_, err := s.pool.Exec(ctx,
		`INSERT INTO site_rules (domain_id, config) VALUES ($1, $2)
		 ON CONFLICT (domain_id) DO UPDATE SET config = EXCLUDED.config`,
		domainID, []byte(config))
	if err != nil {
		return fmt.Errorf("store: upsert site rules: %w", err)
	}
	return nil
}
