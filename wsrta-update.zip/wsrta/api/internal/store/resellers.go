package store

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"

	"github.com/jdobrito/wsrta/internal/core"
)


const resellerCols = `r.id, r.user_id, u.email, r.name, r.status, r.expires_at, r.created_at,
	COALESCE(u.last_seen > now() - interval '5 minutes', false) AS online,
	(SELECT count(*) FROM clients c WHERE c.reseller_id = r.id AND c.status <> 'deleted' AND c.owner_user_id IS NULL) AS clients,
	r.slug, r.landing_template, r.landing_headline, r.landing_subtitle, r.external_site_url, r.max_clients`

const resellerFrom = ` FROM resellers r JOIN users u ON u.id = r.user_id`

func scanReseller(s interface{ Scan(...any) error }, r *core.Reseller) error {
	return s.Scan(&r.ID, &r.UserID, &r.Email, &r.Name, &r.Status, &r.ExpiresAt, &r.CreatedAt, &r.Online, &r.Clients,
		&r.Slug, &r.LandingTemplate, &r.LandingHeadline, &r.LandingSubtitle, &r.ExternalSiteURL, &r.MaxClients)
}



func (s *Store) GetResellerBySlug(ctx context.Context, slug string) (*core.Reseller, error) {
	var r core.Reseller
	err := scanReseller(s.pool.QueryRow(ctx,
		`SELECT `+resellerCols+resellerFrom+` WHERE r.slug = $1 AND r.status = 'active'`, slug), &r)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get reseller by slug: %w", err)
	}
	return &r, nil
}


func (s *Store) UpdateResellerSite(ctx context.Context, id int64, slug, template, headline, subtitle, externalURL string) error {
	tag, err := s.pool.Exec(ctx,
		`UPDATE resellers SET slug=$2, landing_template=$3, landing_headline=$4, landing_subtitle=$5, external_site_url=$6 WHERE id=$1`,
		id, slug, template, headline, subtitle, externalURL)
	if err != nil {
		return fmt.Errorf("store: update reseller site: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}


func (s *Store) ListResellers(ctx context.Context, search string) ([]core.Reseller, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT `+resellerCols+resellerFrom+
			` WHERE ($1 = '' OR r.name ILIKE '%' || $1 || '%' OR u.email ILIKE '%' || $1 || '%')
			  ORDER BY r.id`, search)
	if err != nil {
		return nil, fmt.Errorf("store: list resellers: %w", err)
	}
	defer rows.Close()
	var out []core.Reseller
	for rows.Next() {
		var r core.Reseller
		if err := scanReseller(rows, &r); err != nil {
			return nil, fmt.Errorf("store: scan reseller: %w", err)
		}
		out = append(out, r)
	}
	return out, rows.Err()
}


func (s *Store) GetReseller(ctx context.Context, id int64) (*core.Reseller, error) {
	var r core.Reseller
	err := scanReseller(s.pool.QueryRow(ctx, `SELECT `+resellerCols+resellerFrom+` WHERE r.id = $1`, id), &r)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get reseller: %w", err)
	}
	return &r, nil
}


func (s *Store) GetResellerByUserID(ctx context.Context, userID int64) (*core.Reseller, error) {
	var r core.Reseller
	err := scanReseller(s.pool.QueryRow(ctx, `SELECT `+resellerCols+resellerFrom+` WHERE r.user_id = $1`, userID), &r)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get reseller by user: %w", err)
	}
	return &r, nil
}




func (s *Store) CreateResellerWithUser(ctx context.Context, email, passwordHash, name string, expiresAt *time.Time, maxClients int) (resellerID, userID int64, err error) {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return 0, 0, fmt.Errorf("store: begin: %w", err)
	}
	defer tx.Rollback(ctx)

	if err := tx.QueryRow(ctx,
		`INSERT INTO users (email, password_hash, role) VALUES ($1, $2, 'reseller') RETURNING id`,
		email, passwordHash,
	).Scan(&userID); err != nil {
		return 0, 0, fmt.Errorf("store: criar usuário revendedor: %w", err)
	}
	if err := tx.QueryRow(ctx,
		`INSERT INTO resellers (user_id, name, expires_at, max_clients) VALUES ($1, $2, $3, $4) RETURNING id`,
		userID, name, expiresAt, maxClients,
	).Scan(&resellerID); err != nil {
		return 0, 0, fmt.Errorf("store: criar revendedor: %w", err)
	}
	if err := tx.Commit(ctx); err != nil {
		return 0, 0, fmt.Errorf("store: commit: %w", err)
	}
	return resellerID, userID, nil
}


func (s *Store) UpdateReseller(ctx context.Context, id int64, name string, expiresAt *time.Time, maxClients int) error {
	tag, err := s.pool.Exec(ctx,
		`UPDATE resellers SET name = $2, expires_at = $3, max_clients = $4 WHERE id = $1`, id, name, expiresAt, maxClients)
	if err != nil {
		return fmt.Errorf("store: update reseller: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}



func (s *Store) CountResellerClients(ctx context.Context, resellerID int64) (int, error) {
	var n int
	err := s.pool.QueryRow(ctx,
		`SELECT count(*) FROM clients WHERE reseller_id = $1 AND status <> 'deleted' AND owner_user_id IS NULL`,
		resellerID).Scan(&n)
	if err != nil {
		return 0, fmt.Errorf("store: count reseller clients: %w", err)
	}
	return n, nil
}



func (s *Store) SetResellerStatus(ctx context.Context, id int64, status string) error {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("store: begin: %w", err)
	}
	defer tx.Rollback(ctx)
	tag, err := tx.Exec(ctx, `UPDATE resellers SET status = $2 WHERE id = $1`, id, status)
	if err != nil {
		return fmt.Errorf("store: set reseller status: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	userStatus := "active"
	if status == "suspended" {
		userStatus = "suspended"
	}
	if _, err := tx.Exec(ctx,
		`UPDATE users SET status = $2 WHERE id = (SELECT user_id FROM resellers WHERE id = $1)`, id, userStatus); err != nil {
		return fmt.Errorf("store: propagar status do revendedor: %w", err)
	}
	return tx.Commit(ctx)
}



func (s *Store) DeleteReseller(ctx context.Context, id int64) error {
	_, err := s.pool.Exec(ctx,
		`DELETE FROM users WHERE id = (SELECT user_id FROM resellers WHERE id = $1)`, id)
	if err != nil {
		return fmt.Errorf("store: delete reseller: %w", err)
	}
	return nil
}
