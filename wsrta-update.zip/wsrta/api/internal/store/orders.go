package store

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"

	"github.com/jdobrito/wsrta/internal/core"
)




func (s *Store) SetMPCreds(ctx context.Context, resellerID int64, token, secret string) error {
	encT, encS := encryptSecret(token), encryptSecret(secret)
	if resellerID > 0 {
		tag, err := s.pool.Exec(ctx,
			`UPDATE resellers SET mp_access_token = $2, mp_webhook_secret = $3 WHERE id = $1`, resellerID, encT, encS)
		if err != nil {
			return fmt.Errorf("store: set reseller mp creds: %w", err)
		}
		if tag.RowsAffected() == 0 {
			return ErrNotFound
		}
		return nil
	}
	if _, err := s.pool.Exec(ctx, `UPDATE settings SET mp_access_token = $1, mp_webhook_secret = $2`, encT, encS); err != nil {
		return fmt.Errorf("store: set admin mp creds: %w", err)
	}
	return nil
}


func (s *Store) MPCredsForScope(ctx context.Context, resellerID int64) (token, secret string, err error) {
	var t, sec string
	if resellerID > 0 {
		err = s.pool.QueryRow(ctx, `SELECT mp_access_token, mp_webhook_secret FROM resellers WHERE id = $1`, resellerID).Scan(&t, &sec)
	} else {
		err = s.pool.QueryRow(ctx, `SELECT mp_access_token, mp_webhook_secret FROM settings LIMIT 1`).Scan(&t, &sec)
	}
	if errors.Is(err, pgx.ErrNoRows) {
		return "", "", nil
	}
	if err != nil {
		return "", "", fmt.Errorf("store: mp creds: %w", err)
	}
	return decryptSecret(t), decryptSecret(sec), nil
}


func (s *Store) MPTokenForScope(ctx context.Context, resellerID int64) (string, error) {
	t, _, err := s.MPCredsForScope(ctx, resellerID)
	return t, err
}


func (s *Store) MPConfigured(ctx context.Context, resellerID int64) (bool, error) {
	t, err := s.MPTokenForScope(ctx, resellerID)
	return t != "", err
}




func (s *Store) CreateOrder(ctx context.Context, resellerID, packageID int64, email string, amountCents int64) (int64, error) {
	var rid, pid any
	if resellerID > 0 {
		rid = resellerID
	}
	if packageID > 0 {
		pid = packageID
	}
	var id int64
	err := s.pool.QueryRow(ctx,
		`INSERT INTO orders (reseller_id, package_id, buyer_email, amount_cents) VALUES ($1,$2,$3,$4) RETURNING id`,
		rid, pid, email, amountCents).Scan(&id)
	if err != nil {
		return 0, fmt.Errorf("store: create order: %w", err)
	}
	return id, nil
}


func (s *Store) SetOrderPreference(ctx context.Context, orderID int64, prefID string) error {
	_, err := s.pool.Exec(ctx, `UPDATE orders SET mp_preference_id = $2 WHERE id = $1`, orderID, prefID)
	if err != nil {
		return fmt.Errorf("store: set order preference: %w", err)
	}
	return nil
}


func (s *Store) OrderResellerID(ctx context.Context, orderID int64) (int64, error) {
	var rid *int64
	err := s.pool.QueryRow(ctx, `SELECT reseller_id FROM orders WHERE id = $1`, orderID).Scan(&rid)
	if errors.Is(err, pgx.ErrNoRows) {
		return 0, ErrNotFound
	}
	if err != nil {
		return 0, fmt.Errorf("store: order reseller: %w", err)
	}
	if rid == nil {
		return 0, nil
	}
	return *rid, nil
}



func (s *Store) GetOrderForVerify(ctx context.Context, orderID int64) (amountCents int64, status string, err error) {
	err = s.pool.QueryRow(ctx, `SELECT amount_cents, status FROM orders WHERE id = $1`, orderID).Scan(&amountCents, &status)
	if errors.Is(err, pgx.ErrNoRows) {
		return 0, "", ErrNotFound
	}
	if err != nil {
		return 0, "", fmt.Errorf("store: order verify: %w", err)
	}
	return amountCents, status, nil
}


func (s *Store) MarkOrder(ctx context.Context, orderID int64, status, paymentID string) error {
	_, err := s.pool.Exec(ctx, `UPDATE orders SET status = $2, mp_payment_id = $3 WHERE id = $1`, orderID, status, paymentID)
	if err != nil {
		return fmt.Errorf("store: mark order: %w", err)
	}
	return nil
}


func (s *Store) ListOrders(ctx context.Context, resellerID int64) ([]core.Order, error) {
	where := "o.reseller_id IS NULL"
	args := []any{}
	if resellerID > 0 {
		where = "o.reseller_id = $1"
		args = append(args, resellerID)
	}
	rows, err := s.pool.Query(ctx,
		`SELECT o.id, o.reseller_id, o.package_id, o.buyer_email, o.amount_cents, o.status, o.mp_payment_id,
		        o.created_at, COALESCE(p.name, '')
		   FROM orders o LEFT JOIN packages p ON p.id = o.package_id
		  WHERE `+where+` ORDER BY o.id DESC LIMIT 200`, args...)
	if err != nil {
		return nil, fmt.Errorf("store: list orders: %w", err)
	}
	defer rows.Close()
	var out []core.Order
	for rows.Next() {
		var o core.Order
		if err := rows.Scan(&o.ID, &o.ResellerID, &o.PackageID, &o.BuyerEmail, &o.AmountCents, &o.Status,
			&o.MPPaymentID, &o.CreatedAt, &o.PackageName); err != nil {
			return nil, fmt.Errorf("store: scan order: %w", err)
		}
		out = append(out, o)
	}
	return out, rows.Err()
}
