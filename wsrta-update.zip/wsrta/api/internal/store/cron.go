package store

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"

	"github.com/jdobrito/wsrta/internal/core"
)


func (s *Store) ListCronJobs(ctx context.Context, clientID int64) ([]core.CronJob, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT id, client_id, schedule, command, enabled, created_at
		   FROM cron_jobs WHERE client_id = $1 ORDER BY id`, clientID)
	if err != nil {
		return nil, fmt.Errorf("store: list cron: %w", err)
	}
	defer rows.Close()

	var out []core.CronJob
	for rows.Next() {
		var j core.CronJob
		if err := rows.Scan(&j.ID, &j.ClientID, &j.Schedule, &j.Command, &j.Enabled, &j.CreatedAt); err != nil {
			return nil, fmt.Errorf("store: scan cron: %w", err)
		}
		out = append(out, j)
	}
	return out, rows.Err()
}


func (s *Store) GetCronOwned(ctx context.Context, id, clientID int64) (*core.CronJob, error) {
	var j core.CronJob
	err := s.pool.QueryRow(ctx,
		`SELECT id, client_id, schedule, command, enabled, created_at
		   FROM cron_jobs WHERE id = $1 AND client_id = $2`, id, clientID,
	).Scan(&j.ID, &j.ClientID, &j.Schedule, &j.Command, &j.Enabled, &j.CreatedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get cron owned: %w", err)
	}
	return &j, nil
}


func (s *Store) CreateCronJob(ctx context.Context, clientID int64, schedule, command string, enabled bool) (*core.CronJob, error) {
	var j core.CronJob
	err := s.pool.QueryRow(ctx,
		`INSERT INTO cron_jobs (client_id, schedule, command, enabled)
		 VALUES ($1, $2, $3, $4)
		 RETURNING id, client_id, schedule, command, enabled, created_at`,
		clientID, schedule, command, enabled,
	).Scan(&j.ID, &j.ClientID, &j.Schedule, &j.Command, &j.Enabled, &j.CreatedAt)
	if err != nil {
		return nil, fmt.Errorf("store: create cron: %w", err)
	}
	return &j, nil
}
