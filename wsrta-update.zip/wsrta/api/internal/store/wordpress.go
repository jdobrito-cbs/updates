package store

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
)


type WordPressInstall struct {
	ID        int64     `json:"id"`
	DomainID  int64     `json:"domain_id"`
	FQDN      string    `json:"fqdn"`
	Path      string    `json:"path"`
	AdminUser string    `json:"admin_user"`
	DBName    string    `json:"db_name"`
	CreatedAt time.Time `json:"created_at"`
}

const wpColumns = `w.id, w.domain_id, d.fqdn, w.path, w.admin_user, w.db_name, w.created_at`


func (s *Store) ListWordPressInstalls(ctx context.Context, clientID int64) ([]WordPressInstall, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT `+wpColumns+`
		   FROM wordpress_installs w
		   JOIN domains d ON d.id = w.domain_id
		  WHERE d.client_id = $1 ORDER BY w.id`, clientID)
	if err != nil {
		return nil, fmt.Errorf("store: list wordpress: %w", err)
	}
	defer rows.Close()

	var out []WordPressInstall
	for rows.Next() {
		var i WordPressInstall
		if err := rows.Scan(&i.ID, &i.DomainID, &i.FQDN, &i.Path, &i.AdminUser, &i.DBName, &i.CreatedAt); err != nil {
			return nil, fmt.Errorf("store: scan wordpress: %w", err)
		}
		out = append(out, i)
	}
	return out, rows.Err()
}


func (s *Store) ListAllWordPressInstalls(ctx context.Context) ([]WordPressInstall, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT `+wpColumns+`
		   FROM wordpress_installs w
		   JOIN domains d ON d.id = w.domain_id
		  ORDER BY w.id`)
	if err != nil {
		return nil, fmt.Errorf("store: list all wordpress: %w", err)
	}
	defer rows.Close()
	var out []WordPressInstall
	for rows.Next() {
		var i WordPressInstall
		if err := rows.Scan(&i.ID, &i.DomainID, &i.FQDN, &i.Path, &i.AdminUser, &i.DBName, &i.CreatedAt); err != nil {
			return nil, fmt.Errorf("store: scan wordpress: %w", err)
		}
		out = append(out, i)
	}
	return out, rows.Err()
}


func (s *Store) CreateWordPressInstall(ctx context.Context, domainID int64, path, adminUser, dbName string) (*WordPressInstall, error) {
	var i WordPressInstall
	err := s.pool.QueryRow(ctx,
		`INSERT INTO wordpress_installs (domain_id, path, admin_user, db_name)
		 VALUES ($1, $2, $3, $4)
		 RETURNING id, domain_id, path, admin_user, db_name, created_at`,
		domainID, path, adminUser, dbName,
	).Scan(&i.ID, &i.DomainID, &i.Path, &i.AdminUser, &i.DBName, &i.CreatedAt)
	if err != nil {
		return nil, fmt.Errorf("store: create wordpress: %w", err)
	}
	return &i, nil
}


func (s *Store) GetWordPressInstallOwned(ctx context.Context, id, clientID int64) (*WordPressInstall, error) {
	var i WordPressInstall
	err := s.pool.QueryRow(ctx,
		`SELECT `+wpColumns+`
		   FROM wordpress_installs w
		   JOIN domains d ON d.id = w.domain_id
		  WHERE w.id = $1 AND d.client_id = $2`, id, clientID,
	).Scan(&i.ID, &i.DomainID, &i.FQDN, &i.Path, &i.AdminUser, &i.DBName, &i.CreatedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get wordpress: %w", err)
	}
	return &i, nil
}


func (s *Store) DeleteWordPressInstall(ctx context.Context, id int64) error {
	tag, err := s.pool.Exec(ctx, `DELETE FROM wordpress_installs WHERE id = $1`, id)
	if err != nil {
		return fmt.Errorf("store: delete wordpress: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}
