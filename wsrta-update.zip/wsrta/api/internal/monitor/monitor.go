

package monitor

import (
	"context"
	"log/slog"
	"sync"
	"time"

	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/sysinfo"
)


type Snapshot struct {
	CPU   float64 `json:"cpu"`
	RxBps float64 `json:"rx_bps"`
	TxBps float64 `json:"tx_bps"`
}


type Sampler struct {
	store *store.Store
	log   *slog.Logger

	mu   sync.RWMutex
	snap Snapshot

	prevCPU         sysinfo.CPUSample
	prevRx, prevTx  uint64
	prevTime        time.Time
	accRx, accTx    int64 
	ticksSinceFlush int
}


func New(s *store.Store, log *slog.Logger) *Sampler {
	return &Sampler{store: s, log: log}
}


func (s *Sampler) Run(ctx context.Context) {
	s.prevCPU = sysinfo.CPU()
	s.prevRx, s.prevTx = sysinfo.NetCounters()
	s.prevTime = time.Now()

	t := time.NewTicker(2 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			s.flush(context.Background())
			return
		case <-t.C:
			s.tick(ctx)
		}
	}
}

func (s *Sampler) tick(ctx context.Context) {
	now := time.Now()
	curCPU := sysinfo.CPU()
	cpu := sysinfo.CPUPercent(s.prevCPU, curCPU)
	curRx, curTx := sysinfo.NetCounters()
	elapsed := now.Sub(s.prevTime).Seconds()

	var rxBps, txBps float64
	if elapsed > 0 {
		if curRx >= s.prevRx { 
			d := curRx - s.prevRx
			rxBps = float64(d) / elapsed
			s.accRx += int64(d)
		}
		if curTx >= s.prevTx {
			d := curTx - s.prevTx
			txBps = float64(d) / elapsed
			s.accTx += int64(d)
		}
	}
	s.prevCPU = curCPU
	s.prevRx, s.prevTx = curRx, curTx
	s.prevTime = now

	s.mu.Lock()
	s.snap = Snapshot{CPU: cpu, RxBps: rxBps, TxBps: txBps}
	s.mu.Unlock()

	s.ticksSinceFlush++
	if s.ticksSinceFlush >= 15 { 
		s.flush(ctx)
	}
}

func (s *Sampler) flush(ctx context.Context) {
	s.ticksSinceFlush = 0
	if s.store == nil || (s.accRx == 0 && s.accTx == 0) {
		return
	}
	rx, tx := s.accRx, s.accTx
	s.accRx, s.accTx = 0, 0
	if err := s.store.AddBandwidth(ctx, rx, tx); err != nil {
		s.log.WarnContext(ctx, "monitor: falha ao gravar banda", slog.Any("err", err))
	}
}


func (s *Sampler) Snapshot() Snapshot {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.snap
}
