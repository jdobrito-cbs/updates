package migrate

import (
	"archive/tar"
	"compress/gzip"
	"os"
	"path/filepath"
	"testing"
)




func TestExtractTarGzSecurity(t *testing.T) {
	tmp := t.TempDir()
	dst := filepath.Join(tmp, "out")
	tgz := filepath.Join(tmp, "evil.tar.gz")

	f, err := os.Create(tgz)
	if err != nil {
		t.Fatal(err)
	}
	gz := gzip.NewWriter(f)
	tw := tar.NewWriter(gz)
	body := []byte("x")
	
	_ = tw.WriteHeader(&tar.Header{Name: "../escape.txt", Mode: 0o600, Size: int64(len(body)), Typeflag: tar.TypeReg})
	_, _ = tw.Write(body)
	
	_ = tw.WriteHeader(&tar.Header{Name: "link", Linkname: "/etc/passwd", Typeflag: tar.TypeSymlink})
	_ = tw.Close()
	_ = gz.Close()
	_ = f.Close()

	if err := extractTarGz(tgz, dst); err != nil {
		t.Fatalf("extractTarGz: %v", err)
	}
	
	if _, err := os.Lstat(filepath.Join(tmp, "escape.txt")); err == nil {
		t.Fatal("path traversal: 'escape.txt' vazou para FORA do destino")
	}
	
	if fi, err := os.Lstat(filepath.Join(dst, "link")); err == nil && fi.Mode()&os.ModeSymlink != 0 {
		t.Fatal("symlink do tar foi criado (deveria ter sido ignorado)")
	}
}
