package migrate

import (
	"context"
	"crypto/rand"
	"encoding/base64"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/api/internal/auth"
	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
	"github.com/jdobrito/wsrta/internal/queue"
)





func PrepareClient(ctx context.Context, st *store.Store, q *queue.Queue, sock string, w Website, log *slog.Logger) (clientID, domainID int64, loginPassword string, err error) {
	loginPassword, err = RandomLoginPassword()
	if err != nil {
		return
	}
	hash, err := auth.HashPassword(loginPassword)
	if err != nil {
		return
	}
	email := w.Email
	if email == "" {
		email = "admin@" + w.Domain
	}
	clientID, err = st.CreateClientWithUser(ctx, email, hash, w.Domain, 1, 1024, 10240)
	if err != nil {
		err = fmt.Errorf("criar cliente: %w", err)
		return
	}
	if err = enqueue(ctx, q, sock, core.ActionProvisionClient, core.ProvisionClientPayload{ClientID: clientID}); err != nil {
		return
	}
	log.Info("cliente criado (migração)", "domain", w.Domain, "client_id", clientID, "login_email", email)

	domainID, err = prepareWebsiteResources(ctx, st, q, sock, w, clientID, log)
	return
}




func PrepareExistingClient(ctx context.Context, st *store.Store, q *queue.Queue, sock string, w Website, clientID int64, log *slog.Logger) (domainID int64, err error) {
	log.Info("importando para cliente existente", "domain", w.Domain, "client_id", clientID)
	return prepareWebsiteResources(ctx, st, q, sock, w, clientID, log)
}



func prepareWebsiteResources(ctx context.Context, st *store.Store, q *queue.Queue, sock string, w Website, clientID int64, log *slog.Logger) (domainID int64, err error) {
	php := w.PHP
	if php == "" {
		php = "8.3"
	}
	dom, e := st.CreateDomain(ctx, clientID, w.Domain, w.Docroot, php, "", 0, "")
	if e != nil {
		return 0, fmt.Errorf("criar domínio: %w", e)
	}
	domainID = dom.ID
	if err = enqueue(ctx, q, sock, core.ActionAddDomain, core.AddDomainPayload{DomainID: dom.ID}); err != nil {
		return
	}

	for _, r := range w.DNS {
		rec, e := st.CreateDNSRecord(ctx, dom.ID, r.Type, r.Name, r.Content, r.TTL, r.Prio)
		if e != nil {
			log.Warn("registro DNS ignorado", "name", r.Name, "type", r.Type, "err", e)
			continue
		}
		if err = enqueue(ctx, q, sock, core.ActionSetDNSRecord, core.SetDNSRecordPayload{DNSRecordID: rec.ID}); err != nil {
			return
		}
	}

	for _, d := range w.Databases {
		if _, e := st.CreateDatabase(ctx, clientID, d.Name, d.User, "mariadb"); e != nil {
			log.Warn("registro de banco no painel falhou", "db", d.Name, "err", e)
		}
	}
	return domainID, nil
}



func EnqueueRestores(ctx context.Context, q *queue.Queue, sock string, w Website, clientID, domainID int64) error {
	for _, d := range w.Databases {
		if err := enqueue(ctx, q, sock, core.ActionRestoreDatabase, core.RestoreDatabasePayload{
			ClientID: clientID, DBName: d.Name, DBUser: d.User, DBPasswordHash: d.PasswordHash, DumpPath: d.DumpPath,
		}); err != nil {
			return err
		}
	}
	if w.FilesTar != "" {
		if err := enqueue(ctx, q, sock, core.ActionRestoreFiles, core.RestoreFilesPayload{
			DomainID: domainID, ArchivePath: w.FilesTar,
		}); err != nil {
			return err
		}
	}
	return nil
}


func MigrateWebsite(ctx context.Context, st *store.Store, q *queue.Queue, sock string, w Website, log *slog.Logger) error {
	clientID, domainID, pass, err := PrepareClient(ctx, st, q, sock, w, log)
	if err != nil {
		return err
	}
	
	
	fmt.Printf(">> cliente migrado %q — senha de login (anote, não será exibida de novo): %s\n", w.Domain, pass)
	log.Info("login do cliente migrado", "client_id", clientID, "domain", w.Domain)
	return EnqueueRestores(ctx, q, sock, w, clientID, domainID)
}

func enqueue(ctx context.Context, q *queue.Queue, sock string, t core.ActionType, payload any) error {
	if _, err := q.Enqueue(ctx, t, payload, nil); err != nil {
		return fmt.Errorf("enfileirar %s: %w", t, err)
	}
	queue.Nudge(sock)
	return nil
}


func RandomLoginPassword() (string, error) {
	b := make([]byte, 12)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(b), nil
}
