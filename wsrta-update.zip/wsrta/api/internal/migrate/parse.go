package migrate

import (
	"archive/tar"
	"compress/gzip"
	"encoding/xml"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
)







func ParseBackup(backupPath, stageDir string, tarFiles bool) (*Website, error) {
	root := filepath.Join(stageDir, "extract")
	if err := extractTarGz(backupPath, root); err != nil {
		return nil, fmt.Errorf("extrair backup: %w", err)
	}

	sep := string(os.PathSeparator)
	var metaPath, publicHTML string
	var sqlFiles []string
	err := filepath.WalkDir(root, func(p string, d os.DirEntry, err error) error {
		if err != nil {
			return err
		}
		switch {
		case d.IsDir() && d.Name() == "public_html":
			
			
			
			
			if publicHTML == "" || strings.Count(p, sep) < strings.Count(publicHTML, sep) {
				publicHTML = p
			}
		case strings.EqualFold(d.Name(), "meta.xml"):
			metaPath = p
		case strings.HasSuffix(d.Name(), ".sql"):
			sqlFiles = append(sqlFiles, p)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}

	w := websiteFromMeta(parseMeta(metaPath))

	
	for i := range w.Databases {
		w.Databases[i].DumpPath = matchDump(sqlFiles, w.Databases[i].Name)
	}
	
	if len(w.Databases) == 0 {
		for _, f := range sqlFiles {
			name := strings.TrimSuffix(filepath.Base(f), ".sql")
			w.Databases = append(w.Databases, MDatabase{Name: name, User: name, DumpPath: f})
		}
	}

	w.HasFiles = publicHTML != ""
	
	
	w.IsWordPress = publicHTML != "" && looksLikeWordPress(publicHTML)
	if publicHTML != "" && tarFiles {
		tarPath := filepath.Join(stageDir, sanitize(w.Domain)+"-files.tar.gz")
		if err := tarDirContents(publicHTML, tarPath); err != nil {
			return nil, fmt.Errorf("empacotar arquivos: %w", err)
		}
		w.FilesTar = tarPath
	}

	if w.Domain == "" {
		return nil, fmt.Errorf("domínio não encontrado no backup (meta.xml ausente/incompatível)")
	}
	return w, nil
}



func InspectBackup(backupPath string) (*Website, error) {
	f, err := os.Open(backupPath)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	gz, err := gzip.NewReader(f)
	if err != nil {
		return nil, err
	}
	defer gz.Close()

	tr := tar.NewReader(gz)
	for {
		hdr, err := tr.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, err
		}
		if strings.EqualFold(filepath.Base(hdr.Name), "meta.xml") {
			data, err := io.ReadAll(tr)
			if err != nil {
				return nil, err
			}
			var m metaXML
			_ = xml.Unmarshal(data, &m)
			w := websiteFromMeta(m)
			if w.Domain == "" {
				return nil, fmt.Errorf("meta.xml incompatível")
			}
			return w, nil
		}
	}
	return nil, fmt.Errorf("meta.xml não encontrado no backup (formato incompatível)")
}


func websiteFromMeta(m metaXML) *Website {
	w := &Website{Domain: m.Domain, Email: m.Email, PHP: normalizePHP(m.PHP), HasFiles: true}
	for _, r := range m.DNS {
		rec := MDNSRecord{Type: r.Type, Name: r.Name, Content: r.Content, TTL: r.TTL}
		if r.Prio > 0 {
			p := r.Prio
			rec.Prio = &p
		}
		w.DNS = append(w.DNS, rec)
	}
	for _, db := range m.Databases {
		w.Databases = append(w.Databases, MDatabase{Name: db.Name, User: db.User, PasswordHash: db.PasswordHash})
	}
	return w
}


type metaXML struct {
	Domain    string `xml:"masterDomain"`
	Email     string `xml:"email"`
	PHP       string `xml:"phpSelection"`
	Databases []struct {
		Name         string `xml:"dbName"`
		User         string `xml:"databaseUsers>dbUser"`
		PasswordHash string `xml:"databaseUsers>password"`
	} `xml:"Databases>database"`
	
	DNS []struct {
		Type    string `xml:"type"`
		Name    string `xml:"name"`
		Content string `xml:"content"`
		TTL     int    `xml:"ttl"`
		Prio    int    `xml:"prio"`
	} `xml:"DNSRecords>record"`
}

func parseMeta(path string) metaXML {
	var m metaXML
	if path == "" {
		return m
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return m
	}
	_ = xml.Unmarshal(data, &m)
	return m
}

func matchDump(sqlFiles []string, dbName string) string {
	for _, f := range sqlFiles {
		if strings.TrimSuffix(filepath.Base(f), ".sql") == dbName {
			return f
		}
	}
	if len(sqlFiles) == 1 {
		return sqlFiles[0]
	}
	return ""
}

func normalizePHP(s string) string {
	s = strings.TrimSpace(strings.TrimPrefix(s, "PHP"))
	return strings.TrimSpace(s)
}

func sanitize(s string) string {
	return strings.Map(func(r rune) rune {
		if (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9') || r == '.' || r == '-' {
			return r
		}
		return '_'
	}, s)
}





func looksLikeWordPress(dir string) bool {
	for _, f := range []string{"wp-config.php", "wp-load.php", "wp-settings.php", "wp-blog-header.php"} {
		if st, err := os.Stat(filepath.Join(dir, f)); err == nil && !st.IsDir() {
			return true
		}
	}
	inc, e1 := os.Stat(filepath.Join(dir, "wp-includes"))
	con, e2 := os.Stat(filepath.Join(dir, "wp-content"))
	return e1 == nil && inc.IsDir() && e2 == nil && con.IsDir()
}




func ExtractTarGz(src, dst string) error { return extractTarGz(src, dst) }

func extractTarGz(src, dst string) error {
	f, err := os.Open(src)
	if err != nil {
		return err
	}
	defer f.Close()
	gz, err := gzip.NewReader(f)
	if err != nil {
		return err
	}
	defer gz.Close()

	dst = filepath.Clean(dst)
	tr := tar.NewReader(gz)
	for {
		hdr, err := tr.Next()
		if err == io.EOF {
			return nil
		}
		if err != nil {
			return err
		}
		
		
		
		target := filepath.Join(dst, filepath.Clean("/"+hdr.Name))
		if target != dst && !strings.HasPrefix(target, dst+string(os.PathSeparator)) {
			return fmt.Errorf("entrada de tar fora do destino: %q", hdr.Name)
		}
		switch hdr.Typeflag {
		case tar.TypeSymlink, tar.TypeLink:
			
			
			continue
		case tar.TypeDir:
			if err := os.MkdirAll(target, 0o755); err != nil {
				return err
			}
		case tar.TypeReg:
			if err := os.MkdirAll(filepath.Dir(target), 0o755); err != nil {
				return err
			}
			out, err := os.Create(target)
			if err != nil {
				return err
			}
			if _, err := io.Copy(out, tr); err != nil {
				out.Close()
				return err
			}
			out.Close()
		}
	}
}

func tarDirContents(dir, out string) error {
	f, err := os.Create(out)
	if err != nil {
		return err
	}
	defer f.Close()
	gz := gzip.NewWriter(f)
	defer gz.Close()
	tw := tar.NewWriter(gz)
	defer tw.Close()

	return filepath.Walk(dir, func(p string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		rel, err := filepath.Rel(dir, p)
		if err != nil {
			return err
		}
		if rel == "." {
			return nil
		}
		hdr, err := tar.FileInfoHeader(info, "")
		if err != nil {
			return err
		}
		hdr.Name = filepath.ToSlash(rel)
		if err := tw.WriteHeader(hdr); err != nil {
			return err
		}
		if !info.Mode().IsRegular() {
			return nil
		}
		in, err := os.Open(p)
		if err != nil {
			return err
		}
		defer in.Close()
		_, err = io.Copy(tw, in)
		return err
	})
}
