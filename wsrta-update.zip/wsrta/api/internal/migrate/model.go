

package migrate


type Website struct {
	Domain      string
	Email       string
	PHP         string
	Docroot     string
	Databases   []MDatabase
	DNS         []MDNSRecord
	FilesTar    string
	HasFiles    bool
	IsWordPress bool 
}


type MDatabase struct {
	Name         string
	User         string
	PasswordHash string
	DumpPath     string
}


type MDNSRecord struct {
	Type    string
	Name    string
	Content string
	TTL     int
	Prio    *int
}
