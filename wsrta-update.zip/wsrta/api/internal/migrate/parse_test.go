package migrate

import (
	"archive/tar"
	"compress/gzip"
	"os"
	"path/filepath"
	"testing"
)


const realMeta = `<?xml version="1.0" ?>
<metaFile>
  <VERSION>2.3</VERSION>
  <masterDomain>est.uea.edu.br</masterDomain>
  <phpSelection>PHP 8.2</phpSelection>
  <userName>usr_est</userName>
  <email>jdbrito@uea.edu.br</email>
  <Databases>
    <database>
      <dbName>okTqwghgr2bfb9</dbName>
      <databaseUsers>
        <dbUser>okTqwghgr2bfb9</dbUser>
        <dbHost>localhost</dbHost>
        <password>*DD67B44D45A67D8144BBA462DEC621FA903E8F09</password>
      </databaseUsers>
    </database>
  </Databases>
  <Aliases/>
</metaFile>`

func TestParseMetaReal(t *testing.T) {
	p := filepath.Join(t.TempDir(), "meta.xml")
	if err := os.WriteFile(p, []byte(realMeta), 0o644); err != nil {
		t.Fatal(err)
	}

	m := parseMeta(p)
	if m.Domain != "est.uea.edu.br" {
		t.Fatalf("domain = %q", m.Domain)
	}
	if normalizePHP(m.PHP) != "8.2" {
		t.Fatalf("php = %q", normalizePHP(m.PHP))
	}
	if m.Email != "jdbrito@uea.edu.br" {
		t.Fatalf("email = %q", m.Email)
	}
	if len(m.Databases) != 1 {
		t.Fatalf("databases = %d", len(m.Databases))
	}
	db := m.Databases[0]
	if db.Name != "okTqwghgr2bfb9" || db.User != "okTqwghgr2bfb9" ||
		db.PasswordHash != "*DD67B44D45A67D8144BBA462DEC621FA903E8F09" {
		t.Fatalf("database = %+v", db)
	}

	
	w := websiteFromMeta(m)
	if w.Domain != "est.uea.edu.br" || w.PHP != "8.2" || len(w.Databases) != 1 {
		t.Fatalf("website = %+v", w)
	}
}

func TestLooksLikeWordPress(t *testing.T) {
	if looksLikeWordPress(t.TempDir()) {
		t.Fatal("diretório vazio não deveria ser reconhecido como WordPress")
	}
	
	core := t.TempDir()
	mustMkdirAll(t, filepath.Join(core, "wp-includes"))
	mustMkdirAll(t, filepath.Join(core, "wp-content"))
	if !looksLikeWordPress(core) {
		t.Fatal("wp-includes + wp-content deveria ser reconhecido como WordPress")
	}
	
	cfg := t.TempDir()
	if err := os.WriteFile(filepath.Join(cfg, "wp-config.php"), []byte("<?php"), 0o644); err != nil {
		t.Fatal(err)
	}
	if !looksLikeWordPress(cfg) {
		t.Fatal("wp-config.php deveria ser reconhecido como WordPress")
	}
}




func TestParseBackupDetectsWordPressPrefersShallowestPublicHTML(t *testing.T) {
	stage := t.TempDir()
	tarPath := filepath.Join(stage, "backup.tar.gz")
	base := "backup/est.uea.edu.br"
	ph := base + "/public_html"                          
	nested := ph + "/wp-content/uploads/old/public_html" 
	buildTarGz(t, tarPath,
		[]string{base, ph, ph + "/wp-includes", ph + "/wp-content", nested},
		map[string]string{
			base + "/meta.xml":           realMeta,
			base + "/okTqwghgr2bfb9.sql": "-- dump",
			ph + "/wp-config.php":        "<?php // wp",
			ph + "/index.php":            "<?php",
			nested + "/leftover.txt":     "x",
		})

	w, err := ParseBackup(tarPath, stage, true)
	if err != nil {
		t.Fatal(err)
	}
	if w.Domain != "est.uea.edu.br" {
		t.Fatalf("domain = %q", w.Domain)
	}
	if !w.IsWordPress {
		t.Fatal("deveria detectar WordPress (o public_html raso tem wp-config/wp-includes/wp-content)")
	}
	if w.FilesTar == "" {
		t.Fatal("deveria empacotar os arquivos do docroot")
	}
	if len(w.Databases) != 1 || w.Databases[0].DumpPath == "" {
		t.Fatalf("banco/dump não casado: %+v", w.Databases)
	}
}

func mustMkdirAll(t *testing.T, dir string) {
	t.Helper()
	if err := os.MkdirAll(dir, 0o755); err != nil {
		t.Fatal(err)
	}
}



func buildTarGz(t *testing.T, dst string, dirs []string, files map[string]string) {
	t.Helper()
	f, err := os.Create(dst)
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	gz := gzip.NewWriter(f)
	defer gz.Close()
	tw := tar.NewWriter(gz)
	defer tw.Close()
	for _, d := range dirs {
		if err := tw.WriteHeader(&tar.Header{Name: d + "/", Typeflag: tar.TypeDir, Mode: 0o755}); err != nil {
			t.Fatal(err)
		}
	}
	for name, content := range files {
		if err := tw.WriteHeader(&tar.Header{Name: name, Typeflag: tar.TypeReg, Mode: 0o644, Size: int64(len(content))}); err != nil {
			t.Fatal(err)
		}
		if _, err := tw.Write([]byte(content)); err != nil {
			t.Fatal(err)
		}
	}
}
