

package fileclient

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"time"
)


type Scope struct {
	Mode      string `json:"mode"` 
	Container string `json:"container"`
	Path      string `json:"path"`
}


type Entry struct {
	Name  string `json:"name"`
	IsDir bool   `json:"is_dir"`
	Size  int64  `json:"size"`
	MTime int64  `json:"mtime"`
}


type Client struct {
	http  *http.Client
	token string
}


func New(socketPath, token string) *Client {
	tr := &http.Transport{
		DialContext: func(ctx context.Context, _, _ string) (net.Conn, error) {
			return (&net.Dialer{}).DialContext(ctx, "unix", socketPath)
		},
	}
	return &Client{http: &http.Client{Transport: tr, Timeout: 10 * time.Minute}, token: token}
}


type APIError struct {
	Status  int
	Message string
}

func (e *APIError) Error() string { return e.Message }

func (c *Client) do(ctx context.Context, method, path string, body io.Reader) (*http.Response, error) {
	req, err := http.NewRequestWithContext(ctx, method, "http://unix"+path, body)
	if err != nil {
		return nil, err
	}
	req.Header.Set("X-WSRTA-Token", c.token)
	return c.http.Do(req)
}

func (c *Client) postJSON(ctx context.Context, path string, payload any) (*http.Response, error) {
	b, _ := json.Marshal(payload)
	res, err := c.do(ctx, http.MethodPost, path, bytes.NewReader(b))
	if err != nil {
		return nil, err
	}
	return res, nil
}

func apiErr(res *http.Response) error {
	var e struct {
		Error string `json:"error"`
	}
	_ = json.NewDecoder(res.Body).Decode(&e)
	msg := e.Error
	if msg == "" {
		msg = fmt.Sprintf("file service: HTTP %d", res.StatusCode)
	}
	return &APIError{Status: res.StatusCode, Message: msg}
}


func (c *Client) List(ctx context.Context, s Scope) ([]Entry, error) {
	res, err := c.postJSON(ctx, "/list", s)
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		return nil, apiErr(res)
	}
	var out struct {
		Entries []Entry `json:"entries"`
	}
	if err := json.NewDecoder(res.Body).Decode(&out); err != nil {
		return nil, err
	}
	return out.Entries, nil
}

func (c *Client) simpleScopeOp(ctx context.Context, path string, s Scope) error {
	res, err := c.postJSON(ctx, path, s)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	if res.StatusCode >= 300 {
		return apiErr(res)
	}
	return nil
}

func (c *Client) Mkdir(ctx context.Context, s Scope) error { return c.simpleScopeOp(ctx, "/mkdir", s) }
func (c *Client) NewFile(ctx context.Context, s Scope) error {
	return c.simpleScopeOp(ctx, "/newfile", s)
}
func (c *Client) Delete(ctx context.Context, s Scope) error {
	return c.simpleScopeOp(ctx, "/delete", s)
}


func (c *Client) Rename(ctx context.Context, s Scope, newName string) error {
	res, err := c.postJSON(ctx, "/rename", map[string]any{"scope": s, "new_name": newName})
	if err != nil {
		return err
	}
	defer res.Body.Close()
	if res.StatusCode >= 300 {
		return apiErr(res)
	}
	return nil
}

func (c *Client) moveCopy(ctx context.Context, path string, s Scope, dstDir string) error {
	res, err := c.postJSON(ctx, path, map[string]any{"src": s, "dst_dir": dstDir})
	if err != nil {
		return err
	}
	defer res.Body.Close()
	if res.StatusCode >= 300 {
		return apiErr(res)
	}
	return nil
}

func (c *Client) Move(ctx context.Context, s Scope, dstDir string) error {
	return c.moveCopy(ctx, "/move", s, dstDir)
}
func (c *Client) Copy(ctx context.Context, s Scope, dstDir string) error {
	return c.moveCopy(ctx, "/copy", s, dstDir)
}


func (c *Client) Download(ctx context.Context, s Scope, w io.Writer) error {
	res, err := c.postJSON(ctx, "/download", s)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		return apiErr(res)
	}
	_, err = io.Copy(w, res.Body)
	return err
}


type WPResult struct {
	Stdout string `json:"stdout"`
	Stderr string `json:"stderr"`
	Exit   int    `json:"exit"`
}


func (c *Client) WP(ctx context.Context, container, path string, args []string) (*WPResult, error) {
	res, err := c.postJSON(ctx, "/wp", map[string]any{"container": container, "path": path, "args": args})
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		return nil, apiErr(res)
	}
	var out WPResult
	if err := json.NewDecoder(res.Body).Decode(&out); err != nil {
		return nil, err
	}
	return &out, nil
}


type DockerResult struct {
	Stdout string `json:"stdout"`
	Stderr string `json:"stderr"`
	Exit   int    `json:"exit"`
}



func (c *Client) Docker(ctx context.Context, container string, args []string) (*DockerResult, error) {
	res, err := c.postJSON(ctx, "/docker", map[string]any{"container": container, "args": args})
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		return nil, apiErr(res)
	}
	var out DockerResult
	if err := json.NewDecoder(res.Body).Decode(&out); err != nil {
		return nil, err
	}
	return &out, nil
}


func (c *Client) FirewallState(ctx context.Context) ([]byte, error) {
	res, err := c.postJSON(ctx, "/fw/state", map[string]any{})
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		return nil, apiErr(res)
	}
	return io.ReadAll(res.Body)
}


func (c *Client) NginxScan(ctx context.Context) ([]byte, error) {
	res, err := c.postJSON(ctx, "/nginx/scan", map[string]any{})
	if err != nil {
		return nil, err
	}
	defer res.Body.Close()
	if res.StatusCode != http.StatusOK {
		return nil, apiErr(res)
	}
	return io.ReadAll(res.Body)
}


func (c *Client) FirewallAction(ctx context.Context, kind, ip, jail, service, op string) error {
	res, err := c.postJSON(ctx, "/fw/action", map[string]any{
		"kind": kind, "ip": ip, "jail": jail, "service": service, "op": op,
	})
	if err != nil {
		return err
	}
	defer res.Body.Close()
	if res.StatusCode >= 300 {
		return apiErr(res)
	}
	return nil
}


func (c *Client) Upload(ctx context.Context, s Scope, r io.Reader) error {
	q := url.Values{"mode": {s.Mode}, "container": {s.Container}, "path": {s.Path}}
	res, err := c.do(ctx, http.MethodPost, "/upload?"+q.Encode(), r)
	if err != nil {
		return err
	}
	defer res.Body.Close()
	if res.StatusCode >= 300 {
		return apiErr(res)
	}
	return nil
}
