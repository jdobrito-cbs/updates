package server_test

import (
	"bytes"
	"context"
	"encoding/json"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"os"
	"strconv"
	"testing"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/pquerna/otp/totp"

	"github.com/jdobrito/wsrta/api/internal/auth"
	"github.com/jdobrito/wsrta/api/internal/handlers"
	"github.com/jdobrito/wsrta/api/internal/server"
	"github.com/jdobrito/wsrta/api/internal/store"
	"github.com/jdobrito/wsrta/internal/db"
	"github.com/jdobrito/wsrta/internal/queue"
)



func TestGoldenRuleOwnership(t *testing.T) {
	dsn := os.Getenv("WSRTA_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("defina WSRTA_TEST_DATABASE_URL para rodar a integração da API")
	}

	ctx := context.Background()
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		t.Fatalf("open db: %v", err)
	}
	defer pool.Close()

	for _, tbl := range []string{"actions", "dns_records", "domains", "databases", "cron_jobs", "clients", "users"} {
		if _, err := pool.Exec(ctx, "DELETE FROM "+tbl); err != nil {
			t.Fatalf("limpar %s: %v", tbl, err)
		}
	}

	
	seedUser(t, pool, "admin@x.com", "admin", "adminpass1")
	uidA := seedUser(t, pool, "a@x.com", "client", "clientpass1")
	uidB := seedUser(t, pool, "b@x.com", "client", "clientpass1")
	cidA := seedClient(t, pool, uidA, "cli_a")
	cidB := seedClient(t, pool, uidB, "cli_b")
	_ = cidA
	domainB := seedDomain(t, pool, cidB, "exemplob.com")

	log := slog.New(slog.NewTextHandler(io.Discard, nil))
	tokens := auth.NewTokens("test-secret", time.Hour)
	h := handlers.New(handlers.Config{
		Store:      store.New(pool),
		Queue:      queue.New(pool),
		Tokens:     tokens,
		Rate:       auth.NewRateLimiter(1000),
		DaemonSock: "/tmp/wsrta-test-nonexistent.sock",
		TOTPIssuer: "WSRTA",
		Log:        log,
	})
	app := server.New(h, auth.NewMiddleware(tokens), log)

	tokenA := login(t, app, "a@x.com", "clientpass1")
	tokenB := login(t, app, "b@x.com", "clientpass1")
	tokenAdmin := login(t, app, "admin@x.com", "adminpass1")

	
	if rec := doReq(app, http.MethodPost, "/api/auth/login", "", map[string]string{"email": "a@x.com", "password": "errada"}); rec.Code != http.StatusUnauthorized {
		t.Fatalf("login senha errada: %d, esperava 401", rec.Code)
	}

	
	pathB := "/api/domains/" + itoa(domainB)
	if rec := doReq(app, http.MethodDelete, pathB, tokenA, nil); rec.Code != http.StatusNotFound {
		t.Fatalf("A apagando domínio de B: %d, esperava 404", rec.Code)
	}

	
	if rec := doReq(app, http.MethodDelete, pathB, tokenB, nil); rec.Code != http.StatusAccepted {
		t.Fatalf("B apagando próprio domínio: %d, esperava 202", rec.Code)
	}

	
	if rec := doReq(app, http.MethodGet, "/api/admin/clients", tokenA, nil); rec.Code != http.StatusForbidden {
		t.Fatalf("cliente em /admin/clients: %d, esperava 403", rec.Code)
	}
	
	if rec := doReq(app, http.MethodGet, "/api/admin/clients", tokenAdmin, nil); rec.Code != http.StatusOK {
		t.Fatalf("admin em /admin/clients: %d, esperava 200", rec.Code)
	}
	
	if rec := doReq(app, http.MethodGet, "/api/domains", tokenAdmin, nil); rec.Code != http.StatusForbidden {
		t.Fatalf("admin em /domains: %d, esperava 403", rec.Code)
	}
}



func doReq(h http.Handler, method, path, token string, body any) *httptest.ResponseRecorder {
	var r io.Reader
	if body != nil {
		b, _ := json.Marshal(body)
		r = bytes.NewReader(b)
	}
	req := httptest.NewRequest(method, path, r)
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, req)
	return rec
}



func login(t *testing.T, h http.Handler, email, password string) string {
	t.Helper()
	rec := doReq(h, http.MethodPost, "/api/auth/login", "", map[string]string{"email": email, "password": password})
	if rec.Code != http.StatusOK {
		t.Fatalf("login %s: %d %s", email, rec.Code, rec.Body.String())
	}
	var lr struct {
		Stage  string `json:"stage"`
		Token  string `json:"token"`
		Secret string `json:"secret"`
	}
	if err := json.Unmarshal(rec.Body.Bytes(), &lr); err != nil {
		t.Fatalf("decode login: %v", err)
	}
	if lr.Stage != "enroll" {
		t.Fatalf("login %s: stage=%q, esperava enroll", email, lr.Stage)
	}

	code, err := totp.GenerateCode(lr.Secret, time.Now())
	if err != nil {
		t.Fatalf("gerar TOTP: %v", err)
	}
	rec2 := doReq(h, http.MethodPost, "/api/auth/2fa/enroll", "", map[string]string{"token": lr.Token, "code": code})
	if rec2.Code != http.StatusOK {
		t.Fatalf("enroll %s: %d %s", email, rec2.Code, rec2.Body.String())
	}
	var vr struct {
		Token string `json:"token"`
	}
	if err := json.Unmarshal(rec2.Body.Bytes(), &vr); err != nil {
		t.Fatalf("decode enroll: %v", err)
	}
	return vr.Token
}

func seedUser(t *testing.T, pool *pgxpool.Pool, email, role, password string) int64 {
	t.Helper()
	hash, err := auth.HashPassword(password)
	if err != nil {
		t.Fatalf("hash: %v", err)
	}
	var id int64
	if err := pool.QueryRow(context.Background(),
		`INSERT INTO users (email, password_hash, role) VALUES ($1,$2,$3) RETURNING id`,
		email, hash, role).Scan(&id); err != nil {
		t.Fatalf("seed user: %v", err)
	}
	return id
}

func seedClient(t *testing.T, pool *pgxpool.Pool, userID int64, container string) int64 {
	t.Helper()
	var id int64
	if err := pool.QueryRow(context.Background(),
		`INSERT INTO clients (user_id, name, lxc_container_name) VALUES ($1,'C',$2) RETURNING id`,
		userID, container).Scan(&id); err != nil {
		t.Fatalf("seed client: %v", err)
	}
	return id
}

func seedDomain(t *testing.T, pool *pgxpool.Pool, clientID int64, fqdn string) int64 {
	t.Helper()
	var id int64
	if err := pool.QueryRow(context.Background(),
		`INSERT INTO domains (client_id, fqdn, docroot) VALUES ($1,$2,$3) RETURNING id`,
		clientID, fqdn, "/var/www/"+fqdn).Scan(&id); err != nil {
		t.Fatalf("seed domain: %v", err)
	}
	return id
}

func itoa(v int64) string {
	return strconv.FormatInt(v, 10)
}
