
package server

import (
	"log/slog"
	"net"
	"net/http"
	"strings"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"

	"github.com/jdobrito/wsrta/api/internal/auth"
	"github.com/jdobrito/wsrta/api/internal/handlers"
)






func New(h *handlers.Handlers, mw *auth.Middleware, log *slog.Logger) http.Handler {
	r := chi.NewRouter()
	r.Use(middleware.RequestID)
	r.Use(trustedRealIP)
	r.Use(middleware.Recoverer)
	r.Use(securityHeaders)
	r.Use(requestLogger(log))

	r.Get("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		handlers.WriteJSON(w, http.StatusOK, map[string]string{"status": "ok"})
	})

	
	
	
	r.Get("/_preview/{fqdn}", h.Preview)
	r.Get("/_preview/{fqdn}/*", h.Preview)

	r.Route("/api", func(r chi.Router) {
		
		r.Get("/setup/status", h.SetupStatus)
		r.Post("/setup", h.Setup)

		
		r.Post("/auth/login", h.Login)
		r.Post("/auth/2fa/enroll", h.Enroll2FA)
		r.Post("/auth/2fa/verify", h.Verify2FA)
		r.Get("/edition", h.Edition)                       
		r.Get("/public/site", h.PublicSite)                
		r.Get("/public/site/{slug}", h.PublicResellerSite) 
		r.Post("/public/checkout", h.PublicCheckout)       
		r.Post("/public/mp/webhook", h.MPWebhook)          

		r.Group(func(r chi.Router) {
			r.Use(mw.RequireAuth)
			r.Use(h.TrackPresence) 
			r.Post("/auth/logout", h.Logout)
			r.Get("/auth/me", h.Me)
			r.Post("/auth/refresh", h.RefreshSession)
			r.Get("/version", h.Version)
			r.Get("/branding", h.Branding)
			r.Post("/account/password", h.ChangeOwnPassword)

			
			r.Group(func(r chi.Router) {
				r.Use(mw.RequireAdmin)
				r.Get("/admin/dashboard", h.AdminDashboard)
				r.Get("/admin/actions", h.ListActions)
				r.Get("/admin/system", h.System)

				
				r.Get("/admin/resellers", h.ListResellers)
				r.Post("/admin/resellers", h.CreateReseller)
				r.Put("/admin/resellers/{id}", h.UpdateReseller)
				r.Delete("/admin/resellers/{id}", h.DeleteReseller)
				r.Post("/admin/resellers/{id}/suspend", h.SuspendReseller)
				r.Post("/admin/resellers/{id}/resume", h.ResumeReseller)

				
				r.Get("/admin/packages", h.ListPackages)
				r.Post("/admin/packages", h.CreatePackage)
				r.Put("/admin/packages/{id}", h.UpdatePackage)
				r.Delete("/admin/packages/{id}", h.DeletePackage)
				
				
				r.Get("/admin/apps", h.AdminAppPermissions)
				r.Put("/admin/apps", h.SetAdminAppPermissions)

				
				r.Get("/admin/mercadopago", h.GetMPConfig)
				r.Put("/admin/mercadopago", h.SetMPConfig)
				r.Get("/admin/mailcow", h.GetMailcowConfig)
				r.Put("/admin/mailcow", h.SetMailcowConfig)
				r.Get("/admin/orders", h.ListOrders)

				
				r.Get("/admin/monitoring", h.Monitoring)
				r.Get("/admin/monitoring/bandwidth", h.MonitoringBandwidth)
				r.Get("/admin/monitoring/bandwidth/clients", h.ClientBandwidth)
				r.Post("/admin/monitoring/update/os", h.UpdateSystemOS)
				r.Post("/admin/monitoring/update/panel", h.UpdatePanel)
				r.Get("/admin/settings", h.GetSystemSettings)
				r.Put("/admin/settings", h.UpdateSystemSettings)
				r.Post("/admin/system/restart", h.RestartService)
				r.Get("/admin/security", h.GetSecurity)
				r.Put("/admin/security", h.UpdateSecurity)
				r.Get("/admin/firewall", h.FirewallState)
				r.Post("/admin/firewall/action", h.FirewallAction)

				
				r.Get("/admin/security-events", h.ListSecurityEvents)

				
				r.Get("/admin/vuln/host", h.ListHostVulnScans)
				r.Post("/admin/vuln/host", h.CreateHostVulnScan)
				r.Get("/admin/vuln/scans/{scan_id}/findings", h.VulnScanFindings)
				
				r.Post("/admin/wordpress/harden-all", h.HardenAllWordPress)

				
				r.Get("/admin/admins", h.ListAdmins)
				r.Post("/admin/admins", h.CreateAdmin)
				r.Put("/admin/admins/{id}", h.UpdateAdmin)
				r.Delete("/admin/admins/{id}", h.DeleteAdmin)
				r.Post("/admin/admins/{id}/block", h.BlockAdmin)
				r.Post("/admin/admins/{id}/unblock", h.UnblockAdmin)

				
				r.Route("/admin/files", func(r chi.Router) {
					r.Use(h.WithFSHost)
					mountFiles(r, h)
				})

				
				r.Get("/admin/import/cyberpanel/backups", h.ListBackups)
				r.Post("/admin/import/cyberpanel/preview", h.PreviewBackup)
				r.Post("/admin/import/cyberpanel/import", h.ImportBackup)
				r.Post("/admin/import/cyberpanel/delete", h.DeleteBackup)
				r.Post("/admin/import/cyberpanel/upload", h.UploadBackup)

				
				r.Get("/admin/import/nginx", h.NginxImport)

				r.Route("/admin/clients", func(r chi.Router) {
					r.Get("/", h.ListClients)
					r.Post("/", h.CreateClient)

					r.Route("/{client_id}", func(r chi.Router) {
						r.Get("/", h.GetClientDetail)
						r.Put("/", h.UpdateClient)
						r.Delete("/", h.DeleteClient)
						r.Post("/reset-2fa", h.ResetClient2FA)
						r.Post("/password", h.AdminSetClientPassword)
						r.Post("/suspend", h.SuspendClient)
						r.Post("/resume", h.ResumeClient)
						
						r.Get("/power", h.PowerStatus)
						r.Post("/power", h.PowerClient)
						r.Get("/sftp", h.ClientSFTPInfo)
						r.Post("/sftp/enable", h.EnableSFTP)
						r.Post("/sftp/disable", h.DisableSFTP)

						
						r.Get("/backups", h.ListClientBackups)
						r.Post("/backups", h.CreateClientBackup)
						r.Get("/backups/{id}/download", h.DownloadBackup)
						r.Post("/backups/{id}/restore", h.RestoreClientBackup)
						r.Post("/backups/restore-upload", h.RestoreUpload)
						r.Put("/backup-schedule", h.SetBackupSchedule)

						
						r.Get("/vuln-scans", h.ListClientVulnScans)
						r.Post("/vuln-scans", h.CreateClientVulnScan)
						r.Put("/vuln-schedule", h.SetClientVulnSchedule)

						
						r.Post("/update-packages", h.UpdateClientPackages)

						
						r.Get("/cloudflare", h.ClientCloudflareInfo)
						r.Post("/cloudflare/set", h.SetCloudflare)
						r.Post("/cloudflare/control", h.ControlCloudflare)

						
						r.Route("/files", func(r chi.Router) {
							r.Use(h.WithFSContainer)
							mountFiles(r, h)
						})

						
						r.Get("/phpmyadmin", h.PhpMyAdminInfo)
						r.Post("/phpmyadmin/enable", h.EnablePhpMyAdmin)
						r.Post("/phpmyadmin/disable", h.DisablePhpMyAdmin)

						
						r.Get("/postgres", h.PostgresInfo)
						r.Post("/postgres/enable", h.EnablePostgres)
						r.Post("/postgres/disable", h.DisablePostgres)
						r.Post("/phppgadmin/enable", h.EnablePhpPgAdmin)
						r.Post("/phppgadmin/disable", h.DisablePhpPgAdmin)

						
						r.Post("/fastnginx/enable", h.EnableFastNginx)
						r.Post("/fastnginx/disable", h.DisableFastNginx)

						
						r.Get("/runtimes", h.RuntimesInfo)
						r.Post("/runtimes", h.SetRuntimes)

						
						r.Get("/domains", h.ListDomains)
						r.Post("/domains", h.CreateDomain)
						r.Delete("/domains/{id}", h.DeleteDomain)
						r.Post("/domains/{id}/ssl", h.IssueSSL)
						r.Post("/domains/{id}/php", h.SetDomainPHP)
						r.Post("/domains/{id}/offline", h.SetDomainOffline)
						r.Get("/domains/{id}/rules", h.GetSiteRules)
						r.Put("/domains/{id}/rules", h.UpdateSiteRules)
						
						r.Get("/domains/{id}/forwards", h.ListForwards)
						r.Post("/domains/{id}/forwards", h.CreateForward)
						r.Delete("/domains/{id}/forwards/{forward_id}", h.DeleteForward)
						r.Get("/databases", h.ListDatabases)
						r.Post("/databases", h.CreateDatabase)
						r.Delete("/databases/{id}", h.DeleteDatabase)
						r.Post("/databases/{id}/password", h.ResetDatabasePassword)
						r.Get("/dns/{domain_id}/records", h.ListRecords)
						r.Post("/dns/{domain_id}/records", h.CreateRecord)
						r.Put("/dns/{domain_id}/records/{id}", h.UpdateRecord)
						r.Delete("/dns/{domain_id}/records/{id}", h.DeleteRecord)
						r.Get("/cron", h.ListCron)
						r.Post("/cron", h.CreateCron)
						r.Delete("/cron/{id}", h.DeleteCron)
						r.Get("/wordpress", h.ListWordPress)
						r.Post("/wordpress", h.InstallWordPress)
						r.Delete("/wordpress/{id}", h.RemoveWordPress)
						r.Get("/wordpress/{id}/manager", h.WPManagerInfo)
						r.Post("/wordpress/{id}/manage", h.WPManage)
						r.Post("/wordpress/{id}/harden", h.HardenWordPress)
						r.Post("/wordpress/{id}/upload", h.WPUploadInstall)
						r.Post("/wordpress/{id}/site-url", h.WPSetSiteURL)
						r.Post("/wordpress/{id}/admin-password", h.WPSetPassword)
						r.Post("/wordpress/associate", h.AssociateWordPress)
						
						r.Get("/apps", h.AppsInfo)
						r.Post("/apps", h.InstallApp)
						r.Delete("/apps/{id}", h.RemoveApp)
						r.Post("/apps/{id}/update", h.UpdateApp)
						
						r.Get("/docker", h.DockerInfo)
						r.Post("/docker/enable", h.EnableDocker)
						r.Post("/docker/disable", h.DisableDocker)
						r.Post("/docker/control", h.DockerControl)
						
						r.Get("/email", h.EmailInfo)
						r.Post("/domains/{id}/email/enable", h.EnableEmail)
						r.Post("/domains/{id}/email/disable", h.DisableEmail)
						r.Post("/mailboxes", h.CreateMailbox)
						r.Delete("/mailboxes/{id}", h.DeleteMailbox)
						r.Post("/mailboxes/{id}/password", h.SetMailboxPassword)
						r.Get("/stats", h.Stats)
					})
				})
			})

			
			
			
			r.Group(func(r chi.Router) {
				r.Use(mw.RequireReseller)
				r.Use(h.RequireCompleteEdition) 
				r.Get("/reseller/me", h.ResellerMe)
				r.Put("/reseller/site", h.UpdateResellerSite)     
				r.Get("/reseller/apps", h.ResellerAppPermissions) 
				r.Put("/reseller/apps", h.SetResellerAppPermissions)
				r.Get("/reseller/mercadopago", h.GetMPConfig)
				r.Put("/reseller/mercadopago", h.SetMPConfig)
				r.Get("/reseller/orders", h.ListOrders)
				
				r.Get("/reseller/packages", h.ListPackages)
				r.Post("/reseller/packages", h.CreatePackage)
				r.Put("/reseller/packages/{id}", h.UpdatePackage)
				r.Delete("/reseller/packages/{id}", h.DeletePackage)
				r.Route("/reseller/clients", func(r chi.Router) {
					r.Get("/", h.ListClients)   
					r.Post("/", h.CreateClient) 
					r.Route("/{client_id}", func(r chi.Router) {
						r.Use(h.ResellerOwnsClient) 
						r.Get("/", h.GetClientDetail)
						r.Put("/", h.UpdateClient)
						r.Delete("/", h.DeleteClient)
						r.Post("/suspend", h.SuspendClient)
						r.Post("/resume", h.ResumeClient)
						
						r.Get("/power", h.PowerStatus)
						r.Post("/power", h.PowerClient)
						r.Post("/reset-2fa", h.ResetClient2FA)
						r.Post("/password", h.AdminSetClientPassword)
						
						
						mountClientResources(r, h)
					})
				})
			})

			
			r.Group(func(r chi.Router) {
				r.Use(mw.RequireClient)
				r.Get("/monitoring", h.ClientMonitoring)
				
				r.Get("/power", h.PowerStatus)
				r.Post("/power", h.PowerClient)
				
				
				r.Get("/domains", h.ListDomains)
				r.Post("/domains/{id}/ssl", h.IssueSSL)
				r.Post("/domains/{id}/php", h.SetDomainPHP)
				r.Post("/domains/{id}/offline", h.SetDomainOffline)
				r.Get("/domains/{id}/rules", h.GetSiteRules)
				r.Put("/domains/{id}/rules", h.UpdateSiteRules)

				r.Get("/databases", h.ListDatabases)
				r.Post("/databases", h.CreateDatabase)
				r.Delete("/databases/{id}", h.DeleteDatabase)
				r.Post("/databases/{id}/password", h.ResetDatabasePassword)

				

				r.Get("/cron", h.ListCron)
				r.Post("/cron", h.CreateCron)
				r.Delete("/cron/{id}", h.DeleteCron)

				r.Get("/wordpress", h.ListWordPress)
				r.Post("/wordpress", h.InstallWordPress)
				r.Delete("/wordpress/{id}", h.RemoveWordPress)
				r.Get("/wordpress/{id}/manager", h.WPManagerInfo)
				r.Post("/wordpress/{id}/manage", h.WPManage)
				r.Post("/wordpress/{id}/harden", h.HardenWordPress)
				r.Post("/wordpress/{id}/upload", h.WPUploadInstall)
				r.Post("/wordpress/{id}/site-url", h.WPSetSiteURL)
				r.Post("/wordpress/{id}/admin-password", h.WPSetPassword)
				r.Post("/wordpress/associate", h.AssociateWordPress)
				
				r.Get("/apps", h.AppsInfo)
				r.Post("/apps", h.InstallApp)
				r.Delete("/apps/{id}", h.RemoveApp)
				r.Post("/apps/{id}/update", h.UpdateApp)
				
				r.Get("/docker", h.DockerInfo)
				r.Post("/docker/enable", h.EnableDocker)
				r.Post("/docker/disable", h.DisableDocker)
				r.Post("/docker/control", h.DockerControl)
				
				r.Get("/email", h.EmailInfo)
				r.Post("/domains/{id}/email/enable", h.EnableEmail)
				r.Post("/domains/{id}/email/disable", h.DisableEmail)
				r.Post("/mailboxes", h.CreateMailbox)
				r.Delete("/mailboxes/{id}", h.DeleteMailbox)
				r.Post("/mailboxes/{id}/password", h.SetMailboxPassword)

				r.Get("/sftp", h.ClientSFTPInfo)

				
				r.Get("/runtimes", h.RuntimesInfo)

				
				r.Get("/cloudflare", h.ClientCloudflareInfo)
				r.Post("/cloudflare/set", h.SetCloudflare)
				r.Post("/cloudflare/control", h.ControlCloudflare)

				
				r.Route("/files", func(r chi.Router) {
					r.Use(h.WithFSContainer)
					mountFiles(r, h)
				})

				
				r.Get("/phpmyadmin", h.PhpMyAdminInfo)
				r.Post("/phpmyadmin/enable", h.EnablePhpMyAdmin)
				r.Post("/phpmyadmin/disable", h.DisablePhpMyAdmin)

				
				
				
				r.Get("/postgres", h.PostgresInfo)

				r.Get("/stats", h.Stats)
			})

			
			
			
			
			r.Group(func(r chi.Router) {
				r.Use(mw.RequireAdminOrReseller)
				r.Get("/self/status", h.SelfTenantStatus)
				r.Post("/self/activate", h.ActivateSelfTenant)
				r.Put("/self/limits", h.SelfSetLimits) 

				r.Group(func(r chi.Router) {
					r.Use(h.WithSelfTenant) 
					r.Get("/self/stats", h.Stats)
					r.Get("/self/monitoring", h.ClientMonitoring)
					r.Get("/self/power", h.PowerStatus)
					r.Post("/self/power", h.PowerClient)

					
					r.Get("/self/domains", h.ListDomains)
					r.Post("/self/domains", h.CreateDomain)
					r.Delete("/self/domains/{id}", h.DeleteDomain)
					r.Post("/self/domains/{id}/ssl", h.IssueSSL)
					r.Post("/self/domains/{id}/php", h.SetDomainPHP)
					r.Post("/self/domains/{id}/offline", h.SetDomainOffline)
					r.Get("/self/domains/{id}/rules", h.GetSiteRules)
					r.Put("/self/domains/{id}/rules", h.UpdateSiteRules)
					r.Get("/self/domains/{id}/forwards", h.ListForwards)
					r.Post("/self/domains/{id}/forwards", h.CreateForward)
					r.Delete("/self/domains/{id}/forwards/{forward_id}", h.DeleteForward)

					
					r.Get("/self/dns/{domain_id}/records", h.ListRecords)
					r.Post("/self/dns/{domain_id}/records", h.CreateRecord)
					r.Put("/self/dns/{domain_id}/records/{id}", h.UpdateRecord)
					r.Delete("/self/dns/{domain_id}/records/{id}", h.DeleteRecord)

					
					r.Get("/self/databases", h.ListDatabases)
					r.Post("/self/databases", h.CreateDatabase)
					r.Delete("/self/databases/{id}", h.DeleteDatabase)
					r.Post("/self/databases/{id}/password", h.ResetDatabasePassword)

					
					r.Get("/self/cron", h.ListCron)
					r.Post("/self/cron", h.CreateCron)
					r.Delete("/self/cron/{id}", h.DeleteCron)

					
					r.Get("/self/wordpress", h.ListWordPress)
					r.Post("/self/wordpress", h.InstallWordPress)
					r.Delete("/self/wordpress/{id}", h.RemoveWordPress)
					r.Get("/self/wordpress/{id}/manager", h.WPManagerInfo)
					r.Post("/self/wordpress/{id}/manage", h.WPManage)
					r.Post("/self/wordpress/{id}/harden", h.HardenWordPress)
					r.Post("/self/wordpress/{id}/upload", h.WPUploadInstall)
					r.Post("/self/wordpress/{id}/site-url", h.WPSetSiteURL)
					r.Post("/self/wordpress/{id}/admin-password", h.WPSetPassword)
					r.Post("/self/wordpress/associate", h.AssociateWordPress)
					
					r.Get("/self/apps", h.AppsInfo)
					r.Post("/self/apps", h.InstallApp)
					r.Delete("/self/apps/{id}", h.RemoveApp)
					r.Post("/self/apps/{id}/update", h.UpdateApp)
					
					r.Get("/self/docker", h.DockerInfo)
					r.Post("/self/docker/enable", h.EnableDocker)
					r.Post("/self/docker/disable", h.DisableDocker)
					r.Post("/self/docker/control", h.DockerControl)
					
					r.Get("/self/email", h.EmailInfo)
					r.Post("/self/domains/{id}/email/enable", h.EnableEmail)
					r.Post("/self/domains/{id}/email/disable", h.DisableEmail)
					r.Post("/self/mailboxes", h.CreateMailbox)
					r.Delete("/self/mailboxes/{id}", h.DeleteMailbox)
					r.Post("/self/mailboxes/{id}/password", h.SetMailboxPassword)

					
					r.Get("/self/sftp", h.ClientSFTPInfo)
					r.Post("/self/sftp/enable", h.EnableSFTP)
					r.Post("/self/sftp/disable", h.DisableSFTP)

					
					r.Get("/self/cloudflare", h.ClientCloudflareInfo)
					r.Post("/self/cloudflare/set", h.SetCloudflare)
					r.Post("/self/cloudflare/control", h.ControlCloudflare)

					
					r.Get("/self/phpmyadmin", h.PhpMyAdminInfo)
					r.Post("/self/phpmyadmin/enable", h.EnablePhpMyAdmin)
					r.Post("/self/phpmyadmin/disable", h.DisablePhpMyAdmin)
					r.Get("/self/postgres", h.PostgresInfo)
					r.Post("/self/postgres/enable", h.EnablePostgres)
					r.Post("/self/postgres/disable", h.DisablePostgres)
					r.Post("/self/phppgadmin/enable", h.EnablePhpPgAdmin)
					r.Post("/self/phppgadmin/disable", h.DisablePhpPgAdmin)

					
					r.Get("/self/runtimes", h.RuntimesInfo)
					r.Post("/self/runtimes", h.SetRuntimes)

					
					r.Get("/self/backups", h.ListClientBackups)
					r.Post("/self/backups", h.CreateClientBackup)
					r.Get("/self/backups/{id}/download", h.DownloadBackup)
					r.Post("/self/backups/{id}/restore", h.RestoreClientBackup)
					r.Post("/self/backups/restore-upload", h.RestoreUpload)
					r.Put("/self/backup-schedule", h.SetBackupSchedule)

					
					r.Route("/self/files", func(r chi.Router) {
						r.Use(h.WithFSContainer)
						mountFiles(r, h)
					})
				})
			})
		})
	})

	return r
}





func mountClientResources(r chi.Router, h *handlers.Handlers) {
	
	r.Get("/sftp", h.ClientSFTPInfo)
	r.Post("/sftp/enable", h.EnableSFTP)
	r.Post("/sftp/disable", h.DisableSFTP)
	
	r.Get("/backups", h.ListClientBackups)
	r.Post("/backups", h.CreateClientBackup)
	r.Get("/backups/{id}/download", h.DownloadBackup)
	r.Post("/backups/{id}/restore", h.RestoreClientBackup)
	r.Post("/backups/restore-upload", h.RestoreUpload)
	r.Put("/backup-schedule", h.SetBackupSchedule)
	
	r.Get("/cloudflare", h.ClientCloudflareInfo)
	r.Post("/cloudflare/set", h.SetCloudflare)
	r.Post("/cloudflare/control", h.ControlCloudflare)
	
	r.Route("/files", func(r chi.Router) {
		r.Use(h.WithFSContainer)
		mountFiles(r, h)
	})
	
	r.Get("/phpmyadmin", h.PhpMyAdminInfo)
	r.Post("/phpmyadmin/enable", h.EnablePhpMyAdmin)
	r.Post("/phpmyadmin/disable", h.DisablePhpMyAdmin)
	r.Get("/postgres", h.PostgresInfo)
	r.Post("/postgres/enable", h.EnablePostgres)
	r.Post("/postgres/disable", h.DisablePostgres)
	r.Post("/phppgadmin/enable", h.EnablePhpPgAdmin)
	r.Post("/phppgadmin/disable", h.DisablePhpPgAdmin)
	
	r.Post("/fastnginx/enable", h.EnableFastNginx)
	r.Post("/fastnginx/disable", h.DisableFastNginx)
	r.Get("/runtimes", h.RuntimesInfo)
	r.Post("/runtimes", h.SetRuntimes)
	
	r.Get("/domains", h.ListDomains)
	r.Post("/domains", h.CreateDomain)
	r.Delete("/domains/{id}", h.DeleteDomain)
	r.Post("/domains/{id}/ssl", h.IssueSSL)
	r.Post("/domains/{id}/php", h.SetDomainPHP)
	r.Post("/domains/{id}/offline", h.SetDomainOffline)
	r.Get("/domains/{id}/rules", h.GetSiteRules)
	r.Put("/domains/{id}/rules", h.UpdateSiteRules)
	r.Get("/domains/{id}/forwards", h.ListForwards)
	r.Post("/domains/{id}/forwards", h.CreateForward)
	r.Delete("/domains/{id}/forwards/{forward_id}", h.DeleteForward)
	
	r.Get("/databases", h.ListDatabases)
	r.Post("/databases", h.CreateDatabase)
	r.Delete("/databases/{id}", h.DeleteDatabase)
	r.Post("/databases/{id}/password", h.ResetDatabasePassword)
	
	r.Get("/dns/{domain_id}/records", h.ListRecords)
	r.Post("/dns/{domain_id}/records", h.CreateRecord)
	r.Put("/dns/{domain_id}/records/{id}", h.UpdateRecord)
	r.Delete("/dns/{domain_id}/records/{id}", h.DeleteRecord)
	
	r.Get("/cron", h.ListCron)
	r.Post("/cron", h.CreateCron)
	r.Delete("/cron/{id}", h.DeleteCron)
	
	r.Get("/wordpress", h.ListWordPress)
	r.Post("/wordpress", h.InstallWordPress)
	r.Delete("/wordpress/{id}", h.RemoveWordPress)
	r.Get("/wordpress/{id}/manager", h.WPManagerInfo)
	r.Post("/wordpress/{id}/manage", h.WPManage)
	r.Post("/wordpress/{id}/harden", h.HardenWordPress)
	r.Post("/wordpress/{id}/upload", h.WPUploadInstall)
	r.Post("/wordpress/{id}/site-url", h.WPSetSiteURL)
	r.Post("/wordpress/{id}/admin-password", h.WPSetPassword)
	r.Post("/wordpress/associate", h.AssociateWordPress)
	
	r.Get("/apps", h.AppsInfo)
	r.Post("/apps", h.InstallApp)
	r.Delete("/apps/{id}", h.RemoveApp)
	r.Post("/apps/{id}/update", h.UpdateApp)
	r.Get("/docker", h.DockerInfo)
	r.Post("/docker/enable", h.EnableDocker)
	r.Post("/docker/disable", h.DisableDocker)
	r.Post("/docker/control", h.DockerControl)
	
	r.Get("/email", h.EmailInfo)
	r.Post("/domains/{id}/email/enable", h.EnableEmail)
	r.Post("/domains/{id}/email/disable", h.DisableEmail)
	r.Post("/mailboxes", h.CreateMailbox)
	r.Delete("/mailboxes/{id}", h.DeleteMailbox)
	r.Post("/mailboxes/{id}/password", h.SetMailboxPassword)
	
	r.Get("/stats", h.Stats)
}



func mountFiles(r chi.Router, h *handlers.Handlers) {
	r.Post("/list", h.FilesList)
	r.Post("/mkdir", h.FilesMkdir)
	r.Post("/newfile", h.FilesNewFile)
	r.Post("/delete", h.FilesDelete)
	r.Post("/rename", h.FilesRename)
	r.Post("/move", h.FilesMove)
	r.Post("/copy", h.FilesCopy)
	r.Get("/download", h.FilesDownload)
	r.Post("/upload", h.FilesUpload)
}





func trustedRealIP(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if host, _, err := net.SplitHostPort(r.RemoteAddr); err == nil {
			if ip := net.ParseIP(host); ip != nil && ip.IsLoopback() {
				if xr := strings.TrimSpace(r.Header.Get("X-Real-IP")); xr != "" {
					r.RemoteAddr = net.JoinHostPort(xr, "0")
				} else if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
					parts := strings.Split(xff, ",")
					r.RemoteAddr = net.JoinHostPort(strings.TrimSpace(parts[len(parts)-1]), "0")
				}
			}
		}
		next.ServeHTTP(w, r)
	})
}


func securityHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		h := w.Header()
		h.Set("X-Content-Type-Options", "nosniff")
		h.Set("X-Frame-Options", "DENY")
		h.Set("Referrer-Policy", "no-referrer")
		
		h.Set("Content-Security-Policy",
			"default-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'self'; form-action 'self'")
		next.ServeHTTP(w, r)
	})
}

func requestLogger(log *slog.Logger) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, req *http.Request) {
			next.ServeHTTP(w, req)
			log.Info("http",
				slog.String("method", req.Method),
				slog.String("path", req.URL.Path),
			)
		})
	}
}
