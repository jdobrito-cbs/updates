# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## O que é o WSRTA

Painel de controle de hospedagem **self-hosted**, de uso interno (NÃO é vendido, NÃO há
revendedores). Dois papéis apenas:

- **admin** — opera o host inteiro: cria/remove contas, define cotas, vê tudo.
- **client** — gerencia só os próprios recursos, totalmente isolado dos demais.

Roda em **Ubuntu Server**. Cada cliente é isolado em um **container LXC/LXD** (`cli_<id>`) —
não usuário Linux compartilhado, não Docker. MVP gerencia: Web (Nginx + PHP-FPM por
container), DNS (PowerDNS + PostgreSQL no host), SSL (acme.sh/Let's Encrypt no host), Banco
(MariaDB por container) e Cron. **Email está fora do MVP.**

Plano completo: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md). Setup: [README.md](README.md).

## Princípio inviolável (leia antes de qualquer mudança)

> **A API web NUNCA executa comandos de sistema.**

A API valida, aplica regras e **enfileira uma ação** na tabela `actions` (Postgres). O
**daemon orquestrador** — único processo com `root` — consome a fila, **revalida** e executa.
API e daemon são processos/usuários distintos: a API roda sem privilégios; só o daemon toca o
sistema. Uma falha/RCE na API não pode virar root no host. **Não** adicione chamadas a
`lxc`/`exec`/arquivos do sistema na camada `api/` — isso quebra o modelo de segurança.

## Regras de segurança que valem para todo código

- **Sem injeção de shell**: chamadas a `lxc exec`/processos usam `exec.Command(name, args...)`
  com argumentos **separados**. Nunca concatenar string nem `sh -c "<interpolação>"`.
- **Validação em duas camadas**: a API valida na borda; o daemon revalida o payload.
- **Autorização (regra de ouro)**: todo endpoint de cliente confere no middleware que o
  recurso pertence ao `client_id` do token. IDs vindos de URL/body nunca são confiáveis sem
  checar posse. Nunca confie em `client_id` enviado pelo cliente.
- **`lxc_container_name`** e nomes derivados são gerados/validados pelo servidor, nunca
  aceitos crus.
- Senhas com **argon2id**; JWT com expiração curta; rate-limit no login; segredos só por env
  (`.env` em dev); nada sensível em query string; nada hardcoded.
- Executores do daemon são **idempotentes**, com **rollback** quando possível, e **logam cada
  passo** (slog) com o `action_id` para rastreio ponta a ponta.

## Arquitetura (resumo)

```
HOST Ubuntu
├── API web (Go, chi, sem root) ──INSERT──► actions (Postgres) ◄──SKIP LOCKED── Daemon (Go, root)
│                                + nudge via socket Unix                              │
├── PostgreSQL (dados do painel + fila)                          lxc/LXD, nginx, acme │
├── Nginx host (termina TLS, reverse-proxy por hostname)                              ▼
├── PowerDNS (backend Postgres) + acme.sh                                    HOST + containers
└── Containers LXC: nginx + php-fpm + mariadb + cron (um por cliente)
```

Fluxo do visitante: `visitante → Nginx host (TLS) → reverse-proxy pelo hostname → container`.

Fila: a API faz `INSERT` em `actions` (`pending`) + *nudge* de 1 byte no socket Unix
(best-effort). O daemon reivindica com `SELECT ... FOR UPDATE SKIP LOCKED`, marca `running`,
executa o executor do `ActionType`, grava `done`/`failed` + `result`. Há poll de fallback
(~1s), então o socket é só latência, não correção — a API funciona com o daemon caído.

## Layout do monorepo

**Módulo Go único** na raiz (`github.com/jdobrito/wsrta` — placeholder, confirmar). Código
compartilhado entre API e daemon fica em **`internal/` no topo** (a regra de `internal/` do Go
impede `api/internal` ↔ `daemon/internal`, por isso o que é comum sobe para a raiz).

```
internal/   core (modelos + Action/ActionType/ActionStatus), config, db (pgx), queue
api/        cmd/api/main.go; internal/{server,handlers,auth}     — sem root
daemon/     cmd/daemon/main.go; internal/{consumer,executors,lxd,services} — root
web/        React + TS + Tailwind + Vite (Fase 6)
migrations/ SQL golang-migrate (NNNN_*.up.sql / *.down.sql)
docs/       ARCHITECTURE.md, SECURITY.md
```

## Modelo de dados (tabelas)

`users`(role admin|client) · `clients`(user_id, lxc_container_name, limites cpu/ram/disco) ·
`domains`(client_id, fqdn, docroot, php_version, ssl_enabled) · `databases`(client_id,
db_name, db_user) · `dns_records`(domain_id, type, name, content, ttl, prio) ·
`cron_jobs`(client_id, schedule, command, enabled) · `ssl_certs`(domain_id, issuer,
expires_at, status) · **`actions`**(type, payload JSONB, status pending|running|done|failed,
result, requested_by, created_at, finished_at) — a fila.

## Tipos de ação do daemon

`provision_client` · `deprovision_client` · `add_domain` · `remove_domain` · `issue_ssl`
(DNS-01 via PowerDNS, fallback HTTP-01) · `create_database`/`drop_database` (via `lxc exec`) ·
`set_dns_record`/`delete_dns_record` (backend Postgres do PowerDNS) ·
`set_cron`/`remove_cron` (crontab via `lxc exec`).
Fase 4b: `install_wordpress`/`remove_wordpress` (wp-cli via `lxc exec`; raiz ou subpasta).
SFTP: `enable_sftp`/`disable_sftp` (usuário SFTP no container + proxy de porta do host via LXD).
Backup: `backup_client` (daemon monta o `.tar.gz` do cliente: `mysqldump` + `tar` dos docroots via `Exec`/`PullFile`).
Cloudflare: `set_cloudflare` (cloudflared service install <token>) · `control_cloudflare` (systemctl start|stop|restart cloudflared).
Migração/restore: `restore_database`/`restore_files` (restauram dump/arquivos — de um backup do CyberPanel **ou** de um backup do WSRTA).
Apps (Fase 5, VPS Completo): catálogo em **código** (`internal/core/apps.go`: phpbb=PHP, n8n/evolution=Docker). `install_phpbb`/`remove_phpbb` (app PHP no docroot, igual ao WordPress; baixa o phpBB + banco dedicado; o assistente final roda no navegador `/install`). **Liberação em camadas** (tabela `app_allowed`): o **admin** libera quais apps as **revendas** e os **clientes diretos do admin** veem; a **revenda** libera quais (⊆ do que o admin liberou às revendas) os **clientes dela** veem. `app_installs` registra o instalado por VPS. Rotas: `GET/POST/DELETE <root>/apps` (cliente/admin/revenda/self), `GET/PUT /api/admin/apps`, `GET/PUT /api/reseller/apps`. Fase 7b — **Polimento cPanel + mailcow no instalador**: (1) `web/src/components/FeatureGrid.tsx` — grade de atalhos por seção na Visão geral do cliente (estilo cPanel; tiles "complete" só no VPS Completo). (2) `scripts/install.sh` ganhou `install_mailcow()` **opcional** (`INSTALL_MAILCOW=yes` + `MAILCOW_HOSTNAME`): Docker no host + clone do mailcow-dockerized + `generate_config.sh` não-interativo (env) + web em **8080/8443** (as 80/443 são do painel) + `docker compose up -d`; imprime instruções. Desligado por padrão. Aviso: Docker no host pode colidir com a rede do LXD.

Fase 7a — **Revenda = admin pleno dos clientes dela**: o grupo `/reseller/clients/{client_id}` recebeu o **mesmo conjunto de rotas de recurso** do admin via `mountClientResources(r, h)` (helper em server.go, reusado; posse garantida por `ResellerOwnsClient`). Frontend: `ResellerClientDetailPage` (reusa os painéis com `root=/api/reseller/clients/:id`); botão "Gerenciar" na lista de clientes da revenda. Assim a revenda gerencia domínios/DNS/bancos/WordPress/SFTP/backup/Cloudflare/arquivos/cron/apps/Docker/e-mail/energia dos clientes dela, igual ao admin.

Fase 6 — **E-mail próprio (mailcow, VPS Completo)**: servidor mailcow compartilhado no host, integrado pela **API REST** (HTTP de saída, como o MercadoPago — NÃO é comando de sistema; o pacote `api/internal/mailcow` Manager real|fake fica em api/). Admin configura URL + API key (cifrada em `settings`, `GET/PUT /api/admin/mailcow`). E-mail é **por domínio** (`domains.email_enabled`): habilitar cria o domínio no mailcow + **MX/SPF/DKIM/DMARC** no DNS (cria `dns_records` + enfileira `set_dns_record`; DKIM vem do mailcow). **Caixas** (tabela `mailboxes`, espelho) com **cota** `clients.max_mailboxes` (0=ilimitado) — definida pelo admin no cadastro/edição do cliente, no **pacote** (`packages.max_mailboxes`) e na **revenda** (para uso próprio, na VPS pessoal dela). Rotas `<root>/email`, `<root>/domains/{id}/email/enable|disable`, `<root>/mailboxes[/{id}[/password]]` (client/admin/reseller/self). `EmailPanel` + config mailcow na página Configurações. Webmail = `<mailcow>/SOGo`. Dev: mailcow fake quando `WSRTA_LXD_DRIVER=fake`.

Fase 5b — **Docker por cliente** (Docker-in-LXC, opt-in): `enable_docker`/`disable_docker` (liga `security.nesting` via `lxd.SetConfig` + reinicia + `systemctl --now docker`; coluna `clients.docker_enabled`). `install_docker_app`/`remove_docker_app` rodam um container do catálogo (n8n/evolution) na VPS e expõem a porta por **proxy do LXD** (host `WSRTA`+porta global única). **Painel Docker** (lista/start/stop/restart/remove containers) via **op síncrona `/docker`** no file service do daemon (whitelist ps/start/stop/restart/rm; nome validado — sem docker arbitrário). `docker.io` na imagem golden (desligado por padrão). Apps Docker instalam pela aba **Apps** (exigem Docker habilitado); o painel **Docker** gerencia os containers.
Manutenção do host (admin): `system_update` (apt update+upgrade) · `panel_update` (scripts/update.sh) · `restart_service` (systemctl restart de uma **whitelist** de unidades).
Energia da VPS: `power_client` (op start|stop|restart no container; NÃO mexe no status administrativo). Escopo: cliente (própria VPS), revenda (VPS dos clientes dela), admin (qualquer cliente). Exclusão em cascata: ao apagar um revendedor o admin desprovisiona **todos** os clientes da revenda (cada um vira `deprovision_client`).
Limites: `apply_limits` (resize a quente de cpu/ram/disco de um container existente via LXD config; `lxd.Client.SetLimits`). Usado quando o admin ajusta os limites de um cliente ou da VPS pessoal de uma revenda.
Autogestão (VPS pessoal): admin e revenda gerenciam um container PRÓPRIO como cliente. É uma linha normal em `clients` com `owner_user_id` = user do dono (+ usuário de apoio role=client); escondida das listas (`owner_user_id IS NULL`). Rotas `/api/self/*` (`RequireAdminOrReseller` + `WithSelfTenant`) resolvem o container pelo `owner_user_id` do **token** (nunca id na URL) e reusam os handlers de cliente via `targetClientID` (precedência via contexto). Criada/provisionada **automática no cadastro** (revenda no `CreateReseller` com os limites do admin; admin no `setup`/lazy `activate`). Limites da revenda (cpu/ram/disco/domínios/bancos/banda + `max_clients`) definidos pelo **admin** no cadastro/edição da revenda; só o admin ajusta a própria (`PUT /self/limits`).

## Endpoints (esboço)

Auth: `POST /api/auth/login|logout`, `GET /api/auth/me`.
Admin: `GET/POST/DELETE /api/admin/clients`, `GET /api/admin/actions`, `GET /api/admin/system`,
`POST /api/admin/clients/:id/sftp/enable|disable`, import do CyberPanel
(`GET /api/admin/import/cyberpanel/backups`, `POST .../preview`, `POST .../import`),
backup por cliente (`GET/POST /api/admin/clients/:id/backups`,
`GET .../backups/:id/download`, `POST .../backups/:id/restore`,
`POST .../backups/restore-upload`, `PUT .../backup-schedule`),
config do sistema (`GET/PUT /api/admin/settings`).
Cliente **e** admin (via `targetClientID`): Cloudflare (`GET /cloudflare`,
`POST /cloudflare/set`, `POST /cloudflare/control`).
Cliente (escopado ao próprio `client_id`): `GET /api/domains` (**só lista** — criar/excluir
domínio é exclusivo do admin), `POST /api/domains/:id/ssl`, `GET/PUT /api/domains/:id/rules`,
`GET/POST/DELETE /api/databases`, `GET/POST/DELETE /api/cron`, `GET /api/sftp` (instruções de
acesso), `GET /api/stats`, `GET /api/monitoring`. **DNS é admin-only** (fora do escopo do
cliente). Sobre: `/admin/about` e `/client/about` (página estática, sem API).

## Comandos

```bash
cp .env.example .env
docker compose -f docker-compose.dev.yml up -d   # Postgres do painel + Postgres do PowerDNS
make migrate-up                                  # / make migrate-down
make run-api                                     # API web
make run-daemon                                  # daemon; em dev: WSRTA_LXD_DRIVER=fake
make build                                       # go build ./...
make test                                        # go test ./...
make lint                                        # go vet ./... + gofmt
cd web && pnpm install && pnpm dev               # frontend (Fase 6)
```

Rodar um único teste:
```bash
go test ./daemon/internal/executors -run TestProvisionClient -v
```

## Como trabalhar neste repo (workflow obrigatório)

Desenvolvimento **em fases**, com **gate de revisão ao fim de cada uma**:

1. ✅ **Fundação** — monorepo, migrations, modelos, fila com executores **stub** (só logam).
2. ✅ **Provisionamento** — `provision_client`/`deprovision_client`, imagem golden `wsrta-base`, driver LXD real|fake.
3. ✅ **Web + SSL** — `add_domain`/`remove_domain`/`issue_ssl`, reverse-proxy no host, acme.sh (HTTP-01).
4. ✅ **DB, DNS, Cron** — `create_database`/`drop_database`, `set_dns_record`/`delete_dns_record` (PowerDNS), `set_cron`/`remove_cron`.
4b. ✅ **WordPress** — install/remove via **wp-cli** no container (raiz ou subpasta); **DB dedicado** gerado (senha interna no wp-config); senha do admin **fornecida pelo cliente**. Tabela `wordpress_installs`; ações `install_wordpress`/`remove_wordpress` (self-contained, reusam `WebDeps`); rotas client + admin (`/wordpress`); wp-cli + php-cli/php-mysql na imagem golden. `WordPressPanel` (aba no detalhe do cliente e no painel do cliente).
5. ✅ **API completa + Auth/RBAC** — JWT Bearer + argon2, RBAC admin/cliente, posse por `client_id`.
6a. ✅ **Frontend admin** — React/TS/Tailwind/Vite (`web/`), tema Console, login + clientes/fila/sistema.
Round extra: ✅ **2FA obrigatório (TOTP+recovery, reset pelo admin)**, **admin gerencia recursos de cada cliente** (rotas `/api/admin/clients/:id/*`; handlers compartilhados via `targetClientID`), **CRUD de clientes (busca+edição)**, UI rica (lucide, dashboard, toasts, abas). ✅ **`suspend/resume` de cliente** (executores + endpoints + botões). Login 2FA: `/api/auth/login` → `stage` enroll|mfa + token pré-2FA → `/api/auth/2fa/{enroll,verify}`. Painéis parametrizados por `root` (`web/src/components/panels/*`), reusados por admin e cliente.
6b. ✅ **Frontend cliente** — layout próprio + os mesmos painéis com `root="/api"` (domínios, DNS, bancos, cron, stats).
7. ✅ **Migrador CyberPanel → WSRTA** — backup **nativo** (.tar.gz por site), **1 site → 1 cliente**. Ações `restore_database`/`restore_files` no daemon (cria o banco com a **senha original** do CyberPanel → o `wp-config` do WordPress funciona sem editar; restaura os arquivos no docroot). Lógica reutilizável no **pacote `api/internal/migrate`** (`ParseBackup`, `InspectBackup` streaming-rápido p/ preview, `PrepareClient`+`EnqueueRestores`, `MigrateWebsite`), usada pela CLI `api/cmd/wsrta-migrate` **e** pela API. Enfileira na ordem provision→add_domain→dns→restore_database→restore_files (daemon serial). **WordPress = arquivos+DB+senha preservada (NÃO depende da Fase 4b)**. Parser **confirmado em backup real** (v2.3; raiz `<metaFile>`; backup plano: `meta.xml` + `<db>.sql` + `public_html/` + certs). **Senha do banco = HASH MySQL** (`*HEX`) → restore recria o usuário com `IDENTIFIED BY PASSWORD '<hash>'` (MariaDB). DNS/SSL não vêm nesse backup (cliente re-emite SSL pelo painel). Ver [[cyberpanel-migration]].
   - **Restore pelo painel admin** (página "Importar"): lista os `.tar.gz` em `WSRTA_BACKUP_DIR`, faz **preview** (InspectBackup) e **importa**. O handler cria cliente/domínio/DNS/bancos na hora e **devolve o login (senha 1x)**; a extração pesada + os restores rodam em **goroutine** (a API não toca o sistema — só I/O de arquivo + fila; o daemon faz o restore no container). Acompanha pela Fila.
8. ✅ **SFTP por cliente** — admin habilita SFTP (usuário+senha = a do cliente) no detalhe do cliente; o cliente só vê as instruções (host/porta/usuário + "senha = a que lhe foi informada"). Container ganha `openssh-server`; usuário com home `/var/www` no grupo `www-data`; **proxy do LXD** expõe `<host>:<porta>` (porta = `WSRTA_SFTP_BASE_PORT`+client_id) → container:22. Colunas `sftp_*` em `clients`; `lxd.Client.AddProxyDevice/RemoveDevice`.
9. ✅ **Backup por cliente** (admin-only; manual + agendado; restore **sobre o cliente existente**) — ação `backup_client` (daemon monta o `.tar.gz`: `mysqldump` por banco + `tar` do docroot puxado via `lxd.PullFile`; `manifest.json` no `core`). API: listar/criar/baixar/`restore`/`restore-upload`/`backup-schedule`. Restore reusa `restore_database`/`restore_files` (a API extrai o arquivo e enfileira; `restore_database` **não troca a senha** quando o hash vem vazio). Agendador (`daemon/internal/scheduler`) enfileira diário/semanal. Tabela `backups` + `clients.backup_schedule`. `BackupPanel` (aba no detalhe do cliente). Verificado ao vivo (fake).
10. ✅ **UI: modais próprios** — `Modal` (portal/blur/Esc) + `useConfirm()` (Promise) substituem **todos** os `window.confirm`. `ConfirmProvider` no `main.tsx`.
12. ✅ **Configurações do sistema (admin)** — página **Configurações**: **logoff automático** (minutos; TTL do JWT + timer de inatividade no `AuthContext`) e **domínio do painel** (usado como host público, ex.: SFTP). Tabela `settings` (linha única); `GET/PUT /api/admin/settings`; `/auth/me` e a sessão devolvem `session_timeout_minutes`.
13. ✅ **Cloudflare Tunnel por cliente** — túnel individual no container via **cloudflared**. Cliente (e admin, no detalhe do cliente) cola o **token do conector** e faz **iniciar/parar/reiniciar**. Ações `set_cloudflare` (`cloudflared service install <token>`) e `control_cloudflare` (`systemctl start|stop|restart cloudflared`). Coluna `clients.cloudflare_status` (token **não** é gravado no painel — fica só no container). `cloudflared` na imagem golden. `CloudflarePanel({root, asAdmin})` (página no cliente + aba no admin). Verificado ao vivo (fake).
11. ✅ **Instalador (VPS/servidor)** — `scripts/install.sh` (bash único, root no Ubuntu): instala Go/Node/LXD/Postgres/nginx, builda a imagem golden, cria DBs + roda migrations + schema PowerDNS, **compila** api/daemon/frontend, gera env+segredos, **cert self-signed**, nginx do painel por **HTTPS local em `:PANEL_PORT` (8443)**, serviços **systemd** (api sem root, daemon root) e 1º admin. Acesso por `https://<IP>:8443`.

Regras de processo:
- Ao **iniciar** uma fase, **liste os arquivos** que vai criar/alterar **antes** de codar.
- **Pergunte antes** de qualquer decisão de design não especificada; não invente endpoints
  externos nem dependências.
- Ao **fim** de cada fase, **atualize o README.md** e **pare para revisão**.
- Código idiomático; comente os pontos de segurança.

## Decisões de design já tomadas (não reabrir sem pedir)

- **1 módulo Go** único; compartilhado em `internal/` na raiz. **Go 1.26+** (exigido pelo `canonical/lxd`).
- Path do módulo: `github.com/jdobrito/wsrta` (placeholder — confirmar com o usuário).
- Router **chi**; hash **argon2id**; JWT `golang-jwt/jwt/v5`; Postgres via **pgx/v5**;
  migrations **golang-migrate**; logging **slog**; config via `caarlos0/env` + `godotenv` (dev).
- Fila: socket Unix só *nudge*; verdade no Postgres com `FOR UPDATE SKIP LOCKED` + poll de fallback.
- Driver LXD selecionável por env `WSRTA_LXD_DRIVER=real|fake` (interface `lxd.Client` + fake in-memory p/ dev/teste).
- **Provisionamento**: imagem golden `wsrta-base` (build em `scripts/build-base-image.sh` / `make build-base-image`, roda no host). Provision lança dela. Payload = `client_id`; o daemon busca a linha autoritativa em `clients` e atualiza `clients.status` via `daemon/internal/store`. Envs: `WSRTA_LXD_SOCKET|IMAGE|STORAGE_POOL|NETWORK`.
- **Web + SSL**: Nginx do host gerenciado por arquivos de vhost + reload (`daemon/internal/nginx`); acme.sh via CLI (`daemon/internal/acme`, **HTTP-01/webroot**; DNS-01 ainda não adotado — ver decisão da Fase 4). Reverse-proxy usa o **IP atual** do container (`lxd.Address`). `lxd.Client` ganhou `Exec`/`PushFile`/`Address`. nginx/acme caem para fake quando `WSRTA_LXD_DRIVER=fake`. Payloads = `domain_id`. Envs `WSRTA_NGINX_*`/`WSRTA_ACME_*`/`WSRTA_DOMAIN_DOCROOT_BASE`. `remove_domain` preserva o docroot.
- **API/Auth (Fase 5)**: `api/internal/auth` (argon2id em `password.go`; JWT HS256 Bearer em `jwt.go`; `RequireAuth`/`RequireAdmin`/`RequireClient` + rate-limit no login). **Posse (regra de ouro)** via queries escopadas por `client_id` em `api/internal/store` (`GetXOwned` → `ErrNotFound` se não for dono). Handlers gravam no painel **e** enfileiram a ação (requested_by = user do token); a API nunca toca o sistema. Stats = host via `/proc` + limites/contagens (uso vivo por container adiado). Debug `/debug/actions` removido. **Bootstrapping do 1º admin**: `go run ./api/cmd/create-admin <email> <senha>` (em `api/cmd/create-admin`). Retrofit: `remove_domain` agora apaga a linha do domínio (cascateia dns/ssl). **Testes de integração precisam de `-p 1`** (`make test-integration`) — compartilham o mesmo banco; `go test ./...` paralelo entre pacotes corrompe os dados.
- **DB/DNS/Cron**: `create_database` roda `mysql` via `Exec` (root por unix_socket; identificadores validados [A-Za-z0-9_]); a **senha é gerada pelo daemon** (`secret.go`) e retornada 1x em `actions.result` (caveat de persistência — hardening pendente). DNS escreve **direto no Postgres do PowerDNS** (`daemon/internal/pdns`, schema gpgsql 4.x sem coluna `prio` — prioridade de MX/SRV vai no content); `EnsureZone` cria SOA/NS. Cron = arquivo `/etc/cron.d/wsrta-<id>` via `PushFile` (schedule/command validados: sem `\n`). DNS-01 **mantido fora** (só HTTP-01). Backend PowerDNS cai para fake quando `WSRTA_LXD_DRIVER=fake`. Envs `WSRTA_PDNS_*`/`WSRTA_CRON_USER`. Schema do PowerDNS: `deploy/powerdns/schema.sql`.
- **Frontend (`web/`, Fase 6a)**: React 18 + TS + Tailwind v3 + Vite; **npm** (não pnpm). Estado de servidor com **@tanstack/react-query** (polling da fila), rotas com **react-router-dom**, auth Bearer em `AuthContext` (token no `localStorage`, `setAuthToken` no client). Tema **Console** (grafite + cor semântica por status; tokens em `tailwind.config.js`); fontes self-hosted via `@fontsource` (Space Grotesk/IBM Plex Sans/Mono). **Assinatura** = `StatusRail` (fila pending→running→done). Listas do Go vêm `null` quando vazias → hooks fazem `?? []`. Dev: `web/vite.config.ts` faz proxy de `/api` p/ `localhost:8080`; prod = same-origin. Verificação: `npm run build` (tsc --noEmit + vite build).
- **SFTP por cliente**: ação `enable_sftp`/`disable_sftp` (`daemon/internal/executors/sftp.go`, usa `WebDeps`→não, `Deps`): `useradd` (home `/var/www`, shell nologin, grupo `www-data`) + senha via **stdin do `chpasswd`** (sem shell) + `chmod -R g+w /var/www` + **proxy do LXD** (`AddProxyDevice`, `tcp:0.0.0.0:<porta>`→`tcp:127.0.0.1:22`). Porta = `WSRTA_SFTP_BASE_PORT`(30000)+client_id; host mostrado = `WSRTA_SFTP_HOST`. Colunas `sftp_enabled/port/user` em `clients` (migration 0004; lidas em `core.Client` + store da API). API: admin `POST /sftp/enable|disable`, GET `/sftp` (admin e cliente, via `targetClientID`). UI: `SftpPanel({root, canManage})` reusado (aba no admin com form; página do cliente só leitura). `openssh-server` na imagem golden. **Senha = a mesma que o admin deu ao cliente** (admin a informa ao habilitar; cliente só vê "senha = a que lhe foi informada").
- **Import/restore CyberPanel pelo painel**: pacote `api/internal/migrate` (refatorado do CLI; `InspectBackup` = preview rápido streaming). Handlers `api/internal/handlers/import.go`: `ListBackups` (lista `WSRTA_BACKUP_DIR`, valida nome sem path-traversal), `PreviewBackup`, `ImportBackup` (cria cliente síncrono→devolve login+senha 1x; extração+restores em **goroutine**, staging em `WSRTA_MIGRATE_STAGING`). Rotas em `/api/admin/import/cyberpanel/*`. UI: página **Importar** (`web/src/pages/admin/ImportPage.tsx`) na nav do admin. Helper `api/cmd/create-client <email> <senha> [nome]` para bootstrap de cliente (paralelo ao create-admin).
- **Backup por cliente**: **admin-only**, **manual + agendado** (diário/semanal), restore **SOBRE o cliente existente**. Ação `backup_client` (`daemon/internal/executors/backup.go`, `BackupDeps`): por banco `mysqldump` (stdout, texto) + hash do usuário (`SELECT Password FROM mysql.user` → preserva a senha no restore); por domínio `tar -czf` num temp do container e `lxd.PullFile` (binário-seguro, novo método na interface). Bundle host-side → `WSRTA_CLIENT_BACKUP_DIR/wsrta-c<id>-<ts>.tar.gz` com `db/<db>.sql` + `files/<fqdn>.tar.gz` + `manifest.json` (`core.BackupManifest`). Store `daemon/internal/store/backups.go` + `api/internal/store/backups.go`. **Restore reusa `restore_database`/`restore_files`**: handlers `api/internal/handlers/backup.go` extraem o arquivo (`migrate.ExtractTarGz`) e enfileiram (garantem linhas de painel que faltem); `restore_database` ajustado para **não alterar usuário/senha quando o hash vem vazio**. Download/upload com Bearer via `apiDownload`/`apiUpload` (`web/src/api/client.ts`). Agendador `daemon/internal/scheduler` (tick 30min; due por `last_backup`). `BackupPanel({root})` (aba admin). Migration 0005 (`backups` + `clients.backup_schedule`).
- **Modais (UI)**: `web/src/components/ui/Modal.tsx` (portal, backdrop blur, fecha no Esc/clique-fora, `title` opcional) + `ConfirmDialog.tsx` (`ConfirmProvider` + `useConfirm()` por **Promise**). Todos os `window.confirm` viraram `await confirm({title, message, confirmLabel, danger})`. `ConfirmProvider` montado no `main.tsx` (dentro do `ToastProvider`). Cores de status do tema são `done/failed/pending/running` (NÃO `status-*`).
- **Ajustes de UX/firewall (Expansão Fase 10)**: **(limites)** domínios/bancos são **só por cliente** (coluna em `clients`; `limits.go` usa só `c.MaxDomains`/`MaxDatabases`, 0 = ilimitado) — **removido** o global generalizado da página Configurações. **(design)** a identidade dos demos foi para os componentes do app: tokens `accentStrong`/`onAccent` (CSS vars), `Button` primário com **gradiente**, `Card` `rounded-xl`+sombra, `Input` `rounded-lg`, e o **Login** com fundo em gradiente + logo. **(firewall)** gerência de **fail2ban** (listar jails/IPs banidos + **desbloquear**/banir) e **CSF+LFD** (deny/allow/temp + allow/deny/unblock + start/stop/restart dos serviços) via `daemon/internal/firewall` (Manager **real|fake**) exposto pelo **file service síncrono** (`/fw/state`,`/fw/action`; `fileclient.FirewallState/Action`); handlers admin `GET /api/admin/firewall` + `POST /api/admin/firewall/action` (valida IP/CIDR, jail, whitelist de serviço/op). UI: `FirewallPanel` na página Segurança. Verificado ao vivo (fake). **(domínio: 2 acessos)** o olho do `DomainsPanel` abre um menu: **pelo domínio** (`https://fqdn`) e **pelo servidor** (`<painel>/_preview/<fqdn>/`, redirecionamento interno sem o DNS — o roteamento `/_preview/` no host nginx fica como peça host-only a wirar). **(monitoramento)** removida a página/menu **Sistema** (a **Carga/load average** foi para Monitoramento via `useSystem`); donuts agora detalham **CPU** (modelo/tipo/geração + núcleos, `sysinfo.CPUDesc` de `/proc/cpuinfo`), **Memória** e **Disco** (usado/total) — no admin e no cliente.
- **Política de domínios/DNS + tema + layout + Sobre (Expansão Fase 9)**: **(política, decisão do TI)** o **cliente NÃO cria/exclui domínios nem máquinas, e NÃO administra DNS** — isso é exclusivo do **admin**. O cliente só **gerencia** os domínios que o admin criou para ele (SSL + regras do site), além de bancos, WordPress (**só nos domínios dele**; o admin instala em qualquer domínio via `targetClientID`), SFTP, Cloudflare, Arquivos, Cron. Enforcement: o grupo `RequireClient` em `server.go` **perdeu** `POST/DELETE /domains` e **todas** as rotas de DNS (verificado ao vivo: `POST /api/domains`→405, `DELETE`/DNS→404; admin segue 401). UI: `DomainsPanel({root, canManage})` — `canManage` só no admin (esconde criar/excluir); nav do cliente sem DNS; rota `/client/dns` removida. **(layout definitivo)** o visual dos protótipos (`demo/`) virou o do app React: **tema claro/escuro** (padrão escuro, persistido) via **CSS vars em canais RGB** (`index.css` `:root`/`[data-theme=light]`) + tokens do Tailwind como `rgb(var(--c-x) / <alpha-value>)` (mantém `bg-x/NN`); `lib/theme.ts` + script anti-flash no `index.html`. **`AppShell`** reescrito: nav **agrupada** (`NavGroup[]`) com grupos recolhíveis, **recolher** no desktop (rail, persistido), **drawer automático ≤1100px** (celular/tablet: barra fora da tela + hambúrguer + scrim, fecha ao navegar/redimensionar — breakpoint `desk` no Tailwind), topbar com toggle de tema. **(Sobre)** página `AboutPage` (admin + cliente): nome/descrição do sistema + criador **Jorge Brito** (Full Stack; Jogos Eletrônicos; Gestão de Projetos; jdbrito@uea.edu.br; LinkedIn jorge-obrito).
- **Dashboard + Monitoramento + Reiniciar serviços (Expansão Fase 8)**: três frentes, todas com **leitura de sistema na própria API** (de `/proc`, `/sys`, `net`, `syscall` — LEITURA, não execução; coerente com o princípio) e **mutações via fila/daemon**. **(1) Dashboard admin**: `GET /api/admin/dashboard` (`store.Dashboard` — totais de domínios/bancos/WordPress + contagem por cliente; `sysinfo.PrimaryIP`); UI com cards (IP/totais) + 2 gráficos de barra (domínios/cliente, bancos/cliente). **(2) Monitoramento**: pacote `internal/sysinfo` (OS via `/etc/os-release`+`uname`; Mem `/proc/meminfo`; Disk `statfs`; Network `net.Interfaces`+`/proc/net/route`+`/etc/resolv.conf`; CPU `/proc/stat`; net `/proc/net/dev`). `api/internal/monitor.Sampler` = goroutine na API (tick 2s) que mantém CPU%/throughput em memória e **acumula a banda diária** em `bandwidth_daily` (migration 0012, flush ~30s, ignora reset de contador). `GET /api/admin/monitoring` (SO+rede+cpu/mem/disco+rx/tx, poll 2s), `GET /api/admin/monitoring/bandwidth` (30 dias), **cliente** `GET /api/monitoring` (só cpu/mem/disco). UI `MonitoringPage` (admin-only na nav): 3 donuts, linha em tempo real (cpu/mem/disco 0–100%), boxes de SO e placa de rede, linha de banda em tempo real + barras de banda/dia, e **2 botões de update**. Cliente: `SystemDonuts` (cpu/mem/disco) na Visão geral. **Gráficos com Recharts** (`web/src/components/charts/Charts.tsx`: `BarCard`/`DonutGauge`/`RealtimeLine`; paleta do tema). **(3) Atualizar o sistema** (no Monitoramento, 2 botões): ações `system_update` (apt) e `panel_update` (`update.sh` em `WSRTA_REPO_DIR`=`/opt/wsrta/src`, o instalador copia o fonte p/ lá). **(4) Reiniciar serviços** (em Configurações, admin): ação `restart_service` com **whitelist** `core.RestartableServices` (nginx, wsrta-api, wsrta-daemon, postgresql, pdns) — validada na API **e** revalidada no daemon (nunca nome livre → sem injeção de unidade). As 3 ações de host ficam em `daemon/internal/hostctl` (Manager **real|fake** por `WSRTA_LXD_DRIVER`; Real usa `exec.Command` no host com args separados); executores em `daemon/internal/executors/host.go` (`HostDeps`). Verificado ao vivo (fake): dashboard SQL, sampler gravou banda real de `/proc/net/dev`, e `system_update`/`panel_update`/`restart_service` (whitelist barrou nome malicioso).
- **WordPress Manager Pro (Expansão Fase 7)**: gerência de uma instalação WP via **wp-cli síncrono**, reusando o **file service do daemon** (a API autoriza/escopa; o daemon root executa — o princípio se mantém). `fileapi.Backend.WP(container, dir, args)` roda `wp --allow-root --path=<dir> <args>` no container; `cleanAbs` **clampa o dir a `/var/www`** (sem `..`); rota `/wp` no socket; `fileclient.WP`→`WPResult{Stdout,Stderr,Exit}`. **Sem wp-cli arbitrário**: a API monta os args de uma **whitelist** (`wpArgs`: target plugin|theme|core × action activate|deactivate|delete|update|install; slug `^[a-z0-9][a-z0-9.-]{0,80}$`). Handlers: `WPManagerInfo` (GET — core version + `plugin list`/`theme list --format=json`, devolve `[]` se vazio/inválido) e `WPManage` (POST `{target,action,slug}` → 422 com stderr se `exit!=0`). Resolve dir+container por `GetWordPressInstallOwned`+`GetClient` (posse via `targetClientID`). Rotas `GET /wordpress/:id/manager` + `POST /wordpress/:id/manage` (cliente e admin). UI: `WordPressManager` (modal, botão **Gerenciar** no `WordPressPanel`) — core update, tabela de plugins (ativar/desativar/atualizar/excluir/instalar) e temas. Verificado ao vivo via socket (fake: 200/exit 0 + clamp de path 403; saída real do wp-cli só no host).
- **Fast nginx por cliente (Expansão Fase 6, admin-only)**: toggle que liga/desliga aceleração nos sites do cliente. Ação `set_fast_nginx` (`Deps`): grava/remove `/etc/nginx/conf.d/wsrta-fast.conf` **no container** (gzip + `open_file_cache` + sendfile/tcp tuning + keepalive — http-level, vale para todos os sites do cliente) + `nginx -t` + reload + flag. Coluna `clients.fast_nginx_enabled` (migration 0011). API `POST /api/admin/clients/:id/fastnginx/enable|disable` (**só admin**). UI: card **Fast nginx** na aba Visão do detalhe do cliente (`useSetFastNginx`; lê `client.fast_nginx_enabled`). Verificado ao vivo (fake).
- **Módulo .htaccess (Expansão Fase 5)**: como o container roda **nginx** (não Apache), entregamos as **capacidades** equivalentes por domínio: **PHP directives** (`php_value`/`php_flag`) → `.user.ini` no docroot; **headers de segurança** + **CORS** → diretivos no vhost do container. A API gera o `.user.ini` e os diretivos a partir da **config estruturada** (sem nginx cru do usuário; valida key/header/valor) e enfileira `apply_site_rules` (`DomainID, UserINI, VHostExtra`); o daemon (`WebDeps`) grava o `.user.ini` (`PushFile`), **regenera o vhost** do container com `ContainerVHost.Extra` e valida com **`nginx -t`** antes do reload. Config guardada em `site_rules`(domain_id, config JSONB) (migration 0010). API `GET/PUT /api/domains/:id/rules` (cliente e admin via `ownedDomain`). UI: `SiteRulesEditor` (modal por domínio, botão **Regras** no `DomainsPanel`). Verificado ao vivo (fake). **<1ms de overhead** (nativo no nginx, sem parse por request).
- **phpMyAdmin por cliente (Expansão Fase 4)**: phpMyAdmin **único no host**; ao habilitar para um cliente, o daemon (`set_phpmyadmin`, `PMADeps`) cria o usuário `wsrta_pma`@'127.0.0.1' **no container** (acesso total = só os bancos daquele cliente), expõe o MySQL via **proxy do LXD** (`127.0.0.1:base+id`→container 3306) e escreve `<id>.php` em `WSRTA_PMA_CONFD` (`/etc/phpmyadmin/wsrta.d`) com `auth_type=config` (login automático). `config.inc.php` do host inclui `wsrta.d/*.php` (1 server por cliente, índice = client_id). Coluna `clients.phpmyadmin_enabled` (migration 0009). API `GET /phpmyadmin` (enabled + `open_url=<PMAURL>?server=<id>`), `POST /phpmyadmin/enable|disable` (cliente e admin via `targetClientID`). `PhpMyAdminPanel({root})` junto da aba/página **Bancos**. Instalador instala phpMyAdmin+php-fpm + location `/phpmyadmin` no nginx. Verificado ao vivo (fake): config gerado + flag. **Auth/MySQL real só no host.**
- **File Manager (Expansão Fase 3)**: admin = **host inteiro** (Root File Manager); cliente = **sandbox** no `/var/www` do container dele. Mecanismo: **serviço de arquivos SÍNCRONO no daemon** (`daemon/internal/fileapi`: `Backend` host(os)+container(lxc exec/Push/PullFile) + servidor HTTP sobre **socket Unix** com token). A API (`api/internal/fileclient`) é só **proxy/autorizador** (o princípio se mantém — a API não toca o sistema). `Scope{Mode host|container, Container, Path}`; container clampado a `/var/www` (sem `..`). Operações: list/mkdir/newfile/delete/rename/move/copy/download/upload. Modo definido por middleware (`WithFSHost`/`WithFSContainer`); container resolvido por `targetClientID`. Rotas: `/api/admin/files/*` (host), `/api/files/*` (cliente), `/api/admin/clients/:id/files/*` (admin no cliente). Envs `WSRTA_FILEAPI_SOCKET`/`WSRTA_FILEAPI_TOKEN`. UI: `FileManager({base})` (página admin "Arquivos", aba no detalhe do cliente, página no cliente). **Host real** para o modo container (LXD); modo host verificado ao vivo (listou /etc via socket).
- **Segurança do host (Expansão Fase 2)**: página **Segurança** (admin-only) com toggles **ModSecurity (WAF)**, **CSF+LFD** (firewall + brute-force; substitui o ufw), **fail2ban** e **renovação automática de SSL** (cron do acme.sh). Toggles em `settings` (migration 0008; `UpdateSecurity` grava só esses 4 campos, separado do `UpdateSettings` geral). Ação `apply_security` (`daemon/internal/security` Manager **real|fake** por `WSRTA_LXD_DRIVER`): o **Real** reconcilia cada serviço no host (apt/systemctl/csf/acme.sh, args separados, best-effort + erro por serviço); o **Fake** é no-op. API `GET/PUT /api/admin/security` (PUT salva + enfileira `apply_security`). `SecurityPage` (nav admin). **Só roda de verdade no host Ubuntu**; o brute-force da aplicação (rate-limit de login/2FA) já está sempre ativo.
- **Limites por cliente (Expansão Fase 1)**: domínios e bancos. Padrão **global** em `settings` (`max_domains_per_client`/`max_databases_per_client`, 0 = ilimitado) + **override por cliente** em `clients` (`max_domains`/`max_databases`, 0 = usa o global). Migration 0007. `effectiveLimit(override, global)` + `domainLimitReached`/`databaseLimitReached` (`api/internal/handlers/limits.go`, contam via `CountClientDomains/Databases`) bloqueiam (`403`) em `CreateDomain`/`CreateDatabase`. UI: campos na página **Configurações** (global) e no modal de criar/editar cliente (override). `core.Settings`/`core.Client` ganharam os campos; `UpdateClient` recebe os 2 limites.
- **Configurações do sistema**: tabela `settings` (linha única, migration 0006). `session_timeout_minutes` vira o **TTL do JWT** (`auth.IssueWithTTL`, lido em `issueSession` via `h.sessionMinutes`) **e** um **timer de inatividade** no `AuthContext` (desloga após N min sem `mousemove/keydown/click/scroll/touch`). `panel_domain` é o host público (helper `h.publicHost` — usado nas instruções de SFTP). `GET/PUT /api/admin/settings`; `session_timeout_minutes` volta no `/auth/me` e na resposta de sessão (enroll/verify). Página `web/src/pages/admin/SettingsPage.tsx` + nav.
- **Cloudflare Tunnel por cliente**: 1 túnel por container via **cloudflared** (na imagem golden). Ações `set_cloudflare`/`control_cloudflare` (`daemon/internal/executors/cloudflare.go`, `Deps`): `cloudflared service uninstall` (best-effort) + `service install <token>` (token = arg separado, sem shell) / `systemctl start|stop|restart cloudflared`. **Token NÃO é gravado no painel** — vai só no payload→container (systemd unit); o painel guarda só `clients.cloudflare_status` (''/running/stopped, via `ClientStore.SetClientCloudflareStatus`). API `GET /cloudflare` (status+configured), `POST /cloudflare/set` (token), `POST /cloudflare/control` (op) — em `targetClientID` (cliente gerencia o próprio; **admin gerencia no detalhe do cliente** para ajudar na conexão). `CloudflarePanel({root, asAdmin})` reusado: página no cliente + aba no admin.
- **Auditoria de segurança (correções aplicadas)** — ver [docs/SECURITY.md](docs/SECURITY.md) §6. Invariantes novos: **`WSRTA_JWT_SECRET` ≥ 16 chars ou a API aborta** (`api/cmd/api/main.go`); **`core.ValidFQDN`** (hostname RFC-1123) na API (`CreateDomain`) e revalidado no daemon (`add_domain`/`issue_ssl`) — FQDN nunca vai cru para nginx/paths; **docroot é sempre derivado no servidor** (cliente não envia; daemon clampa a `DocrootBase` em `docrootFor`); **rate-limit também no 2FA**; `decodeJSON` limita o corpo a 1 MiB; `trustedRealIP` (substitui `middleware.RealIP`) só confia em header de peer loopback; cabeçalhos de segurança na API + CSP/ufw no instalador. Restore valida `db.Name`/`fqdn` do manifesto antes de compor caminhos. **Não** reabrir esses pontos sem rever a auditoria.
- **Instalador**: `scripts/install.sh` (root no Ubuntu Server; **compila no servidor**, painel por **IP:porta com HTTPS local/self-signed** — decisões do usuário). Idempotente; vars no topo (`PANEL_PORT=8443`, `ADMIN_EMAIL/PASSWORD`, senhas de DB geradas). Embute nginx/systemd/env via heredoc. API roda como user `wsrta` em `127.0.0.1:8080`; nginx termina TLS na `:8443` e faz proxy de `/api`+`/healthz`; frontend estático em `/var/www/wsrta-panel`. Daemon como root (systemd `wsrta-daemon`), API como `wsrta` (`wsrta-api`); env em `/etc/wsrta/wsrta.env` (640, grupo wsrta). Só validável de fato no host real (LXD). `bash -n` + shellcheck limpos.
- **Update + distribuição (zips)**: `scripts/lib-deploy.sh` (compartilhado por install/update) tem `apply_migrations` (**rastreadas** em `schema_migrations` → atualiza sem apagar dados), `apply_pdns_schema` (guardado) e `build_app` (compila no servidor). `scripts/update.sh` (root): carrega `/etc/wsrta/wsrta.env`, **recompila** api/daemon/frontend, aplica só migrations novas e reinicia os serviços — **preserva DB e config**; `--golden` reconstrói a imagem LXD. `scripts/make-release.sh` gera **`dist/wsrta-install.zip`** (novo) e **`dist/wsrta-update.zip`** (atualização) — só fonte, descompactam em `wsrta/`, compilam no servidor. **Regra: regerar os dois zips a cada mudança de código** (ver [[release-zips-workflow]]).
- **Remoção de comentários no pacote (produção)**: `scripts/strip-comments` (Go, só stdlib) remove comentários **apenas da cópia de release** (o fonte de DEV mantém tudo). Lexer ciente de strings/template-literals/regex (JS/TS) e raw-strings (Go); **preserva** diretivas `//go:`/`// +build` e `/// <reference>`/pragmas `@ts-`. O `make-release.sh` roda o stripper sobre `$DEST` e, como **gate de segurança**, recompila o código stripado (Go `go build` + web `npm ci && build`) antes de zipar — nunca empacota algo quebrado. Suporta `.go/.ts/.tsx/.js/.jsx/.css/.scss/.sql`; **não** mexe em shell (risco de here-docs).

## Idioma

O usuário trabalha em **português (BR)**. Responda e escreva docs/commits em português.
```
