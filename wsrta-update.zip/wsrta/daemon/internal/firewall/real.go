package firewall

import (
	"bufio"
	"context"
	"errors"
	"log/slog"
	"os"
	"os/exec"
	"strings"
)


type Real struct{ log *slog.Logger }


func NewReal(log *slog.Logger) *Real { return &Real{log: log} }

func run(ctx context.Context, name string, args ...string) (string, error) {
	out, err := exec.CommandContext(ctx, name, args...).CombinedOutput()
	return string(out), err
}

func have(bin string) bool { _, err := exec.LookPath(bin); return err == nil }

func isActive(ctx context.Context, unit string) bool {
	out, _ := run(ctx, "systemctl", "is-active", unit)
	return strings.TrimSpace(out) == "active"
}


func fail(out string, err error) error {
	if err == nil {
		return nil
	}
	if m := strings.TrimSpace(out); m != "" {
		return errors.New(m)
	}
	return err
}

func (r *Real) State(ctx context.Context) State {
	st := State{CSF: CSFLists{Deny: []string{}, Allow: []string{}, Temp: []string{}}, Jails: []Jail{}}
	st.Status.Fail2ban = isActive(ctx, "fail2ban")
	st.Status.CSF = have("csf") && isActive(ctx, "csf")
	st.Status.LFD = isActive(ctx, "lfd")
	if st.Status.Fail2ban {
		st.Jails = r.jails(ctx)
	}
	if have("csf") {
		st.CSF = r.csfLists(ctx)
	}
	return st
}

func (r *Real) jails(ctx context.Context) []Jail {
	out, err := run(ctx, "fail2ban-client", "status")
	if err != nil {
		return []Jail{}
	}
	var names []string
	for _, line := range strings.Split(out, "\n") {
		if i := strings.Index(line, "Jail list:"); i >= 0 {
			for _, n := range strings.Split(line[i+len("Jail list:"):], ",") {
				if n = strings.TrimSpace(n); n != "" {
					names = append(names, n)
				}
			}
		}
	}
	jails := make([]Jail, 0, len(names))
	for _, name := range names {
		jails = append(jails, Jail{Name: name, Banned: r.banned(ctx, name)})
	}
	return jails
}

func (r *Real) banned(ctx context.Context, jail string) []string {
	out, err := run(ctx, "fail2ban-client", "status", jail)
	if err != nil {
		return []string{}
	}
	for _, line := range strings.Split(out, "\n") {
		if i := strings.Index(line, "Banned IP list:"); i >= 0 {
			rest := strings.TrimSpace(line[i+len("Banned IP list:"):])
			if rest == "" {
				return []string{}
			}
			return strings.Fields(rest)
		}
	}
	return []string{}
}

func (r *Real) csfLists(ctx context.Context) CSFLists {
	l := CSFLists{
		Deny:  readListFile("/etc/csf/csf.deny"),
		Allow: readListFile("/etc/csf/csf.allow"),
		Temp:  []string{},
	}
	if out, err := run(ctx, "csf", "-t"); err == nil {
		for _, line := range strings.Split(out, "\n") {
			line = strings.TrimSpace(line)
			if line == "" || strings.HasPrefix(line, "A/D") || strings.HasPrefix(line, "csf") {
				continue
			}
			l.Temp = append(l.Temp, line)
		}
	}
	return l
}

func readListFile(path string) []string {
	f, err := os.Open(path)
	if err != nil {
		return []string{}
	}
	defer f.Close()
	out := []string{}
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		out = append(out, line)
	}
	return out
}

func (r *Real) Unban(ctx context.Context, jail, ip string) error {
	return fail(run(ctx, "fail2ban-client", "set", jail, "unbanip", ip))
}
func (r *Real) Ban(ctx context.Context, jail, ip string) error {
	return fail(run(ctx, "fail2ban-client", "set", jail, "banip", ip))
}
func (r *Real) CSFAllow(ctx context.Context, ip string) error {
	return fail(run(ctx, "csf", "-a", ip))
}
func (r *Real) CSFDeny(ctx context.Context, ip string) error {
	return fail(run(ctx, "csf", "-d", ip))
}
func (r *Real) CSFUnblock(ctx context.Context, ip string) error {
	_, _ = run(ctx, "csf", "-dr", ip) 
	_, _ = run(ctx, "csf", "-tr", ip) 
	return nil
}
func (r *Real) Service(ctx context.Context, name, op string) error {
	return fail(run(ctx, "systemctl", op, name))
}
