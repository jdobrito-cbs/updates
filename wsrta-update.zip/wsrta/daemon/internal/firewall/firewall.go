


package firewall

import "context"


type Status struct {
	CSF      bool `json:"csf"`
	LFD      bool `json:"lfd"`
	Fail2ban bool `json:"fail2ban"`
}


type Jail struct {
	Name   string   `json:"name"`
	Banned []string `json:"banned"`
}


type CSFLists struct {
	Deny  []string `json:"deny"`
	Allow []string `json:"allow"`
	Temp  []string `json:"temp"`
}


type State struct {
	Status Status   `json:"status"`
	Jails  []Jail   `json:"jails"`
	CSF    CSFLists `json:"csf"`
}


type Manager interface {
	State(ctx context.Context) State
	Unban(ctx context.Context, jail, ip string) error
	Ban(ctx context.Context, jail, ip string) error
	CSFAllow(ctx context.Context, ip string) error
	CSFDeny(ctx context.Context, ip string) error
	CSFUnblock(ctx context.Context, ip string) error
	Service(ctx context.Context, name, op string) error
}
