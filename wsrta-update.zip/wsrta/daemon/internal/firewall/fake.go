package firewall

import (
	"context"
	"log/slog"
)


type Fake struct{ log *slog.Logger }


func NewFake(log *slog.Logger) *Fake { return &Fake{log: log} }

func (f *Fake) State(_ context.Context) State {
	return State{
		Status: Status{CSF: true, LFD: true, Fail2ban: true},
		Jails: []Jail{
			{Name: "sshd", Banned: []string{"203.0.113.10", "198.51.100.7", "45.146.165.22"}},
			{Name: "wsrta-panel", Banned: []string{"203.0.113.55"}},
			{Name: "nginx-http-auth", Banned: []string{}},
		},
		CSF: CSFLists{
			Deny:  []string{"203.0.113.10 # brute force SSH", "45.146.165.0/24 # scanner"},
			Allow: []string{"192.168.0.0/16 # rede interna", "10.0.0.0/8"},
			Temp:  []string{"198.51.100.7 (LFD: 1h restantes)"},
		},
	}
}

func (f *Fake) Unban(_ context.Context, jail, ip string) error {
	f.log.Info("fake firewall: unban", slog.String("jail", jail), slog.String("ip", ip))
	return nil
}
func (f *Fake) Ban(_ context.Context, _ string, _ string) error     { return nil }
func (f *Fake) CSFAllow(_ context.Context, _ string) error          { return nil }
func (f *Fake) CSFDeny(_ context.Context, _ string) error           { return nil }
func (f *Fake) CSFUnblock(_ context.Context, _ string) error        { return nil }
func (f *Fake) Service(_ context.Context, _ string, _ string) error { return nil }
