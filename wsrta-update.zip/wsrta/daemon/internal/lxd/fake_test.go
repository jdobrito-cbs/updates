package lxd_test

import (
	"context"
	"errors"
	"testing"

	"github.com/jdobrito/wsrta/daemon/internal/lxd"
)

func TestFakeLifecycle(t *testing.T) {
	f := lxd.NewFake()
	ctx := context.Background()
	name := "cli_1"

	if ok, _ := f.Exists(ctx, name); ok {
		t.Fatal("container não deveria existir ainda")
	}

	if err := f.Create(ctx, lxd.ContainerSpec{Name: name, Image: "wsrta-base"}); err != nil {
		t.Fatalf("create: %v", err)
	}
	if ok, _ := f.Exists(ctx, name); !ok {
		t.Fatal("container deveria existir após create")
	}
	if st, _ := f.Status(name); st != lxd.StatusStopped {
		t.Fatalf("status após create = %q, esperava Stopped", st)
	}

	
	if err := f.Create(ctx, lxd.ContainerSpec{Name: name}); err == nil {
		t.Fatal("create duplicado deveria falhar")
	}

	if err := f.Start(ctx, name); err != nil {
		t.Fatalf("start: %v", err)
	}
	if info, _ := f.Info(ctx, name); info.Status != lxd.StatusRunning {
		t.Fatalf("status = %q, esperava Running", info.Status)
	}

	if err := f.Stop(ctx, name); err != nil {
		t.Fatalf("stop: %v", err)
	}
	if err := f.Delete(ctx, name); err != nil {
		t.Fatalf("delete: %v", err)
	}
	if _, err := f.Info(ctx, name); !errors.Is(err, lxd.ErrNotFound) {
		t.Fatalf("esperava ErrNotFound, veio %v", err)
	}
}
