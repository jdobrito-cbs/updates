




package lxd

import (
	"context"
	"errors"
)


var ErrNotFound = errors.New("lxd: container não encontrado")


const (
	StatusRunning = "Running"
	StatusStopped = "Stopped"
)


type ContainerSpec struct {
	Name        string
	Image       string  
	CPULimit    float64 
	RAMLimitMB  int
	DiskQuotaMB int
	StoragePool string
	Network     string
}


type ContainerInfo struct {
	Name   string
	Status string
}



type ExecResult struct {
	Stdout   string
	Stderr   string
	ExitCode int
}



type Client interface {
	Exists(ctx context.Context, name string) (bool, error)
	Create(ctx context.Context, spec ContainerSpec) error 
	Start(ctx context.Context, name string) error
	Stop(ctx context.Context, name string) error 
	Delete(ctx context.Context, name string) error
	Info(ctx context.Context, name string) (ContainerInfo, error)

	
	
	Exec(ctx context.Context, name string, cmd []string, stdin []byte) (ExecResult, error)
	
	PushFile(ctx context.Context, name, path string, content []byte, mode int) error
	
	PullFile(ctx context.Context, name, srcPath, dstPath string) error
	
	Address(ctx context.Context, name string) (string, error)
	
	NetUsage(ctx context.Context, name string) (rx, tx int64, err error)

	
	SetLimits(ctx context.Context, name string, cpu float64, ramMB, diskMB int) error

	
	SetConfig(ctx context.Context, name, key, value string) error

	
	AddProxyDevice(ctx context.Context, name, device, listen, connect string) error
	
	RemoveDevice(ctx context.Context, name, device string) error

	Close() error
}
