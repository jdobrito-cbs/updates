package lxd

import (
	"context"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"sync"
)


type Fake struct {
	mu         sync.Mutex
	containers map[string]*fakeContainer

	
	FailStart bool
	
	FailExec bool
	
	IP string
	
	
	FSRoot string

	
	ExecCalls []ExecCall
	Files     map[string][]byte            
	Devices   map[string]map[string]string 
	netUsage  map[string][2]int64          
}


func (f *Fake) cpath(name, p string) string {
	return filepath.Join(f.FSRoot, name, filepath.FromSlash(p))
}


type ExecCall struct {
	Name string
	Cmd  []string
}

type fakeContainer struct {
	spec   ContainerSpec
	status string
}


func NewFake() *Fake {
	return &Fake{
		containers: make(map[string]*fakeContainer),
		Files:      make(map[string][]byte),
		Devices:    make(map[string]map[string]string),
	}
}

func (f *Fake) Exists(_ context.Context, name string) (bool, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	_, ok := f.containers[name]
	return ok, nil
}

func (f *Fake) Create(_ context.Context, spec ContainerSpec) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if _, ok := f.containers[spec.Name]; ok {
		return fmt.Errorf("lxd(fake): container %q já existe", spec.Name)
	}
	f.containers[spec.Name] = &fakeContainer{spec: spec, status: StatusStopped}
	return nil
}

func (f *Fake) Start(_ context.Context, name string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.FailStart {
		return fmt.Errorf("lxd(fake): falha de start injetada para %q", name)
	}
	c, ok := f.containers[name]
	if !ok {
		return ErrNotFound
	}
	c.status = StatusRunning
	return nil
}

func (f *Fake) Stop(_ context.Context, name string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	c, ok := f.containers[name]
	if !ok {
		return ErrNotFound
	}
	c.status = StatusStopped
	return nil
}

func (f *Fake) Delete(_ context.Context, name string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if _, ok := f.containers[name]; !ok {
		return ErrNotFound
	}
	delete(f.containers, name)
	return nil
}

func (f *Fake) Info(_ context.Context, name string) (ContainerInfo, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	c, ok := f.containers[name]
	if !ok {
		return ContainerInfo{}, ErrNotFound
	}
	return ContainerInfo{Name: name, Status: c.status}, nil
}

func (f *Fake) Exec(_ context.Context, name string, cmd []string, _ []byte) (ExecResult, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if _, ok := f.containers[name]; !ok {
		return ExecResult{}, ErrNotFound
	}
	f.ExecCalls = append(f.ExecCalls, ExecCall{Name: name, Cmd: cmd})
	if f.FailExec {
		return ExecResult{ExitCode: 1, Stderr: "lxd(fake): falha de exec injetada"}, nil
	}
	
	
	if f.FSRoot != "" {
		if res, handled := f.execFS(name, cmd); handled {
			return res, nil
		}
	}
	return ExecResult{ExitCode: 0}, nil
}



func (f *Fake) execFS(name string, cmd []string) (ExecResult, bool) {
	if len(cmd) == 0 {
		return ExecResult{}, false
	}
	
	var paths []string
	for _, a := range cmd[1:] {
		if strings.HasPrefix(a, "/") {
			paths = append(paths, a)
		}
	}
	fail := func(err error) (ExecResult, bool) { return ExecResult{ExitCode: 1, Stderr: err.Error()}, true }
	okRes := ExecResult{ExitCode: 0}

	switch cmd[0] {
	case "mkdir":
		for _, p := range paths {
			if err := os.MkdirAll(f.cpath(name, p), 0o755); err != nil {
				return fail(err)
			}
		}
		return okRes, true
	case "touch":
		for _, p := range paths {
			hp := f.cpath(name, p)
			_ = os.MkdirAll(filepath.Dir(hp), 0o755)
			h, err := os.OpenFile(hp, os.O_CREATE, 0o644)
			if err != nil {
				return fail(err)
			}
			_ = h.Close()
		}
		return okRes, true
	case "rm":
		for _, p := range paths {
			if err := os.RemoveAll(f.cpath(name, p)); err != nil {
				return fail(err)
			}
		}
		return okRes, true
	case "test":
		if len(paths) == 0 {
			return ExecResult{ExitCode: 1}, true
		}
		if _, err := os.Stat(f.cpath(name, paths[0])); err != nil {
			return ExecResult{ExitCode: 1}, true 
		}
		return okRes, true
	case "mv":
		if len(paths) != 2 {
			return ExecResult{ExitCode: 1, Stderr: "mv: src dst"}, true
		}
		if err := os.Rename(f.cpath(name, paths[0]), f.cpath(name, paths[1])); err != nil {
			return fail(err)
		}
		return okRes, true
	case "cp":
		if len(paths) != 2 {
			return ExecResult{ExitCode: 1, Stderr: "cp: src dst"}, true
		}
		if err := copyTree(f.cpath(name, paths[0]), f.cpath(name, paths[1])); err != nil {
			return fail(err)
		}
		return okRes, true
	case "find":
		if len(paths) == 0 {
			return ExecResult{ExitCode: 1}, true
		}
		return f.findList(name, paths[0]), true
	case "chown":
		return okRes, true 
	}
	return ExecResult{}, false
}



func (f *Fake) findList(name, dir string) ExecResult {
	entries, err := os.ReadDir(f.cpath(name, dir))
	if err != nil {
		return ExecResult{ExitCode: 0}
	}
	var sb strings.Builder
	for _, e := range entries {
		info, err := e.Info()
		if err != nil {
			continue
		}
		typ := "f"
		if e.IsDir() {
			typ = "d"
		}
		fmt.Fprintf(&sb, "%s\t%d\t%d\t%s\n", typ, info.Size(), info.ModTime().Unix(), e.Name())
	}
	return ExecResult{ExitCode: 0, Stdout: sb.String()}
}


func copyTree(src, dst string) error {
	info, err := os.Stat(src)
	if err != nil {
		return err
	}
	if !info.IsDir() {
		return copyFile(src, dst)
	}
	if err := os.MkdirAll(dst, 0o755); err != nil {
		return err
	}
	entries, err := os.ReadDir(src)
	if err != nil {
		return err
	}
	for _, e := range entries {
		if err := copyTree(filepath.Join(src, e.Name()), filepath.Join(dst, e.Name())); err != nil {
			return err
		}
	}
	return nil
}

func copyFile(src, dst string) error {
	if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
		return err
	}
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer out.Close()
	_, err = io.Copy(out, in)
	return err
}

func (f *Fake) PushFile(_ context.Context, name, p string, content []byte, _ int) error {
	f.mu.Lock()
	if _, ok := f.containers[name]; !ok {
		f.mu.Unlock()
		return ErrNotFound
	}
	f.Files[name+":"+p] = content
	root := f.FSRoot
	f.mu.Unlock()
	if root != "" {
		hp := f.cpath(name, p)
		if err := os.MkdirAll(filepath.Dir(hp), 0o755); err != nil {
			return err
		}
		return os.WriteFile(hp, content, 0o644)
	}
	return nil
}

func (f *Fake) Address(_ context.Context, name string) (string, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if _, ok := f.containers[name]; !ok {
		return "", ErrNotFound
	}
	if f.IP != "" {
		return f.IP, nil
	}
	return "10.0.0.2", nil
}



func (f *Fake) NetUsage(_ context.Context, name string) (int64, int64, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	if _, ok := f.containers[name]; !ok {
		return 0, 0, ErrNotFound
	}
	if f.netUsage == nil {
		f.netUsage = map[string][2]int64{}
	}
	c := f.netUsage[name]
	c[0] += 1 << 20
	c[1] += 1 << 19
	f.netUsage[name] = c
	return c[0], c[1], nil
}

func (f *Fake) PullFile(_ context.Context, name, src, dst string) error {
	if f.FSRoot != "" {
		return copyFile(f.cpath(name, src), dst)
	}
	f.mu.Lock()
	data := f.Files[name+":"+src]
	f.mu.Unlock()
	return os.WriteFile(dst, data, 0o600)
}

func (f *Fake) AddProxyDevice(_ context.Context, name, device, listen, connect string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if _, ok := f.containers[name]; !ok {
		return ErrNotFound
	}
	f.Devices[name+":"+device] = map[string]string{"type": "proxy", "listen": listen, "connect": connect}
	return nil
}

func (f *Fake) RemoveDevice(_ context.Context, name, device string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	delete(f.Devices, name+":"+device)
	return nil
}


func (f *Fake) SetLimits(_ context.Context, name string, _ float64, _, _ int) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if _, ok := f.containers[name]; !ok {
		return ErrNotFound
	}
	return nil
}


func (f *Fake) SetConfig(_ context.Context, name, _, _ string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if _, ok := f.containers[name]; !ok {
		return ErrNotFound
	}
	return nil
}

func (f *Fake) Close() error { return nil }


func (f *Fake) Status(name string) (string, bool) {
	f.mu.Lock()
	defer f.mu.Unlock()
	c, ok := f.containers[name]
	if !ok {
		return "", false
	}
	return c.status, true
}
