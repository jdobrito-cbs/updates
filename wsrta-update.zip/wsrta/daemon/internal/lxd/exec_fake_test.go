package lxd_test

import (
	"context"
	"errors"
	"testing"

	"github.com/jdobrito/wsrta/daemon/internal/lxd"
)

func TestFakeExecPushAddress(t *testing.T) {
	f := lxd.NewFake()
	ctx := context.Background()
	name := "cli_1"

	
	if _, err := f.Exec(ctx, name, []string{"true"}, nil); !errors.Is(err, lxd.ErrNotFound) {
		t.Fatalf("Exec sem container: esperava ErrNotFound, veio %v", err)
	}

	if err := f.Create(ctx, lxd.ContainerSpec{Name: name}); err != nil {
		t.Fatalf("create: %v", err)
	}

	
	res, err := f.Exec(ctx, name, []string{"nginx", "-t"}, nil)
	if err != nil {
		t.Fatalf("exec: %v", err)
	}
	if res.ExitCode != 0 {
		t.Fatalf("exit code = %d, esperava 0", res.ExitCode)
	}
	if len(f.ExecCalls) != 1 || f.ExecCalls[0].Cmd[0] != "nginx" {
		t.Fatalf("ExecCalls = %+v", f.ExecCalls)
	}

	
	if err := f.PushFile(ctx, name, "/etc/nginx/sites-enabled/x.conf", []byte("vhost"), 0o644); err != nil {
		t.Fatalf("push: %v", err)
	}
	if string(f.Files[name+":/etc/nginx/sites-enabled/x.conf"]) != "vhost" {
		t.Fatalf("arquivo não registrado: %v", f.Files)
	}

	
	ip, err := f.Address(ctx, name)
	if err != nil {
		t.Fatalf("address: %v", err)
	}
	if ip != "10.0.0.2" {
		t.Fatalf("ip = %q, esperava 10.0.0.2", ip)
	}

	
	f.FailExec = true
	res, _ = f.Exec(ctx, name, []string{"false"}, nil)
	if res.ExitCode != 1 {
		t.Fatalf("FailExec: exit code = %d, esperava 1", res.ExitCode)
	}
}
