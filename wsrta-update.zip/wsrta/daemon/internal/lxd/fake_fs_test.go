package lxd

import (
	"context"
	"os"
	"strings"
	"testing"
)




func TestFakeFunctionalFS(t *testing.T) {
	f := NewFake()
	f.FSRoot = t.TempDir()
	ctx := context.Background()
	if err := f.Create(ctx, ContainerSpec{Name: "cli_x"}); err != nil {
		t.Fatal(err)
	}

	
	if res, _ := f.Exec(ctx, "cli_x", []string{"mkdir", "-p", "/var/www/site.com"}, nil); res.ExitCode != 0 {
		t.Fatalf("mkdir falhou: %+v", res)
	}
	
	if err := f.PushFile(ctx, "cli_x", "/var/www/site.com/index.html", []byte("ola"), 0o644); err != nil {
		t.Fatal(err)
	}
	
	res, _ := f.Exec(ctx, "cli_x",
		[]string{"find", "/var/www", "-maxdepth", "1", "-mindepth", "1", "-printf", "%y\\t%s\\t%T@\\t%f\\n"}, nil)
	if res.ExitCode != 0 || !strings.Contains(res.Stdout, "site.com") || !strings.HasPrefix(res.Stdout, "d\t") {
		t.Fatalf("find não listou o docroot: %q", res.Stdout)
	}

	
	dst := f.FSRoot + "/pulled.html"
	if err := f.PullFile(ctx, "cli_x", "/var/www/site.com/index.html", dst); err != nil {
		t.Fatal(err)
	}
	b, _ := os.ReadFile(dst)
	if string(b) != "ola" {
		t.Fatalf("PullFile devolveu %q", string(b))
	}
}
