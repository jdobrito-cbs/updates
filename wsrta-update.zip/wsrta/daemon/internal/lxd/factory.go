package lxd

import "fmt"


type Config struct {
	Socket string 
	
	
	
	FakeFSRoot string
}


func New(driver string, cfg Config) (Client, error) {
	switch driver {
	case "fake":
		f := NewFake()
		f.FSRoot = cfg.FakeFSRoot
		return f, nil
	case "real", "":
		return newReal(cfg)
	default:
		return nil, fmt.Errorf("lxd: driver desconhecido %q (use 'real' ou 'fake')", driver)
	}
}
