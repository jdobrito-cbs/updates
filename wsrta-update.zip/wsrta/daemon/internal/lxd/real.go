package lxd

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"math"
	"os"
	"strconv"

	lxdclient "github.com/canonical/lxd/client"
	"github.com/canonical/lxd/shared/api"
)


type bufWriteCloser struct {
	*bytes.Buffer
}

func (bufWriteCloser) Close() error { return nil }


type realClient struct {
	server lxdclient.InstanceServer
}

func newReal(cfg Config) (Client, error) {
	server, err := lxdclient.ConnectLXDUnix(cfg.Socket, nil)
	if err != nil {
		return nil, fmt.Errorf("lxd: conectar ao socket: %w", err)
	}
	return &realClient{server: server}, nil
}

func (c *realClient) Exists(_ context.Context, name string) (bool, error) {
	names, err := c.server.GetInstanceNames(api.InstanceTypeContainer)
	if err != nil {
		return false, fmt.Errorf("lxd: listar instâncias: %w", err)
	}
	for _, n := range names {
		if n == name {
			return true, nil
		}
	}
	return false, nil
}

func (c *realClient) Create(_ context.Context, spec ContainerSpec) error {
	req := api.InstancesPost{
		Name: spec.Name,
		Type: api.InstanceTypeContainer,
		Source: api.InstanceSource{
			Type:  "image",
			Alias: spec.Image,
		},
		InstancePut: api.InstancePut{
			Config:  buildConfig(spec),
			Devices: buildDevices(spec),
		},
	}
	op, err := c.server.CreateInstance(req)
	if err != nil {
		return fmt.Errorf("lxd: criar instância: %w", err)
	}
	if err := op.Wait(); err != nil {
		return fmt.Errorf("lxd: aguardar criação: %w", err)
	}
	return nil
}

func (c *realClient) changeState(name, action string, force bool) error {
	op, err := c.server.UpdateInstanceState(name, api.InstanceStatePut{
		Action: action,
		Force:  force,
	}, "")
	if err != nil {
		return err
	}
	return op.Wait()
}

func (c *realClient) Start(_ context.Context, name string) error {
	if err := c.changeState(name, "start", false); err != nil {
		return fmt.Errorf("lxd: iniciar %q: %w", name, err)
	}
	return nil
}

func (c *realClient) Stop(_ context.Context, name string) error {
	if err := c.changeState(name, "stop", true); err != nil {
		return fmt.Errorf("lxd: parar %q: %w", name, err)
	}
	return nil
}

func (c *realClient) Delete(_ context.Context, name string) error {
	op, err := c.server.DeleteInstance(name, true) 
	if err != nil {
		return fmt.Errorf("lxd: remover %q: %w", name, err)
	}
	if err := op.Wait(); err != nil {
		return fmt.Errorf("lxd: aguardar remoção de %q: %w", name, err)
	}
	return nil
}

func (c *realClient) Info(_ context.Context, name string) (ContainerInfo, error) {
	state, _, err := c.server.GetInstanceState(name)
	if err != nil {
		return ContainerInfo{}, fmt.Errorf("lxd: estado de %q: %w", name, err)
	}
	return ContainerInfo{Name: name, Status: state.Status}, nil
}

func (c *realClient) PullFile(_ context.Context, name, src, dst string) error {
	reader, _, err := c.server.GetInstanceFile(name, src)
	if err != nil {
		return fmt.Errorf("lxd: pull %q: %w", src, err)
	}
	defer reader.Close()
	f, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer f.Close()
	if _, err := io.Copy(f, reader); err != nil {
		return fmt.Errorf("lxd: copiar %q: %w", src, err)
	}
	return nil
}

func (c *realClient) AddProxyDevice(_ context.Context, name, device, listen, connect string) error {
	inst, etag, err := c.server.GetInstance(name)
	if err != nil {
		return fmt.Errorf("lxd: get %q: %w", name, err)
	}
	if inst.Devices == nil {
		inst.Devices = map[string]map[string]string{}
	}
	inst.Devices[device] = map[string]string{
		"type":    "proxy",
		"listen":  listen,
		"connect": connect,
	}
	op, err := c.server.UpdateInstance(name, inst.Writable(), etag)
	if err != nil {
		return fmt.Errorf("lxd: adicionar device %q: %w", device, err)
	}
	return op.Wait()
}

func (c *realClient) RemoveDevice(_ context.Context, name, device string) error {
	inst, etag, err := c.server.GetInstance(name)
	if err != nil {
		return fmt.Errorf("lxd: get %q: %w", name, err)
	}
	if _, ok := inst.Devices[device]; !ok {
		return nil
	}
	delete(inst.Devices, device)
	op, err := c.server.UpdateInstance(name, inst.Writable(), etag)
	if err != nil {
		return fmt.Errorf("lxd: remover device %q: %w", device, err)
	}
	return op.Wait()
}




func (c *realClient) SetLimits(_ context.Context, name string, cpu float64, ramMB, diskMB int) error {
	inst, etag, err := c.server.GetInstance(name)
	if err != nil {
		return fmt.Errorf("lxd: get %q: %w", name, err)
	}
	if inst.Config == nil {
		inst.Config = map[string]string{}
	}
	if ramMB > 0 {
		inst.Config["limits.memory"] = fmt.Sprintf("%dMB", ramMB)
	}
	if cpu > 0 {
		whole := int(math.Ceil(cpu))
		if whole < 1 {
			whole = 1
		}
		inst.Config["limits.cpu"] = strconv.Itoa(whole)
		if cpu != float64(whole) {
			inst.Config["limits.cpu.allowance"] = fmt.Sprintf("%d%%", int(cpu*100))
		} else {
			delete(inst.Config, "limits.cpu.allowance")
		}
	}
	if diskMB > 0 {
		if inst.Devices == nil {
			inst.Devices = map[string]map[string]string{}
		}
		root, ok := inst.Devices["root"]
		if !ok {
			root = map[string]string{"type": "disk", "path": "/"}
		}
		root["size"] = fmt.Sprintf("%dMB", diskMB)
		inst.Devices["root"] = root
	}
	op, err := c.server.UpdateInstance(name, inst.Writable(), etag)
	if err != nil {
		return fmt.Errorf("lxd: aplicar limites em %q: %w", name, err)
	}
	return op.Wait()
}




func (c *realClient) SetConfig(_ context.Context, name, key, value string) error {
	inst, etag, err := c.server.GetInstance(name)
	if err != nil {
		return fmt.Errorf("lxd: get %q: %w", name, err)
	}
	if inst.Config == nil {
		inst.Config = map[string]string{}
	}
	inst.Config[key] = value
	op, err := c.server.UpdateInstance(name, inst.Writable(), etag)
	if err != nil {
		return fmt.Errorf("lxd: set config %q em %q: %w", key, name, err)
	}
	return op.Wait()
}

func (c *realClient) Close() error {
	c.server.Disconnect()
	return nil
}

func (c *realClient) Exec(_ context.Context, name string, cmd []string, stdin []byte) (ExecResult, error) {
	var stdout, stderr bytes.Buffer
	args := &lxdclient.InstanceExecArgs{
		Stdout:   bufWriteCloser{&stdout},
		Stderr:   bufWriteCloser{&stderr},
		DataDone: make(chan bool),
	}
	if len(stdin) > 0 {
		args.Stdin = io.NopCloser(bytes.NewReader(stdin))
	}

	op, err := c.server.ExecInstance(name, api.InstanceExecPost{
		Command:   cmd,
		WaitForWS: true,
	}, args)
	if err != nil {
		return ExecResult{}, fmt.Errorf("lxd: exec em %q: %w", name, err)
	}
	if err := op.Wait(); err != nil {
		return ExecResult{}, fmt.Errorf("lxd: aguardar exec em %q: %w", name, err)
	}
	<-args.DataDone 

	rc := 0
	if v, ok := op.Get().Metadata["return"]; ok {
		if f, ok := v.(float64); ok {
			rc = int(f)
		}
	}
	return ExecResult{Stdout: stdout.String(), Stderr: stderr.String(), ExitCode: rc}, nil
}

func (c *realClient) PushFile(_ context.Context, name, path string, content []byte, mode int) error {
	args := lxdclient.InstanceFileArgs{
		Content: bytes.NewReader(content),
		Mode:    mode,
		Type:    "file",
	}
	if err := c.server.CreateInstanceFile(name, path, args); err != nil {
		return fmt.Errorf("lxd: push file %q em %q: %w", path, name, err)
	}
	return nil
}

func (c *realClient) Address(_ context.Context, name string) (string, error) {
	state, _, err := c.server.GetInstanceState(name)
	if err != nil {
		return "", fmt.Errorf("lxd: estado de %q: %w", name, err)
	}
	for ifaceName, netw := range state.Network {
		if ifaceName == "lo" {
			continue
		}
		for _, addr := range netw.Addresses {
			if addr.Family == "inet" && addr.Scope == "global" {
				return addr.Address, nil
			}
		}
	}
	return "", fmt.Errorf("lxd: %q sem endereço IPv4 global", name)
}

func (c *realClient) NetUsage(_ context.Context, name string) (int64, int64, error) {
	state, _, err := c.server.GetInstanceState(name)
	if err != nil {
		return 0, 0, fmt.Errorf("lxd: estado de %q: %w", name, err)
	}
	var rx, tx int64
	for ifaceName, netw := range state.Network {
		if ifaceName == "lo" {
			continue
		}
		rx += int64(netw.Counters.BytesReceived)
		tx += int64(netw.Counters.BytesSent)
	}
	return rx, tx, nil
}


func buildConfig(spec ContainerSpec) map[string]string {
	config := map[string]string{}
	if spec.RAMLimitMB > 0 {
		config["limits.memory"] = fmt.Sprintf("%dMB", spec.RAMLimitMB)
	}
	if spec.CPULimit > 0 {
		whole := int(math.Ceil(spec.CPULimit))
		if whole < 1 {
			whole = 1
		}
		config["limits.cpu"] = strconv.Itoa(whole)
		
		if spec.CPULimit != float64(whole) {
			config["limits.cpu.allowance"] = fmt.Sprintf("%d%%", int(spec.CPULimit*100))
		}
	}
	return config
}


func buildDevices(spec ContainerSpec) map[string]map[string]string {
	devices := map[string]map[string]string{}

	root := map[string]string{"type": "disk", "path": "/"}
	if spec.StoragePool != "" {
		root["pool"] = spec.StoragePool
	}
	if spec.DiskQuotaMB > 0 {
		
		root["size"] = fmt.Sprintf("%dMB", spec.DiskQuotaMB)
	}
	devices["root"] = root

	if spec.Network != "" {
		devices["eth0"] = map[string]string{
			"type":    "nic",
			"network": spec.Network,
			"name":    "eth0",
		}
	}
	return devices
}
