package pdns_test

import (
	"context"
	"testing"

	"github.com/jdobrito/wsrta/daemon/internal/pdns"
)

func TestFakeBackend(t *testing.T) {
	f := pdns.NewFake()
	ctx := context.Background()

	
	if err := f.SetRecord(ctx, "exemplo.com", "www.exemplo.com", "A", "1.2.3.4", 3600, 0); err == nil {
		t.Fatal("SetRecord sem zona deveria falhar")
	}

	
	if err := f.EnsureZone(ctx, "Exemplo.COM"); err != nil {
		t.Fatalf("ensure: %v", err)
	}
	if !f.Zones["exemplo.com"] {
		t.Fatalf("zona não garantida/normalizada: %v", f.Zones)
	}

	
	if err := f.SetRecord(ctx, "exemplo.com", "exemplo.com", "MX", "mail.exemplo.com", 3600, 10); err != nil {
		t.Fatalf("set mx: %v", err)
	}
	if f.Records["exemplo.com|exemplo.com|MX"] != "10 mail.exemplo.com" {
		t.Fatalf("prioridade não embutida: %v", f.Records)
	}

	if err := f.DeleteRecord(ctx, "exemplo.com", "exemplo.com", "MX", "mail.exemplo.com", 10); err != nil {
		t.Fatalf("delete: %v", err)
	}
	if _, ok := f.Records["exemplo.com|exemplo.com|MX"]; ok {
		t.Fatal("registro não removido")
	}
}
