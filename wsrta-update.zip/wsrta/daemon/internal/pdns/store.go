


package pdns

import (
	"context"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)


type ZoneConfig struct {
	PrimaryNS   string
	SecondaryNS string
	Hostmaster  string
	RecordTTL   int
	SOARefresh  int
	SOARetry    int
	SOAExpire   int
	SOAMinimum  int
}


type Store struct {
	pool *pgxpool.Pool
	cfg  ZoneConfig
}


func NewStore(pool *pgxpool.Pool, cfg ZoneConfig) *Store {
	if cfg.RecordTTL == 0 {
		cfg.RecordTTL = 3600
	}
	if cfg.SOARefresh == 0 {
		cfg.SOARefresh = 10800
	}
	if cfg.SOARetry == 0 {
		cfg.SOARetry = 3600
	}
	if cfg.SOAExpire == 0 {
		cfg.SOAExpire = 604800
	}
	if cfg.SOAMinimum == 0 {
		cfg.SOAMinimum = 3600
	}
	return &Store{pool: pool, cfg: cfg}
}


func (s *Store) EnsureZone(ctx context.Context, fqdn string) error {
	zone := normalize(fqdn)

	var id int
	err := s.pool.QueryRow(ctx, `SELECT id FROM domains WHERE name = $1`, zone).Scan(&id)
	if err == nil {
		return nil 
	}
	if !errors.Is(err, pgx.ErrNoRows) {
		return fmt.Errorf("pdns: consultar zona: %w", err)
	}

	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("pdns: begin: %w", err)
	}
	defer tx.Rollback(ctx)

	if err := tx.QueryRow(ctx,
		`INSERT INTO domains (name, type) VALUES ($1, 'NATIVE') RETURNING id`, zone,
	).Scan(&id); err != nil {
		return fmt.Errorf("pdns: inserir zona: %w", err)
	}

	serial := time.Now().Unix()
	soa := fmt.Sprintf("%s %s %d %d %d %d %d",
		normalize(s.cfg.PrimaryNS), normalize(s.cfg.Hostmaster), serial,
		s.cfg.SOARefresh, s.cfg.SOARetry, s.cfg.SOAExpire, s.cfg.SOAMinimum)
	if err := insertRecord(ctx, tx, id, zone, "SOA", soa, s.cfg.RecordTTL); err != nil {
		return err
	}

	for _, ns := range []string{s.cfg.PrimaryNS, s.cfg.SecondaryNS} {
		if ns == "" {
			continue
		}
		if err := insertRecord(ctx, tx, id, zone, "NS", normalize(ns), s.cfg.RecordTTL); err != nil {
			return err
		}
	}

	return tx.Commit(ctx)
}


func (s *Store) SetRecord(ctx context.Context, zone, name, rtype, content string, ttl, prio int) error {
	zone = normalize(zone)
	name = normalize(name)
	content = withPriority(rtype, content, prio)
	if ttl <= 0 {
		ttl = s.cfg.RecordTTL
	}

	id, err := s.zoneID(ctx, zone)
	if err != nil {
		return err
	}

	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("pdns: begin: %w", err)
	}
	defer tx.Rollback(ctx)

	if _, err := tx.Exec(ctx,
		`DELETE FROM records WHERE domain_id=$1 AND name=$2 AND type=$3 AND content=$4`,
		id, name, rtype, content,
	); err != nil {
		return fmt.Errorf("pdns: limpar registro: %w", err)
	}
	if err := insertRecord(ctx, tx, id, name, rtype, content, ttl); err != nil {
		return err
	}
	return tx.Commit(ctx)
}


func (s *Store) DeleteRecord(ctx context.Context, zone, name, rtype, content string, prio int) error {
	zone = normalize(zone)
	name = normalize(name)
	content = withPriority(rtype, content, prio)

	id, err := s.zoneID(ctx, zone)
	if err != nil {
		return err
	}
	if _, err := s.pool.Exec(ctx,
		`DELETE FROM records WHERE domain_id=$1 AND name=$2 AND type=$3 AND content=$4`,
		id, name, rtype, content,
	); err != nil {
		return fmt.Errorf("pdns: remover registro: %w", err)
	}
	return nil
}


func (s *Store) Close() { s.pool.Close() }

func (s *Store) zoneID(ctx context.Context, zone string) (int, error) {
	var id int
	if err := s.pool.QueryRow(ctx, `SELECT id FROM domains WHERE name=$1`, zone).Scan(&id); err != nil {
		return 0, fmt.Errorf("pdns: zona %q não encontrada: %w", zone, err)
	}
	return id, nil
}

func insertRecord(ctx context.Context, tx pgx.Tx, domainID int, name, rtype, content string, ttl int) error {
	if _, err := tx.Exec(ctx,
		`INSERT INTO records (domain_id, name, type, content, ttl, auth) VALUES ($1,$2,$3,$4,$5,'t')`,
		domainID, name, rtype, content, ttl,
	); err != nil {
		return fmt.Errorf("pdns: inserir registro: %w", err)
	}
	return nil
}


func withPriority(rtype, content string, prio int) string {
	if (rtype == "MX" || rtype == "SRV") && prio > 0 {
		return fmt.Sprintf("%d %s", prio, content)
	}
	return content
}


func normalize(name string) string {
	return strings.TrimSuffix(strings.ToLower(strings.TrimSpace(name)), ".")
}
