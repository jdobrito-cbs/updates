package pdns

import (
	"context"
	"fmt"
	"sync"
)


type Fake struct {
	mu      sync.Mutex
	Zones   map[string]bool   
	Records map[string]string 
}


func NewFake() *Fake {
	return &Fake{Zones: make(map[string]bool), Records: make(map[string]string)}
}

func (f *Fake) EnsureZone(_ context.Context, fqdn string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.Zones[normalize(fqdn)] = true
	return nil
}

func (f *Fake) SetRecord(_ context.Context, zone, name, rtype, content string, _, prio int) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if !f.Zones[normalize(zone)] {
		return fmt.Errorf("pdns(fake): zona %q não garantida", zone)
	}
	f.Records[key(zone, name, rtype)] = withPriority(rtype, content, prio)
	return nil
}

func (f *Fake) DeleteRecord(_ context.Context, zone, name, rtype, _ string, _ int) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	delete(f.Records, key(zone, name, rtype))
	return nil
}

func key(zone, name, rtype string) string {
	return normalize(zone) + "|" + normalize(name) + "|" + rtype
}
