package pdns_test

import (
	"context"
	"os"
	"testing"

	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/jdobrito/wsrta/daemon/internal/pdns"
	"github.com/jdobrito/wsrta/internal/db"
)



func TestStoreIntegration(t *testing.T) {
	dsn := os.Getenv("WSRTA_TEST_PDNS_URL")
	if dsn == "" {
		t.Skip("defina WSRTA_TEST_PDNS_URL para rodar a integração do PowerDNS")
	}

	ctx := context.Background()
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		t.Fatalf("open: %v", err)
	}
	defer pool.Close()

	if _, err := pool.Exec(ctx, "DELETE FROM records"); err != nil {
		t.Fatalf("limpar records: %v", err)
	}
	if _, err := pool.Exec(ctx, "DELETE FROM domains"); err != nil {
		t.Fatalf("limpar domains: %v", err)
	}

	s := pdns.NewStore(pool, pdns.ZoneConfig{
		PrimaryNS: "ns1.wsrta.local", Hostmaster: "hostmaster.wsrta.local", RecordTTL: 3600,
	})

	if err := s.EnsureZone(ctx, "Exemplo.COM"); err != nil {
		t.Fatalf("ensure: %v", err)
	}
	if err := s.EnsureZone(ctx, "exemplo.com"); err != nil {
		t.Fatalf("ensure idempotente: %v", err)
	}

	soa := count(t, pool, "SELECT count(*) FROM records r JOIN domains d ON d.id=r.domain_id WHERE d.name='exemplo.com' AND r.type='SOA'")
	if soa != 1 {
		t.Fatalf("SOA count = %d, esperava 1", soa)
	}

	if err := s.SetRecord(ctx, "exemplo.com", "www.exemplo.com", "A", "1.2.3.4", 3600, 0); err != nil {
		t.Fatalf("set A: %v", err)
	}
	if err := s.SetRecord(ctx, "exemplo.com", "exemplo.com", "MX", "mail.exemplo.com", 3600, 10); err != nil {
		t.Fatalf("set MX: %v", err)
	}
	var mx string
	if err := pool.QueryRow(ctx,
		"SELECT content FROM records r JOIN domains d ON d.id=r.domain_id WHERE d.name='exemplo.com' AND r.type='MX'").Scan(&mx); err != nil {
		t.Fatalf("ler MX: %v", err)
	}
	if mx != "10 mail.exemplo.com" {
		t.Fatalf("MX content = %q (prio deveria estar embutida)", mx)
	}

	
	if err := s.SetRecord(ctx, "exemplo.com", "www.exemplo.com", "A", "1.2.3.4", 3600, 0); err != nil {
		t.Fatalf("set A de novo: %v", err)
	}
	if a := count(t, pool, "SELECT count(*) FROM records WHERE name='www.exemplo.com' AND type='A'"); a != 1 {
		t.Fatalf("A count = %d, esperava 1 (idempotente)", a)
	}

	if err := s.DeleteRecord(ctx, "exemplo.com", "www.exemplo.com", "A", "1.2.3.4", 0); err != nil {
		t.Fatalf("delete A: %v", err)
	}
	if a := count(t, pool, "SELECT count(*) FROM records WHERE name='www.exemplo.com' AND type='A'"); a != 0 {
		t.Fatalf("A ainda presente após delete: %d", a)
	}
}

func count(t *testing.T, pool *pgxpool.Pool, query string) int {
	t.Helper()
	var n int
	if err := pool.QueryRow(context.Background(), query).Scan(&n); err != nil {
		t.Fatalf("count: %v", err)
	}
	return n
}
