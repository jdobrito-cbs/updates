
package store

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/jdobrito/wsrta/internal/core"
)


var ErrNotFound = errors.New("store: client não encontrado")


type Clients struct {
	pool *pgxpool.Pool
}


func NewClients(pool *pgxpool.Pool) *Clients {
	return &Clients{pool: pool}
}


func (c *Clients) GetClient(ctx context.Context, id int64) (*core.Client, error) {
	var cl core.Client
	err := c.pool.QueryRow(ctx,
		`SELECT id, user_id, name, lxc_container_name, cpu_limit, ram_limit_mb, disk_quota_mb, status
		   FROM clients WHERE id = $1`, id,
	).Scan(&cl.ID, &cl.UserID, &cl.Name, &cl.LXCContainerName,
		&cl.CPULimit, &cl.RAMLimitMB, &cl.DiskQuotaMB, &cl.Status)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get client: %w", err)
	}
	return &cl, nil
}


func (c *Clients) SetClientStatus(ctx context.Context, id int64, status string) error {
	tag, err := c.pool.Exec(ctx, `UPDATE clients SET status = $2 WHERE id = $1`, id, status)
	if err != nil {
		return fmt.Errorf("store: set status: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}




func (c *Clients) DeleteClient(ctx context.Context, id int64) error {
	_, err := c.pool.Exec(ctx,
		`DELETE FROM users WHERE id = (SELECT user_id FROM clients WHERE id = $1)`, id)
	if err != nil {
		return fmt.Errorf("store: delete client: %w", err)
	}
	return nil
}


func (c *Clients) SetClientFastNginx(ctx context.Context, id int64, enabled bool) error {
	tag, err := c.pool.Exec(ctx, `UPDATE clients SET fast_nginx_enabled = $2 WHERE id = $1`, id, enabled)
	if err != nil {
		return fmt.Errorf("store: set fast nginx: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}


func (c *Clients) SetClientPhpMyAdmin(ctx context.Context, id int64, enabled bool) error {
	tag, err := c.pool.Exec(ctx, `UPDATE clients SET phpmyadmin_enabled = $2 WHERE id = $1`, id, enabled)
	if err != nil {
		return fmt.Errorf("store: set phpmyadmin: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}


func (c *Clients) SetClientPhpMyAdminPassword(ctx context.Context, id int64, password string) error {
	if _, err := c.pool.Exec(ctx, `UPDATE clients SET phpmyadmin_password = $2 WHERE id = $1`, id, password); err != nil {
		return fmt.Errorf("store: set phpmyadmin password: %w", err)
	}
	return nil
}


func (c *Clients) SetClientPhpPgAdminPassword(ctx context.Context, id int64, password string) error {
	if _, err := c.pool.Exec(ctx, `UPDATE clients SET phppgadmin_password = $2 WHERE id = $1`, id, password); err != nil {
		return fmt.Errorf("store: set phppgadmin password: %w", err)
	}
	return nil
}


func (c *Clients) SetClientCloudflareStatus(ctx context.Context, id int64, status string) error {
	tag, err := c.pool.Exec(ctx, `UPDATE clients SET cloudflare_status = $2 WHERE id = $1`, id, status)
	if err != nil {
		return fmt.Errorf("store: set cloudflare status: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}


func (c *Clients) SetClientDockerEnabled(ctx context.Context, id int64, enabled bool) error {
	tag, err := c.pool.Exec(ctx, `UPDATE clients SET docker_enabled = $2 WHERE id = $1`, id, enabled)
	if err != nil {
		return fmt.Errorf("store: set docker enabled: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}


func (c *Clients) SetClientPowerState(ctx context.Context, id int64, state string) error {
	tag, err := c.pool.Exec(ctx, `UPDATE clients SET power_state = $2 WHERE id = $1`, id, state)
	if err != nil {
		return fmt.Errorf("store: set power state: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}


func (c *Clients) SetAppInstallStatus(ctx context.Context, id int64, status string) error {
	if _, err := c.pool.Exec(ctx, `UPDATE app_installs SET status = $2 WHERE id = $1`, id, status); err != nil {
		return fmt.Errorf("store: set app install status: %w", err)
	}
	return nil
}


func (c *Clients) SetClientSFTP(ctx context.Context, id int64, enabled bool, port int, user string) error {
	tag, err := c.pool.Exec(ctx,
		`UPDATE clients SET sftp_enabled = $2, sftp_port = $3, sftp_user = $4 WHERE id = $1`,
		id, enabled, port, user)
	if err != nil {
		return fmt.Errorf("store: set sftp: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}
