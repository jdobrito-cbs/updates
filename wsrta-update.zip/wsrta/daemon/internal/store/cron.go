package store

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/jdobrito/wsrta/internal/core"
)


type Cron struct {
	pool *pgxpool.Pool
}


func NewCron(pool *pgxpool.Pool) *Cron {
	return &Cron{pool: pool}
}


func (s *Cron) GetCronJob(ctx context.Context, id int64) (*core.CronJob, string, error) {
	var j core.CronJob
	var container string
	err := s.pool.QueryRow(ctx,
		`SELECT j.id, j.client_id, j.schedule, j.command, j.enabled, j.created_at, c.lxc_container_name
		   FROM cron_jobs j
		   JOIN clients c ON c.id = j.client_id
		  WHERE j.id = $1`, id,
	).Scan(&j.ID, &j.ClientID, &j.Schedule, &j.Command, &j.Enabled, &j.CreatedAt, &container)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, "", ErrNotFound
	}
	if err != nil {
		return nil, "", fmt.Errorf("store: get cron_job: %w", err)
	}
	return &j, container, nil
}


func (s *Cron) DeleteCronJob(ctx context.Context, id int64) error {
	tag, err := s.pool.Exec(ctx, `DELETE FROM cron_jobs WHERE id = $1`, id)
	if err != nil {
		return fmt.Errorf("store: delete cron_job: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}
