package store

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/jdobrito/wsrta/internal/core"
)




type Vuln struct {
	pool *pgxpool.Pool
}


func NewVuln(pool *pgxpool.Pool) *Vuln { return &Vuln{pool: pool} }


type VulnDomain struct{ FQDN string }


type VulnWP struct {
	FQDN string
	Path string
}


func (s *Vuln) ClientContainer(ctx context.Context, clientID int64) (string, error) {
	var name string
	if err := s.pool.QueryRow(ctx,
		`SELECT lxc_container_name FROM clients WHERE id = $1`, clientID).Scan(&name); err != nil {
		return "", fmt.Errorf("store: client container: %w", err)
	}
	return name, nil
}


func (s *Vuln) ListDomains(ctx context.Context, clientID int64) ([]VulnDomain, error) {
	rows, err := s.pool.Query(ctx, `SELECT fqdn FROM domains WHERE client_id = $1 ORDER BY id`, clientID)
	if err != nil {
		return nil, fmt.Errorf("store: vuln list domains: %w", err)
	}
	defer rows.Close()
	var out []VulnDomain
	for rows.Next() {
		var d VulnDomain
		if err := rows.Scan(&d.FQDN); err != nil {
			return nil, err
		}
		out = append(out, d)
	}
	return out, rows.Err()
}


func (s *Vuln) ListWordPress(ctx context.Context, clientID int64) ([]VulnWP, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT d.fqdn, w.path FROM wordpress_installs w
		   JOIN domains d ON d.id = w.domain_id
		  WHERE d.client_id = $1 ORDER BY w.id`, clientID)
	if err != nil {
		return nil, fmt.Errorf("store: vuln list wordpress: %w", err)
	}
	defer rows.Close()
	var out []VulnWP
	for rows.Next() {
		var w VulnWP
		if err := rows.Scan(&w.FQDN, &w.Path); err != nil {
			return nil, err
		}
		out = append(out, w)
	}
	return out, rows.Err()
}


func (s *Vuln) MarkRunning(ctx context.Context, scanID int64) error {
	_, err := s.pool.Exec(ctx, `UPDATE vuln_scans SET status = 'running' WHERE id = $1`, scanID)
	return err
}



func (s *Vuln) AddFinding(ctx context.Context, scanID int64, f core.VulnFinding) error {
	san := func(x string) string { return strings.ToValidUTF8(x, "") }
	_, err := s.pool.Exec(ctx,
		`INSERT INTO vuln_findings (scan_id, fqdn, severity, category, title, detail, remediation)
		 VALUES ($1, $2, $3, $4, $5, $6, $7)`,
		scanID, san(f.FQDN), f.Severity, san(f.Category), san(f.Title), san(f.Detail), san(f.Remediation))
	return err
}


func (s *Vuln) Finish(ctx context.Context, scanID int64, high, medium, low, info int, summary, status string) error {
	_, err := s.pool.Exec(ctx,
		`UPDATE vuln_scans SET status = $2, high = $3, medium = $4, low = $5, info = $6, summary = $7, finished_at = now()
		   WHERE id = $1`,
		scanID, status, high, medium, low, info, strings.ToValidUTF8(summary, ""))
	return err
}


func (s *Vuln) SetLastScan(ctx context.Context, clientID int64) error {
	_, err := s.pool.Exec(ctx, `UPDATE clients SET last_vuln_scan = now() WHERE id = $1`, clientID)
	return err
}


type ScheduledVulnClient struct {
	ClientID int64
	Schedule string
	LastScan *time.Time
}


func (s *Vuln) ListScheduled(ctx context.Context) ([]ScheduledVulnClient, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT id, vuln_schedule, last_vuln_scan FROM clients
		  WHERE vuln_schedule <> '' AND owner_user_id IS NULL`)
	if err != nil {
		return nil, fmt.Errorf("store: vuln list scheduled: %w", err)
	}
	defer rows.Close()
	var out []ScheduledVulnClient
	for rows.Next() {
		var c ScheduledVulnClient
		if err := rows.Scan(&c.ClientID, &c.Schedule, &c.LastScan); err != nil {
			return nil, err
		}
		out = append(out, c)
	}
	return out, rows.Err()
}


func (s *Vuln) SecurityFlags(ctx context.Context) (modsec, csf, fail2ban, sslRenew bool, err error) {
	err = s.pool.QueryRow(ctx,
		`SELECT sec_modsecurity, sec_csf, sec_fail2ban, sec_ssl_autorenew FROM settings WHERE id = 1`).
		Scan(&modsec, &csf, &fail2ban, &sslRenew)
	return modsec, csf, fail2ban, sslRenew, err
}


func (s *Vuln) CreateScan(ctx context.Context, clientID int64) (int64, error) {
	var cid any
	if clientID > 0 {
		cid = clientID
	}
	var id int64
	if err := s.pool.QueryRow(ctx,
		`INSERT INTO vuln_scans (client_id, status) VALUES ($1, 'pending') RETURNING id`, cid).Scan(&id); err != nil {
		return 0, fmt.Errorf("store: create scan: %w", err)
	}
	return id, nil
}
