package store

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/jdobrito/wsrta/internal/core"
)


type DNS struct {
	pool *pgxpool.Pool
}


func NewDNS(pool *pgxpool.Pool) *DNS {
	return &DNS{pool: pool}
}


func (s *DNS) GetDNSRecord(ctx context.Context, id int64) (*core.DNSRecord, string, error) {
	var r core.DNSRecord
	var zone string
	err := s.pool.QueryRow(ctx,
		`SELECT r.id, r.domain_id, r.type, r.name, r.content, r.ttl, r.prio, r.created_at, d.fqdn
		   FROM dns_records r
		   JOIN domains d ON d.id = r.domain_id
		  WHERE r.id = $1`, id,
	).Scan(&r.ID, &r.DomainID, &r.Type, &r.Name, &r.Content, &r.TTL, &r.Prio, &r.CreatedAt, &zone)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, "", ErrNotFound
	}
	if err != nil {
		return nil, "", fmt.Errorf("store: get dns_record: %w", err)
	}
	return &r, zone, nil
}


func (s *DNS) DeleteDNSRecord(ctx context.Context, id int64) error {
	tag, err := s.pool.Exec(ctx, `DELETE FROM dns_records WHERE id = $1`, id)
	if err != nil {
		return fmt.Errorf("store: delete dns_record: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}
