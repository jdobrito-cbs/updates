package store

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/jdobrito/wsrta/internal/core"
)


type Databases struct {
	pool *pgxpool.Pool
}


func NewDatabases(pool *pgxpool.Pool) *Databases {
	return &Databases{pool: pool}
}


func (s *Databases) GetDatabase(ctx context.Context, id int64) (*core.Database, string, error) {
	var d core.Database
	var container string
	err := s.pool.QueryRow(ctx,
		`SELECT d.id, d.client_id, d.db_name, d.db_user, d.engine, d.created_at, c.lxc_container_name
		   FROM databases d
		   JOIN clients c ON c.id = d.client_id
		  WHERE d.id = $1`, id,
	).Scan(&d.ID, &d.ClientID, &d.DBName, &d.DBUser, &d.Engine, &d.CreatedAt, &container)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, "", ErrNotFound
	}
	if err != nil {
		return nil, "", fmt.Errorf("store: get database: %w", err)
	}
	return &d, container, nil
}


func (s *Databases) DeleteDatabase(ctx context.Context, id int64) error {
	tag, err := s.pool.Exec(ctx, `DELETE FROM databases WHERE id = $1`, id)
	if err != nil {
		return fmt.Errorf("store: delete database: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}
