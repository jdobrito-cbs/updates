package store

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/jdobrito/wsrta/internal/core"
)



type Backups struct {
	pool *pgxpool.Pool
}


func NewBackups(pool *pgxpool.Pool) *Backups {
	return &Backups{pool: pool}
}


func (s *Backups) GetClient(ctx context.Context, id int64) (*core.Client, error) {
	var cl core.Client
	err := s.pool.QueryRow(ctx,
		`SELECT id, name, lxc_container_name, status FROM clients WHERE id = $1`, id,
	).Scan(&cl.ID, &cl.Name, &cl.LXCContainerName, &cl.Status)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, ErrNotFound
	}
	if err != nil {
		return nil, fmt.Errorf("store: get client: %w", err)
	}
	return &cl, nil
}


func (s *Backups) ListClientDomains(ctx context.Context, clientID int64) ([]core.Domain, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT id, client_id, fqdn, docroot, php_version FROM domains WHERE client_id = $1 ORDER BY id`, clientID)
	if err != nil {
		return nil, fmt.Errorf("store: list domains: %w", err)
	}
	defer rows.Close()
	var out []core.Domain
	for rows.Next() {
		var d core.Domain
		if err := rows.Scan(&d.ID, &d.ClientID, &d.FQDN, &d.Docroot, &d.PHPVersion); err != nil {
			return nil, err
		}
		out = append(out, d)
	}
	return out, rows.Err()
}


func (s *Backups) ListClientDatabases(ctx context.Context, clientID int64) ([]core.Database, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT id, client_id, db_name, db_user FROM databases WHERE client_id = $1 ORDER BY id`, clientID)
	if err != nil {
		return nil, fmt.Errorf("store: list databases: %w", err)
	}
	defer rows.Close()
	var out []core.Database
	for rows.Next() {
		var d core.Database
		if err := rows.Scan(&d.ID, &d.ClientID, &d.DBName, &d.DBUser); err != nil {
			return nil, err
		}
		out = append(out, d)
	}
	return out, rows.Err()
}


func (s *Backups) CreateBackup(ctx context.Context, clientID int64, note string) (int64, error) {
	var id int64
	err := s.pool.QueryRow(ctx,
		`INSERT INTO backups (client_id, note, status) VALUES ($1, $2, 'pending') RETURNING id`,
		clientID, note).Scan(&id)
	if err != nil {
		return 0, fmt.Errorf("store: create backup: %w", err)
	}
	return id, nil
}


func (s *Backups) SetBackupResult(ctx context.Context, id int64, status, filename string, size int64) error {
	tag, err := s.pool.Exec(ctx,
		`UPDATE backups SET status = $2, filename = $3, size_bytes = $4, finished_at = now() WHERE id = $1`,
		id, status, filename, size)
	if err != nil {
		return fmt.Errorf("store: set backup result: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}


type ScheduledClient struct {
	ClientID   int64
	Schedule   string
	LastBackup *time.Time
}


func (s *Backups) ListScheduledBackups(ctx context.Context) ([]ScheduledClient, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT c.id, c.backup_schedule, MAX(b.created_at) FILTER (WHERE b.status = 'done')
		   FROM clients c
		   LEFT JOIN backups b ON b.client_id = c.id
		  WHERE c.backup_schedule <> '' AND c.status = 'active'
		  GROUP BY c.id, c.backup_schedule`)
	if err != nil {
		return nil, fmt.Errorf("store: list scheduled: %w", err)
	}
	defer rows.Close()
	var out []ScheduledClient
	for rows.Next() {
		var sc ScheduledClient
		if err := rows.Scan(&sc.ClientID, &sc.Schedule, &sc.LastBackup); err != nil {
			return nil, err
		}
		out = append(out, sc)
	}
	return out, rows.Err()
}
