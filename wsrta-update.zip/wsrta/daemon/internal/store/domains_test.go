package store_test

import (
	"context"
	"os"
	"testing"
	"time"

	"github.com/jdobrito/wsrta/daemon/internal/store"
	"github.com/jdobrito/wsrta/internal/db"
)


func TestDomainsStore(t *testing.T) {
	dsn := os.Getenv("WSRTA_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("defina WSRTA_TEST_DATABASE_URL para rodar o teste de integração de domínios")
	}

	ctx := context.Background()
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		t.Fatalf("open db: %v", err)
	}
	defer pool.Close()

	for _, tbl := range []string{"ssl_certs", "domains", "clients", "users"} {
		if _, err := pool.Exec(ctx, "DELETE FROM "+tbl); err != nil {
			t.Fatalf("limpar %s: %v", tbl, err)
		}
	}

	var userID, clientID, domainID int64
	if err := pool.QueryRow(ctx,
		`INSERT INTO users (email, password_hash, role) VALUES ('a@b.c','x','client') RETURNING id`,
	).Scan(&userID); err != nil {
		t.Fatalf("insert user: %v", err)
	}
	if err := pool.QueryRow(ctx,
		`INSERT INTO clients (user_id, name, lxc_container_name) VALUES ($1,'C','cli_1') RETURNING id`, userID,
	).Scan(&clientID); err != nil {
		t.Fatalf("insert client: %v", err)
	}
	if err := pool.QueryRow(ctx,
		`INSERT INTO domains (client_id, fqdn, docroot) VALUES ($1,'exemplo.com','/var/www/exemplo.com') RETURNING id`, clientID,
	).Scan(&domainID); err != nil {
		t.Fatalf("insert domain: %v", err)
	}

	s := store.NewDomains(pool)

	dom, container, err := s.GetDomain(ctx, domainID)
	if err != nil {
		t.Fatalf("get domain: %v", err)
	}
	if dom.FQDN != "exemplo.com" || container != "cli_1" {
		t.Fatalf("domínio/container incorreto: %+v container=%q", dom, container)
	}

	if err := s.UpsertSSLCert(ctx, domainID, "Let's Encrypt", time.Now().AddDate(0, 0, 90), "active"); err != nil {
		t.Fatalf("upsert ssl: %v", err)
	}
	
	if err := s.UpsertSSLCert(ctx, domainID, "Let's Encrypt", time.Now().AddDate(0, 0, 90), "active"); err != nil {
		t.Fatalf("upsert ssl 2: %v", err)
	}
	var n int
	if err := pool.QueryRow(ctx, `SELECT count(*) FROM ssl_certs WHERE domain_id=$1`, domainID).Scan(&n); err != nil {
		t.Fatalf("count: %v", err)
	}
	if n != 1 {
		t.Fatalf("ssl_certs = %d, esperava 1 (upsert substitui)", n)
	}

	if err := s.SetDomainSSL(ctx, domainID, true); err != nil {
		t.Fatalf("set ssl: %v", err)
	}
	dom2, _, _ := s.GetDomain(ctx, domainID)
	if !dom2.SSLEnabled {
		t.Fatal("ssl_enabled deveria ser true")
	}
}
