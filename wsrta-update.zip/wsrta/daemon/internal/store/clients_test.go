package store_test

import (
	"context"
	"errors"
	"os"
	"testing"

	"github.com/jdobrito/wsrta/daemon/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
	"github.com/jdobrito/wsrta/internal/db"
)


func TestClientsStore(t *testing.T) {
	dsn := os.Getenv("WSRTA_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("defina WSRTA_TEST_DATABASE_URL para rodar o teste de integração do store")
	}

	ctx := context.Background()
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		t.Fatalf("open db: %v", err)
	}
	defer pool.Close()

	
	if _, err := pool.Exec(ctx, "DELETE FROM clients"); err != nil {
		t.Fatalf("limpar clients: %v", err)
	}
	if _, err := pool.Exec(ctx, "DELETE FROM users"); err != nil {
		t.Fatalf("limpar users: %v", err)
	}

	var userID int64
	if err := pool.QueryRow(ctx,
		`INSERT INTO users (email, password_hash, role) VALUES ('a@b.c','x','admin') RETURNING id`,
	).Scan(&userID); err != nil {
		t.Fatalf("insert user: %v", err)
	}

	var clientID int64
	if err := pool.QueryRow(ctx,
		`INSERT INTO clients (user_id, name, lxc_container_name, cpu_limit, ram_limit_mb, disk_quota_mb)
		 VALUES ($1, 'Teste', 'cli_1', 1.5, 1024, 10240) RETURNING id`, userID,
	).Scan(&clientID); err != nil {
		t.Fatalf("insert client: %v", err)
	}

	s := store.NewClients(pool)

	cl, err := s.GetClient(ctx, clientID)
	if err != nil {
		t.Fatalf("get client: %v", err)
	}
	if cl.LXCContainerName != "cli_1" || cl.CPULimit != 1.5 || cl.RAMLimitMB != 1024 {
		t.Fatalf("client lido incorreto: %+v", cl)
	}

	if err := s.SetClientStatus(ctx, clientID, core.ClientActive); err != nil {
		t.Fatalf("set status: %v", err)
	}
	cl2, _ := s.GetClient(ctx, clientID)
	if cl2.Status != core.ClientActive {
		t.Fatalf("status = %q, esperava active", cl2.Status)
	}

	if _, err := s.GetClient(ctx, 999999); !errors.Is(err, store.ErrNotFound) {
		t.Fatalf("esperava ErrNotFound, veio %v", err)
	}
}
