package store

import (
	"context"
	"errors"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/jdobrito/wsrta/internal/core"
)


type Domains struct {
	pool *pgxpool.Pool
}


func NewDomains(pool *pgxpool.Pool) *Domains {
	return &Domains{pool: pool}
}


func (s *Domains) GetDomain(ctx context.Context, id int64) (*core.Domain, string, error) {
	var d core.Domain
	var container string
	err := s.pool.QueryRow(ctx,
		`SELECT d.id, d.client_id, d.fqdn, d.docroot, d.php_version, d.ssl_enabled, d.created_at,
		        d.upstream_ip, d.upstream_port, d.upstream_path, c.lxc_container_name
		   FROM domains d
		   JOIN clients c ON c.id = d.client_id
		  WHERE d.id = $1`, id,
	).Scan(&d.ID, &d.ClientID, &d.FQDN, &d.Docroot, &d.PHPVersion, &d.SSLEnabled, &d.CreatedAt, &d.UpstreamIP, &d.UpstreamPort, &d.UpstreamPath, &container)
	if errors.Is(err, pgx.ErrNoRows) {
		return nil, "", ErrNotFound
	}
	if err != nil {
		return nil, "", fmt.Errorf("store: get domain: %w", err)
	}
	return &d, container, nil
}


func (s *Domains) ListForwards(ctx context.Context, domainID int64) ([]core.DomainForward, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT id, domain_id, path, target, COALESCE(target_domain_id, 0), created_at
		   FROM domain_forwards WHERE domain_id = $1 ORDER BY path`, domainID)
	if err != nil {
		return nil, fmt.Errorf("store: list forwards: %w", err)
	}
	defer rows.Close()
	var out []core.DomainForward
	for rows.Next() {
		var f core.DomainForward
		if err := rows.Scan(&f.ID, &f.DomainID, &f.Path, &f.Target, &f.TargetDomainID, &f.CreatedAt); err != nil {
			return nil, fmt.Errorf("store: scan forward: %w", err)
		}
		out = append(out, f)
	}
	return out, rows.Err()
}


func (s *Domains) SetDomainSSL(ctx context.Context, id int64, enabled bool) error {
	tag, err := s.pool.Exec(ctx, `UPDATE domains SET ssl_enabled = $2 WHERE id = $1`, id, enabled)
	if err != nil {
		return fmt.Errorf("store: set domain ssl: %w", err)
	}
	if tag.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}


func (s *Domains) DeleteDomain(ctx context.Context, id int64) error {
	if _, err := s.pool.Exec(ctx, `DELETE FROM domains WHERE id = $1`, id); err != nil {
		return fmt.Errorf("store: delete domain: %w", err)
	}
	return nil
}


func (s *Domains) UpsertSSLCert(ctx context.Context, domainID int64, issuer string, expiresAt time.Time, status string) error {
	tx, err := s.pool.Begin(ctx)
	if err != nil {
		return fmt.Errorf("store: begin: %w", err)
	}
	defer tx.Rollback(ctx) 

	if _, err := tx.Exec(ctx, `DELETE FROM ssl_certs WHERE domain_id = $1`, domainID); err != nil {
		return fmt.Errorf("store: limpar ssl_certs: %w", err)
	}
	if _, err := tx.Exec(ctx,
		`INSERT INTO ssl_certs (domain_id, issuer, expires_at, status) VALUES ($1, $2, $3, $4)`,
		domainID, issuer, expiresAt, status,
	); err != nil {
		return fmt.Errorf("store: inserir ssl_cert: %w", err)
	}
	return tx.Commit(ctx)
}
