package store_test

import (
	"context"
	"os"
	"testing"

	"github.com/jdobrito/wsrta/daemon/internal/store"
	"github.com/jdobrito/wsrta/internal/db"
)


func TestPhase4Stores(t *testing.T) {
	dsn := os.Getenv("WSRTA_TEST_DATABASE_URL")
	if dsn == "" {
		t.Skip("defina WSRTA_TEST_DATABASE_URL para rodar a integração da Fase 4")
	}

	ctx := context.Background()
	pool, err := db.Open(ctx, dsn)
	if err != nil {
		t.Fatalf("open db: %v", err)
	}
	defer pool.Close()

	for _, tbl := range []string{"cron_jobs", "dns_records", "databases", "domains", "clients", "users"} {
		if _, err := pool.Exec(ctx, "DELETE FROM "+tbl); err != nil {
			t.Fatalf("limpar %s: %v", tbl, err)
		}
	}

	var userID, clientID, domainID, dbID, dnsID, cronID int64
	mustScan(t, pool.QueryRow(ctx,
		`INSERT INTO users (email,password_hash,role) VALUES ('a@b.c','x','client') RETURNING id`).Scan(&userID))
	mustScan(t, pool.QueryRow(ctx,
		`INSERT INTO clients (user_id,name,lxc_container_name) VALUES ($1,'C','cli_1') RETURNING id`, userID).Scan(&clientID))
	mustScan(t, pool.QueryRow(ctx,
		`INSERT INTO domains (client_id,fqdn,docroot) VALUES ($1,'exemplo.com','/var/www/exemplo.com') RETURNING id`, clientID).Scan(&domainID))
	mustScan(t, pool.QueryRow(ctx,
		`INSERT INTO databases (client_id,db_name,db_user) VALUES ($1,'app','appuser') RETURNING id`, clientID).Scan(&dbID))
	mustScan(t, pool.QueryRow(ctx,
		`INSERT INTO dns_records (domain_id,type,name,content,ttl,prio) VALUES ($1,'MX','exemplo.com','mail.exemplo.com',3600,10) RETURNING id`, domainID).Scan(&dnsID))
	mustScan(t, pool.QueryRow(ctx,
		`INSERT INTO cron_jobs (client_id,schedule,command) VALUES ($1,'@daily','echo hi') RETURNING id`, clientID).Scan(&cronID))

	
	dbStore := store.NewDatabases(pool)
	d, container, err := dbStore.GetDatabase(ctx, dbID)
	if err != nil || d.DBName != "app" || container != "cli_1" {
		t.Fatalf("GetDatabase: %+v container=%q err=%v", d, container, err)
	}

	
	dnsStore := store.NewDNS(pool)
	rec, zone, err := dnsStore.GetDNSRecord(ctx, dnsID)
	if err != nil || zone != "exemplo.com" || rec.Prio == nil || *rec.Prio != 10 {
		t.Fatalf("GetDNSRecord: %+v zone=%q err=%v", rec, zone, err)
	}
	if err := dnsStore.DeleteDNSRecord(ctx, dnsID); err != nil {
		t.Fatalf("DeleteDNSRecord: %v", err)
	}

	
	cronStore := store.NewCron(pool)
	job, c2, err := cronStore.GetCronJob(ctx, cronID)
	if err != nil || job.Schedule != "@daily" || c2 != "cli_1" {
		t.Fatalf("GetCronJob: %+v container=%q err=%v", job, c2, err)
	}
	if err := cronStore.DeleteCronJob(ctx, cronID); err != nil {
		t.Fatalf("DeleteCronJob: %v", err)
	}
}

func mustScan(t *testing.T, err error) {
	t.Helper()
	if err != nil {
		t.Fatalf("insert/scan: %v", err)
	}
}
