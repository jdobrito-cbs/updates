package executors

import "fmt"




func wsrtaTestPage(fqdn string) string {
	return fmt.Sprintf(`<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>%[1]s · WSRTA</title>
<style>
  *{box-sizing:border-box} html,body{height:100%%;margin:0}
  body{display:grid;place-items:center;padding:24px;font-family:"Segoe UI",system-ui,-apple-system,Roboto,Arial,sans-serif;color:#e6e8ec;
    background:radial-gradient(900px 520px at 18%% -10%%,rgba(84,182,174,.18),transparent 60%%),radial-gradient(760px 520px at 110%% 120%%,rgba(84,182,174,.10),transparent 55%%),#14161b}
  .card{width:min(560px,100%%);text-align:center;background:#1b1e24;border:1px solid #2a2f38;border-radius:20px;padding:44px 36px;
    box-shadow:0 24px 60px -28px rgba(0,0,0,.7)}
  .logo{display:inline-flex;margin-bottom:18px}
  h1{margin:0;font-size:2rem;letter-spacing:.5px}
  .domain{margin:6px 0 0;font-family:ui-monospace,Consolas,monospace;color:#54b6ae;font-size:1.02rem;word-break:break-all}
  .badge{display:inline-flex;align-items:center;gap:8px;margin:22px 0 14px;padding:7px 16px;border-radius:999px;font-weight:600;font-size:.9rem;
    color:#4fb477;background:rgba(79,180,119,.14);border:1px solid rgba(79,180,119,.32)}
  .badge::before{content:"";width:8px;height:8px;border-radius:50%%;background:#4fb477;box-shadow:0 0 0 0 rgba(79,180,119,.6);animation:p 2s infinite}
  @keyframes p{0%%{box-shadow:0 0 0 0 rgba(79,180,119,.5)}70%%{box-shadow:0 0 0 9px rgba(79,180,119,0)}100%%{box-shadow:0 0 0 0 rgba(79,180,119,0)}}
  .msg{color:#9ba1ac;line-height:1.6;margin:0;font-size:.95rem}
  .ft{margin-top:26px;font-size:.74rem;color:#69707c}
  @media (prefers-reduced-motion:reduce){.badge::before{animation:none}}
</style>
</head>
<body>
  <div class="card">
    <span class="logo">
      <svg width="64" height="64" viewBox="0 0 48 48" fill="none" aria-label="WSRTA">
        <defs>
          <linearGradient id="b" x1="7" y1="5" x2="41" y2="43" gradientUnits="userSpaceOnUse"><stop stop-color="#74D4CB"/><stop offset=".55" stop-color="#54B6AE"/><stop offset="1" stop-color="#3A968E"/></linearGradient>
          <radialGradient id="s" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(13 9) rotate(55) scale(42)"><stop stop-color="#fff" stop-opacity=".42"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>
        </defs>
        <rect x="2" y="2" width="44" height="44" rx="14" fill="url(#b)"/>
        <rect x="2" y="2" width="44" height="44" rx="14" fill="url(#s)"/>
        <rect x="2.5" y="2.5" width="43" height="43" rx="13.5" stroke="#fff" stroke-opacity=".22"/>
        <path d="M13 16 L18.5 32 L24 23 L29.5 32 L35 16" transform="translate(0 1)" stroke="#205c56" stroke-opacity=".35" stroke-width="4.2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M13 16 L18.5 32 L24 23 L29.5 32 L35 16" stroke="#fff" stroke-width="4.2" stroke-linecap="round" stroke-linejoin="round"/>
        <circle cx="24" cy="22.4" r="3.7" fill="#fff"/><circle cx="24" cy="22.4" r="1.7" fill="#3A968E"/>
      </svg>
    </span>
    <h1>WSRTA</h1>
    <p class="domain">%[1]s</p>
    <div class="badge">Página habilitada</div>
    <p class="msg">Seu domínio está ativo e a área da página foi criada com sucesso.<br/>
      <strong style="color:#e6e8ec">Site em construção</strong> — em breve, o seu conteúdo aqui.</p>
    <p class="ft">Servido pelo WSRTA · Painel de Controle de Hospedagem</p>
  </div>
</body>
</html>
`, fqdn)
}
