package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"path"

	"github.com/jdobrito/wsrta/daemon/internal/nginx"
	"github.com/jdobrito/wsrta/internal/core"
)




type ApplySiteRulesExecutor struct {
	deps WebDeps
}


func NewApplySiteRulesExecutor(deps WebDeps) *ApplySiteRulesExecutor {
	return &ApplySiteRulesExecutor{deps: deps}
}

func (e *ApplySiteRulesExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.ApplySiteRulesPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	dom, container, err := e.deps.Domains.GetDomain(ctx, p.DomainID)
	if err != nil {
		return "", fmt.Errorf("buscar domínio %d: %w", p.DomainID, err)
	}
	if err := core.ValidFQDN(dom.FQDN); err != nil {
		return "", err
	}
	docroot := e.deps.docrootFor(dom)

	
	if err := e.deps.LXD.PushFile(ctx, container, path.Join(docroot, ".user.ini"), []byte(p.UserINI), 0o644); err != nil {
		return "", fmt.Errorf("gravar .user.ini: %w", err)
	}

	
	vhost, err := nginx.RenderContainerVHost(nginx.ContainerVHost{
		FQDN:      dom.FQDN,
		Docroot:   docroot,
		PHPSocket: e.deps.resolvePHPSocket(ctx, container, dom.PHPVersion),
		Extra:     p.VHostExtra,
	})
	if err != nil {
		return "", fmt.Errorf("render vhost: %w", err)
	}
	if err := e.deps.LXD.PushFile(ctx, container, internalVHostPath(dom.FQDN), []byte(vhost), 0o644); err != nil {
		return "", fmt.Errorf("escrever vhost: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, container, "nginx", "-t"); err != nil {
		
		
		if base, e2 := nginx.RenderContainerVHost(nginx.ContainerVHost{
			FQDN: dom.FQDN, Docroot: docroot, PHPSocket: e.deps.resolvePHPSocket(ctx, container, dom.PHPVersion),
		}); e2 == nil {
			if e3 := e.deps.LXD.PushFile(ctx, container, internalVHostPath(dom.FQDN), []byte(base), 0o644); e3 == nil {
				_ = runExec(ctx, e.deps.LXD, container, "nginx", "-s", "reload")
			}
		}
		return "", fmt.Errorf("nginx -t: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, container, "nginx", "-s", "reload"); err != nil {
		return "", fmt.Errorf("reload nginx: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "regras do site aplicadas", slog.String("fqdn", dom.FQDN))
	return fmt.Sprintf("regras aplicadas em %q", dom.FQDN), nil
}
