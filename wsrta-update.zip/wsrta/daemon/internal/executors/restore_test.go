package executors_test

import (
	"context"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/jdobrito/wsrta/daemon/internal/acme"
	"github.com/jdobrito/wsrta/daemon/internal/executors"
	"github.com/jdobrito/wsrta/daemon/internal/nginx"
	"github.com/jdobrito/wsrta/internal/core"
)

func tempFile(t *testing.T, name string, content []byte) string {
	t.Helper()
	p := filepath.Join(t.TempDir(), name)
	if err := os.WriteFile(p, content, 0o644); err != nil {
		t.Fatalf("temp file: %v", err)
	}
	return p
}

func TestRestoreDatabaseCreatesAndImports(t *testing.T) {
	l := runningContainer(t)
	st := &fakeStore{client: sampleClient()}
	dump := tempFile(t, "app.sql", []byte("CREATE TABLE x(id int);"))
	exec := executors.NewRestoreDatabaseExecutor(newDeps(l, st))

	
	payload, _ := json.Marshal(core.RestoreDatabasePayload{
		ClientID: 1, DBName: "app", DBUser: "appuser",
		DBPasswordHash: "*DD67B44D45A67D8144BBA462DEC621FA903E8F09", DumpPath: dump,
	})
	if _, err := exec.Execute(context.Background(), &core.Action{ID: 1, Payload: payload}); err != nil {
		t.Fatalf("execute: %v", err)
	}

	var created, imported bool
	for _, c := range l.ExecCalls {
		if len(c.Cmd) >= 3 && c.Cmd[0] == "mysql" && c.Cmd[1] == "-e" && strings.Contains(c.Cmd[2], "CREATE DATABASE") {
			created = true
		}
		if len(c.Cmd) == 2 && c.Cmd[0] == "mysql" && c.Cmd[1] == "app" {
			imported = true
		}
	}
	if !created {
		t.Fatalf("CREATE DATABASE não executado: %+v", l.ExecCalls)
	}
	if !imported {
		t.Fatalf("import do dump (mysql app) não executado: %+v", l.ExecCalls)
	}
}

func TestRestoreFilesPushesAndExtracts(t *testing.T) {
	l := runningContainer(t)
	st := &fakeDomainStore{domain: sampleDomain(), container: "cli_1"}
	archive := tempFile(t, "site.tar.gz", []byte("fake-tarball"))
	exec := executors.NewRestoreFilesExecutor(newWebDeps(l, nginx.NewFake(), acme.NewFake(), st))

	payload, _ := json.Marshal(core.RestoreFilesPayload{DomainID: 1, ArchivePath: archive})
	if _, err := exec.Execute(context.Background(), &core.Action{ID: 1, Payload: payload}); err != nil {
		t.Fatalf("execute: %v", err)
	}

	if _, ok := l.Files["cli_1:/tmp/wsrta-restore.tar.gz"]; !ok {
		t.Fatalf("tarball não enviado: %v", l.Files)
	}
	var extracted bool
	for _, c := range l.ExecCalls {
		if len(c.Cmd) >= 2 && c.Cmd[0] == "tar" && c.Cmd[1] == "xzf" {
			extracted = true
		}
	}
	if !extracted {
		t.Fatalf("tar de extração não executado: %+v", l.ExecCalls)
	}
}
