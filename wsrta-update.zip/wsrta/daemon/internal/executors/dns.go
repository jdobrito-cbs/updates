package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/internal/core"
)


type DNSDeps struct {
	Backend DNSBackend
	Store   DNSStore
	Log     *slog.Logger
}


type SetDNSRecordExecutor struct {
	deps DNSDeps
}


func NewSetDNSRecordExecutor(deps DNSDeps) *SetDNSRecordExecutor {
	return &SetDNSRecordExecutor{deps: deps}
}

func (e *SetDNSRecordExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.SetDNSRecordPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}

	rec, zone, err := e.deps.Store.GetDNSRecord(ctx, p.DNSRecordID)
	if err != nil {
		return "", fmt.Errorf("buscar registro %d: %w", p.DNSRecordID, err)
	}

	if err := e.deps.Backend.EnsureZone(ctx, zone); err != nil {
		return "", fmt.Errorf("garantir zona %q: %w", zone, err)
	}
	if err := e.deps.Backend.SetRecord(ctx, zone, rec.Name, rec.Type, rec.Content, rec.TTL, prioOf(rec)); err != nil {
		return "", fmt.Errorf("gravar registro: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "registro DNS aplicado",
		slog.String("zone", zone), slog.String("name", rec.Name), slog.String("type", rec.Type))
	return fmt.Sprintf("registro %s %s aplicado na zona %q", rec.Type, rec.Name, zone), nil
}


type DeleteDNSRecordExecutor struct {
	deps DNSDeps
}


func NewDeleteDNSRecordExecutor(deps DNSDeps) *DeleteDNSRecordExecutor {
	return &DeleteDNSRecordExecutor{deps: deps}
}

func (e *DeleteDNSRecordExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.DeleteDNSRecordPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}

	rec, zone, err := e.deps.Store.GetDNSRecord(ctx, p.DNSRecordID)
	if err != nil {
		return "", fmt.Errorf("buscar registro %d: %w", p.DNSRecordID, err)
	}

	if err := e.deps.Backend.DeleteRecord(ctx, zone, rec.Name, rec.Type, rec.Content, prioOf(rec)); err != nil {
		return "", fmt.Errorf("remover registro do PowerDNS: %w", err)
	}
	if err := e.deps.Store.DeleteDNSRecord(ctx, rec.ID); err != nil {
		return "", fmt.Errorf("apagar registro do painel: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "registro DNS removido",
		slog.String("zone", zone), slog.String("name", rec.Name), slog.String("type", rec.Type))
	return fmt.Sprintf("registro %s %s removido da zona %q", rec.Type, rec.Name, zone), nil
}


func prioOf(rec *core.DNSRecord) int {
	if rec.Prio != nil {
		return *rec.Prio
	}
	return 0
}
