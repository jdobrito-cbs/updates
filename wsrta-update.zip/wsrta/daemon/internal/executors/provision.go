package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/daemon/internal/lxd"
	"github.com/jdobrito/wsrta/internal/core"
)


type Deps struct {
	LXD      lxd.Client
	Store    ClientStore
	Log      *slog.Logger
	Image    string           
	Pool     string           
	Network  string           
	Progress ProgressReporter 
}



type ProvisionClientExecutor struct {
	deps Deps
}


func NewProvisionClientExecutor(deps Deps) *ProvisionClientExecutor {
	return &ProvisionClientExecutor{deps: deps}
}

func (e *ProvisionClientExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.ProvisionClientPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}

	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	name := client.LXCContainerName
	log := e.deps.Log.With(slog.Int64("client_id", client.ID), slog.String("container", name))

	if err := e.deps.Store.SetClientStatus(ctx, client.ID, core.ClientProvisioning); err != nil {
		return "", fmt.Errorf("status provisioning: %w", err)
	}

	exists, err := e.deps.LXD.Exists(ctx, name)
	if err != nil {
		return "", fmt.Errorf("verificar existência: %w", err)
	}

	created := false
	if !exists {
		spec := lxd.ContainerSpec{
			Name:        name,
			Image:       e.deps.Image,
			CPULimit:    client.CPULimit,
			RAMLimitMB:  client.RAMLimitMB,
			DiskQuotaMB: client.DiskQuotaMB,
			StoragePool: e.deps.Pool,
			Network:     e.deps.Network,
		}
		if err := e.deps.LXD.Create(ctx, spec); err != nil {
			return "", fmt.Errorf("criar container: %w", err)
		}
		created = true
		log.InfoContext(ctx, "container criado")
	} else {
		log.InfoContext(ctx, "container já existe; criação pulada (idempotente)")
	}

	
	info, err := e.deps.LXD.Info(ctx, name)
	if err != nil {
		e.rollback(ctx, name, created)
		return "", fmt.Errorf("obter estado: %w", err)
	}
	if info.Status != lxd.StatusRunning {
		if err := e.deps.LXD.Start(ctx, name); err != nil {
			e.rollback(ctx, name, created)
			return "", fmt.Errorf("iniciar container: %w", err)
		}
		log.InfoContext(ctx, "container iniciado")
	}

	if err := e.deps.Store.SetClientStatus(ctx, client.ID, core.ClientActive); err != nil {
		return "", fmt.Errorf("status active: %w", err)
	}
	return fmt.Sprintf("container %q provisionado e ativo", name), nil
}



func (e *ProvisionClientExecutor) rollback(ctx context.Context, name string, created bool) {
	if !created {
		return
	}
	if err := e.deps.LXD.Delete(ctx, name); err != nil {
		e.deps.Log.ErrorContext(ctx, "rollback: falha ao remover container",
			slog.String("container", name), slog.Any("err", err))
	}
}
