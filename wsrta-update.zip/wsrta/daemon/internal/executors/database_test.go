package executors_test

import (
	"context"
	"encoding/json"
	"errors"
	"strings"
	"testing"

	"github.com/jdobrito/wsrta/daemon/internal/executors"
	"github.com/jdobrito/wsrta/internal/core"
)

type fakeDatabaseStore struct {
	db        *core.Database
	container string
	deleted   bool
}

func (s *fakeDatabaseStore) GetDatabase(_ context.Context, id int64) (*core.Database, string, error) {
	if s.db == nil || s.db.ID != id {
		return nil, "", errors.New("banco não encontrado")
	}
	d := *s.db
	return &d, s.container, nil
}

func (s *fakeDatabaseStore) DeleteDatabase(_ context.Context, _ int64) error {
	s.deleted = true
	return nil
}

func TestCreateDatabaseRunsMySQLAndReturnsPassword(t *testing.T) {
	l := runningContainer(t)
	st := &fakeDatabaseStore{db: &core.Database{ID: 1, ClientID: 1, DBName: "app", DBUser: "appuser"}, container: "cli_1"}
	exec := executors.NewCreateDatabaseExecutor(executors.DBDeps{LXD: l, Store: st, Log: discardLogger()})

	payload, _ := json.Marshal(core.CreateDatabasePayload{DatabaseID: 1})
	res, err := exec.Execute(context.Background(), &core.Action{ID: 1, Payload: payload})
	if err != nil {
		t.Fatalf("execute: %v", err)
	}
	if !strings.Contains(res, "senha") {
		t.Fatalf("resultado sem senha: %s", res)
	}
	found := false
	for _, c := range l.ExecCalls {
		if len(c.Cmd) >= 3 && c.Cmd[0] == "mysql" &&
			strings.Contains(c.Cmd[2], "CREATE DATABASE") && strings.Contains(c.Cmd[2], "`app`") {
			found = true
		}
	}
	if !found {
		t.Fatalf("mysql CREATE DATABASE não executado: %+v", l.ExecCalls)
	}
}

func TestCreateDatabaseRejectsBadIdent(t *testing.T) {
	l := runningContainer(t)
	st := &fakeDatabaseStore{db: &core.Database{ID: 1, DBName: "bad;DROP", DBUser: "u"}, container: "cli_1"}
	exec := executors.NewCreateDatabaseExecutor(executors.DBDeps{LXD: l, Store: st, Log: discardLogger()})

	payload, _ := json.Marshal(core.CreateDatabasePayload{DatabaseID: 1})
	if _, err := exec.Execute(context.Background(), &core.Action{ID: 1, Payload: payload}); err == nil {
		t.Fatal("esperava erro de identificador inválido")
	}
}

func TestDropDatabaseDeletesRow(t *testing.T) {
	l := runningContainer(t)
	st := &fakeDatabaseStore{db: &core.Database{ID: 1, DBName: "app", DBUser: "appuser"}, container: "cli_1"}
	exec := executors.NewDropDatabaseExecutor(executors.DBDeps{LXD: l, Store: st, Log: discardLogger()})

	payload, _ := json.Marshal(core.DropDatabasePayload{DatabaseID: 1})
	if _, err := exec.Execute(context.Background(), &core.Action{ID: 1, Payload: payload}); err != nil {
		t.Fatalf("execute: %v", err)
	}
	if !st.deleted {
		t.Fatal("DeleteDatabase não foi chamado")
	}
}
