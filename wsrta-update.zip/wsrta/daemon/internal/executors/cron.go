package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/daemon/internal/lxd"
	"github.com/jdobrito/wsrta/internal/core"
)


type CronDeps struct {
	LXD      lxd.Client
	Store    CronStore
	Log      *slog.Logger
	CronUser string
}


func cronFilePath(id int64) string {
	return fmt.Sprintf("/etc/cron.d/wsrta-%d", id)
}



type SetCronExecutor struct {
	deps CronDeps
}


func NewSetCronExecutor(deps CronDeps) *SetCronExecutor {
	return &SetCronExecutor{deps: deps}
}

func (e *SetCronExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.SetCronPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}

	job, container, err := e.deps.Store.GetCronJob(ctx, p.CronJobID)
	if err != nil {
		return "", fmt.Errorf("buscar cron %d: %w", p.CronJobID, err)
	}
	if err := validateCron(job.Schedule, job.Command); err != nil {
		return "", err
	}

	path := cronFilePath(job.ID)
	if !job.Enabled {
		if err := runExec(ctx, e.deps.LXD, container, "rm", "-f", path); err != nil {
			return "", fmt.Errorf("remover cron desabilitado: %w", err)
		}
		e.deps.Log.InfoContext(ctx, "cron desabilitado (arquivo removido)", slog.Int64("cron_id", job.ID))
		return fmt.Sprintf("cron %d desabilitado", job.ID), nil
	}

	
	content := fmt.Sprintf("%s %s %s\n", job.Schedule, e.deps.CronUser, job.Command)
	if err := e.deps.LXD.PushFile(ctx, container, path, []byte(content), 0o644); err != nil {
		return "", fmt.Errorf("escrever arquivo de cron: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "cron aplicado", slog.Int64("cron_id", job.ID))
	return fmt.Sprintf("cron %d aplicado", job.ID), nil
}


type RemoveCronExecutor struct {
	deps CronDeps
}


func NewRemoveCronExecutor(deps CronDeps) *RemoveCronExecutor {
	return &RemoveCronExecutor{deps: deps}
}

func (e *RemoveCronExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.RemoveCronPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}

	job, container, err := e.deps.Store.GetCronJob(ctx, p.CronJobID)
	if err != nil {
		return "", fmt.Errorf("buscar cron %d: %w", p.CronJobID, err)
	}

	exists, err := e.deps.LXD.Exists(ctx, container)
	if err != nil {
		return "", fmt.Errorf("verificar container: %w", err)
	}
	if exists {
		if err := runExec(ctx, e.deps.LXD, container, "rm", "-f", cronFilePath(job.ID)); err != nil {
			return "", fmt.Errorf("remover arquivo de cron: %w", err)
		}
	}
	if err := e.deps.Store.DeleteCronJob(ctx, job.ID); err != nil {
		return "", fmt.Errorf("apagar registro de cron: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "cron removido", slog.Int64("cron_id", job.ID))
	return fmt.Sprintf("cron %d removido", job.ID), nil
}
