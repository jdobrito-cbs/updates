package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"regexp"
	"strings"

	"github.com/jdobrito/wsrta/daemon/internal/nginx"
	"github.com/jdobrito/wsrta/internal/core"
)



var fastcgiPassRe = regexp.MustCompile(`fastcgi_pass unix:[^;]*;`)




type SetDomainPHPExecutor struct {
	deps WebDeps
}


func NewSetDomainPHPExecutor(deps WebDeps) *SetDomainPHPExecutor {
	return &SetDomainPHPExecutor{deps: deps}
}

func (e *SetDomainPHPExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.SetDomainPHPPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	dom, container, err := e.deps.Domains.GetDomain(ctx, p.DomainID)
	if err != nil {
		return "", fmt.Errorf("buscar domínio %d: %w", p.DomainID, err)
	}
	log := e.deps.Log.With(slog.String("fqdn", dom.FQDN), slog.String("php", p.PHPVersion))

	if err := e.ensurePHP(ctx, container, p.PHPVersion, log); err != nil {
		return "", err
	}

	
	
	socket := phpSocket(p.PHPVersion)
	if err := e.repointVHost(ctx, container, dom, socket); err != nil {
		return "", err
	}
	if err := runExec(ctx, e.deps.LXD, container, "nginx", "-t"); err != nil {
		return "", fmt.Errorf("nginx -t no container: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, container, "nginx", "-s", "reload"); err != nil {
		return "", fmt.Errorf("reload nginx no container: %w", err)
	}
	log.InfoContext(ctx, "versão de PHP do domínio aplicada", slog.String("socket", socket))
	return fmt.Sprintf("PHP %s aplicado em %q", p.PHPVersion, dom.FQDN), nil
}



func (e *SetDomainPHPExecutor) ensurePHP(ctx context.Context, container, v string, log *slog.Logger) error {
	
	if res, err := e.deps.LXD.Exec(ctx, container, []string{"test", "-S", "/run/php/php" + v + "-fpm.sock"}, nil); err == nil && res.ExitCode == 0 {
		return nil
	}
	
	if !e.aptHasPackage(ctx, container, "php"+v+"-fpm") {
		if err := e.addOndrejPPA(ctx, container, log); err != nil {
			return fmt.Errorf("adicionar PPA do PHP: %w", err)
		}
	}
	pkgs := []string{
		"php" + v + "-fpm", "php" + v + "-mysql", "php" + v + "-mbstring", "php" + v + "-xml",
		"php" + v + "-curl", "php" + v + "-gd", "php" + v + "-zip", "php" + v + "-intl",
	}
	
	
	_ = runExec(ctx, e.deps.LXD, container, "apt-get", "update")
	install := append([]string{"env", "DEBIAN_FRONTEND=noninteractive", "apt-get", "install", "-y", "--no-install-recommends"}, pkgs...)
	if err := runExec(ctx, e.deps.LXD, container, install...); err != nil {
		return fmt.Errorf("instalar php%s-fpm: %w", v, err)
	}
	_ = runExec(ctx, e.deps.LXD, container, "systemctl", "enable", "--now", "php"+v+"-fpm")
	
	
	if res, err := e.deps.LXD.Exec(ctx, container, []string{"test", "-S", "/run/php/php" + v + "-fpm.sock"}, nil); err != nil || res.ExitCode != 0 {
		return fmt.Errorf("php%s-fpm instalado mas o socket /run/php/php%s-fpm.sock não subiu (serviço não iniciou)", v, v)
	}
	return nil
}


func (e *SetDomainPHPExecutor) aptHasPackage(ctx context.Context, container, pkg string) bool {
	res, err := e.deps.LXD.Exec(ctx, container, []string{"apt-cache", "policy", pkg}, nil)
	if err != nil {
		return false
	}
	return strings.Contains(res.Stdout, "Candidate:") && !strings.Contains(res.Stdout, "Candidate: (none)")
}



func (e *SetDomainPHPExecutor) addOndrejPPA(ctx context.Context, container string, log *slog.Logger) error {
	log.InfoContext(ctx, "adicionando o PPA ondrej/php ao container (multi-PHP)")
	_ = runExec(ctx, e.deps.LXD, container, "env", "DEBIAN_FRONTEND=noninteractive", "apt-get", "install", "-y", "software-properties-common")
	if err := runExec(ctx, e.deps.LXD, container, "env", "DEBIAN_FRONTEND=noninteractive", "add-apt-repository", "-y", "ppa:ondrej/php"); err != nil {
		return err
	}
	return runExec(ctx, e.deps.LXD, container, "apt-get", "update")
}



func (e *SetDomainPHPExecutor) repointVHost(ctx context.Context, container string, dom *core.Domain, socket string) error {
	vhostPath := internalVHostPath(dom.FQDN)
	res, err := e.deps.LXD.Exec(ctx, container, []string{"cat", vhostPath}, nil)
	if err == nil && res.ExitCode == 0 && fastcgiPassRe.MatchString(res.Stdout) {
		updated := fastcgiPassRe.ReplaceAllString(res.Stdout, "fastcgi_pass unix:"+socket+";")
		return e.deps.LXD.PushFile(ctx, container, vhostPath, []byte(updated), 0o644)
	}
	vhost, err := nginx.RenderContainerVHost(nginx.ContainerVHost{FQDN: dom.FQDN, Docroot: e.deps.docrootFor(dom), PHPSocket: socket})
	if err != nil {
		return err
	}
	return e.deps.LXD.PushFile(ctx, container, vhostPath, []byte(vhost), 0o644)
}
