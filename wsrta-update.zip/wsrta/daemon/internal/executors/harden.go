package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/internal/core"
)




const hardeningPlugin = `<?php
/* Plugin Name: WSRTA Hardening
   Description: Mitiga enumeracao de usuarios (CVE-2017-5487) e reforca o WordPress. Gerado pelo WSRTA. */
if (!defined('ABSPATH')) { exit; }

// 1) Esconde o endpoint REST de usuarios para visitantes NAO autenticados.
add_filter('rest_endpoints', function ($endpoints) {
    if (!is_user_logged_in()) {
        unset($endpoints['/wp/v2/users']);
        unset($endpoints['/wp/v2/users/(?P<id>[\d]+)']);
    }
    return $endpoints;
});

// 2) Bloqueia enumeracao por ?author=N (301 para a home).
add_action('template_redirect', function () {
    if (!is_admin() && isset($_GET['author']) && preg_match('/^\d+$/', (string) $_GET['author'])) {
        wp_safe_redirect(home_url('/'), 301);
        exit;
    }
});

// 3) Remove a meta tag de versao do WP (reduz fingerprinting).
remove_action('wp_head', 'wp_generator');

// 4) Desliga o pingback do XML-RPC (vetor de DDoS/brute-force).
add_filter('xmlrpc_methods', function ($methods) {
    unset($methods['pingback.ping']);
    return $methods;
});
`



type HardenWordPressExecutor struct {
	deps WebDeps
}


func NewHardenWordPressExecutor(deps WebDeps) *HardenWordPressExecutor {
	return &HardenWordPressExecutor{deps: deps}
}

func (e *HardenWordPressExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.HardenWordPressPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	dom, container, err := e.deps.Domains.GetDomain(ctx, p.DomainID)
	if err != nil {
		return "", fmt.Errorf("buscar domínio %d: %w", p.DomainID, err)
	}
	
	dir, _ := targetDirAndURL(e.deps.docrootFor(dom), dom.FQDN, p.Path)
	muDir := dir + "/wp-content/mu-plugins"
	if err := runExec(ctx, e.deps.LXD, container, "mkdir", "-p", muDir); err != nil {
		return "", fmt.Errorf("criar mu-plugins: %w", err)
	}
	if err := e.deps.LXD.PushFile(ctx, container, muDir+"/wsrta-hardening.php", []byte(hardeningPlugin), 0o644); err != nil {
		return "", fmt.Errorf("gravar mu-plugin de hardening: %w", err)
	}
	
	_ = runExec(ctx, e.deps.LXD, container, "chown", "www-data:www-data", muDir+"/wsrta-hardening.php")
	e.deps.Log.InfoContext(ctx, "wordpress protegido (hardening)",
		slog.Int64("domain_id", p.DomainID), slog.String("path", p.Path))
	return "WordPress protegido: mu-plugin de hardening instalado (bloqueia enumeração de usuários, esconde a versão, desliga pingback).", nil
}
