package executors

import (
	"context"
	"log/slog"

	"github.com/jdobrito/wsrta/internal/core"
)




type StubExecutor struct {
	log *slog.Logger
}


func NewStubExecutor(log *slog.Logger) *StubExecutor {
	return &StubExecutor{log: log}
}


func (s *StubExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	s.log.InfoContext(ctx, "executor stub: nenhuma operação real (Fase 1)",
		slog.Int64("action_id", a.ID),
		slog.String("type", string(a.Type)),
		slog.String("payload", string(a.Payload)),
	)
	return "stub: nenhuma operação real executada (Fase 1)", nil
}



func RegisterStubs(r *Registry, log *slog.Logger) {
	stub := NewStubExecutor(log)
	for _, t := range core.AllActionTypes() {
		r.Register(t, stub)
	}
}
