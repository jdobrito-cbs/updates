package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"path/filepath"

	"github.com/jdobrito/wsrta/daemon/internal/lxd"
	"github.com/jdobrito/wsrta/internal/core"
)

const ppaDevice = "phppgadmin"


type PPADeps struct {
	LXD   lxd.Client
	Store ClientStore
	Log   *slog.Logger
	ConfD string 
}





type SetPhpPgAdminExecutor struct {
	deps PPADeps
}


func NewSetPhpPgAdminExecutor(deps PPADeps) *SetPhpPgAdminExecutor {
	return &SetPhpPgAdminExecutor{deps: deps}
}

func (e *SetPhpPgAdminExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.SetPhpPgAdminPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	container := client.LXCContainerName
	confFile := filepath.Join(e.deps.ConfD, fmt.Sprintf("%d.php", client.ID))

	if !p.Enabled {
		_ = e.deps.LXD.RemoveDevice(ctx, container, ppaDevice)
		_ = runExec(ctx, e.deps.LXD, container, "sudo", "-u", "postgres", "psql", "-c", `DROP ROLE IF EXISTS "wsrta_ppa";`)
		_ = os.Remove(confFile)
		_ = e.deps.Store.SetClientPhpPgAdminPassword(ctx, client.ID, "")
		return "phpPgAdmin desabilitado", nil
	}

	pass, err := randomPassword(20)
	if err != nil {
		return "", err
	}
	
	roleSQL := fmt.Sprintf(
		`DO $$ BEGIN IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname='wsrta_ppa') THEN `+
			`CREATE ROLE "wsrta_ppa" LOGIN SUPERUSER PASSWORD '%[1]s'; `+
			`ELSE ALTER ROLE "wsrta_ppa" LOGIN SUPERUSER PASSWORD '%[1]s'; END IF; END $$;`,
		sqlEscapeString(pass))
	if err := runExec(ctx, e.deps.LXD, container, "sudo", "-u", "postgres", "psql", "-c", roleSQL); err != nil {
		return "", fmt.Errorf("criar role wsrta_ppa: %w", err)
	}
	
	
	const hba = `f=$(ls /etc/postgresql/*/main/pg_hba.conf 2>/dev/null | head -1); ` +
		`if [ -n "$f" ]; then grep -q 'wsrta_ppa' "$f" || echo 'host all wsrta_ppa 127.0.0.1/32 scram-sha-256' >> "$f"; fi; ` +
		`systemctl reload postgresql 2>/dev/null || true`
	if err := runExec(ctx, e.deps.LXD, container, "bash", "-lc", hba); err != nil {
		e.deps.Log.WarnContext(ctx, "ajuste do pg_hba (continuando)", slog.Any("err", err))
	}
	
	listen := fmt.Sprintf("tcp:127.0.0.1:%d", p.Port)
	if err := e.deps.LXD.AddProxyDevice(ctx, container, ppaDevice, listen, "tcp:127.0.0.1:5432"); err != nil {
		return "", fmt.Errorf("expor Postgres: %w", err)
	}
	
	gid := wwwDataGID()
	if err := os.MkdirAll(e.deps.ConfD, 0o750); err != nil {
		return "", fmt.Errorf("criar confd: %w", err)
	}
	if gid >= 0 {
		_ = os.Chown(e.deps.ConfD, -1, gid) 
	}
	conf := fmt.Sprintf(ppaServerTmpl, client.ID, phpEscape(client.Name), p.Port, client.ID, phpEscape(pass))
	if err := os.WriteFile(confFile, []byte(conf), 0o640); err != nil {
		return "", fmt.Errorf("gravar config phpPgAdmin: %w", err)
	}
	if gid >= 0 {
		_ = os.Chown(confFile, -1, gid) 
	}
	
	_ = e.deps.Store.SetClientPhpPgAdminPassword(ctx, client.ID, pass)
	e.deps.Log.InfoContext(ctx, "phpPgAdmin habilitado", slog.Int64("client_id", client.ID), slog.Int("port", p.Port))
	return fmt.Sprintf("phpPgAdmin habilitado (porta %d)", p.Port), nil
}



const ppaServerTmpl = `<?php
$i = %d;
$conf['servers'][$i]['desc']            = '%s';
$conf['servers'][$i]['host']            = '127.0.0.1';
$conf['servers'][$i]['port']            = %d;
$conf['servers'][$i]['sslmode']         = 'allow';
$conf['servers'][$i]['defaultdb']       = 'postgres';
$conf['servers'][$i]['pg_dump_path']    = '/usr/bin/pg_dump';
$conf['servers'][$i]['pg_dumpall_path'] = '/usr/bin/pg_dumpall';
$GLOBALS['WSRTA_PPA_CREDS'][%d] = array('user' => 'wsrta_ppa', 'pass' => '%s');
`
