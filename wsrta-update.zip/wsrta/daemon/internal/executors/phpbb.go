package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/internal/core"
)



const phpbbVersion = "3.3.11"

func phpbbURL() string {
	
	major := phpbbVersion[:3] 
	return fmt.Sprintf("https://download.phpbb.com/pub/release/%s/%s/phpBB-%s.tar.bz2", major, phpbbVersion, phpbbVersion)
}




type InstallPhpBBExecutor struct {
	deps WebDeps
}


func NewInstallPhpBBExecutor(deps WebDeps) *InstallPhpBBExecutor {
	return &InstallPhpBBExecutor{deps: deps}
}

func (e *InstallPhpBBExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.InstallPhpBBPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	if err := validMySQLIdent(p.DBName); err != nil {
		return "", err
	}

	dom, container, err := e.deps.Domains.GetDomain(ctx, p.DomainID)
	if err != nil {
		return "", fmt.Errorf("buscar domínio %d: %w", p.DomainID, err)
	}
	dir, url := targetDirAndURL(e.deps.docrootFor(dom), dom.FQDN, p.Path)

	dbUser := p.DBName
	dbPass, err := randomPassword(24)
	if err != nil {
		return "", fmt.Errorf("gerar senha do banco: %w", err)
	}

	
	createSQL := fmt.Sprintf(
		"CREATE DATABASE IF NOT EXISTS `%[1]s` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"+
			"CREATE USER IF NOT EXISTS '%[2]s'@'localhost' IDENTIFIED BY '%[3]s';"+
			"GRANT ALL PRIVILEGES ON `%[1]s`.* TO '%[2]s'@'localhost';FLUSH PRIVILEGES;",
		p.DBName, dbUser, sqlEscapeString(dbPass))
	if err := runExec(ctx, e.deps.LXD, container, "mysql", "-e", createSQL); err != nil {
		return "", fmt.Errorf("criar banco: %w", err)
	}

	
	
	tmp := "/tmp/phpbb-" + p.DBName
	tarball := tmp + "/pkg.tar.bz2"
	_ = runExec(ctx, e.deps.LXD, container, "rm", "-rf", tmp)
	if err := runExec(ctx, e.deps.LXD, container, "mkdir", "-p", tmp); err != nil {
		return "", fmt.Errorf("criar temp: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, container, "curl", "-fsSL", phpbbURL(), "-o", tarball); err != nil {
		return "", fmt.Errorf("baixar phpBB: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, container, "tar", "-xjf", tarball, "-C", tmp); err != nil {
		return "", fmt.Errorf("extrair phpBB: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, container, "mkdir", "-p", dir); err != nil {
		return "", fmt.Errorf("criar diretório: %w", err)
	}
	
	if err := runExec(ctx, e.deps.LXD, container, "cp", "-a", tmp+"/phpBB3/.", dir+"/"); err != nil {
		return "", fmt.Errorf("copiar arquivos: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, container, "chown", "-R", "www-data:www-data", dir); err != nil {
		return "", fmt.Errorf("ajustar dono: %w", err)
	}
	_ = runExec(ctx, e.deps.LXD, container, "rm", "-rf", tmp)

	e.deps.Log.InfoContext(ctx, "phpbb instalado", slog.String("url", url), slog.String("container", container), slog.String("db", p.DBName))
	return fmt.Sprintf("phpBB baixado em %s — conclua a instalação em https://%s/install (banco: %s)", url, url, p.DBName), nil
}





type UpdatePhpBBExecutor struct {
	deps WebDeps
}


func NewUpdatePhpBBExecutor(deps WebDeps) *UpdatePhpBBExecutor {
	return &UpdatePhpBBExecutor{deps: deps}
}

func (e *UpdatePhpBBExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.UpdatePhpBBPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	dom, container, err := e.deps.Domains.GetDomain(ctx, p.DomainID)
	if err != nil {
		return "", fmt.Errorf("buscar domínio %d: %w", p.DomainID, err)
	}
	dir, url := targetDirAndURL(e.deps.docrootFor(dom), dom.FQDN, p.Path)

	tmp := fmt.Sprintf("/tmp/phpbb-upd-%d", p.DomainID) 
	tarball := tmp + "/pkg.tar.bz2"
	_ = runExec(ctx, e.deps.LXD, container, "rm", "-rf", tmp)
	if err := runExec(ctx, e.deps.LXD, container, "mkdir", "-p", tmp); err != nil {
		return "", fmt.Errorf("criar temp: %w", err)
	}
	
	_ = runExec(ctx, e.deps.LXD, container, "cp", "-a", dir+"/config.php", tmp+"/config.php.bak")
	if err := runExec(ctx, e.deps.LXD, container, "curl", "-fsSL", phpbbURL(), "-o", tarball); err != nil {
		return "", fmt.Errorf("baixar phpBB: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, container, "tar", "-xjf", tarball, "-C", tmp); err != nil {
		return "", fmt.Errorf("extrair phpBB: %w", err)
	}
	
	if err := runExec(ctx, e.deps.LXD, container, "cp", "-a", tmp+"/phpBB3/.", dir+"/"); err != nil {
		return "", fmt.Errorf("copiar arquivos: %w", err)
	}
	_ = runExec(ctx, e.deps.LXD, container, "cp", "-a", tmp+"/config.php.bak", dir+"/config.php")
	if err := runExec(ctx, e.deps.LXD, container, "chown", "-R", "www-data:www-data", dir); err != nil {
		return "", fmt.Errorf("ajustar dono: %w", err)
	}
	_ = runExec(ctx, e.deps.LXD, container, "rm", "-rf", tmp)

	e.deps.Log.InfoContext(ctx, "phpbb atualizado", slog.String("container", container), slog.String("versao", phpbbVersion))
	return fmt.Sprintf("phpBB atualizado para %s — conclua a migração do banco em https://%s/install/app.php/update e depois APAGUE a pasta install/ do site.", phpbbVersion, url), nil
}


type RemovePhpBBExecutor struct {
	deps WebDeps
}


func NewRemovePhpBBExecutor(deps WebDeps) *RemovePhpBBExecutor {
	return &RemovePhpBBExecutor{deps: deps}
}

func (e *RemovePhpBBExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.RemovePhpBBPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	if err := validMySQLIdent(p.DBName); err != nil {
		return "", err
	}

	dom, container, err := e.deps.Domains.GetDomain(ctx, p.DomainID)
	if err != nil {
		return "", fmt.Errorf("buscar domínio %d: %w", p.DomainID, err)
	}
	dir, _ := targetDirAndURL(e.deps.docrootFor(dom), dom.FQDN, p.Path)

	if err := runExec(ctx, e.deps.LXD, container, "rm", "-rf", dir); err != nil {
		return "", fmt.Errorf("remover arquivos: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, container, "mkdir", "-p", dir); err != nil {
		return "", fmt.Errorf("recriar diretório: %w", err)
	}
	_ = runExec(ctx, e.deps.LXD, container, "chown", "www-data:www-data", dir)

	dropSQL := fmt.Sprintf(
		"DROP DATABASE IF EXISTS `%[1]s`;DROP USER IF EXISTS '%[1]s'@'localhost';FLUSH PRIVILEGES;",
		p.DBName)
	if err := runExec(ctx, e.deps.LXD, container, "mysql", "-e", dropSQL); err != nil {
		return "", fmt.Errorf("dropar banco: %w", err)
	}

	e.deps.Log.InfoContext(ctx, "phpbb removido", slog.String("fqdn", dom.FQDN), slog.String("db", p.DBName))
	return fmt.Sprintf("phpBB removido de %s", dom.FQDN), nil
}
