package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/daemon/internal/lxd"
	"github.com/jdobrito/wsrta/internal/core"
)


type DBDeps struct {
	LXD   lxd.Client
	Store DatabaseStore
	Log   *slog.Logger
}




type CreateDatabaseExecutor struct {
	deps DBDeps
}


func NewCreateDatabaseExecutor(deps DBDeps) *CreateDatabaseExecutor {
	return &CreateDatabaseExecutor{deps: deps}
}

func (e *CreateDatabaseExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.CreateDatabasePayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}

	db, container, err := e.deps.Store.GetDatabase(ctx, p.DatabaseID)
	if err != nil {
		return "", fmt.Errorf("buscar banco %d: %w", p.DatabaseID, err)
	}
	
	if err := validMySQLIdent(db.DBName); err != nil {
		return "", err
	}
	if err := validMySQLIdent(db.DBUser); err != nil {
		return "", err
	}

	
	pass := p.Password
	if pass == "" {
		var gerr error
		if pass, gerr = randomPassword(24); gerr != nil {
			return "", fmt.Errorf("gerar senha: %w", gerr)
		}
	}

	if db.Engine == "postgres" {
		return e.createPostgres(ctx, container, db, pass)
	}

	
	sql := fmt.Sprintf(
		"CREATE DATABASE IF NOT EXISTS `%[1]s`;"+
			"CREATE USER IF NOT EXISTS '%[2]s'@'localhost' IDENTIFIED BY '%[3]s';"+
			"ALTER USER '%[2]s'@'localhost' IDENTIFIED BY '%[3]s';"+
			"GRANT ALL PRIVILEGES ON `%[1]s`.* TO '%[2]s'@'localhost';"+
			"FLUSH PRIVILEGES;",
		db.DBName, db.DBUser, sqlEscapeString(pass))

	
	if err := runExec(ctx, e.deps.LXD, container, "mysql", "-e", sql); err != nil {
		return "", fmt.Errorf("criar banco: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "banco criado",
		slog.String("db", db.DBName), slog.String("user", db.DBUser), slog.String("container", container))

	return fmt.Sprintf("banco %q criado; usuário %q@localhost; senha (anote, não será exibida de novo): %s",
		db.DBName, db.DBUser, pass), nil
}



func (e *CreateDatabaseExecutor) createPostgres(ctx context.Context, container string, db *core.Database, pass string) (string, error) {
	
	roleSQL := fmt.Sprintf(
		`DO $$ BEGIN IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname='%[1]s') THEN `+
			`CREATE ROLE "%[1]s" LOGIN PASSWORD '%[2]s'; ELSE ALTER ROLE "%[1]s" PASSWORD '%[2]s'; END IF; END $$;`,
		db.DBUser, sqlEscapeString(pass))
	if err := runExec(ctx, e.deps.LXD, container, "sudo", "-u", "postgres", "psql", "-c", roleSQL); err != nil {
		return "", fmt.Errorf("criar role postgres: %w", err)
	}
	
	if err := runExec(ctx, e.deps.LXD, container, "sudo", "-u", "postgres", "createdb", "-O", db.DBUser, db.DBName); err != nil {
		e.deps.Log.WarnContext(ctx, "createdb (pode já existir; continuando)", slog.Any("err", err))
	}
	e.deps.Log.InfoContext(ctx, "banco postgres criado",
		slog.String("db", db.DBName), slog.String("user", db.DBUser), slog.String("container", container))
	return fmt.Sprintf("banco PostgreSQL %q criado; usuário %q; senha (anote, não será exibida de novo): %s",
		db.DBName, db.DBUser, pass), nil
}


type DropDatabaseExecutor struct {
	deps DBDeps
}


func NewDropDatabaseExecutor(deps DBDeps) *DropDatabaseExecutor {
	return &DropDatabaseExecutor{deps: deps}
}

func (e *DropDatabaseExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.DropDatabasePayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}

	db, container, err := e.deps.Store.GetDatabase(ctx, p.DatabaseID)
	if err != nil {
		return "", fmt.Errorf("buscar banco %d: %w", p.DatabaseID, err)
	}
	if err := validMySQLIdent(db.DBName); err != nil {
		return "", err
	}
	if err := validMySQLIdent(db.DBUser); err != nil {
		return "", err
	}

	if db.Engine == "postgres" {
		
		_ = runExec(ctx, e.deps.LXD, container, "sudo", "-u", "postgres", "psql", "-c",
			fmt.Sprintf(`DROP DATABASE IF EXISTS "%s";`, db.DBName))
		_ = runExec(ctx, e.deps.LXD, container, "sudo", "-u", "postgres", "psql", "-c",
			fmt.Sprintf(`DROP ROLE IF EXISTS "%s";`, db.DBUser))
	} else {
		sql := fmt.Sprintf(
			"DROP DATABASE IF EXISTS `%s`;DROP USER IF EXISTS '%s'@'localhost';FLUSH PRIVILEGES;",
			db.DBName, db.DBUser)
		if err := runExec(ctx, e.deps.LXD, container, "mysql", "-e", sql); err != nil {
			return "", fmt.Errorf("remover banco: %w", err)
		}
	}

	if err := e.deps.Store.DeleteDatabase(ctx, db.ID); err != nil {
		return "", fmt.Errorf("apagar registro do banco: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "banco removido", slog.String("db", db.DBName))
	return fmt.Sprintf("banco %q removido", db.DBName), nil
}


type ResetDBPasswordExecutor struct {
	deps DBDeps
}


func NewResetDBPasswordExecutor(deps DBDeps) *ResetDBPasswordExecutor {
	return &ResetDBPasswordExecutor{deps: deps}
}

func (e *ResetDBPasswordExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.ResetDBPasswordPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	db, container, err := e.deps.Store.GetDatabase(ctx, p.DatabaseID)
	if err != nil {
		return "", fmt.Errorf("buscar banco %d: %w", p.DatabaseID, err)
	}
	
	if err := validMySQLIdent(db.DBUser); err != nil {
		return "", err
	}
	esc := sqlEscapeString(p.Password)

	if db.Engine == "postgres" {
		sql := fmt.Sprintf(`ALTER ROLE "%s" PASSWORD '%s';`, db.DBUser, esc)
		if err := runExec(ctx, e.deps.LXD, container, "sudo", "-u", "postgres", "psql", "-c", sql); err != nil {
			return "", fmt.Errorf("alterar senha postgres: %w", err)
		}
	} else {
		sql := fmt.Sprintf("ALTER USER '%s'@'localhost' IDENTIFIED BY '%s';FLUSH PRIVILEGES;", db.DBUser, esc)
		if err := runExec(ctx, e.deps.LXD, container, "mysql", "-e", sql); err != nil {
			return "", fmt.Errorf("alterar senha: %w", err)
		}
	}
	e.deps.Log.InfoContext(ctx, "senha do banco alterada", slog.String("db", db.DBName), slog.String("user", db.DBUser))
	return fmt.Sprintf("senha do usuário %q (banco %q) alterada", db.DBUser, db.DBName), nil
}
