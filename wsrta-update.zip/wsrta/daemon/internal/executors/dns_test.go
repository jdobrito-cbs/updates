package executors_test

import (
	"context"
	"encoding/json"
	"errors"
	"testing"

	"github.com/jdobrito/wsrta/daemon/internal/executors"
	"github.com/jdobrito/wsrta/daemon/internal/pdns"
	"github.com/jdobrito/wsrta/internal/core"
)

type fakeDNSStore struct {
	rec     *core.DNSRecord
	zone    string
	deleted bool
}

func (s *fakeDNSStore) GetDNSRecord(_ context.Context, id int64) (*core.DNSRecord, string, error) {
	if s.rec == nil || s.rec.ID != id {
		return nil, "", errors.New("registro não encontrado")
	}
	r := *s.rec
	return &r, s.zone, nil
}

func (s *fakeDNSStore) DeleteDNSRecord(_ context.Context, _ int64) error {
	s.deleted = true
	return nil
}

func TestSetDNSRecordEnsuresZoneAndWrites(t *testing.T) {
	backend := pdns.NewFake()
	st := &fakeDNSStore{
		rec:  &core.DNSRecord{ID: 1, DomainID: 1, Type: "A", Name: "www.exemplo.com", Content: "1.2.3.4", TTL: 3600},
		zone: "exemplo.com",
	}
	exec := executors.NewSetDNSRecordExecutor(executors.DNSDeps{Backend: backend, Store: st, Log: discardLogger()})

	payload, _ := json.Marshal(core.SetDNSRecordPayload{DNSRecordID: 1})
	if _, err := exec.Execute(context.Background(), &core.Action{ID: 1, Payload: payload}); err != nil {
		t.Fatalf("execute: %v", err)
	}
	if !backend.Zones["exemplo.com"] {
		t.Fatal("zona não foi garantida")
	}
	if backend.Records["exemplo.com|www.exemplo.com|A"] != "1.2.3.4" {
		t.Fatalf("registro não gravado: %v", backend.Records)
	}
}

func TestDeleteDNSRecordRemovesAndDeletesRow(t *testing.T) {
	backend := pdns.NewFake()
	ctx := context.Background()
	_ = backend.EnsureZone(ctx, "exemplo.com")
	_ = backend.SetRecord(ctx, "exemplo.com", "www.exemplo.com", "A", "1.2.3.4", 3600, 0)

	st := &fakeDNSStore{
		rec:  &core.DNSRecord{ID: 1, Type: "A", Name: "www.exemplo.com", Content: "1.2.3.4", TTL: 3600},
		zone: "exemplo.com",
	}
	exec := executors.NewDeleteDNSRecordExecutor(executors.DNSDeps{Backend: backend, Store: st, Log: discardLogger()})

	payload, _ := json.Marshal(core.DeleteDNSRecordPayload{DNSRecordID: 1})
	if _, err := exec.Execute(ctx, &core.Action{ID: 1, Payload: payload}); err != nil {
		t.Fatalf("execute: %v", err)
	}
	if _, ok := backend.Records["exemplo.com|www.exemplo.com|A"]; ok {
		t.Fatal("registro não removido do backend")
	}
	if !st.deleted {
		t.Fatal("DeleteDNSRecord não foi chamado")
	}
}
