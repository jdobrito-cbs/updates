package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"path"
	"strings"

	"github.com/jdobrito/wsrta/daemon/internal/lxd"
	"github.com/jdobrito/wsrta/internal/core"
)


func wpCLI(ctx context.Context, c lxd.Client, name, dir string, args ...string) error {
	full := append([]string{"wp", "--allow-root", "--path=" + dir}, args...)
	return runExec(ctx, c, name, full...)
}




func targetDirAndURL(docroot, fqdn, p string) (string, string) {
	clean := strings.Trim(p, "/")
	if clean == "" {
		return docroot, fqdn
	}
	dir := path.Join(docroot, clean)
	if dir != docroot && !strings.HasPrefix(dir, docroot+"/") {
		return docroot, fqdn 
	}
	return dir, fqdn + "/" + clean
}



type InstallWordPressExecutor struct {
	deps WebDeps
}


func NewInstallWordPressExecutor(deps WebDeps) *InstallWordPressExecutor {
	return &InstallWordPressExecutor{deps: deps}
}

func (e *InstallWordPressExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.InstallWordPressPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	if err := validMySQLIdent(p.DBName); err != nil {
		return "", err
	}

	dom, container, err := e.deps.Domains.GetDomain(ctx, p.DomainID)
	if err != nil {
		return "", fmt.Errorf("buscar domínio %d: %w", p.DomainID, err)
	}
	dir, url := targetDirAndURL(e.deps.docrootFor(dom), dom.FQDN, p.Path)

	dbUser := p.DBName
	dbPass, err := randomPassword(24)
	if err != nil {
		return "", fmt.Errorf("gerar senha do banco: %w", err)
	}

	
	createSQL := fmt.Sprintf(
		"CREATE DATABASE IF NOT EXISTS `%[1]s`;"+
			"CREATE USER IF NOT EXISTS '%[2]s'@'localhost' IDENTIFIED BY '%[3]s';"+
			"GRANT ALL PRIVILEGES ON `%[1]s`.* TO '%[2]s'@'localhost';FLUSH PRIVILEGES;",
		p.DBName, dbUser, sqlEscapeString(dbPass))
	if err := runExec(ctx, e.deps.LXD, container, "mysql", "-e", createSQL); err != nil {
		return "", fmt.Errorf("criar banco: %w", err)
	}

	
	if err := runExec(ctx, e.deps.LXD, container, "mkdir", "-p", dir); err != nil {
		return "", fmt.Errorf("criar diretório: %w", err)
	}
	if err := wpCLI(ctx, e.deps.LXD, container, dir, "core", "download"); err != nil {
		return "", fmt.Errorf("wp core download: %w", err)
	}
	if err := wpCLI(ctx, e.deps.LXD, container, dir, "config", "create",
		"--dbname="+p.DBName, "--dbuser="+dbUser, "--dbpass="+dbPass, "--dbhost=localhost"); err != nil {
		return "", fmt.Errorf("wp config create: %w", err)
	}
	if err := wpCLI(ctx, e.deps.LXD, container, dir, "core", "install",
		"--url="+url, "--title="+p.Title, "--admin_user="+p.AdminUser,
		"--admin_password="+p.AdminPassword, "--admin_email="+p.AdminEmail, "--skip-email"); err != nil {
		return "", fmt.Errorf("wp core install: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, container, "chown", "-R", "www-data:www-data", dir); err != nil {
		return "", fmt.Errorf("ajustar dono: %w", err)
	}

	e.deps.Log.InfoContext(ctx, "wordpress instalado", slog.String("url", url), slog.String("container", container))
	return fmt.Sprintf("WordPress instalado em %s (admin: %s)", url, p.AdminUser), nil
}


type RemoveWordPressExecutor struct {
	deps WebDeps
}


func NewRemoveWordPressExecutor(deps WebDeps) *RemoveWordPressExecutor {
	return &RemoveWordPressExecutor{deps: deps}
}

func (e *RemoveWordPressExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.RemoveWordPressPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	if err := validMySQLIdent(p.DBName); err != nil {
		return "", err
	}

	dom, container, err := e.deps.Domains.GetDomain(ctx, p.DomainID)
	if err != nil {
		return "", fmt.Errorf("buscar domínio %d: %w", p.DomainID, err)
	}
	dir, _ := targetDirAndURL(e.deps.docrootFor(dom), dom.FQDN, p.Path)

	
	if err := runExec(ctx, e.deps.LXD, container, "rm", "-rf", dir); err != nil {
		return "", fmt.Errorf("remover arquivos: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, container, "mkdir", "-p", dir); err != nil {
		return "", fmt.Errorf("recriar diretório: %w", err)
	}
	_ = runExec(ctx, e.deps.LXD, container, "chown", "www-data:www-data", dir)

	dropSQL := fmt.Sprintf(
		"DROP DATABASE IF EXISTS `%[1]s`;DROP USER IF EXISTS '%[1]s'@'localhost';FLUSH PRIVILEGES;",
		p.DBName)
	if err := runExec(ctx, e.deps.LXD, container, "mysql", "-e", dropSQL); err != nil {
		return "", fmt.Errorf("dropar banco: %w", err)
	}

	e.deps.Log.InfoContext(ctx, "wordpress removido", slog.String("fqdn", dom.FQDN), slog.String("db", p.DBName))
	return fmt.Sprintf("WordPress removido de %s", dom.FQDN), nil
}
