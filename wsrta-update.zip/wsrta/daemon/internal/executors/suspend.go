package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/daemon/internal/lxd"
	"github.com/jdobrito/wsrta/internal/core"
)



type SuspendClientExecutor struct {
	deps Deps
}


func NewSuspendClientExecutor(deps Deps) *SuspendClientExecutor {
	return &SuspendClientExecutor{deps: deps}
}

func (e *SuspendClientExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.SuspendClientPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}

	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	name := client.LXCContainerName

	exists, err := e.deps.LXD.Exists(ctx, name)
	if err != nil {
		return "", fmt.Errorf("verificar container: %w", err)
	}
	if exists {
		info, err := e.deps.LXD.Info(ctx, name)
		if err != nil {
			return "", fmt.Errorf("obter estado: %w", err)
		}
		if info.Status == lxd.StatusRunning {
			if err := e.deps.LXD.Stop(ctx, name); err != nil {
				return "", fmt.Errorf("parar container: %w", err)
			}
		}
	}

	if err := e.deps.Store.SetClientStatus(ctx, client.ID, core.ClientSuspended); err != nil {
		return "", fmt.Errorf("status suspended: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "cliente suspenso", slog.Int64("client_id", client.ID), slog.String("container", name))
	return fmt.Sprintf("cliente %q suspenso", name), nil
}


type ResumeClientExecutor struct {
	deps Deps
}


func NewResumeClientExecutor(deps Deps) *ResumeClientExecutor {
	return &ResumeClientExecutor{deps: deps}
}

func (e *ResumeClientExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.ResumeClientPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}

	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	name := client.LXCContainerName

	exists, err := e.deps.LXD.Exists(ctx, name)
	if err != nil {
		return "", fmt.Errorf("verificar container: %w", err)
	}
	if exists {
		info, err := e.deps.LXD.Info(ctx, name)
		if err != nil {
			return "", fmt.Errorf("obter estado: %w", err)
		}
		if info.Status != lxd.StatusRunning {
			if err := e.deps.LXD.Start(ctx, name); err != nil {
				return "", fmt.Errorf("iniciar container: %w", err)
			}
		}
	}

	if err := e.deps.Store.SetClientStatus(ctx, client.ID, core.ClientActive); err != nil {
		return "", fmt.Errorf("status active: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "cliente retomado", slog.Int64("client_id", client.ID), slog.String("container", name))
	return fmt.Sprintf("cliente %q retomado", name), nil
}
