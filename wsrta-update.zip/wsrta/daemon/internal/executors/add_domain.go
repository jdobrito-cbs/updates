package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/daemon/internal/nginx"
	"github.com/jdobrito/wsrta/internal/core"
)




type AddDomainExecutor struct {
	deps WebDeps
}


func NewAddDomainExecutor(deps WebDeps) *AddDomainExecutor {
	return &AddDomainExecutor{deps: deps}
}

func (e *AddDomainExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.AddDomainPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}

	dom, container, err := e.deps.Domains.GetDomain(ctx, p.DomainID)
	if err != nil {
		return "", fmt.Errorf("buscar domínio %d: %w", p.DomainID, err)
	}
	
	if err := core.ValidFQDN(dom.FQDN); err != nil {
		return "", err
	}
	
	
	if dom.UpstreamIP != "" {
		return e.addExternalDomain(ctx, dom)
	}
	log := e.deps.Log.With(slog.String("fqdn", dom.FQDN), slog.String("container", container))
	docroot := e.deps.docrootFor(dom)

	
	if err := runExec(ctx, e.deps.LXD, container, "mkdir", "-p", docroot); err != nil {
		return "", fmt.Errorf("criar docroot: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, container, "chown", "-R", "www-data:www-data", docroot); err != nil {
		return "", fmt.Errorf("ajustar dono do docroot: %w", err)
	}

	
	
	
	indexPath := docroot + "/index.html"
	if err := runExec(ctx, e.deps.LXD, container, "test", "-e", indexPath); err != nil {
		if err := e.deps.LXD.PushFile(ctx, container, indexPath, []byte(wsrtaTestPage(dom.FQDN)), 0o644); err != nil {
			return "", fmt.Errorf("escrever página de teste: %w", err)
		}
		_ = runExec(ctx, e.deps.LXD, container, "chown", "www-data:www-data", indexPath)
		log.InfoContext(ctx, "página de teste do WSRTA criada no docroot")
	}

	internalVHost, err := nginx.RenderContainerVHost(nginx.ContainerVHost{
		FQDN:      dom.FQDN,
		Docroot:   docroot,
		PHPSocket: e.deps.resolvePHPSocket(ctx, container, dom.PHPVersion),
	})
	if err != nil {
		return "", fmt.Errorf("render vhost interno: %w", err)
	}
	if err := e.deps.LXD.PushFile(ctx, container, internalVHostPath(dom.FQDN), []byte(internalVHost), 0o644); err != nil {
		return "", fmt.Errorf("escrever vhost interno: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, container, "nginx", "-t"); err != nil {
		
		
		
		_ = runExec(ctx, e.deps.LXD, container, "rm", "-f", internalVHostPath(dom.FQDN))
		return "", fmt.Errorf("nginx -t no container: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, container, "nginx", "-s", "reload"); err != nil {
		return "", fmt.Errorf("reload nginx no container: %w", err)
	}
	log.InfoContext(ctx, "vhost interno aplicado")

	
	ip, err := e.deps.LXD.Address(ctx, container)
	if err != nil {
		return "", fmt.Errorf("obter IP do container: %w", err)
	}
	hostVHost, err := nginx.RenderHostVHost(nginx.HostVHost{
		FQDN:         dom.FQDN,
		UpstreamIP:   ip,
		UpstreamPort: e.deps.UpstreamPort,
		ACMEWebroot:  e.deps.ACMEWebroot,
		SSL:          false,
	})
	if err != nil {
		return "", fmt.Errorf("render vhost do host: %w", err)
	}
	if err := e.deps.Nginx.WriteVHost(ctx, dom.FQDN, hostVHost); err != nil {
		return "", fmt.Errorf("escrever vhost do host: %w", err)
	}
	
	
	if _, err := e.deps.writeForwards(ctx, dom.ID, dom.FQDN); err != nil {
		return "", fmt.Errorf("escrever encaminhamentos: %w", err)
	}
	
	
	if err := e.deps.Nginx.WritePreviewSnippet(ctx, dom.FQDN, ip, e.deps.UpstreamPort); err != nil {
		return "", fmt.Errorf("escrever preview do host: %w", err)
	}
	if err := e.deps.Nginx.Reload(ctx); err != nil {
		return "", fmt.Errorf("reload nginx do host: %w", err)
	}
	log.InfoContext(ctx, "reverse-proxy aplicado", slog.String("upstream", ip))

	return fmt.Sprintf("domínio %q adicionado (proxy → %s:%d)", dom.FQDN, ip, e.deps.UpstreamPort), nil
}



func (e *AddDomainExecutor) addExternalDomain(ctx context.Context, dom *core.Domain) (string, error) {
	if err := core.ValidUpstreamHost(dom.UpstreamIP); err != nil {
		return "", err
	}
	if err := core.ValidUpstreamPath(dom.UpstreamPath); err != nil {
		return "", err
	}
	port := dom.UpstreamPort
	if port == 0 {
		port = 80
	}
	log := e.deps.Log.With(slog.String("fqdn", dom.FQDN), slog.String("upstream", dom.UpstreamIP))

	hostVHost, err := nginx.RenderHostVHost(nginx.HostVHost{
		FQDN:         dom.FQDN,
		UpstreamIP:   dom.UpstreamIP,
		UpstreamPort: port,
		UpstreamPath: dom.UpstreamPath,
		ACMEWebroot:  e.deps.ACMEWebroot,
		SSL:          false,
	})
	if err != nil {
		return "", fmt.Errorf("render vhost externo: %w", err)
	}
	if err := e.deps.Nginx.WriteVHost(ctx, dom.FQDN, hostVHost); err != nil {
		return "", fmt.Errorf("escrever vhost do host: %w", err)
	}
	if _, err := e.deps.writeForwards(ctx, dom.ID, dom.FQDN); err != nil {
		return "", fmt.Errorf("escrever encaminhamentos: %w", err)
	}
	if err := e.deps.Nginx.WritePreviewSnippet(ctx, dom.FQDN, dom.UpstreamIP, port); err != nil {
		return "", fmt.Errorf("escrever preview do host: %w", err)
	}
	if err := e.deps.Nginx.Reload(ctx); err != nil {
		return "", fmt.Errorf("reload nginx do host: %w", err)
	}
	log.InfoContext(ctx, "domínio externo (proxy) aplicado", slog.Int("port", port))
	return fmt.Sprintf("domínio %q apontado para o servidor externo %s:%d", dom.FQDN, dom.UpstreamIP, port), nil
}
