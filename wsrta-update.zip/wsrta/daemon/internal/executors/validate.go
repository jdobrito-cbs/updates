package executors

import (
	"fmt"
	"regexp"
	"strings"
)

var mysqlIdentRe = regexp.MustCompile(`^[A-Za-z0-9_]{1,64}$`)
var linuxUserRe = regexp.MustCompile(`^[a-z_][a-z0-9_-]{0,31}$`)


func validLinuxUser(s string) error {
	if !linuxUserRe.MatchString(s) {
		return fmt.Errorf("usuário inválido: %q (use [a-z0-9_-], começando por letra/_)", s)
	}
	return nil
}


func validMySQLIdent(s string) error {
	if !mysqlIdentRe.MatchString(s) {
		return fmt.Errorf("identificador MySQL inválido: %q (use [A-Za-z0-9_], até 64)", s)
	}
	return nil
}



func validateCron(schedule, command string) error {
	if strings.ContainsAny(schedule, "\n\r") {
		return fmt.Errorf("schedule de cron contém quebra de linha")
	}
	if strings.ContainsAny(command, "\n\r") {
		return fmt.Errorf("comando de cron contém quebra de linha")
	}
	sch := strings.TrimSpace(schedule)
	if sch == "" || strings.TrimSpace(command) == "" {
		return fmt.Errorf("schedule e comando do cron são obrigatórios")
	}
	if !strings.HasPrefix(sch, "@") && len(strings.Fields(sch)) != 5 {
		return fmt.Errorf("schedule de cron deve ter 5 campos ou começar com @ (ex.: @daily)")
	}
	return nil
}
