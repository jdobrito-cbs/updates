package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"regexp"
	"strings"

	"github.com/jdobrito/wsrta/internal/core"
)





var mysqlPwHashRe = regexp.MustCompile(`^\*?[0-9A-Fa-f]{16,80}$`)




type RestoreDatabaseExecutor struct {
	deps Deps
}


func NewRestoreDatabaseExecutor(deps Deps) *RestoreDatabaseExecutor {
	return &RestoreDatabaseExecutor{deps: deps}
}

func (e *RestoreDatabaseExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.RestoreDatabasePayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	if err := validMySQLIdent(p.DBName); err != nil {
		return "", err
	}
	if err := validMySQLIdent(p.DBUser); err != nil {
		return "", err
	}

	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	container := client.LXCContainerName
	reportProgress(ctx, e.deps.Progress, a.ID, 10, "preparando restauração")

	
	
	
	var sql string
	if p.DBPasswordHash != "" {
		if !mysqlPwHashRe.MatchString(p.DBPasswordHash) {
			return "", fmt.Errorf("hash de senha do banco em formato inválido (esperado *HEX); restauração abortada por segurança")
		}
		identClause := "IDENTIFIED BY PASSWORD '" + p.DBPasswordHash + "'"
		sql = fmt.Sprintf(
			"CREATE DATABASE IF NOT EXISTS `%[1]s`;"+
				"CREATE USER IF NOT EXISTS '%[2]s'@'localhost' %[3]s;"+
				"ALTER USER '%[2]s'@'localhost' %[3]s;"+
				"GRANT ALL PRIVILEGES ON `%[1]s`.* TO '%[2]s'@'localhost';FLUSH PRIVILEGES;",
			p.DBName, p.DBUser, identClause)
	} else {
		sql = fmt.Sprintf("CREATE DATABASE IF NOT EXISTS `%s`;", p.DBName)
	}
	if err := runExec(ctx, e.deps.LXD, container, "mysql", "-e", sql); err != nil {
		return "", fmt.Errorf("criar banco: %w", err)
	}
	reportProgress(ctx, e.deps.Progress, a.ID, 30, "banco criado")

	dump, err := os.ReadFile(p.DumpPath)
	if err != nil {
		return "", fmt.Errorf("ler dump %q: %w", p.DumpPath, err)
	}
	reportProgress(ctx, e.deps.Progress, a.ID, 50, "importando dump")
	
	res, err := e.deps.LXD.Exec(ctx, container, []string{"mysql", p.DBName}, dump)
	if err != nil {
		return "", fmt.Errorf("importar dump: %w", err)
	}
	if res.ExitCode != 0 {
		return "", fmt.Errorf("importar dump falhou (rc=%d): %s", res.ExitCode, res.Stderr)
	}
	reportProgress(ctx, e.deps.Progress, a.ID, 95, "concluindo")

	e.deps.Log.InfoContext(ctx, "banco restaurado",
		slog.String("db", p.DBName), slog.String("container", container), slog.Int("bytes", len(dump)))
	return fmt.Sprintf("banco %q restaurado (%d bytes)", p.DBName, len(dump)), nil
}


func sqlEscapeString(s string) string {
	s = strings.ReplaceAll(s, `\`, `\\`)
	s = strings.ReplaceAll(s, `'`, `\'`)
	return s
}
