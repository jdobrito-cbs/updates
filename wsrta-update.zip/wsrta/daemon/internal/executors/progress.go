package executors

import "context"




type ProgressReporter interface {
	UpdateProgress(ctx context.Context, actionID int64, percent int, stage string) error
}




func reportProgress(ctx context.Context, pr ProgressReporter, actionID int64, percent int, stage string) {
	if pr == nil {
		return
	}
	_ = pr.UpdateProgress(ctx, actionID, percent, stage)
}



func pctOf(done, total int) int {
	if total <= 0 {
		return 0
	}
	p := done * 100 / total
	if p > 99 {
		p = 99
	}
	return p
}
