package executors_test

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"strings"
	"testing"
	"time"

	"github.com/jdobrito/wsrta/daemon/internal/acme"
	"github.com/jdobrito/wsrta/daemon/internal/executors"
	"github.com/jdobrito/wsrta/daemon/internal/lxd"
	"github.com/jdobrito/wsrta/daemon/internal/nginx"
	"github.com/jdobrito/wsrta/internal/core"
)


type fakeDomainStore struct {
	domain    *core.Domain
	container string
	sslSet    *bool
	certs     []string
	deleted   bool
}

func (s *fakeDomainStore) GetDomain(_ context.Context, id int64) (*core.Domain, string, error) {
	if s.domain == nil || s.domain.ID != id {
		return nil, "", errors.New("domínio não encontrado")
	}
	d := *s.domain
	return &d, s.container, nil
}

func (s *fakeDomainStore) SetDomainSSL(_ context.Context, _ int64, enabled bool) error {
	s.sslSet = &enabled
	return nil
}

func (s *fakeDomainStore) UpsertSSLCert(_ context.Context, _ int64, issuer string, _ time.Time, _ string) error {
	s.certs = append(s.certs, issuer)
	return nil
}

func (s *fakeDomainStore) DeleteDomain(_ context.Context, _ int64) error {
	s.deleted = true
	return nil
}

func (s *fakeDomainStore) ListForwards(_ context.Context, _ int64) ([]core.DomainForward, error) {
	return nil, nil
}

func newWebDeps(l *lxd.Fake, n *nginx.Fake, ac *acme.Fake, ds executors.DomainStore) executors.WebDeps {
	return executors.WebDeps{
		LXD:          l,
		Nginx:        n,
		Acme:         ac,
		Domains:      ds,
		Log:          slog.New(slog.NewTextHandler(io.Discard, nil)),
		DocrootBase:  "/var/www",
		ACMEWebroot:  "/var/www/acme",
		UpstreamPort: 80,
	}
}

func sampleDomain() *core.Domain {
	return &core.Domain{
		ID: 1, ClientID: 1, FQDN: "exemplo.com",
		Docroot: "/var/www/exemplo.com", PHPVersion: "8.3",
	}
}


func runningContainer(t *testing.T) *lxd.Fake {
	t.Helper()
	l := lxd.NewFake()
	ctx := context.Background()
	if err := l.Create(ctx, lxd.ContainerSpec{Name: "cli_1"}); err != nil {
		t.Fatalf("create container: %v", err)
	}
	if err := l.Start(ctx, "cli_1"); err != nil {
		t.Fatalf("start container: %v", err)
	}
	return l
}

func TestAddDomainWritesVHostsAndProxies(t *testing.T) {
	l := runningContainer(t)
	n := nginx.NewFake()
	ds := &fakeDomainStore{domain: sampleDomain(), container: "cli_1"}
	exec := executors.NewAddDomainExecutor(newWebDeps(l, n, acme.NewFake(), ds))

	payload, _ := json.Marshal(core.AddDomainPayload{DomainID: 1})
	act := &core.Action{ID: 1, Type: core.ActionAddDomain, Payload: payload}
	if _, err := exec.Execute(context.Background(), act); err != nil {
		t.Fatalf("execute: %v", err)
	}

	vh, ok := n.VHost("exemplo.com")
	if !ok {
		t.Fatal("vhost do host não foi escrito")
	}
	if !strings.Contains(vh, "proxy_pass http://10.0.0.2:80;") {
		t.Fatalf("vhost sem proxy_pass esperado:\n%s", vh)
	}
	if n.Reloads == 0 {
		t.Fatal("nginx do host não foi recarregado")
	}
	if _, ok := l.Files["cli_1:/etc/nginx/sites-enabled/exemplo.com.conf"]; !ok {
		t.Fatalf("vhost interno não empurrado: %v", l.Files)
	}
}

func TestIssueSSLRewritesVHostWithTLS(t *testing.T) {
	l := runningContainer(t)
	n := nginx.NewFake()
	ac := acme.NewFake()
	ds := &fakeDomainStore{domain: sampleDomain(), container: "cli_1"}
	exec := executors.NewIssueSSLExecutor(newWebDeps(l, n, ac, ds))

	payload, _ := json.Marshal(core.IssueSSLPayload{DomainID: 1})
	act := &core.Action{ID: 2, Type: core.ActionIssueSSL, Payload: payload}
	if _, err := exec.Execute(context.Background(), act); err != nil {
		t.Fatalf("execute: %v", err)
	}

	if len(ac.Issued) != 1 || ac.Issued[0] != "exemplo.com" {
		t.Fatalf("acme não chamado corretamente: %v", ac.Issued)
	}
	vh, _ := n.VHost("exemplo.com")
	if !strings.Contains(vh, "listen 443 ssl;") || !strings.Contains(vh, "ssl_certificate ") {
		t.Fatalf("vhost sem TLS:\n%s", vh)
	}
	if ds.sslSet == nil || !*ds.sslSet {
		t.Fatal("SetDomainSSL(true) não foi chamado")
	}
	if len(ds.certs) != 1 {
		t.Fatalf("UpsertSSLCert não chamado: %v", ds.certs)
	}
}

func TestRemoveDomainRemovesHostVHost(t *testing.T) {
	l := runningContainer(t)
	n := nginx.NewFake()
	ds := &fakeDomainStore{domain: sampleDomain(), container: "cli_1"}

	add := executors.NewAddDomainExecutor(newWebDeps(l, n, acme.NewFake(), ds))
	addPayload, _ := json.Marshal(core.AddDomainPayload{DomainID: 1})
	if _, err := add.Execute(context.Background(), &core.Action{ID: 1, Type: core.ActionAddDomain, Payload: addPayload}); err != nil {
		t.Fatalf("add: %v", err)
	}

	rm := executors.NewRemoveDomainExecutor(newWebDeps(l, n, acme.NewFake(), ds))
	rmPayload, _ := json.Marshal(core.RemoveDomainPayload{DomainID: 1})
	if _, err := rm.Execute(context.Background(), &core.Action{ID: 2, Type: core.ActionRemoveDomain, Payload: rmPayload}); err != nil {
		t.Fatalf("remove: %v", err)
	}
	if _, ok := n.VHost("exemplo.com"); ok {
		t.Fatal("vhost do host deveria ter sido removido")
	}
}
