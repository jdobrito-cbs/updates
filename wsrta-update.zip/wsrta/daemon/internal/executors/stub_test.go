package executors_test

import (
	"context"
	"encoding/json"
	"io"
	"log/slog"
	"testing"

	"github.com/jdobrito/wsrta/daemon/internal/executors"
	"github.com/jdobrito/wsrta/internal/core"
)

func discardLogger() *slog.Logger {
	return slog.New(slog.NewTextHandler(io.Discard, nil))
}

func TestStubExecutorReturnsDone(t *testing.T) {
	stub := executors.NewStubExecutor(discardLogger())
	a := &core.Action{
		ID:      1,
		Type:    core.ActionProvisionClient,
		Payload: json.RawMessage(`{"client_id":1}`),
	}

	res, err := stub.Execute(context.Background(), a)
	if err != nil {
		t.Fatalf("Execute retornou erro: %v", err)
	}
	if res == "" {
		t.Fatal("Execute retornou resultado vazio")
	}
}

func TestRegisterStubsCobreTodosOsTipos(t *testing.T) {
	reg := executors.NewRegistry()
	executors.RegisterStubs(reg, discardLogger())

	for _, ty := range core.AllActionTypes() {
		if _, ok := reg.Get(ty); !ok {
			t.Errorf("tipo %q não tem executor registrado", ty)
		}
	}
}

func TestRegistryGetTipoDesconhecido(t *testing.T) {
	reg := executors.NewRegistry()
	if _, ok := reg.Get(core.ActionType("inexistente")); ok {
		t.Fatal("Get devolveu ok=true para tipo inexistente")
	}
}
