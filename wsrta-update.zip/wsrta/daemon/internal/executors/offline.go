package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"strings"

	"github.com/jdobrito/wsrta/daemon/internal/nginx"
	"github.com/jdobrito/wsrta/internal/core"
)



const offlineMarker = ".wsrta-offline.html"






type SetDomainOfflineExecutor struct {
	deps WebDeps
}


func NewSetDomainOfflineExecutor(deps WebDeps) *SetDomainOfflineExecutor {
	return &SetDomainOfflineExecutor{deps: deps}
}

func (e *SetDomainOfflineExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.SetDomainOfflinePayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	dom, container, err := e.deps.Domains.GetDomain(ctx, p.DomainID)
	if err != nil {
		return "", fmt.Errorf("buscar domínio %d: %w", p.DomainID, err)
	}
	marker := e.deps.docrootFor(dom) + "/" + offlineMarker
	log := e.deps.Log.With(slog.String("fqdn", dom.FQDN), slog.String("mode", p.Mode))

	if p.Mode == "" {
		
		_ = runExec(ctx, e.deps.LXD, container, "rm", "-f", marker)
	} else {
		
		if err := e.deps.LXD.PushFile(ctx, container, marker, []byte(offlinePage(p.Mode, dom.FQDN)), 0o644); err != nil {
			return "", fmt.Errorf("escrever página offline: %w", err)
		}
		_ = runExec(ctx, e.deps.LXD, container, "chown", "www-data:www-data", marker)
	}

	
	if err := e.ensureVHostOffline(ctx, container, dom); err != nil {
		return "", err
	}
	if err := runExec(ctx, e.deps.LXD, container, "nginx", "-t"); err != nil {
		return "", fmt.Errorf("nginx -t no container: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, container, "nginx", "-s", "reload"); err != nil {
		return "", fmt.Errorf("reload nginx no container: %w", err)
	}
	log.InfoContext(ctx, "modo offline do domínio aplicado")
	if p.Mode == "" {
		return fmt.Sprintf("domínio %q reativado", dom.FQDN), nil
	}
	return fmt.Sprintf("domínio %q em %s", dom.FQDN, p.Mode), nil
}


func (e *SetDomainOfflineExecutor) ensureVHostOffline(ctx context.Context, container string, dom *core.Domain) error {
	vhostPath := internalVHostPath(dom.FQDN)
	res, err := e.deps.LXD.Exec(ctx, container, []string{"cat", vhostPath}, nil)
	if err == nil && res.ExitCode == 0 && strings.Contains(res.Stdout, "wsrta_offline") {
		return nil 
	}
	vhost, err := nginx.RenderContainerVHost(nginx.ContainerVHost{
		FQDN:      dom.FQDN,
		Docroot:   e.deps.docrootFor(dom),
		PHPSocket: e.deps.resolvePHPSocket(ctx, container, dom.PHPVersion),
	})
	if err != nil {
		return err
	}
	return e.deps.LXD.PushFile(ctx, container, vhostPath, []byte(vhost), 0o644)
}



func offlinePage(mode, fqdn string) string {
	title, msg, icon := "Site em manutenção", "Estamos fazendo uma manutenção rápida. O site volta em instantes.", "🛠️"
	if mode == "suspended" {
		title, msg, icon = "Site indisponível", "Este site está temporariamente indisponível. Em caso de dúvida, fale com o suporte.", "⏸️"
	}
	return `<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>` + title + `</title>
<style>
:root{color-scheme:dark}*{box-sizing:border-box}
body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0f1216;color:#e6e9ef;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;padding:24px}
.card{max-width:520px;text-align:center;background:#171b21;border:1px solid #232a33;border-radius:16px;padding:40px 32px;box-shadow:0 20px 60px rgba(0,0,0,.4)}
.badge{width:56px;height:56px;margin:0 auto 20px;border-radius:16px;display:grid;place-items:center;background:rgba(96,165,250,.12);font-size:28px}
h1{margin:0 0 10px;font-size:22px}
p{margin:0;color:#98a2b3;line-height:1.6}
.host{margin-top:22px;font-family:ui-monospace,monospace;font-size:12px;color:#5b6472}
</style></head>
<body><div class="card">
<div class="badge">` + icon + `</div>
<h1>` + title + `</h1>
<p>` + msg + `</p>
<div class="host">` + fqdn + `</div>
</div></body></html>`
}
