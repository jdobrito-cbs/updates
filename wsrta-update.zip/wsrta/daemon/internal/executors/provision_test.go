package executors_test

import (
	"context"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"testing"

	"github.com/jdobrito/wsrta/daemon/internal/executors"
	"github.com/jdobrito/wsrta/daemon/internal/lxd"
	"github.com/jdobrito/wsrta/internal/core"
)


type fakeStore struct {
	client   *core.Client
	statuses []string
	deleted  bool
}

func (s *fakeStore) DeleteClient(_ context.Context, _ int64) error {
	s.deleted = true
	s.client = nil
	return nil
}

func (s *fakeStore) GetClient(_ context.Context, id int64) (*core.Client, error) {
	if s.client == nil || s.client.ID != id {
		return nil, errors.New("client não encontrado")
	}
	c := *s.client
	return &c, nil
}

func (s *fakeStore) SetClientStatus(_ context.Context, id int64, status string) error {
	s.statuses = append(s.statuses, status)
	if s.client != nil {
		s.client.Status = status
	}
	return nil
}

func (s *fakeStore) SetClientSFTP(_ context.Context, _ int64, enabled bool, port int, user string) error {
	if s.client != nil {
		s.client.SFTPEnabled = enabled
		s.client.SFTPPort = port
		s.client.SFTPUser = user
	}
	return nil
}

func (s *fakeStore) SetClientCloudflareStatus(_ context.Context, _ int64, _ string) error {
	return nil
}

func (s *fakeStore) SetClientPhpMyAdmin(_ context.Context, _ int64, enabled bool) error {
	if s.client != nil {
		s.client.PhpMyAdminEnabled = enabled
	}
	return nil
}

func (s *fakeStore) SetClientFastNginx(_ context.Context, _ int64, enabled bool) error {
	if s.client != nil {
		s.client.FastNginxEnabled = enabled
	}
	return nil
}

func (s *fakeStore) SetClientDockerEnabled(_ context.Context, _ int64, enabled bool) error {
	if s.client != nil {
		s.client.DockerEnabled = enabled
	}
	return nil
}

func (s *fakeStore) SetClientPowerState(_ context.Context, _ int64, _ string) error { return nil }

func (s *fakeStore) SetAppInstallStatus(_ context.Context, _ int64, _ string) error { return nil }

func (s *fakeStore) SetClientPhpMyAdminPassword(_ context.Context, _ int64, password string) error {
	if s.client != nil {
		s.client.PhpMyAdminPassword = password
	}
	return nil
}

func (s *fakeStore) SetClientPhpPgAdminPassword(_ context.Context, _ int64, password string) error {
	if s.client != nil {
		s.client.PhpPgAdminPassword = password
	}
	return nil
}

func newDeps(fakeLXD *lxd.Fake, st executors.ClientStore) executors.Deps {
	return executors.Deps{
		LXD:     fakeLXD,
		Store:   st,
		Log:     slog.New(slog.NewTextHandler(io.Discard, nil)),
		Image:   "wsrta-base",
		Pool:    "default",
		Network: "lxdbr0",
	}
}

func provisionAction(clientID int64) *core.Action {
	payload, _ := json.Marshal(core.ProvisionClientPayload{ClientID: clientID})
	return &core.Action{ID: 1, Type: core.ActionProvisionClient, Payload: payload}
}

func sampleClient() *core.Client {
	return &core.Client{
		ID: 1, LXCContainerName: "cli_1",
		CPULimit: 1, RAMLimitMB: 512, DiskQuotaMB: 5120,
		Status: core.ClientProvisioning,
	}
}

func TestProvisionCreatesStartsAndActivates(t *testing.T) {
	f := lxd.NewFake()
	st := &fakeStore{client: sampleClient()}
	exec := executors.NewProvisionClientExecutor(newDeps(f, st))

	res, err := exec.Execute(context.Background(), provisionAction(1))
	if err != nil {
		t.Fatalf("execute: %v", err)
	}
	if res == "" {
		t.Fatal("resultado vazio")
	}
	if status, ok := f.Status("cli_1"); !ok || status != lxd.StatusRunning {
		t.Fatalf("container deveria estar Running, veio %q (ok=%v)", status, ok)
	}
	if st.client.Status != core.ClientActive {
		t.Fatalf("status final = %q, esperava active", st.client.Status)
	}
}

func TestProvisionIsIdempotent(t *testing.T) {
	f := lxd.NewFake()
	st := &fakeStore{client: sampleClient()}
	exec := executors.NewProvisionClientExecutor(newDeps(f, st))

	if _, err := exec.Execute(context.Background(), provisionAction(1)); err != nil {
		t.Fatalf("1ª execução: %v", err)
	}
	if _, err := exec.Execute(context.Background(), provisionAction(1)); err != nil {
		t.Fatalf("2ª execução (idempotente): %v", err)
	}
	if status, _ := f.Status("cli_1"); status != lxd.StatusRunning {
		t.Fatalf("status = %q, esperava Running", status)
	}
}

func TestProvisionRollsBackOnStartFailure(t *testing.T) {
	f := lxd.NewFake()
	f.FailStart = true
	st := &fakeStore{client: sampleClient()}
	exec := executors.NewProvisionClientExecutor(newDeps(f, st))

	if _, err := exec.Execute(context.Background(), provisionAction(1)); err == nil {
		t.Fatal("esperava erro quando Start falha")
	}
	
	if _, ok := f.Status("cli_1"); ok {
		t.Fatal("container deveria ter sido removido no rollback")
	}
}

func TestDeprovisionRemovesContainerAndClient(t *testing.T) {
	f := lxd.NewFake()
	st := &fakeStore{client: sampleClient()}

	prov := executors.NewProvisionClientExecutor(newDeps(f, st))
	if _, err := prov.Execute(context.Background(), provisionAction(1)); err != nil {
		t.Fatalf("provision: %v", err)
	}

	deprov := executors.NewDeprovisionClientExecutor(newDeps(f, st))
	payload, _ := json.Marshal(core.DeprovisionClientPayload{ClientID: 1})
	act := &core.Action{ID: 2, Type: core.ActionDeprovisionClient, Payload: payload}
	if _, err := deprov.Execute(context.Background(), act); err != nil {
		t.Fatalf("deprovision: %v", err)
	}
	if _, ok := f.Status("cli_1"); ok {
		t.Fatal("container deveria ter sido removido")
	}
	if !st.deleted || st.client != nil {
		t.Fatal("cliente deveria ter sido REMOVIDO (hard delete), não apenas marcado")
	}
}

func TestDeprovisionToleratesMissingContainer(t *testing.T) {
	f := lxd.NewFake() 
	st := &fakeStore{client: sampleClient()}
	deprov := executors.NewDeprovisionClientExecutor(newDeps(f, st))

	payload, _ := json.Marshal(core.DeprovisionClientPayload{ClientID: 1})
	act := &core.Action{ID: 2, Type: core.ActionDeprovisionClient, Payload: payload}
	if _, err := deprov.Execute(context.Background(), act); err != nil {
		t.Fatalf("deprovision idempotente deveria suceder, veio: %v", err)
	}
	if !st.deleted {
		t.Fatal("cliente deveria ter sido removido mesmo sem container")
	}
}
