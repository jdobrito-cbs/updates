package executors_test

import (
	"context"
	"encoding/json"
	"errors"
	"strings"
	"testing"

	"github.com/jdobrito/wsrta/daemon/internal/executors"
	"github.com/jdobrito/wsrta/internal/core"
)

type fakeCronStore struct {
	job       *core.CronJob
	container string
	deleted   bool
}

func (s *fakeCronStore) GetCronJob(_ context.Context, id int64) (*core.CronJob, string, error) {
	if s.job == nil || s.job.ID != id {
		return nil, "", errors.New("cron não encontrado")
	}
	j := *s.job
	return &j, s.container, nil
}

func (s *fakeCronStore) DeleteCronJob(_ context.Context, _ int64) error {
	s.deleted = true
	return nil
}

func TestSetCronWritesCrondFile(t *testing.T) {
	l := runningContainer(t)
	st := &fakeCronStore{
		job:       &core.CronJob{ID: 5, Schedule: "0 3 * * *", Command: "php /var/www/cron.php", Enabled: true},
		container: "cli_1",
	}
	exec := executors.NewSetCronExecutor(executors.CronDeps{LXD: l, Store: st, Log: discardLogger(), CronUser: "www-data"})

	payload, _ := json.Marshal(core.SetCronPayload{CronJobID: 5})
	if _, err := exec.Execute(context.Background(), &core.Action{ID: 1, Payload: payload}); err != nil {
		t.Fatalf("execute: %v", err)
	}
	content, ok := l.Files["cli_1:/etc/cron.d/wsrta-5"]
	if !ok {
		t.Fatalf("arquivo de cron não criado: %v", l.Files)
	}
	if !strings.Contains(string(content), "0 3 * * * www-data php /var/www/cron.php") {
		t.Fatalf("conteúdo de cron inesperado: %q", string(content))
	}
}

func TestSetCronRejectsNewline(t *testing.T) {
	l := runningContainer(t)
	st := &fakeCronStore{
		job:       &core.CronJob{ID: 5, Schedule: "0 3 * * *", Command: "php x\n0 0 * * * rm -rf /", Enabled: true},
		container: "cli_1",
	}
	exec := executors.NewSetCronExecutor(executors.CronDeps{LXD: l, Store: st, Log: discardLogger(), CronUser: "www-data"})

	payload, _ := json.Marshal(core.SetCronPayload{CronJobID: 5})
	if _, err := exec.Execute(context.Background(), &core.Action{ID: 1, Payload: payload}); err == nil {
		t.Fatal("esperava erro por quebra de linha no comando")
	}
}

func TestRemoveCronDeletesFileAndRow(t *testing.T) {
	l := runningContainer(t)
	st := &fakeCronStore{
		job:       &core.CronJob{ID: 5, Schedule: "@daily", Command: "echo hi", Enabled: true},
		container: "cli_1",
	}
	exec := executors.NewRemoveCronExecutor(executors.CronDeps{LXD: l, Store: st, Log: discardLogger(), CronUser: "www-data"})

	payload, _ := json.Marshal(core.RemoveCronPayload{CronJobID: 5})
	if _, err := exec.Execute(context.Background(), &core.Action{ID: 1, Payload: payload}); err != nil {
		t.Fatalf("execute: %v", err)
	}
	found := false
	for _, c := range l.ExecCalls {
		if len(c.Cmd) >= 3 && c.Cmd[0] == "rm" && c.Cmd[2] == "/etc/cron.d/wsrta-5" {
			found = true
		}
	}
	if !found {
		t.Fatalf("rm do arquivo de cron não executado: %+v", l.ExecCalls)
	}
	if !st.deleted {
		t.Fatal("DeleteCronJob não foi chamado")
	}
}
