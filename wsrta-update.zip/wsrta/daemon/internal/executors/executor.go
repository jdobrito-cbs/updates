







package executors

import (
	"context"

	"github.com/jdobrito/wsrta/internal/core"
)



type Executor interface {
	Execute(ctx context.Context, a *core.Action) (string, error)
}


type Registry struct {
	m map[core.ActionType]Executor
}


func NewRegistry() *Registry {
	return &Registry{m: make(map[core.ActionType]Executor)}
}


func (r *Registry) Register(t core.ActionType, e Executor) {
	r.m[t] = e
}


func (r *Registry) Get(t core.ActionType) (Executor, bool) {
	e, ok := r.m[t]
	return e, ok
}
