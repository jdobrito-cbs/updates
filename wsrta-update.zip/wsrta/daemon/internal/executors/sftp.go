package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/internal/core"
)

const sftpDevice = "sftp"



type EnableSFTPExecutor struct {
	deps Deps
}


func NewEnableSFTPExecutor(deps Deps) *EnableSFTPExecutor {
	return &EnableSFTPExecutor{deps: deps}
}

func (e *EnableSFTPExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.EnableSFTPPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	if err := validLinuxUser(p.User); err != nil {
		return "", err
	}

	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	container := client.LXCContainerName

	
	_ = runExec(ctx, e.deps.LXD, container, "systemctl", "enable", "--now", "ssh")
	
	
	
	_ = e.deps.LXD.PushFile(ctx, container, "/etc/ssh/sshd_config.d/99-wsrta-sftp.conf",
		[]byte("PasswordAuthentication yes\n"), 0o644)
	_ = runExec(ctx, e.deps.LXD, container,
		"useradd", "-m", "-d", "/var/www", "-s", "/usr/sbin/nologin", "-G", "www-data", p.User)

	
	res, err := e.deps.LXD.Exec(ctx, container, []string{"chpasswd"}, []byte(p.User+":"+p.Password))
	if err != nil {
		return "", fmt.Errorf("definir senha: %w", err)
	}
	if res.ExitCode != 0 {
		return "", fmt.Errorf("definir senha falhou (rc=%d): %s", res.ExitCode, res.Stderr)
	}

	
	_ = runExec(ctx, e.deps.LXD, container, "chmod", "-R", "g+w", "/var/www")

	
	_ = runExec(ctx, e.deps.LXD, container, "systemctl", "restart", "ssh")

	
	listen := fmt.Sprintf("tcp:0.0.0.0:%d", p.HostPort)
	if err := e.deps.LXD.AddProxyDevice(ctx, container, sftpDevice, listen, "tcp:127.0.0.1:22"); err != nil {
		return "", fmt.Errorf("expor porta SFTP: %w", err)
	}

	if err := e.deps.Store.SetClientSFTP(ctx, client.ID, true, p.HostPort, p.User); err != nil {
		return "", fmt.Errorf("salvar estado do SFTP: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "sftp habilitado",
		slog.Int64("client_id", client.ID), slog.String("user", p.User), slog.Int("port", p.HostPort))
	return fmt.Sprintf("SFTP habilitado na porta %d (usuário %q)", p.HostPort, p.User), nil
}


type DisableSFTPExecutor struct {
	deps Deps
}


func NewDisableSFTPExecutor(deps Deps) *DisableSFTPExecutor {
	return &DisableSFTPExecutor{deps: deps}
}

func (e *DisableSFTPExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.DisableSFTPPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}

	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	container := client.LXCContainerName

	if err := e.deps.LXD.RemoveDevice(ctx, container, sftpDevice); err != nil {
		return "", fmt.Errorf("remover proxy SFTP: %w", err)
	}
	if p.User != "" && validLinuxUser(p.User) == nil {
		_ = runExec(ctx, e.deps.LXD, container, "userdel", p.User)
	}

	if err := e.deps.Store.SetClientSFTP(ctx, client.ID, false, 0, ""); err != nil {
		return "", fmt.Errorf("salvar estado do SFTP: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "sftp desabilitado", slog.Int64("client_id", client.ID))
	return "SFTP desabilitado", nil
}
