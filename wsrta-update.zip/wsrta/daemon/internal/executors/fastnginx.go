package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/internal/core"
)

const fastNginxPath = "/etc/nginx/conf.d/wsrta-fast.conf"










const fastNginxConf = `# WSRTA — aceleração do nginx (fast nginx)
gzip_vary on;
gzip_comp_level 5;
gzip_min_length 256;
gzip_proxied any;
gzip_types text/plain text/css text/xml application/json application/javascript application/xml image/svg+xml font/woff2;
open_file_cache max=2000 inactive=20s;
open_file_cache_valid 30s;
open_file_cache_min_uses 2;
open_file_cache_errors off;
`



type SetFastNginxExecutor struct {
	deps Deps
}


func NewSetFastNginxExecutor(deps Deps) *SetFastNginxExecutor {
	return &SetFastNginxExecutor{deps: deps}
}

func (e *SetFastNginxExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.SetFastNginxPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	container := client.LXCContainerName

	if p.Enabled {
		if err := e.deps.LXD.PushFile(ctx, container, fastNginxPath, []byte(fastNginxConf), 0o644); err != nil {
			return "", fmt.Errorf("escrever conf de aceleração: %w", err)
		}
	} else {
		_ = runExec(ctx, e.deps.LXD, container, "rm", "-f", fastNginxPath)
	}
	if err := runExec(ctx, e.deps.LXD, container, "nginx", "-t"); err != nil {
		
		
		if p.Enabled {
			_ = runExec(ctx, e.deps.LXD, container, "rm", "-f", fastNginxPath)
		}
		return "", fmt.Errorf("nginx -t: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, container, "nginx", "-s", "reload"); err != nil {
		return "", fmt.Errorf("reload nginx: %w", err)
	}
	if err := e.deps.Store.SetClientFastNginx(ctx, client.ID, p.Enabled); err != nil {
		return "", err
	}
	e.deps.Log.InfoContext(ctx, "fast nginx", slog.Int64("client_id", client.ID), slog.Bool("enabled", p.Enabled))
	if p.Enabled {
		return "aceleração do nginx ativada", nil
	}
	return "aceleração do nginx desativada", nil
}
