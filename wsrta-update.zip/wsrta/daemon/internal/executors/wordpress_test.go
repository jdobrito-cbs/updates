package executors_test

import (
	"context"
	"encoding/json"
	"strings"
	"testing"

	"github.com/jdobrito/wsrta/daemon/internal/acme"
	"github.com/jdobrito/wsrta/daemon/internal/executors"
	"github.com/jdobrito/wsrta/daemon/internal/nginx"
	"github.com/jdobrito/wsrta/internal/core"
)

func hasArg(cmd []string, s string) bool {
	for _, c := range cmd {
		if c == s {
			return true
		}
	}
	return false
}

func TestInstallWordPressRunsWPCLI(t *testing.T) {
	l := runningContainer(t)
	st := &fakeDomainStore{domain: sampleDomain(), container: "cli_1"}
	exec := executors.NewInstallWordPressExecutor(newWebDeps(l, nginx.NewFake(), acme.NewFake(), st))

	payload, _ := json.Marshal(core.InstallWordPressPayload{
		DomainID: 1, Path: "blog", AdminUser: "admin", AdminEmail: "a@b.c",
		AdminPassword: "secret123", Title: "Meu Blog", DBName: "wp_abc123",
	})
	if _, err := exec.Execute(context.Background(), &core.Action{ID: 1, Payload: payload}); err != nil {
		t.Fatalf("execute: %v", err)
	}

	var createdDB, downloaded, installed bool
	for _, c := range l.ExecCalls {
		if c.Cmd[0] == "mysql" && len(c.Cmd) >= 3 && strings.Contains(c.Cmd[2], "CREATE DATABASE") && strings.Contains(c.Cmd[2], "`wp_abc123`") {
			createdDB = true
		}
		if c.Cmd[0] == "wp" && hasArg(c.Cmd, "download") && hasArg(c.Cmd, "--path=/var/www/exemplo.com/blog") {
			downloaded = true
		}
		if c.Cmd[0] == "wp" && hasArg(c.Cmd, "install") && hasArg(c.Cmd, "--url=exemplo.com/blog") {
			installed = true
		}
	}
	if !createdDB {
		t.Fatalf("banco dedicado não criado: %+v", l.ExecCalls)
	}
	if !downloaded {
		t.Fatalf("wp core download na subpasta não executado: %+v", l.ExecCalls)
	}
	if !installed {
		t.Fatalf("wp core install com a URL correta não executado: %+v", l.ExecCalls)
	}
}

func TestRemoveWordPressDropsDBAndFiles(t *testing.T) {
	l := runningContainer(t)
	st := &fakeDomainStore{domain: sampleDomain(), container: "cli_1"}
	exec := executors.NewRemoveWordPressExecutor(newWebDeps(l, nginx.NewFake(), acme.NewFake(), st))

	payload, _ := json.Marshal(core.RemoveWordPressPayload{DomainID: 1, Path: "blog", DBName: "wp_abc123"})
	if _, err := exec.Execute(context.Background(), &core.Action{ID: 1, Payload: payload}); err != nil {
		t.Fatalf("execute: %v", err)
	}

	var removed, dropped bool
	for _, c := range l.ExecCalls {
		if c.Cmd[0] == "rm" && hasArg(c.Cmd, "-rf") && hasArg(c.Cmd, "/var/www/exemplo.com/blog") {
			removed = true
		}
		if c.Cmd[0] == "mysql" && len(c.Cmd) >= 3 && strings.Contains(c.Cmd[2], "DROP DATABASE") {
			dropped = true
		}
	}
	if !removed {
		t.Fatalf("arquivos não removidos: %+v", l.ExecCalls)
	}
	if !dropped {
		t.Fatalf("banco não dropado: %+v", l.ExecCalls)
	}
}
