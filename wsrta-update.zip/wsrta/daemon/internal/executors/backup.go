package executors

import (
	"archive/tar"
	"compress/gzip"
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"path"
	"path/filepath"
	"strings"
	"time"

	"github.com/jdobrito/wsrta/daemon/internal/lxd"
	"github.com/jdobrito/wsrta/internal/core"
)


type BackupStore interface {
	GetClient(ctx context.Context, id int64) (*core.Client, error)
	ListClientDomains(ctx context.Context, clientID int64) ([]core.Domain, error)
	ListClientDatabases(ctx context.Context, clientID int64) ([]core.Database, error)
	SetBackupResult(ctx context.Context, id int64, status, filename string, size int64) error
}


type BackupDeps struct {
	LXD         lxd.Client
	Store       BackupStore
	Log         *slog.Logger
	BackupDir   string
	DocrootBase string
	Progress    ProgressReporter 
}



type BackupClientExecutor struct {
	deps BackupDeps
}


func NewBackupClientExecutor(deps BackupDeps) *BackupClientExecutor {
	return &BackupClientExecutor{deps: deps}
}

func (e *BackupClientExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.BackupClientPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}

	filename, size, err := e.build(ctx, a.ID, p)
	if err != nil {
		_ = e.deps.Store.SetBackupResult(ctx, p.BackupID, "failed", "", 0)
		return "", err
	}
	if err := e.deps.Store.SetBackupResult(ctx, p.BackupID, "done", filename, size); err != nil {
		return "", fmt.Errorf("gravar resultado: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "backup gerado",
		slog.Int64("client_id", p.ClientID), slog.String("file", filename), slog.Int64("bytes", size))
	return fmt.Sprintf("backup %s (%d KB)", filename, size/1024), nil
}

func (e *BackupClientExecutor) build(ctx context.Context, actionID int64, p core.BackupClientPayload) (string, int64, error) {
	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", 0, fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	container := client.LXCContainerName
	domains, err := e.deps.Store.ListClientDomains(ctx, p.ClientID)
	if err != nil {
		return "", 0, err
	}
	dbs, err := e.deps.Store.ListClientDatabases(ctx, p.ClientID)
	if err != nil {
		return "", 0, err
	}

	if err := os.MkdirAll(e.deps.BackupDir, 0o750); err != nil {
		return "", 0, fmt.Errorf("criar dir de backups: %w", err)
	}
	filename := fmt.Sprintf("wsrta-c%d-%s.tar.gz", p.ClientID, time.Now().Format("20060102-150405"))
	dst := filepath.Join(e.deps.BackupDir, filename)
	hostTmp := filepath.Join(e.deps.BackupDir, fmt.Sprintf(".pull-%d.tmp", p.BackupID))
	ctTmp := fmt.Sprintf("/tmp/wsrta-bkp-%d.tar.gz", p.BackupID)

	out, err := os.Create(dst)
	if err != nil {
		return "", 0, fmt.Errorf("criar arquivo: %w", err)
	}
	gz := gzip.NewWriter(out)
	tw := tar.NewWriter(gz)

	manifest := core.BackupManifest{
		ClientID:   p.ClientID,
		ClientName: client.Name,
		CreatedAt:  time.Now().UTC(),
	}

	
	total := len(dbs) + len(domains)
	done := 0
	reportProgress(ctx, e.deps.Progress, actionID, 0, "preparando backup")

	
	for _, d := range dbs {
		if err := validMySQLIdent(d.DBName); err != nil {
			e.deps.Log.WarnContext(ctx, "banco ignorado no backup", slog.String("db", d.DBName), slog.Any("err", err))
			continue
		}
		hash := e.dbPasswordHash(ctx, container, d.DBUser)
		res, err := e.deps.LXD.Exec(ctx, container, []string{"mysqldump", "--single-transaction", "--quick", d.DBName}, nil)
		if err != nil || res.ExitCode != 0 {
			e.deps.Log.WarnContext(ctx, "dump falhou; pulando banco", slog.String("db", d.DBName))
			continue
		}
		if werr := writeTarBytes(tw, "db/"+d.DBName+".sql", []byte(res.Stdout)); werr != nil {
			return cleanupFail(out, dst, werr)
		}
		manifest.Databases = append(manifest.Databases, core.ManifestDatabase{Name: d.DBName, User: d.DBUser, PasswordHash: hash})
		done++
		reportProgress(ctx, e.deps.Progress, actionID, pctOf(done, total), fmt.Sprintf("banco %s (%d/%d)", d.DBName, done, total))
	}

	
	for _, d := range domains {
		docroot := d.Docroot
		if docroot == "" {
			docroot = path.Join(e.deps.DocrootBase, d.FQDN)
		}
		if err := runExec(ctx, e.deps.LXD, container, "tar", "-czf", ctTmp, "-C", docroot, "."); err != nil {
			e.deps.Log.WarnContext(ctx, "tar do docroot falhou; pulando domínio", slog.String("fqdn", d.FQDN))
			continue
		}
		if err := e.deps.LXD.PullFile(ctx, container, ctTmp, hostTmp); err != nil {
			e.deps.Log.WarnContext(ctx, "pull do tar falhou; pulando domínio", slog.String("fqdn", d.FQDN))
			continue
		}
		data, err := os.ReadFile(hostTmp)
		if err != nil {
			return cleanupFail(out, dst, fmt.Errorf("ler tar puxado: %w", err))
		}
		if werr := writeTarBytes(tw, "files/"+d.FQDN+".tar.gz", data); werr != nil {
			return cleanupFail(out, dst, werr)
		}
		manifest.Domains = append(manifest.Domains, core.ManifestDomain{FQDN: d.FQDN, Docroot: docroot, PHP: d.PHPVersion})
		done++
		reportProgress(ctx, e.deps.Progress, actionID, pctOf(done, total), fmt.Sprintf("site %s (%d/%d)", d.FQDN, done, total))
	}
	_ = os.Remove(hostTmp)
	_ = runExec(ctx, e.deps.LXD, container, "rm", "-f", ctTmp)
	reportProgress(ctx, e.deps.Progress, actionID, 99, "finalizando arquivo")

	mb, _ := json.MarshalIndent(manifest, "", "  ")
	if werr := writeTarBytes(tw, "manifest.json", mb); werr != nil {
		return cleanupFail(out, dst, werr)
	}

	if err := tw.Close(); err != nil {
		return cleanupFail(out, dst, err)
	}
	if err := gz.Close(); err != nil {
		return cleanupFail(out, dst, err)
	}
	if err := out.Close(); err != nil {
		return "", 0, err
	}
	info, err := os.Stat(dst)
	if err != nil {
		return "", 0, err
	}
	return filename, info.Size(), nil
}


func (e *BackupClientExecutor) dbPasswordHash(ctx context.Context, container, user string) string {
	if err := validMySQLIdent(user); err != nil {
		return ""
	}
	q := fmt.Sprintf("SELECT Password FROM mysql.user WHERE User='%s' AND Host='localhost' LIMIT 1", user)
	res, err := e.deps.LXD.Exec(ctx, container, []string{"mysql", "-N", "-B", "-e", q}, nil)
	if err != nil || res.ExitCode != 0 {
		return ""
	}
	return strings.TrimSpace(res.Stdout)
}

func writeTarBytes(tw *tar.Writer, name string, data []byte) error {
	hdr := &tar.Header{Name: name, Mode: 0o600, Size: int64(len(data)), ModTime: time.Now()}
	if err := tw.WriteHeader(hdr); err != nil {
		return err
	}
	_, err := tw.Write(data)
	return err
}

func cleanupFail(out *os.File, dst string, err error) (string, int64, error) {
	_ = out.Close()
	_ = os.Remove(dst)
	return "", 0, err
}
