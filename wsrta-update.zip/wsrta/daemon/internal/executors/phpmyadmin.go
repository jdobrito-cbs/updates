package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"os/user"
	"path/filepath"
	"strconv"
	"strings"

	"github.com/jdobrito/wsrta/daemon/internal/lxd"
	"github.com/jdobrito/wsrta/internal/core"
)




func wwwDataGID() int {
	g, err := user.LookupGroup("www-data")
	if err != nil {
		return -1
	}
	id, err := strconv.Atoi(g.Gid)
	if err != nil {
		return -1
	}
	return id
}

const pmaDevice = "phpmyadmin"


type PMADeps struct {
	LXD   lxd.Client
	Store ClientStore
	Log   *slog.Logger
	ConfD string 
}





type SetPhpMyAdminExecutor struct {
	deps PMADeps
}


func NewSetPhpMyAdminExecutor(deps PMADeps) *SetPhpMyAdminExecutor {
	return &SetPhpMyAdminExecutor{deps: deps}
}

func (e *SetPhpMyAdminExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.SetPhpMyAdminPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	container := client.LXCContainerName
	confFile := filepath.Join(e.deps.ConfD, fmt.Sprintf("%d.php", client.ID))

	if !p.Enabled {
		_ = e.deps.LXD.RemoveDevice(ctx, container, pmaDevice)
		_ = runExec(ctx, e.deps.LXD, container, "mysql", "-e", "DROP USER IF EXISTS 'wsrta_pma'@'127.0.0.1';FLUSH PRIVILEGES;")
		_ = os.Remove(confFile)
		_ = e.deps.Store.SetClientPhpMyAdminPassword(ctx, client.ID, "")
		if err := e.deps.Store.SetClientPhpMyAdmin(ctx, client.ID, false); err != nil {
			return "", err
		}
		return "phpMyAdmin desabilitado", nil
	}

	pass, err := randomPassword(20)
	if err != nil {
		return "", err
	}
	
	sql := fmt.Sprintf(
		"CREATE USER IF NOT EXISTS 'wsrta_pma'@'127.0.0.1' IDENTIFIED BY '%[1]s';"+
			"ALTER USER 'wsrta_pma'@'127.0.0.1' IDENTIFIED BY '%[1]s';"+
			"GRANT ALL PRIVILEGES ON *.* TO 'wsrta_pma'@'127.0.0.1' WITH GRANT OPTION;FLUSH PRIVILEGES;",
		sqlEscapeString(pass))
	if err := runExec(ctx, e.deps.LXD, container, "mysql", "-e", sql); err != nil {
		return "", fmt.Errorf("criar usuário pma: %w", err)
	}
	
	listen := fmt.Sprintf("tcp:127.0.0.1:%d", p.Port)
	if err := e.deps.LXD.AddProxyDevice(ctx, container, pmaDevice, listen, "tcp:127.0.0.1:3306"); err != nil {
		return "", fmt.Errorf("expor MySQL: %w", err)
	}
	
	gid := wwwDataGID()
	if err := os.MkdirAll(e.deps.ConfD, 0o750); err != nil {
		return "", fmt.Errorf("criar confd: %w", err)
	}
	if gid >= 0 {
		_ = os.Chown(e.deps.ConfD, -1, gid) 
	}
	conf := fmt.Sprintf(pmaServerTmpl, client.ID, phpEscape(client.Name), p.Port, phpEscape(pass))
	if err := os.WriteFile(confFile, []byte(conf), 0o640); err != nil {
		return "", fmt.Errorf("gravar config phpMyAdmin: %w", err)
	}
	if gid >= 0 {
		_ = os.Chown(confFile, -1, gid) 
	}
	
	_ = e.deps.Store.SetClientPhpMyAdminPassword(ctx, client.ID, pass)
	if err := e.deps.Store.SetClientPhpMyAdmin(ctx, client.ID, true); err != nil {
		return "", err
	}
	e.deps.Log.InfoContext(ctx, "phpMyAdmin habilitado", slog.Int64("client_id", client.ID), slog.Int("port", p.Port))
	return fmt.Sprintf("phpMyAdmin habilitado (porta %d)", p.Port), nil
}





const pmaServerTmpl = `<?php
$i = %d;
$cfg['Servers'][$i]['verbose']         = '%s';
$cfg['Servers'][$i]['host']            = '127.0.0.1';
$cfg['Servers'][$i]['port']            = %d;
$cfg['Servers'][$i]['auth_type']       = 'cookie';
$cfg['Servers'][$i]['user']            = 'wsrta_pma';
$cfg['Servers'][$i]['password']        = '%s';
$cfg['Servers'][$i]['AllowNoPassword'] = false;
`


func phpEscape(s string) string {
	s = strings.ReplaceAll(s, `\`, `\\`)
	s = strings.ReplaceAll(s, `'`, `\'`)
	return s
}
