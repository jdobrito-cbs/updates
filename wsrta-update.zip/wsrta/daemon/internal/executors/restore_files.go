package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"os"

	"github.com/jdobrito/wsrta/internal/core"
)


const restoreArchivePath = "/tmp/wsrta-restore.tar.gz"



type RestoreFilesExecutor struct {
	deps WebDeps
}


func NewRestoreFilesExecutor(deps WebDeps) *RestoreFilesExecutor {
	return &RestoreFilesExecutor{deps: deps}
}

func (e *RestoreFilesExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.RestoreFilesPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}

	dom, container, err := e.deps.Domains.GetDomain(ctx, p.DomainID)
	if err != nil {
		return "", fmt.Errorf("buscar domínio %d: %w", p.DomainID, err)
	}
	docroot := e.deps.docrootFor(dom)
	reportProgress(ctx, e.deps.Progress, a.ID, 10, "preparando restauração")

	archive, err := os.ReadFile(p.ArchivePath)
	if err != nil {
		return "", fmt.Errorf("ler arquivo %q: %w", p.ArchivePath, err)
	}
	reportProgress(ctx, e.deps.Progress, a.ID, 25, "enviando arquivos")
	if err := e.deps.LXD.PushFile(ctx, container, restoreArchivePath, archive, 0o600); err != nil {
		return "", fmt.Errorf("enviar tarball: %w", err)
	}
	reportProgress(ctx, e.deps.Progress, a.ID, 55, "extraindo arquivos")
	if err := runExec(ctx, e.deps.LXD, container, "mkdir", "-p", docroot); err != nil {
		return "", fmt.Errorf("criar docroot: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, container, "tar", "xzf", restoreArchivePath, "-C", docroot); err != nil {
		return "", fmt.Errorf("extrair arquivos: %w", err)
	}
	reportProgress(ctx, e.deps.Progress, a.ID, 85, "ajustando permissões")
	if err := runExec(ctx, e.deps.LXD, container, "chown", "-R", "www-data:www-data", docroot); err != nil {
		return "", fmt.Errorf("ajustar dono: %w", err)
	}
	_ = runExec(ctx, e.deps.LXD, container, "rm", "-f", restoreArchivePath)

	e.deps.Log.InfoContext(ctx, "arquivos restaurados",
		slog.String("fqdn", dom.FQDN), slog.String("docroot", docroot), slog.Int("bytes", len(archive)))
	return fmt.Sprintf("arquivos restaurados em %q (%d bytes)", docroot, len(archive)), nil
}
