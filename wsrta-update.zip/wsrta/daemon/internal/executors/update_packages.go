package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"strings"

	"github.com/jdobrito/wsrta/internal/core"
)



type UpdateClientPackagesExecutor struct {
	deps Deps
}


func NewUpdateClientPackagesExecutor(deps Deps) *UpdateClientPackagesExecutor {
	return &UpdateClientPackagesExecutor{deps: deps}
}

func (e *UpdateClientPackagesExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.UpdateClientPackagesPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	container := client.LXCContainerName

	
	upd, err := e.deps.LXD.Exec(ctx, container,
		[]string{"env", "DEBIAN_FRONTEND=noninteractive", "apt-get", "update"}, nil)
	if err != nil {
		return "", fmt.Errorf("apt-get update: %w", err)
	}
	upg, err := e.deps.LXD.Exec(ctx, container,
		[]string{"env", "DEBIAN_FRONTEND=noninteractive", "apt-get", "-y", "-o", "Dpkg::Options::=--force-confold", "upgrade"}, nil)
	if err != nil {
		return "", fmt.Errorf("apt-get upgrade: %w", err)
	}
	logtxt := tailLog("$ apt-get update\n"+upd.Stdout+upd.Stderr+"\n$ apt-get -y upgrade\n"+upg.Stdout+upg.Stderr, 8000)
	if upg.ExitCode != 0 {
		return logtxt, fmt.Errorf("apt-get upgrade falhou (rc=%d)", upg.ExitCode)
	}
	e.deps.Log.InfoContext(ctx, "pacotes do container atualizados", slog.Int64("client_id", p.ClientID))
	return logtxt, nil
}


func tailLog(s string, n int) string {
	s = strings.TrimSpace(s)
	if len(s) > n {
		return "…(truncado)\n" + s[len(s)-n:]
	}
	return s
}
