package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"time"

	"github.com/jdobrito/wsrta/daemon/internal/nginx"
	"github.com/jdobrito/wsrta/internal/core"
)






type IssueSSLExecutor struct {
	deps WebDeps
}


func NewIssueSSLExecutor(deps WebDeps) *IssueSSLExecutor {
	return &IssueSSLExecutor{deps: deps}
}

func (e *IssueSSLExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.IssueSSLPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}

	dom, container, err := e.deps.Domains.GetDomain(ctx, p.DomainID)
	if err != nil {
		return "", fmt.Errorf("buscar domínio %d: %w", p.DomainID, err)
	}
	if err := core.ValidFQDN(dom.FQDN); err != nil {
		return "", err
	}
	log := e.deps.Log.With(slog.String("fqdn", dom.FQDN))

	
	cert, err := e.deps.Acme.Issue(ctx, dom.FQDN, e.deps.ACMEWebroot)
	if err != nil {
		return "", fmt.Errorf("emitir certificado: %w", err)
	}
	log.InfoContext(ctx, "certificado emitido")

	
	ip, err := e.deps.LXD.Address(ctx, container)
	if err != nil {
		return "", fmt.Errorf("obter IP do container: %w", err)
	}
	hostVHost, err := nginx.RenderHostVHost(nginx.HostVHost{
		FQDN:         dom.FQDN,
		UpstreamIP:   ip,
		UpstreamPort: e.deps.UpstreamPort,
		ACMEWebroot:  e.deps.ACMEWebroot,
		SSL:          true,
		CertPath:     cert.CertPath,
		KeyPath:      cert.KeyPath,
	})
	if err != nil {
		return "", fmt.Errorf("render vhost com TLS: %w", err)
	}
	if err := e.deps.Nginx.WriteVHost(ctx, dom.FQDN, hostVHost); err != nil {
		return "", fmt.Errorf("escrever vhost com TLS: %w", err)
	}
	if err := e.deps.Nginx.Reload(ctx); err != nil {
		return "", fmt.Errorf("reload nginx do host: %w", err)
	}

	
	expires := time.Now().AddDate(0, 0, 90)
	if err := e.deps.Domains.UpsertSSLCert(ctx, dom.ID, "Let's Encrypt", expires, "active"); err != nil {
		return "", fmt.Errorf("registrar ssl_cert: %w", err)
	}
	if err := e.deps.Domains.SetDomainSSL(ctx, dom.ID, true); err != nil {
		return "", fmt.Errorf("marcar domain.ssl_enabled: %w", err)
	}

	return fmt.Sprintf("certificado emitido e instalado para %q", dom.FQDN), nil
}
