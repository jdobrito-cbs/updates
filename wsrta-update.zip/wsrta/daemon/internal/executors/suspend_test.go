package executors_test

import (
	"context"
	"encoding/json"
	"testing"

	"github.com/jdobrito/wsrta/daemon/internal/executors"
	"github.com/jdobrito/wsrta/daemon/internal/lxd"
	"github.com/jdobrito/wsrta/internal/core"
)

func TestSuspendStopsAndMarks(t *testing.T) {
	l := runningContainer(t)
	st := &fakeStore{client: sampleClient()}
	exec := executors.NewSuspendClientExecutor(newDeps(l, st))

	payload, _ := json.Marshal(core.SuspendClientPayload{ClientID: 1})
	if _, err := exec.Execute(context.Background(), &core.Action{ID: 1, Payload: payload}); err != nil {
		t.Fatalf("execute: %v", err)
	}
	if status, _ := l.Status("cli_1"); status != lxd.StatusStopped {
		t.Fatalf("container = %q, esperava Stopped", status)
	}
	if st.client.Status != core.ClientSuspended {
		t.Fatalf("status = %q, esperava suspended", st.client.Status)
	}
}

func TestResumeStartsAndMarks(t *testing.T) {
	l := runningContainer(t)
	_ = l.Stop(context.Background(), "cli_1")
	st := &fakeStore{client: sampleClient()}
	exec := executors.NewResumeClientExecutor(newDeps(l, st))

	payload, _ := json.Marshal(core.ResumeClientPayload{ClientID: 1})
	if _, err := exec.Execute(context.Background(), &core.Action{ID: 1, Payload: payload}); err != nil {
		t.Fatalf("execute: %v", err)
	}
	if status, _ := l.Status("cli_1"); status != lxd.StatusRunning {
		t.Fatalf("container = %q, esperava Running", status)
	}
	if st.client.Status != core.ClientActive {
		t.Fatalf("status = %q, esperava active", st.client.Status)
	}
}
