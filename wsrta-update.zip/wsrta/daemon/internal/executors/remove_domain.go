package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"path"
	"strings"

	"github.com/jdobrito/wsrta/internal/core"
)





type RemoveDomainExecutor struct {
	deps WebDeps
}


func NewRemoveDomainExecutor(deps WebDeps) *RemoveDomainExecutor {
	return &RemoveDomainExecutor{deps: deps}
}

func (e *RemoveDomainExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.RemoveDomainPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}

	dom, container, err := e.deps.Domains.GetDomain(ctx, p.DomainID)
	if err != nil {
		return "", fmt.Errorf("buscar domínio %d: %w", p.DomainID, err)
	}
	log := e.deps.Log.With(slog.String("fqdn", dom.FQDN), slog.String("container", container))

	
	if err := e.deps.Nginx.RemoveVHost(ctx, dom.FQDN); err != nil {
		return "", fmt.Errorf("remover vhost do host: %w", err)
	}
	if err := e.deps.Nginx.RemovePreviewSnippet(ctx, dom.FQDN); err != nil {
		log.WarnContext(ctx, "falha ao remover preview (continuando)", slog.Any("err", err))
	}
	if err := e.deps.Nginx.RemoveForwards(ctx, dom.FQDN); err != nil {
		log.WarnContext(ctx, "falha ao remover encaminhamentos (continuando)", slog.Any("err", err))
	}
	if err := e.deps.Nginx.Reload(ctx); err != nil {
		return "", fmt.Errorf("reload nginx do host: %w", err)
	}

	
	exists, err := e.deps.LXD.Exists(ctx, container)
	if err != nil {
		return "", fmt.Errorf("verificar container: %w", err)
	}
	if exists {
		if err := runExec(ctx, e.deps.LXD, container, "rm", "-f", internalVHostPath(dom.FQDN)); err != nil {
			log.WarnContext(ctx, "falha ao remover vhost interno (continuando)", slog.Any("err", err))
		} else if err := runExec(ctx, e.deps.LXD, container, "nginx", "-s", "reload"); err != nil {
			log.WarnContext(ctx, "falha ao recarregar nginx do container (continuando)", slog.Any("err", err))
		}
		
		
		if p.DeleteFiles {
			docroot := e.deps.docrootFor(dom)
			base := path.Clean(e.deps.DocrootBase)
			if docroot != base && strings.HasPrefix(docroot, base+"/") {
				if err := runExec(ctx, e.deps.LXD, container, "rm", "-rf", docroot); err != nil {
					log.WarnContext(ctx, "falha ao apagar docroot (continuando)", slog.Any("err", err))
				} else {
					log.InfoContext(ctx, "docroot apagado", slog.String("docroot", docroot))
				}
			}
		}
	}
	
	if err := e.deps.Domains.DeleteDomain(ctx, dom.ID); err != nil {
		return "", fmt.Errorf("apagar registro do domínio: %w", err)
	}
	log.InfoContext(ctx, "domínio removido", slog.Bool("docroot_apagado", p.DeleteFiles))

	return fmt.Sprintf("domínio %q removido", dom.FQDN), nil
}
