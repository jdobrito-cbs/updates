package executors

import (
	"context"
	"time"

	"github.com/jdobrito/wsrta/internal/core"
)



type ClientStore interface {
	GetClient(ctx context.Context, id int64) (*core.Client, error)
	SetClientStatus(ctx context.Context, id int64, status string) error
	
	DeleteClient(ctx context.Context, id int64) error
	SetClientSFTP(ctx context.Context, id int64, enabled bool, port int, user string) error
	SetClientCloudflareStatus(ctx context.Context, id int64, status string) error
	SetClientPhpMyAdmin(ctx context.Context, id int64, enabled bool) error
	SetClientFastNginx(ctx context.Context, id int64, enabled bool) error
	SetClientDockerEnabled(ctx context.Context, id int64, enabled bool) error
	SetClientPowerState(ctx context.Context, id int64, state string) error
	SetAppInstallStatus(ctx context.Context, id int64, status string) error
	
	SetClientPhpMyAdminPassword(ctx context.Context, id int64, password string) error
	SetClientPhpPgAdminPassword(ctx context.Context, id int64, password string) error
}


type DomainStore interface {
	
	GetDomain(ctx context.Context, id int64) (*core.Domain, string, error)
	SetDomainSSL(ctx context.Context, id int64, enabled bool) error
	UpsertSSLCert(ctx context.Context, domainID int64, issuer string, expiresAt time.Time, status string) error
	DeleteDomain(ctx context.Context, id int64) error
	
	ListForwards(ctx context.Context, domainID int64) ([]core.DomainForward, error)
}




type DatabaseStore interface {
	
	GetDatabase(ctx context.Context, id int64) (*core.Database, string, error)
	DeleteDatabase(ctx context.Context, id int64) error
}


type DNSStore interface {
	
	GetDNSRecord(ctx context.Context, id int64) (*core.DNSRecord, string, error)
	DeleteDNSRecord(ctx context.Context, id int64) error
}


type CronStore interface {
	
	GetCronJob(ctx context.Context, id int64) (*core.CronJob, string, error)
	DeleteCronJob(ctx context.Context, id int64) error
}



type DNSBackend interface {
	EnsureZone(ctx context.Context, fqdn string) error
	SetRecord(ctx context.Context, zone, name, rtype, content string, ttl, prio int) error
	DeleteRecord(ctx context.Context, zone, name, rtype, content string, prio int) error
}
