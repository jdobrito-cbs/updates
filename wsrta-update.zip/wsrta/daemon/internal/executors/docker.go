package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/internal/core"
)




type EnableDockerExecutor struct {
	deps Deps
}


func NewEnableDockerExecutor(deps Deps) *EnableDockerExecutor {
	return &EnableDockerExecutor{deps: deps}
}

func (e *EnableDockerExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.DockerTogglePayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	name := client.LXCContainerName

	if err := e.deps.LXD.SetConfig(ctx, name, "security.nesting", "true"); err != nil {
		return "", fmt.Errorf("habilitar nesting: %w", err)
	}
	
	_ = e.deps.LXD.Stop(ctx, name)
	if err := e.deps.LXD.Start(ctx, name); err != nil {
		return "", fmt.Errorf("reiniciar container: %w", err)
	}
	if err := runExec(ctx, e.deps.LXD, name, "systemctl", "enable", "--now", "docker"); err != nil {
		return "", fmt.Errorf("iniciar dockerd: %w", err)
	}
	if err := e.deps.Store.SetClientDockerEnabled(ctx, client.ID, true); err != nil {
		return "", fmt.Errorf("gravar flag: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "docker habilitado", slog.Int64("client_id", client.ID), slog.String("container", name))
	return fmt.Sprintf("Docker habilitado em %s", name), nil
}


type DisableDockerExecutor struct {
	deps Deps
}


func NewDisableDockerExecutor(deps Deps) *DisableDockerExecutor {
	return &DisableDockerExecutor{deps: deps}
}

func (e *DisableDockerExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.DockerTogglePayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	name := client.LXCContainerName
	_ = runExec(ctx, e.deps.LXD, name, "systemctl", "disable", "--now", "docker")
	if err := e.deps.Store.SetClientDockerEnabled(ctx, client.ID, false); err != nil {
		return "", fmt.Errorf("gravar flag: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "docker desabilitado", slog.Int64("client_id", client.ID))
	return fmt.Sprintf("Docker desabilitado em %s", name), nil
}




type InstallDockerAppExecutor struct {
	deps Deps
}


func NewInstallDockerAppExecutor(deps Deps) *InstallDockerAppExecutor {
	return &InstallDockerAppExecutor{deps: deps}
}

func (e *InstallDockerAppExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.InstallDockerAppPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	
	
	fail := func(format string, args ...any) (string, error) {
		_ = e.deps.Store.SetAppInstallStatus(ctx, p.AppInstallID, "failed")
		return "", fmt.Errorf(format, args...)
	}
	app, ok := core.AppBySlug(p.Slug)
	if !ok || app.Kind != core.AppKindDocker {
		return fail("slug não é app Docker: %q", p.Slug)
	}
	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return fail("buscar client %d: %v", p.ClientID, err)
	}
	name := client.LXCContainerName
	port := fmt.Sprintf("%d", app.DockerPort)

	
	if err := runExec(ctx, e.deps.LXD, name, "docker", "run", "-d",
		"--name", p.ContainerName, "--restart", "unless-stopped",
		"-p", "127.0.0.1:"+port+":"+port, app.DockerImage); err != nil {
		return fail("docker run: %w", err)
	}
	
	device := "dockerapp-" + p.ContainerName
	if err := e.deps.LXD.AddProxyDevice(ctx, name, device,
		fmt.Sprintf("tcp:0.0.0.0:%d", p.HostPort), "tcp:127.0.0.1:"+port); err != nil {
		return fail("expor porta: %w", err)
	}
	if err := e.deps.Store.SetAppInstallStatus(ctx, p.AppInstallID, "active"); err != nil {
		return "", fmt.Errorf("gravar status: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "app docker instalado", slog.String("app", p.Slug),
		slog.String("container", p.ContainerName), slog.Int("host_port", p.HostPort))
	return fmt.Sprintf("%s rodando (porta %d)", app.Name, p.HostPort), nil
}



type UpdateDockerAppExecutor struct {
	deps Deps
}


func NewUpdateDockerAppExecutor(deps Deps) *UpdateDockerAppExecutor {
	return &UpdateDockerAppExecutor{deps: deps}
}

func (e *UpdateDockerAppExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.InstallDockerAppPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	fail := func(format string, args ...any) (string, error) {
		_ = e.deps.Store.SetAppInstallStatus(ctx, p.AppInstallID, "failed")
		return "", fmt.Errorf(format, args...)
	}
	app, ok := core.AppBySlug(p.Slug)
	if !ok || app.Kind != core.AppKindDocker {
		return fail("slug não é app Docker: %q", p.Slug)
	}
	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return fail("buscar client %d: %v", p.ClientID, err)
	}
	name := client.LXCContainerName
	port := fmt.Sprintf("%d", app.DockerPort)

	
	if err := runExec(ctx, e.deps.LXD, name, "docker", "pull", app.DockerImage); err != nil {
		return fail("docker pull: %w", err)
	}
	_ = runExec(ctx, e.deps.LXD, name, "docker", "rm", "-f", p.ContainerName) 
	if err := runExec(ctx, e.deps.LXD, name, "docker", "run", "-d",
		"--name", p.ContainerName, "--restart", "unless-stopped",
		"-p", "127.0.0.1:"+port+":"+port, app.DockerImage); err != nil {
		return fail("docker run: %w", err)
	}
	if err := e.deps.Store.SetAppInstallStatus(ctx, p.AppInstallID, "active"); err != nil {
		return "", fmt.Errorf("gravar status: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "app docker atualizado", slog.String("app", p.Slug), slog.String("container", p.ContainerName))
	return app.Name + " atualizado (imagem mais nova)", nil
}


type RemoveDockerAppExecutor struct {
	deps Deps
}


func NewRemoveDockerAppExecutor(deps Deps) *RemoveDockerAppExecutor {
	return &RemoveDockerAppExecutor{deps: deps}
}

func (e *RemoveDockerAppExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.RemoveDockerAppPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	name := client.LXCContainerName
	_ = runExec(ctx, e.deps.LXD, name, "docker", "rm", "-f", p.ContainerName) 
	if p.DeviceName != "" {
		_ = e.deps.LXD.RemoveDevice(ctx, name, p.DeviceName)
	}
	e.deps.Log.InfoContext(ctx, "app docker removido", slog.String("container", p.ContainerName))
	return fmt.Sprintf("container %s removido", p.ContainerName), nil
}
