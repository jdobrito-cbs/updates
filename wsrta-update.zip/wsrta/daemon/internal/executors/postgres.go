package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/internal/core"
)


func aptInstall(ctx context.Context, e Deps, container string, pkgs ...string) error {
	_ = runExec(ctx, e.LXD, container, "apt-get", "update")
	args := append([]string{"env", "DEBIAN_FRONTEND=noninteractive", "apt-get", "install", "-y", "--no-install-recommends"}, pkgs...)
	return runExec(ctx, e.LXD, container, args...)
}



type SetPostgresExecutor struct{ deps Deps }


func NewSetPostgresExecutor(deps Deps) *SetPostgresExecutor { return &SetPostgresExecutor{deps: deps} }

func (e *SetPostgresExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.SetPostgresPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	container := client.LXCContainerName
	if !p.Enabled {
		_ = runExec(ctx, e.deps.LXD, container, "systemctl", "stop", "postgresql")
		return "PostgreSQL desativado", nil
	}
	if err := aptInstall(ctx, e.deps, container, "postgresql"); err != nil {
		return "", fmt.Errorf("instalar postgresql: %w", err)
	}
	_ = runExec(ctx, e.deps.LXD, container, "systemctl", "enable", "--now", "postgresql")
	e.deps.Log.InfoContext(ctx, "postgresql instalado/ativado", slog.String("container", container))
	return "PostgreSQL ativado", nil
}



