package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/daemon/internal/nginx"
	"github.com/jdobrito/wsrta/internal/core"
)



type SetDomainForwardsExecutor struct {
	deps WebDeps
}


func NewSetDomainForwardsExecutor(deps WebDeps) *SetDomainForwardsExecutor {
	return &SetDomainForwardsExecutor{deps: deps}
}

func (e *SetDomainForwardsExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.SetDomainForwardsPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	dom, _, err := e.deps.Domains.GetDomain(ctx, p.DomainID)
	if err != nil {
		return "", fmt.Errorf("buscar domínio %d: %w", p.DomainID, err)
	}
	if err := core.ValidFQDN(dom.FQDN); err != nil {
		return "", err
	}
	n, err := e.deps.writeForwards(ctx, dom.ID, dom.FQDN)
	if err != nil {
		return "", err
	}
	if err := e.deps.Nginx.Reload(ctx); err != nil {
		return "", fmt.Errorf("reload nginx do host: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "encaminhamentos do domínio aplicados", slog.String("fqdn", dom.FQDN), slog.Int("n", n))
	return fmt.Sprintf("%d encaminhamento(s) aplicado(s) em %q", n, dom.FQDN), nil
}




func (d WebDeps) writeForwards(ctx context.Context, domainID int64, fqdn string) (int, error) {
	fwds, err := d.Domains.ListForwards(ctx, domainID)
	if err != nil {
		return 0, fmt.Errorf("listar encaminhamentos: %w", err)
	}
	var nf []nginx.Forward
	for _, f := range fwds {
		if core.ValidUpstreamPath(f.Path) != nil || f.Path == "" {
			d.Log.WarnContext(ctx, "encaminhamento inválido ignorado", slog.String("path", f.Path), slog.String("target", f.Target))
			continue
		}
		if f.TargetDomainID > 0 {
			
			
			td, tcontainer, err := d.Domains.GetDomain(ctx, f.TargetDomainID)
			if err != nil {
				d.Log.WarnContext(ctx, "alvo interno do encaminhamento não encontrado", slog.String("path", f.Path), slog.Int64("target_domain_id", f.TargetDomainID))
				continue
			}
			ip, err := d.LXD.Address(ctx, tcontainer)
			if err != nil || ip == "" {
				d.Log.WarnContext(ctx, "sem IP do container alvo do encaminhamento", slog.String("path", f.Path), slog.String("fqdn", td.FQDN))
				continue
			}
			nf = append(nf, nginx.Forward{Path: f.Path, Target: ip, Host: td.FQDN})
			continue
		}
		if core.ValidUpstreamTarget(f.Target) != nil {
			d.Log.WarnContext(ctx, "encaminhamento inválido ignorado", slog.String("path", f.Path), slog.String("target", f.Target))
			continue
		}
		nf = append(nf, nginx.Forward{Path: f.Path, Target: f.Target})
	}
	if err := d.Nginx.WriteForwards(ctx, fqdn, nginx.RenderForwards(nf)); err != nil {
		return 0, err
	}
	return len(nf), nil
}
