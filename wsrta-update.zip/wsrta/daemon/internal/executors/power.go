package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/daemon/internal/lxd"
	"github.com/jdobrito/wsrta/internal/core"
)




type PowerClientExecutor struct {
	deps Deps
}


func NewPowerClientExecutor(deps Deps) *PowerClientExecutor {
	return &PowerClientExecutor{deps: deps}
}

func (e *PowerClientExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.PowerClientPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	name := client.LXCContainerName

	exists, err := e.deps.LXD.Exists(ctx, name)
	if err != nil {
		return "", fmt.Errorf("verificar container: %w", err)
	}
	if !exists {
		return "", fmt.Errorf("container %q não existe", name)
	}
	info, err := e.deps.LXD.Info(ctx, name)
	if err != nil {
		return "", fmt.Errorf("obter estado: %w", err)
	}
	running := info.Status == lxd.StatusRunning

	
	
	
	defer func() {
		state := "running"
		if fresh, ferr := e.deps.LXD.Info(ctx, name); ferr != nil || fresh.Status != lxd.StatusRunning {
			state = "stopped"
		}
		if err := e.deps.Store.SetClientPowerState(ctx, client.ID, state); err != nil {
			e.deps.Log.WarnContext(ctx, "falha ao gravar power_state (continuando)", slog.Any("err", err))
		}
	}()

	switch p.Op {
	case "start":
		if !running {
			if err := e.deps.LXD.Start(ctx, name); err != nil {
				return "", fmt.Errorf("iniciar container: %w", err)
			}
		}
	case "stop":
		if running {
			if err := e.deps.LXD.Stop(ctx, name); err != nil {
				return "", fmt.Errorf("parar container: %w", err)
			}
		}
	case "restart":
		if running {
			if err := e.deps.LXD.Stop(ctx, name); err != nil {
				return "", fmt.Errorf("parar container: %w", err)
			}
		}
		if err := e.deps.LXD.Start(ctx, name); err != nil {
			return "", fmt.Errorf("iniciar container: %w", err)
		}
	}
	e.deps.Log.InfoContext(ctx, "power da VPS", slog.Int64("client_id", client.ID), slog.String("op", p.Op))
	return fmt.Sprintf("VPS %s (op=%s)", name, p.Op), nil
}
