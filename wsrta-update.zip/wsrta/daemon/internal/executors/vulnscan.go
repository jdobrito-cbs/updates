package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"os"
	"os/exec"
	"path"
	"strings"
	"time"

	"github.com/jdobrito/wsrta/daemon/internal/lxd"
	"github.com/jdobrito/wsrta/daemon/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
)


type VulnDeps struct {
	LXD      lxd.Client
	Store    *store.Vuln
	Log      *slog.Logger
	NiktoBin string 
}




type ScanVulnerabilitiesExecutor struct {
	deps VulnDeps
}


func NewScanVulnerabilitiesExecutor(deps VulnDeps) *ScanVulnerabilitiesExecutor {
	return &ScanVulnerabilitiesExecutor{deps: deps}
}

func (e *ScanVulnerabilitiesExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.ScanVulnerabilitiesPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	_ = e.deps.Store.MarkRunning(ctx, p.ScanID)

	var findings []core.VulnFinding
	var err error
	if p.ClientID == 0 {
		findings = e.scanHost(ctx)
	} else {
		findings, err = e.scanClient(ctx, p.ClientID, p.Nikto)
		if err != nil {
			_ = e.deps.Store.Finish(ctx, p.ScanID, 0, 0, 0, 0, "falha: "+err.Error(), "failed")
			return "", err
		}
	}

	
	var high, medium, low, info int
	for _, f := range findings {
		switch f.Severity {
		case core.VulnHigh:
			high++
		case core.VulnMedium:
			medium++
		case core.VulnLow:
			low++
		default:
			info++
		}
		if err := e.deps.Store.AddFinding(ctx, p.ScanID, f); err != nil {
			e.deps.Log.WarnContext(ctx, "scan: falha ao gravar achado", slog.Any("err", err))
		}
	}
	summary := fmt.Sprintf("%d críticos, %d médios, %d baixos, %d informativos", high, medium, low, info)
	_ = e.deps.Store.Finish(ctx, p.ScanID, high, medium, low, info, summary, "done")
	if p.ClientID > 0 {
		_ = e.deps.Store.SetLastScan(ctx, p.ClientID)
	}
	e.deps.Log.InfoContext(ctx, "scan de vulnerabilidades concluído",
		slog.Int64("scan_id", p.ScanID), slog.Int64("client_id", p.ClientID), slog.String("resumo", summary))
	return summary, nil
}



func (e *ScanVulnerabilitiesExecutor) scanClient(ctx context.Context, clientID int64, doNikto bool) ([]core.VulnFinding, error) {
	container, err := e.deps.Store.ClientContainer(ctx, clientID)
	if err != nil {
		return nil, err
	}
	var out []core.VulnFinding

	wps, err := e.deps.Store.ListWordPress(ctx, clientID)
	if err != nil {
		return nil, err
	}
	for _, wp := range wps {
		out = append(out, e.scanWordPress(ctx, container, wp)...)
	}

	doms, err := e.deps.Store.ListDomains(ctx, clientID)
	if err != nil {
		return nil, err
	}
	
	
	nikto := doNikto && e.deps.NiktoBin != ""
	niktoDeadline := time.Now().Add(3 * time.Minute)
	for _, d := range doms {
		out = append(out, e.scanDocroot(ctx, container, d.FQDN)...)
		if nikto && time.Now().Before(niktoDeadline) {
			out = append(out, e.scanNikto(ctx, d.FQDN)...)
		}
	}
	if doNikto && e.deps.NiktoBin == "" {
		out = append(out, finding("", core.VulnInfo, "nikto",
			"Varredura do servidor web (Nikto) desligada", "",
			"Opcional: defina WSRTA_NIKTO_BIN no daemon (e instale o nikto) para varrer o servidor web em busca de configurações inseguras. Fica de fora dos scans agendados de propósito."))
	}
	if len(out) == 0 {
		out = append(out, finding("", core.VulnInfo, "geral", "Nenhum problema encontrado",
			"O scan não encontrou vulnerabilidades conhecidas nos sites e WordPress do cliente.", ""))
	}
	return out, nil
}


func (e *ScanVulnerabilitiesExecutor) scanWordPress(ctx context.Context, container string, wp store.VulnWP) []core.VulnFinding {
	dir := "/var/www/" + wp.FQDN
	if p := strings.Trim(wp.Path, "/"); p != "" {
		dir += "/" + p
	}
	var out []core.VulnFinding

	
	
	
	
	if r := e.wp(ctx, container, dir, "core", "verify-checksums"); r.ExitCode != 0 {
		if mism := checksumMismatch(r.Stdout + "\n" + r.Stderr); len(mism) > 0 {
			out = append(out, finding(wp.FQDN, core.VulnHigh, "wordpress",
				"Arquivos do core do WordPress modificados",
				trunc(strings.Join(mism, "\n"), 1500),
				"Possível adulteração/malware. Restaure o core com 'wp core download --force', investigue os arquivos alterados e troque as senhas do WordPress e do banco."))
		} else {
			out = append(out, finding(wp.FQDN, core.VulnInfo, "wordpress",
				"Não foi possível verificar a integridade do core do WordPress",
				trunc(r.Stderr+"\n"+r.Stdout, 800),
				"Não indica invasão. Confira se o wp-cli funciona e se o container acessa api.wordpress.org (CSF/fail2ban podem bloquear a saída)."))
		}
	}
	if r := e.wp(ctx, container, dir, "plugin", "verify-checksums", "--all"); r.ExitCode != 0 {
		if mism := checksumMismatch(r.Stdout + "\n" + r.Stderr); len(mism) > 0 {
			out = append(out, finding(wp.FQDN, core.VulnMedium, "wordpress",
				"Arquivos de plugin modificados",
				trunc(strings.Join(mism, "\n"), 1500),
				"Reinstale os plugins afetados ('wp plugin install <slug> --force') ou remova os que não usa; verifique injeção de código."))
		} else {
			out = append(out, finding(wp.FQDN, core.VulnInfo, "wordpress",
				"Verificação de integridade dos plugins incompleta",
				trunc(r.Stderr+"\n"+r.Stdout, 800),
				"Não indica invasão. Plugins premium/customizados não têm checksum público; confira também se o container acessa api.wordpress.org (CSF/fail2ban)."))
		}
	}
	if r := e.wp(ctx, container, dir, "core", "check-update", "--field=version", "--format=csv"); r.ExitCode == 0 {
		if v := firstLine(r.Stdout); v != "" {
			out = append(out, finding(wp.FQDN, core.VulnMedium, "desatualizado",
				"WordPress core desatualizado (disponível "+v+")",
				"Rodar versões antigas do core deixa falhas conhecidas abertas.",
				"Atualize pelo painel: WordPress → Gerenciar → Atualizar core."))
		}
	}
	if r := e.wp(ctx, container, dir, "plugin", "list", "--update=available", "--field=name", "--format=csv"); r.ExitCode == 0 {
		for _, name := range nonEmptyLines(r.Stdout) {
			out = append(out, finding(wp.FQDN, core.VulnMedium, "desatualizado",
				"Plugin desatualizado: "+name,
				"Plugins desatualizados são o principal vetor de invasão em WordPress.",
				"Atualize o plugin pelo painel (WordPress → Gerenciar)."))
		}
	}
	if r := e.wp(ctx, container, dir, "theme", "list", "--update=available", "--field=name", "--format=csv"); r.ExitCode == 0 {
		for _, name := range nonEmptyLines(r.Stdout) {
			out = append(out, finding(wp.FQDN, core.VulnLow, "desatualizado",
				"Tema desatualizado: "+name, "",
				"Atualize o tema pelo painel (WordPress → Gerenciar)."))
		}
	}
	
	
	if r := e.exec(ctx, container, "ls", dir+"/wp-content/mu-plugins/wsrta-hardening.php"); r.ExitCode != 0 {
		out = append(out, finding(wp.FQDN, core.VulnLow, "wordpress",
			"Enumeração de usuários possivelmente exposta (CVE-2017-5487)",
			"O REST /wp-json/wp/v2/users e o ?author=N podem revelar os logins dos usuários — meio caminho de um brute-force.",
			"No painel do WordPress do site, clique em 'Proteger' (instala um mu-plugin que bloqueia a enumeração via REST e ?author=)."))
	}
	return out
}


func (e *ScanVulnerabilitiesExecutor) scanDocroot(ctx context.Context, container, fqdn string) []core.VulnFinding {
	dir := "/var/www/" + fqdn
	var out []core.VulnFinding

	
	r := e.exec(ctx, container, "find", dir, "-maxdepth", "3", "-type", "f",
		"(", "-name", ".env", "-o", "-name", "*.sql", "-o", "-name", "*.sql.gz",
		"-o", "-name", "wp-config.php.bak", "-o", "-name", "wp-config.php~", "-o", "-name", ".htpasswd", ")")
	for _, f := range nonEmptyLines(r.Stdout) {
		out = append(out, finding(fqdn, core.VulnHigh, "arquivo-exposto",
			"Arquivo sensível no docroot: "+path.Base(f), f,
			"Remova o arquivo do docroot (ou mova para fora de /var/www). Dumps .sql e .env expõem credenciais do banco/app."))
	}
	
	if rg := e.exec(ctx, container, "find", dir, "-maxdepth", "2", "-name", ".git", "-type", "d"); rg.ExitCode == 0 {
		for _, f := range nonEmptyLines(rg.Stdout) {
			out = append(out, finding(fqdn, core.VulnHigh, "arquivo-exposto",
				"Repositório .git exposto no docroot", f,
				"Remova o diretório .git do docroot — ele expõe todo o código-fonte, credenciais e histórico do site."))
		}
	}
	
	rp := e.exec(ctx, container, "grep", "-rlEI",
		`eval\(base64_decode|gzinflate\(base64_decode|str_rot13\(base64|\$_(GET|POST|REQUEST|COOKIE)\[[^]]*\]\(|preg_replace\('/.*/e'|assert\(\$_`,
		"--include=*.php", dir)
	for _, f := range nonEmptyLines(rp.Stdout) {
		out = append(out, finding(fqdn, core.VulnHigh, "malware",
			"Possível código malicioso (ofuscação PHP): "+path.Base(f), f,
			"Inspecione o arquivo — padrões como eval(base64_decode(...)) costumam ser backdoor/webshell. Remova/limpe, restaure de um backup limpo e troque as senhas."))
	}
	
	if rd := e.exec(ctx, container, "find", dir, "-maxdepth", "2", "-type", "f",
		"(", "-name", "debug.log", "-o", "-name", "error_log", ")"); rd.ExitCode == 0 {
		for _, f := range nonEmptyLines(rd.Stdout) {
			out = append(out, finding(fqdn, core.VulnLow, "arquivo-exposto",
				"Log acessível no docroot: "+path.Base(f), f,
				"Mova os logs para fora do docroot; eles podem vazar caminhos internos e dados sensíveis."))
		}
	}
	return out
}



func (e *ScanVulnerabilitiesExecutor) scanNikto(ctx context.Context, fqdn string) []core.VulnFinding {
	bin := e.deps.NiktoBin 
	nctx, cancel := context.WithTimeout(ctx, 90*time.Second)
	defer cancel()
	cmd := exec.CommandContext(nctx, bin, "-host", "https://"+fqdn, "-maxtime", "45s", "-nointeractive", "-ask", "no", "-Tuning", "123bde")
	out, _ := cmd.CombinedOutput()
	var res []core.VulnFinding
	for _, ln := range strings.Split(string(out), "\n") {
		ln = strings.TrimSpace(ln)
		
		if strings.HasPrefix(ln, "+ ") && len(ln) > 8 && !strings.Contains(ln, "Target") && !strings.Contains(ln, "Start Time") {
			res = append(res, finding(fqdn, core.VulnLow, "nikto",
				"Nikto: "+trunc(strings.TrimPrefix(ln, "+ "), 160), ln,
				"Revise a configuração do servidor web conforme o apontamento do Nikto (headers, métodos, arquivos padrão)."))
		}
	}
	return res
}



func (e *ScanVulnerabilitiesExecutor) scanHost(ctx context.Context) []core.VulnFinding {
	var out []core.VulnFinding

	
	if r := hostRun(ctx, "apt-get", "-s", "upgrade"); r != "" {
		n := strings.Count(r, "\nInst ") + boolToInt(strings.HasPrefix(r, "Inst "))
		if n > 0 {
			out = append(out, finding("", core.VulnMedium, "sistema",
				fmt.Sprintf("%d atualização(ões) de pacote pendente(s) no SO", n),
				"Pacotes desatualizados podem ter falhas de segurança conhecidas.",
				"Atualize o sistema pelo menu 'Atualizar SO' (ou 'apt-get update && apt-get upgrade')."))
		}
	}

	
	sshd := readAll("/etc/ssh/sshd_config") + "\n" + readGlob("/etc/ssh/sshd_config.d")
	if directiveOn(sshd, "PermitRootLogin", "yes") {
		out = append(out, finding("", core.VulnHigh, "sistema",
			"Login de root por SSH permitido", "PermitRootLogin yes no sshd_config.",
			"Defina 'PermitRootLogin no' (ou prohibit-password) em /etc/ssh/sshd_config e reinicie o ssh."))
	}
	if directiveOn(sshd, "PasswordAuthentication", "yes") {
		out = append(out, finding("", core.VulnLow, "sistema",
			"Autenticação SSH por senha habilitada", "PasswordAuthentication yes.",
			"Prefira chaves SSH e defina 'PasswordAuthentication no' (necessário 'yes' só para o SFTP por senha dos clientes)."))
	}

	
	if modsec, csf, f2b, _, err := e.deps.Store.SecurityFlags(ctx); err == nil {
		check := func(on bool, nome, remedy string) {
			if !on {
				out = append(out, finding("", core.VulnMedium, "sistema",
					"Proteção desligada: "+nome, "",
					"Ative em Segurança: "+remedy))
			}
		}
		check(modsec, "ModSecurity (WAF)", "liga o firewall de aplicação web.")
		check(csf, "CSF+LFD (firewall)", "liga o firewall + proteção a brute-force.")
		check(f2b, "fail2ban", "bane IPs após tentativas repetidas.")
	}

	
	if fi, err := os.Stat("/etc/wsrta/wsrta.env"); err == nil {
		if fi.Mode().Perm()&0o004 != 0 {
			out = append(out, finding("", core.VulnHigh, "sistema",
				"Arquivo de segredos legível por todos", "/etc/wsrta/wsrta.env com permissão para 'others'.",
				"Restrinja: 'chmod 640 /etc/wsrta/wsrta.env' (grupo wsrta). Ele contém segredos do JWT/DB."))
		}
	}

	if len(out) == 0 {
		out = append(out, finding("", core.VulnInfo, "sistema", "Nenhum problema encontrado no sistema",
			"O scan do painel não encontrou pendências de segurança conhecidas.", ""))
	}
	return out
}



func (e *ScanVulnerabilitiesExecutor) wp(ctx context.Context, container, dir string, args ...string) lxd.ExecResult {
	full := append([]string{"wp", "--allow-root", "--path=" + dir}, args...)
	return e.exec(ctx, container, full...)
}

func (e *ScanVulnerabilitiesExecutor) exec(ctx context.Context, container string, cmd ...string) lxd.ExecResult {
	res, err := e.deps.LXD.Exec(ctx, container, cmd, nil)
	if err != nil {
		return lxd.ExecResult{ExitCode: -1, Stderr: err.Error()}
	}
	return res
}

func finding(fqdn, sev, cat, title, detail, remediation string) core.VulnFinding {
	return core.VulnFinding{FQDN: fqdn, Severity: sev, Category: cat, Title: title, Detail: detail, Remediation: remediation}
}




func checksumMismatch(out string) []string {
	var lines []string
	for _, ln := range strings.Split(out, "\n") {
		l := strings.TrimSpace(ln)
		low := strings.ToLower(l)
		if strings.Contains(low, "doesn't verify against checksum") ||
			strings.Contains(low, "file is missing") ||
			strings.Contains(low, "should not exist") ||
			strings.Contains(low, "file was added") {
			lines = append(lines, l)
		}
	}
	return lines
}

func trunc(s string, n int) string {
	s = strings.TrimSpace(s)
	if len(s) > n {
		return s[:n] + "…"
	}
	return s
}

func firstLine(s string) string {
	for _, ln := range strings.Split(s, "\n") {
		if ln = strings.TrimSpace(ln); ln != "" {
			return ln
		}
	}
	return ""
}

func nonEmptyLines(s string) []string {
	var out []string
	for _, ln := range strings.Split(s, "\n") {
		if ln = strings.TrimSpace(ln); ln != "" {
			out = append(out, ln)
		}
	}
	return out
}


func hostRun(ctx context.Context, name string, args ...string) string {
	cctx, cancel := context.WithTimeout(ctx, 60*time.Second)
	defer cancel()
	cmd := exec.CommandContext(cctx, name, args...)
	cmd.Env = append(os.Environ(), "DEBIAN_FRONTEND=noninteractive")
	out, _ := cmd.CombinedOutput()
	return string(out)
}

func readAll(p string) string {
	b, err := os.ReadFile(p)
	if err != nil {
		return ""
	}
	return string(b)
}

func readGlob(dir string) string {
	ents, err := os.ReadDir(dir)
	if err != nil {
		return ""
	}
	var sb strings.Builder
	for _, en := range ents {
		if !en.IsDir() {
			sb.WriteString(readAll(path.Join(dir, en.Name())))
			sb.WriteString("\n")
		}
	}
	return sb.String()
}


func directiveOn(content, name, value string) bool {
	for _, ln := range strings.Split(content, "\n") {
		ln = strings.TrimSpace(ln)
		if ln == "" || strings.HasPrefix(ln, "#") {
			continue
		}
		fields := strings.Fields(ln)
		if len(fields) >= 2 && strings.EqualFold(fields[0], name) && strings.EqualFold(fields[1], value) {
			return true
		}
	}
	return false
}

func boolToInt(b bool) int {
	if b {
		return 1
	}
	return 0
}
