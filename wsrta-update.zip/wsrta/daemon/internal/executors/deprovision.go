package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/daemon/internal/lxd"
	"github.com/jdobrito/wsrta/internal/core"
)






type DeprovisionClientExecutor struct {
	deps Deps
}


func NewDeprovisionClientExecutor(deps Deps) *DeprovisionClientExecutor {
	return &DeprovisionClientExecutor{deps: deps}
}

func (e *DeprovisionClientExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.DeprovisionClientPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}

	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	name := client.LXCContainerName
	log := e.deps.Log.With(slog.Int64("client_id", client.ID), slog.String("container", name))

	if err := e.deps.Store.SetClientStatus(ctx, client.ID, core.ClientDeprovisioning); err != nil {
		return "", fmt.Errorf("status deprovisioning: %w", err)
	}

	exists, err := e.deps.LXD.Exists(ctx, name)
	if err != nil {
		return "", fmt.Errorf("verificar existência: %w", err)
	}
	if exists {
		info, err := e.deps.LXD.Info(ctx, name)
		if err != nil {
			return "", fmt.Errorf("obter estado: %w", err)
		}
		if info.Status == lxd.StatusRunning {
			if err := e.deps.LXD.Stop(ctx, name); err != nil {
				return "", fmt.Errorf("parar container: %w", err)
			}
		}
		if err := e.deps.LXD.Delete(ctx, name); err != nil {
			return "", fmt.Errorf("remover container: %w", err)
		}
		log.InfoContext(ctx, "container removido")
	} else {
		log.InfoContext(ctx, "container ausente; nada a remover (idempotente)")
	}

	
	if err := e.deps.Store.DeleteClient(ctx, client.ID); err != nil {
		return "", fmt.Errorf("remover cliente: %w", err)
	}
	return fmt.Sprintf("cliente removido (container %q)", name), nil
}
