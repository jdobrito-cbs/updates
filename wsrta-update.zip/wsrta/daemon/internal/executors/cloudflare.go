package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/internal/core"
	"github.com/jdobrito/wsrta/internal/crypto"
)



type SetCloudflareExecutor struct {
	deps Deps
}


func NewSetCloudflareExecutor(deps Deps) *SetCloudflareExecutor {
	return &SetCloudflareExecutor{deps: deps}
}

func (e *SetCloudflareExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.SetCloudflarePayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	container := client.LXCContainerName

	
	token := crypto.Decrypt(p.Token)
	if token == "" {
		return "", fmt.Errorf("token do Cloudflare vazio/indecifrável (WSRTA_SECRETS_KEY ausente ou divergente no daemon?)")
	}
	
	
	_ = runExec(ctx, e.deps.LXD, container, "cloudflared", "service", "uninstall")
	if err := runExec(ctx, e.deps.LXD, container, "cloudflared", "service", "install", token); err != nil {
		return "", fmt.Errorf("instalar cloudflared: %w", err)
	}
	if err := e.deps.Store.SetClientCloudflareStatus(ctx, client.ID, "running"); err != nil {
		return "", fmt.Errorf("salvar status: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "cloudflare tunnel configurado", slog.Int64("client_id", client.ID))
	return "cloudflare tunnel configurado e iniciado", nil
}


type ControlCloudflareExecutor struct {
	deps Deps
}


func NewControlCloudflareExecutor(deps Deps) *ControlCloudflareExecutor {
	return &ControlCloudflareExecutor{deps: deps}
}

func (e *ControlCloudflareExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.ControlCloudflarePayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	if err := runExec(ctx, e.deps.LXD, client.LXCContainerName, "systemctl", p.Op, "cloudflared"); err != nil {
		return "", fmt.Errorf("systemctl %s cloudflared: %w", p.Op, err)
	}
	status := "running"
	if p.Op == "stop" {
		status = "stopped"
	}
	if err := e.deps.Store.SetClientCloudflareStatus(ctx, client.ID, status); err != nil {
		return "", fmt.Errorf("salvar status: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "cloudflared "+p.Op, slog.Int64("client_id", client.ID))
	return fmt.Sprintf("cloudflared %s", p.Op), nil
}
