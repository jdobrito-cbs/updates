package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/daemon/internal/security"
	"github.com/jdobrito/wsrta/internal/core"
)


type SecurityDeps struct {
	Manager security.Manager
	Log     *slog.Logger
}


type ApplySecurityExecutor struct {
	deps SecurityDeps
}


func NewApplySecurityExecutor(deps SecurityDeps) *ApplySecurityExecutor {
	return &ApplySecurityExecutor{deps: deps}
}

func (e *ApplySecurityExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.ApplySecurityPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	summary, err := e.deps.Manager.Apply(ctx, security.Config{
		ModSecurity:  p.ModSecurity,
		CSF:          p.CSF,
		Fail2ban:     p.Fail2ban,
		SSLAutoRenew: p.SSLAutoRenew,
	})
	if err != nil {
		return summary, fmt.Errorf("segurança aplicada parcialmente (%s): %w", summary, err)
	}
	e.deps.Log.InfoContext(ctx, "segurança aplicada", slog.String("resultado", summary))
	return summary, nil
}
