package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/daemon/internal/hostctl"
	"github.com/jdobrito/wsrta/internal/core"
)


type HostDeps struct {
	Manager hostctl.Manager
	Log     *slog.Logger
}


type SystemUpdateExecutor struct{ deps HostDeps }


func NewSystemUpdateExecutor(deps HostDeps) *SystemUpdateExecutor {
	return &SystemUpdateExecutor{deps: deps}
}

func (e *SystemUpdateExecutor) Execute(ctx context.Context, _ *core.Action) (string, error) {
	e.deps.Log.InfoContext(ctx, "system_update: iniciando")
	return e.deps.Manager.SystemUpdate(ctx)
}


type PanelUpdateExecutor struct{ deps HostDeps }


func NewPanelUpdateExecutor(deps HostDeps) *PanelUpdateExecutor {
	return &PanelUpdateExecutor{deps: deps}
}

func (e *PanelUpdateExecutor) Execute(ctx context.Context, _ *core.Action) (string, error) {
	e.deps.Log.InfoContext(ctx, "panel_update: iniciando")
	return e.deps.Manager.PanelUpdate(ctx)
}


type RestartServiceExecutor struct{ deps HostDeps }


func NewRestartServiceExecutor(deps HostDeps) *RestartServiceExecutor {
	return &RestartServiceExecutor{deps: deps}
}

func (e *RestartServiceExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.RestartServicePayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	
	if err := p.Validate(); err != nil {
		return "", err
	}
	if err := e.deps.Manager.RestartService(ctx, p.Service); err != nil {
		return "", fmt.Errorf("reiniciar %s: %w", p.Service, err)
	}
	e.deps.Log.InfoContext(ctx, "restart_service", slog.String("service", p.Service))
	return "serviço " + p.Service + " reiniciado", nil
}
