package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"

	"github.com/jdobrito/wsrta/internal/core"
)




type ApplyLimitsExecutor struct {
	deps Deps
}


func NewApplyLimitsExecutor(deps Deps) *ApplyLimitsExecutor {
	return &ApplyLimitsExecutor{deps: deps}
}

func (e *ApplyLimitsExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.ApplyLimitsPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	name := client.LXCContainerName
	exists, err := e.deps.LXD.Exists(ctx, name)
	if err != nil {
		return "", fmt.Errorf("verificar container: %w", err)
	}
	if !exists {
		
		
		return fmt.Sprintf("container %q ainda não existe; limites aplicados no provisionamento", name), nil
	}
	if err := e.deps.LXD.SetLimits(ctx, name, p.CPULimit, p.RAMLimitMB, p.DiskQuotaMB); err != nil {
		return "", fmt.Errorf("aplicar limites: %w", err)
	}
	e.deps.Log.InfoContext(ctx, "limites aplicados", slog.Int64("client_id", client.ID),
		slog.Float64("cpu", p.CPULimit), slog.Int("ram_mb", p.RAMLimitMB), slog.Int("disk_mb", p.DiskQuotaMB))
	return fmt.Sprintf("limites aplicados em %s (cpu=%v ram=%dMB disco=%dMB)", name, p.CPULimit, p.RAMLimitMB, p.DiskQuotaMB), nil
}
