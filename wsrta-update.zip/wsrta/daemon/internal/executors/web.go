package executors

import (
	"context"
	"fmt"
	"log/slog"
	"path"
	"strings"

	"github.com/jdobrito/wsrta/daemon/internal/acme"
	"github.com/jdobrito/wsrta/daemon/internal/lxd"
	"github.com/jdobrito/wsrta/daemon/internal/nginx"
	"github.com/jdobrito/wsrta/internal/core"
)


type WebDeps struct {
	LXD          lxd.Client
	Nginx        nginx.Manager
	Acme         acme.Issuer
	Domains      DomainStore
	Log          *slog.Logger
	DocrootBase  string           
	ACMEWebroot  string           
	UpstreamPort int              
	Progress     ProgressReporter 
}



func runExec(ctx context.Context, c lxd.Client, name string, cmd ...string) error {
	res, err := c.Exec(ctx, name, cmd, nil)
	if err != nil {
		return err
	}
	if res.ExitCode != 0 {
		return fmt.Errorf("comando %v falhou (rc=%d): %s", cmd, res.ExitCode, res.Stderr)
	}
	return nil
}




func (d WebDeps) docrootFor(dom *core.Domain) string {
	base := path.Clean(d.DocrootBase)
	if dom.Docroot != "" {
		clean := path.Clean(dom.Docroot)
		if clean == base || strings.HasPrefix(clean, base+"/") {
			return clean
		}
	}
	return path.Join(base, dom.FQDN)
}


func internalVHostPath(fqdn string) string {
	return "/etc/nginx/sites-enabled/" + fqdn + ".conf"
}


func phpSocket(phpVersion string) string {
	if phpVersion == "" {
		return "/run/php/php-fpm.sock"
	}
	return fmt.Sprintf("/run/php/php%s-fpm.sock", phpVersion)
}






func (d WebDeps) resolvePHPSocket(ctx context.Context, container, phpVersion string) string {
	want := phpSocket(phpVersion)
	if res, err := d.LXD.Exec(ctx, container, []string{"test", "-S", want}, nil); err == nil && res.ExitCode == 0 {
		return want
	}
	
	if res, err := d.LXD.Exec(ctx, container, []string{"ls", "/run/php/"}, nil); err == nil {
		for _, name := range strings.Fields(res.Stdout) {
			if strings.HasPrefix(name, "php") && strings.HasSuffix(name, "-fpm.sock") {
				return "/run/php/" + name
			}
		}
	}
	return want
}
