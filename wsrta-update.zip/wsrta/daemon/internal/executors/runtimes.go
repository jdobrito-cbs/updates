package executors

import (
	"context"
	"encoding/json"
	"fmt"
	"log/slog"
	"strings"

	"github.com/jdobrito/wsrta/internal/core"
)




type SetRuntimesExecutor struct {
	deps Deps
}


func NewSetRuntimesExecutor(deps Deps) *SetRuntimesExecutor {
	return &SetRuntimesExecutor{deps: deps}
}

func (e *SetRuntimesExecutor) Execute(ctx context.Context, a *core.Action) (string, error) {
	var p core.SetRuntimesPayload
	if err := json.Unmarshal(a.Payload, &p); err != nil {
		return "", fmt.Errorf("payload inválido: %w", err)
	}
	if err := p.Validate(); err != nil {
		return "", err
	}
	client, err := e.deps.Store.GetClient(ctx, p.ClientID)
	if err != nil {
		return "", fmt.Errorf("buscar client %d: %w", p.ClientID, err)
	}
	container := client.LXCContainerName
	log := e.deps.Log.With(slog.String("container", container))

	if len(p.Runtimes) == 0 {
		return "nenhum runtime liberado", nil
	}
	if err := runExec(ctx, e.deps.LXD, container, "apt-get", "update"); err != nil {
		log.WarnContext(ctx, "apt-get update falhou (continuando)", slog.Any("err", err))
	}
	var installed []string
	for _, key := range p.Runtimes {
		rt := core.RuntimeByKey(key)
		if rt == nil {
			continue
		}
		
		args := append([]string{"env", "DEBIAN_FRONTEND=noninteractive", "apt-get", "install", "-y", "--no-install-recommends"}, rt.Packages...)
		if err := runExec(ctx, e.deps.LXD, container, args...); err != nil {
			log.WarnContext(ctx, "falha ao instalar runtime (continuando)", slog.String("runtime", key), slog.Any("err", err))
			continue
		}
		installed = append(installed, rt.Label)
	}
	if len(installed) == 0 {
		return "", fmt.Errorf("nenhum runtime instalado (ver logs)")
	}
	return fmt.Sprintf("runtimes liberados: %s", strings.Join(installed, ", ")), nil
}
