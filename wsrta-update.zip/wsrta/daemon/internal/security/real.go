package security

import (
	"context"
	"fmt"
	"log/slog"
	"os"
	"os/exec"
	"regexp"
	"strconv"
	"strings"
)



var ifaceNameRe = regexp.MustCompile(`^[a-zA-Z0-9._-]{1,15}$`)


var portRe = regexp.MustCompile(`^[1-9][0-9]{0,4}$`)





type Real struct {
	log    *slog.Logger
	acmeSh string 
}


func NewReal(log *slog.Logger, acmeSh string) *Real {
	if acmeSh == "" {
		acmeSh = "/root/.acme.sh/acme.sh"
	}
	return &Real{log: log, acmeSh: acmeSh}
}


func (r *Real) Apply(ctx context.Context, c Config) (string, error) {
	var b strings.Builder
	var firstErr error
	step := func(name string, err error) {
		if err != nil {
			if firstErr == nil {
				firstErr = err
			}
			fmt.Fprintf(&b, "%s=ERRO; ", name)
			r.log.WarnContext(ctx, "security: passo falhou", slog.String("servico", name), slog.Any("err", err))
		} else {
			fmt.Fprintf(&b, "%s=ok; ", name)
		}
	}
	step("modsecurity", r.applyModSecurity(ctx, c.ModSecurity))
	step("csf", r.applyCSF(ctx, c.CSF))
	step("fail2ban", r.applyFail2ban(ctx, c.Fail2ban))
	step("ssl_autorenew", r.applySSLAutoRenew(ctx, c.SSLAutoRenew))
	return strings.TrimSpace(b.String()), firstErr
}


func (r *Real) run(ctx context.Context, dir, name string, args ...string) error {
	cmd := exec.CommandContext(ctx, name, args...)
	if dir != "" {
		cmd.Dir = dir
	}
	cmd.Env = append(os.Environ(), "DEBIAN_FRONTEND=noninteractive")
	out, err := cmd.CombinedOutput()
	if err != nil {
		return fmt.Errorf("%s: %w: %s", name, err, strings.TrimSpace(string(out)))
	}
	return nil
}

func (r *Real) reloadNginx(ctx context.Context) error {
	if err := r.run(ctx, "", "nginx", "-t"); err != nil {
		return err
	}
	return r.run(ctx, "", "nginx", "-s", "reload")
}


func (r *Real) applyFail2ban(ctx context.Context, on bool) error {
	if !on {
		return r.run(ctx, "", "systemctl", "disable", "--now", "fail2ban")
	}
	if _, err := exec.LookPath("fail2ban-client"); err != nil {
		if err := r.run(ctx, "", "apt-get", "install", "-y", "fail2ban"); err != nil {
			return err
		}
	}
	return r.run(ctx, "", "systemctl", "enable", "--now", "fail2ban")
}


func (r *Real) applyCSF(ctx context.Context, on bool) error {
	if !on {
		if _, err := exec.LookPath("csf"); err != nil {
			return nil 
		}
		return r.run(ctx, "", "csf", "-x") 
	}
	if _, err := exec.LookPath("csf"); err != nil {
		if err := r.installCSF(ctx); err != nil {
			return err
		}
	}
	
	_ = r.run(ctx, "", "ufw", "--force", "disable")
	
	
	
	if err := writeCSFPost(); err != nil {
		r.log.WarnContext(ctx, "csf: não consegui escrever o csfpost.sh (SSH/painel/bridge)", slog.Any("err", err))
	}
	
	
	
	
	_ = r.run(ctx, "", "sed", "-i", "-E", `s/^TESTING[[:space:]]*=[[:space:]]*"1"/TESTING = "0"/`, "/etc/csf/csf.conf")
	if err := r.run(ctx, "", "csf", "-e"); err != nil { 
		return err
	}
	return r.run(ctx, "", "csf", "-r") 
}






func writeCSFPost() error {
	br := os.Getenv("WSRTA_LXD_NETWORK")
	if !ifaceNameRe.MatchString(br) {
		br = "lxdbr0"
	}
	panel := os.Getenv("WSRTA_PANEL_PORT")
	if !portRe.MatchString(panel) {
		panel = "8443"
	}
	
	
	sftpBase := os.Getenv("WSRTA_SFTP_BASE_PORT")
	if !portRe.MatchString(sftpBase) {
		sftpBase = "30000"
	}
	base, _ := strconv.Atoi(sftpBase)
	sftpRange := fmt.Sprintf("%d:%d", base, base+999) 
	script := "#!/bin/sh\n" +
		"# WSRTA (gerado por apply_security): garante SSH + painel + SFTP + bridge do LXD. NÃO editar.\n" +
		"BR=" + br + "\n" +
		"PANEL=" + panel + "\n" +
		"for p in 22 80 443 \"$PANEL\"; do\n" +
		"  iptables -I INPUT -p tcp --dport \"$p\" -j ACCEPT 2>/dev/null\n" +
		"done\n" +
		"iptables -I INPUT -p tcp --dport " + sftpRange + " -j ACCEPT 2>/dev/null\n" +
		"iptables  -I INPUT   -i \"$BR\" -j ACCEPT 2>/dev/null\n" +
		"iptables  -I FORWARD -i \"$BR\" -j ACCEPT 2>/dev/null\n" +
		"iptables  -I FORWARD -o \"$BR\" -j ACCEPT 2>/dev/null\n" +
		"ip6tables -I INPUT   -i \"$BR\" -j ACCEPT 2>/dev/null\n" +
		"ip6tables -I FORWARD -i \"$BR\" -j ACCEPT 2>/dev/null\n" +
		"ip6tables -I FORWARD -o \"$BR\" -j ACCEPT 2>/dev/null\n"
	return os.WriteFile("/etc/csf/csfpost.sh", []byte(script), 0o700)
}

func (r *Real) installCSF(ctx context.Context) error {
	
	_ = r.run(ctx, "", "apt-get", "update")
	_ = r.run(ctx, "", "apt-get", "install", "-y", "perl", "libwww-perl", "libio-socket-ssl-perl", "libcrypt-ssleay-perl", "unzip")
	
	if err := r.run(ctx, "", "wget", "-q", "-O", "/usr/src/csf.tgz", "https://download.configserver.com/csf.tgz"); err != nil {
		if err2 := r.run(ctx, "", "curl", "-fsSL", "-o", "/usr/src/csf.tgz", "https://download.configserver.com/csf.tgz"); err2 != nil {
			return fmt.Errorf("baixar csf (wget e curl falharam; verifique a rede/saída do host): %w", err)
		}
	}
	if err := r.run(ctx, "/usr/src", "tar", "-xzf", "csf.tgz"); err != nil {
		return err
	}
	
	return r.run(ctx, "/usr/src/csf", "sh", "install.sh")
}




func (r *Real) applyModSecurity(ctx context.Context, on bool) error {
	const dir = "/etc/nginx/modsecurity"
	const incl = "/etc/nginx/conf.d/wsrta-modsecurity.conf"
	if !on {
		_ = os.Remove(incl)
		return r.reloadNginx(ctx)
	}
	if err := r.run(ctx, "", "apt-get", "install", "-y", "libnginx-mod-http-modsecurity"); err != nil {
		return err
	}
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return err
	}
	
	
	
	if err := os.WriteFile(dir+"/main.conf", []byte("SecRuleEngine On\nSecRequestBodyAccess On\nSecResponseBodyAccess Off\n"), 0o644); err != nil {
		return err
	}
	body := "modsecurity on;\nmodsecurity_rules_file " + dir + "/main.conf;\n"
	if err := os.WriteFile(incl, []byte(body), 0o644); err != nil {
		return err
	}
	
	
	
	
	if err := r.run(ctx, "", "nginx", "-t"); err != nil {
		_ = os.Remove(incl)
		return fmt.Errorf("modsecurity não carregou; include revertido (o WAF não subiu): %w", err)
	}
	return r.run(ctx, "", "nginx", "-s", "reload")
}


func (r *Real) applySSLAutoRenew(ctx context.Context, on bool) error {
	
	
	
	if _, err := os.Stat(r.acmeSh); err != nil {
		r.log.WarnContext(ctx, "acme.sh não encontrado; renovação automática de SSL ignorada", slog.String("path", r.acmeSh))
		return nil
	}
	if on {
		return r.run(ctx, "", r.acmeSh, "--install-cronjob")
	}
	return r.run(ctx, "", r.acmeSh, "--uninstall-cronjob")
}
