package security

import (
	"context"
	"fmt"
)


type Fake struct{}


func NewFake() *Fake { return &Fake{} }


func (f *Fake) Apply(_ context.Context, c Config) (string, error) {
	return fmt.Sprintf("fake: modsecurity=%v csf=%v fail2ban=%v ssl_autorenew=%v",
		c.ModSecurity, c.CSF, c.Fail2ban, c.SSLAutoRenew), nil
}
