


package security

import "context"


type Config struct {
	ModSecurity  bool
	CSF          bool
	Fail2ban     bool
	SSLAutoRenew bool
}


type Manager interface {
	Apply(ctx context.Context, c Config) (string, error)
}
