


package seccollect

import (
	"bufio"
	"context"
	"log/slog"
	"os"
	"regexp"
	"strings"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)


type Collector struct {
	pool     *pgxpool.Pool
	log      *slog.Logger
	interval time.Duration
	sources  []*source
}

type source struct {
	path   string
	kind   string 
	offset int64  
}

func envOr(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}


func New(pool *pgxpool.Pool, log *slog.Logger) *Collector {
	return &Collector{
		pool: pool, log: log, interval: time.Minute,
		sources: []*source{
			{path: envOr("WSRTA_AUTH_LOG", "/var/log/auth.log"), kind: "ssh"},
			{path: envOr("WSRTA_NGINX_ERROR_LOG", "/var/log/nginx/error.log"), kind: "waf"},
		},
	}
}



func (c *Collector) Run(ctx context.Context) {
	for _, s := range c.sources {
		if fi, err := os.Stat(s.path); err == nil {
			s.offset = fi.Size()
		}
	}
	t := time.NewTicker(c.interval)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			for _, s := range c.sources {
				c.tick(ctx, s)
			}
		}
	}
}


const maxLinesPerTick = 300

func (c *Collector) tick(ctx context.Context, s *source) {
	fi, err := os.Stat(s.path)
	if err != nil {
		return 
	}
	size := fi.Size()
	if size < s.offset {
		s.offset = 0 
	}
	if size == s.offset {
		return
	}
	f, err := os.Open(s.path)
	if err != nil {
		return
	}
	defer f.Close()
	if _, err := f.Seek(s.offset, 0); err != nil {
		return
	}
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 64*1024), 1024*1024)
	n := 0
	for sc.Scan() && n < maxLinesPerTick {
		if ev, ok := parseLine(s.kind, sc.Text()); ok {
			c.insert(ctx, ev)
			n++
		}
	}
	s.offset = size
}

type event struct{ eventType, severity, ip, email, detail string }

var (
	ipPat        = `((?:\d{1,3}\.){3}\d{1,3}|[0-9a-fA-F:]+)`
	sshFailRe    = regexp.MustCompile(`Failed password for (?:invalid user )?(\S+) from ` + ipPat)
	sshInvalidRe = regexp.MustCompile(`Invalid user (\S+) from ` + ipPat)
	wafClientRe  = regexp.MustCompile(`\[client ` + ipPat + `\]|client: ` + ipPat)
	wafMsgRe     = regexp.MustCompile(`\[msg "([^"]{0,200})"\]`)
)

func parseLine(kind, line string) (event, bool) {
	switch kind {
	case "ssh":
		if m := sshFailRe.FindStringSubmatch(line); m != nil {
			return event{"ssh_failed", "low", m[2], m[1], "falha de senha no SSH"}, true
		}
		if m := sshInvalidRe.FindStringSubmatch(line); m != nil {
			return event{"ssh_failed", "low", m[2], m[1], "usuário SSH inexistente"}, true
		}
	case "waf":
		if !strings.Contains(line, "ModSecurity") {
			return event{}, false
		}
		ip := ""
		if m := wafClientRe.FindStringSubmatch(line); m != nil {
			ip = firstNonEmpty(m[1], m[2])
		}
		detail := "requisição bloqueada pelo WAF (ModSecurity)"
		if mm := wafMsgRe.FindStringSubmatch(line); mm != nil {
			detail = "WAF: " + mm[1]
		}
		return event{"waf_block", "medium", ip, "", detail}, true
	}
	return event{}, false
}

func firstNonEmpty(a, b string) string {
	if a != "" {
		return a
	}
	return b
}

func (c *Collector) insert(ctx context.Context, ev event) {
	san := func(x string) string {
		x = strings.ToValidUTF8(x, "")
		if len(x) > 500 {
			x = x[:500]
		}
		return x
	}
	_, err := c.pool.Exec(ctx,
		`INSERT INTO security_events (event_type, severity, ip, email, user_agent, detail, blocked)
		 VALUES ($1, $2, $3, $4, '', $5, false)`,
		ev.eventType, ev.severity, san(ev.ip), san(ev.email), san(ev.detail))
	if err != nil {
		c.log.WarnContext(ctx, "seccollect: gravar evento", slog.Any("err", err))
	}
}
