package hostctl

import (
	"archive/zip"
	"context"
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
)






const updateSigningPubKey = "Juerdlmv5fPiQADekor9SSze6sMhPCQv6IvWNcon0v0="



func verifyUpdateSignature(ctx context.Context, zipURL, zipPath string) error {
	pubB64 := strings.TrimSpace(os.Getenv("WSRTA_UPDATE_PUBKEY"))
	if pubB64 == "" {
		pubB64 = updateSigningPubKey
	}
	pub, err := base64.StdEncoding.DecodeString(pubB64)
	if err != nil || len(pub) != ed25519.PublicKeySize {
		return errors.New("chave pública de update inválida/ausente")
	}
	sigPath := zipPath + ".sig"
	if err := downloadTo(ctx, zipURL+".sig", sigPath); err != nil {
		return fmt.Errorf("baixar assinatura (.sig ausente no repo de updates?): %w", err)
	}
	sigB64, err := os.ReadFile(sigPath)
	if err != nil {
		return err
	}
	sig, err := base64.StdEncoding.DecodeString(strings.TrimSpace(string(sigB64)))
	if err != nil {
		return fmt.Errorf("assinatura mal-formada: %w", err)
	}
	zipBytes, err := os.ReadFile(zipPath)
	if err != nil {
		return err
	}
	if !ed25519.Verify(ed25519.PublicKey(pub), zipBytes, sig) {
		return errors.New("assinatura NÃO confere com a chave pública embarcada")
	}
	return nil
}


type Real struct {
	repoDir    string 
	updateRepo string 
}


func NewReal(repoDir, updateRepo string) *Real {
	return &Real{repoDir: repoDir, updateRepo: updateRepo}
}


func (r *Real) run(ctx context.Context, dir, name string, args ...string) (string, error) {
	cmd := exec.CommandContext(ctx, name, args...)
	if dir != "" {
		cmd.Dir = dir
	}
	cmd.Env = append(os.Environ(), "DEBIAN_FRONTEND=noninteractive")
	out, err := cmd.CombinedOutput()
	if err != nil {
		return string(out), fmt.Errorf("%s: %w: %s", name, err, strings.TrimSpace(string(out)))
	}
	return string(out), nil
}



func (r *Real) SystemUpdate(ctx context.Context) (string, error) {
	upd, err := r.run(ctx, "", "apt-get", "update")
	if err != nil {
		return "", err
	}
	upg, err := r.run(ctx, "", "apt-get", "-y", "upgrade")
	if err != nil {
		return "", err
	}
	return lastBytes("$ apt-get update\n"+upd+"\n$ apt-get -y upgrade\n"+upg, 8000), nil
}




func lastBytes(s string, n int) string {
	s = strings.TrimSpace(s)
	if len(s) > n {
		s = "…(truncado)\n" + s[len(s)-n:]
	}
	return strings.ToValidUTF8(s, "")
}




func (r *Real) PanelUpdate(ctx context.Context) (string, error) {
	name, url, err := r.latestUpdateZip(ctx)
	if err != nil {
		if r.repoDir != "" {
			if _, e := os.Stat(filepath.Join(r.repoDir, "scripts", "update.sh")); e == nil {
				if _, e2 := r.run(ctx, r.repoDir, "bash", filepath.Join(r.repoDir, "scripts", "update.sh")); e2 != nil {
					return "", e2
				}
				return "painel atualizado (update.sh local; GitHub indisponível: " + err.Error() + ")", nil
			}
		}
		return "", err
	}

	tmp, err := os.MkdirTemp("", "wsrta-update-")
	if err != nil {
		return "", err
	}
	defer os.RemoveAll(tmp)

	zipPath := filepath.Join(tmp, name)
	if err := downloadTo(ctx, url, zipPath); err != nil {
		return "", fmt.Errorf("baixar %s: %w", name, err)
	}
	
	
	if err := verifyUpdateSignature(ctx, url, zipPath); err != nil {
		return "", fmt.Errorf("update REJEITADO: %w", err)
	}
	if err := unzipInto(zipPath, tmp); err != nil {
		return "", fmt.Errorf("extrair %s: %w", name, err)
	}
	repo := filepath.Join(tmp, "wsrta")
	
	
	
	if r.repoDir != "" {
		newVer := strings.TrimSpace(readFileOr(filepath.Join(repo, "VERSION")))
		curVer := strings.TrimSpace(readFileOr(filepath.Join(r.repoDir, "VERSION")))
		if newVer != "" && curVer != "" && !versionAtLeast(newVer, curVer) {
			return "", fmt.Errorf("update REJEITADO: versão %s é ANTERIOR à instalada %s (anti-rollback)", newVer, curVer)
		}
	}
	script := filepath.Join(repo, "scripts", "update.sh")
	if _, err := os.Stat(script); err != nil {
		return "", fmt.Errorf("update.sh ausente no pacote %s", name)
	}
	if _, err := r.run(ctx, repo, "bash", script); err != nil {
		return "", err
	}
	return "painel atualizado a partir de " + name + " (GitHub)", nil
}




func (r *Real) latestUpdateZip(ctx context.Context) (name, downloadURL string, err error) {
	if r.updateRepo == "" {
		return "", "", errors.New("WSRTA_UPDATE_REPO não configurado")
	}
	api := "https://api.github.com/repos/" + r.updateRepo + "/contents"
	req, _ := http.NewRequestWithContext(ctx, http.MethodGet, api, nil)
	req.Header.Set("Accept", "application/vnd.github+json")
	req.Header.Set("User-Agent", "wsrta-updater")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return "", "", err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		b, _ := io.ReadAll(io.LimitReader(resp.Body, 512))
		return "", "", fmt.Errorf("GitHub API %d: %s", resp.StatusCode, strings.TrimSpace(string(b)))
	}
	var items []struct {
		Name        string `json:"name"`
		DownloadURL string `json:"download_url"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&items); err != nil {
		return "", "", err
	}
	for _, it := range items {
		if strings.HasPrefix(it.Name, "wsrta-") && strings.HasSuffix(it.Name, "-update.zip") && it.Name > name {
			name, downloadURL = it.Name, it.DownloadURL
		}
	}
	if name == "" {
		return "", "", errors.New("nenhum wsrta*-update.zip encontrado no repo de updates")
	}
	return name, downloadURL, nil
}

func readFileOr(p string) string {
	b, err := os.ReadFile(p)
	if err != nil {
		return ""
	}
	return string(b)
}


func versionAtLeast(a, b string) bool {
	pa, pb := parseVer(a), parseVer(b)
	for i := 0; i < 3; i++ {
		if pa[i] != pb[i] {
			return pa[i] > pb[i]
		}
	}
	return true 
}

func parseVer(s string) [3]int {
	var v [3]int
	for i, p := range strings.SplitN(strings.TrimSpace(s), ".", 3) {
		if i >= 3 {
			break
		}
		n, _ := strconv.Atoi(strings.TrimSpace(p))
		v[i] = n
	}
	return v
}

func downloadTo(ctx context.Context, url, dest string) error {
	req, _ := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	req.Header.Set("User-Agent", "wsrta-updater")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	f, err := os.Create(dest)
	if err != nil {
		return err
	}
	defer f.Close()
	_, err = io.Copy(f, resp.Body)
	return err
}


func unzipInto(zipPath, destDir string) error {
	zr, err := zip.OpenReader(zipPath)
	if err != nil {
		return err
	}
	defer zr.Close()
	root := filepath.Clean(destDir) + string(os.PathSeparator)
	for _, f := range zr.File {
		target := filepath.Join(destDir, f.Name)
		if !strings.HasPrefix(target, root) {
			return fmt.Errorf("caminho inválido no zip: %s", f.Name)
		}
		if f.FileInfo().IsDir() {
			if err := os.MkdirAll(target, 0o755); err != nil {
				return err
			}
			continue
		}
		if err := os.MkdirAll(filepath.Dir(target), 0o755); err != nil {
			return err
		}
		rc, err := f.Open()
		if err != nil {
			return err
		}
		out, err := os.OpenFile(target, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0o644)
		if err != nil {
			rc.Close()
			return err
		}
		_, copyErr := io.Copy(out, rc)
		out.Close()
		rc.Close()
		if copyErr != nil {
			return copyErr
		}
	}
	return nil
}


func (r *Real) RestartService(ctx context.Context, unit string) error {
	_, err := r.run(ctx, "", "systemctl", "restart", unit)
	return err
}
