


package hostctl

import "context"


type Manager interface {
	SystemUpdate(ctx context.Context) (string, error)
	PanelUpdate(ctx context.Context) (string, error)
	RestartService(ctx context.Context, unit string) error
}
