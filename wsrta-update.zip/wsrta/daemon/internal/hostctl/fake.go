package hostctl

import (
	"context"
	"log/slog"
)


type Fake struct{ log *slog.Logger }


func NewFake(log *slog.Logger) *Fake { return &Fake{log: log} }

func (f *Fake) SystemUpdate(ctx context.Context) (string, error) {
	f.log.InfoContext(ctx, "hostctl fake: system_update")
	return "fake: pacotes do SO atualizados (no-op em dev)", nil
}

func (f *Fake) PanelUpdate(ctx context.Context) (string, error) {
	f.log.InfoContext(ctx, "hostctl fake: panel_update")
	return "fake: painel atualizado (no-op em dev)", nil
}

func (f *Fake) RestartService(ctx context.Context, unit string) error {
	f.log.InfoContext(ctx, "hostctl fake: restart", slog.String("unit", unit))
	return nil
}
