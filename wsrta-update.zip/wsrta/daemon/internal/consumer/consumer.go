
package consumer

import (
	"context"
	"errors"
	"log/slog"
	"time"

	"github.com/jdobrito/wsrta/daemon/internal/executors"
	"github.com/jdobrito/wsrta/internal/core"
	"github.com/jdobrito/wsrta/internal/queue"
)


type Consumer struct {
	q        *queue.Queue
	registry *executors.Registry
	log      *slog.Logger
	poll     time.Duration
}


func New(q *queue.Queue, r *executors.Registry, log *slog.Logger) *Consumer {
	return &Consumer{q: q, registry: r, log: log, poll: time.Second}
}






func (c *Consumer) Run(ctx context.Context, nudges <-chan struct{}) error {
	ticker := time.NewTicker(c.poll)
	defer ticker.Stop()

	for {
		c.drain(ctx)

		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-ticker.C:
		case <-nudges:
		}
	}
}


func (c *Consumer) drain(ctx context.Context) {
	for {
		if ctx.Err() != nil {
			return
		}
		a, err := c.q.Claim(ctx)
		if errors.Is(err, queue.ErrNoPending) {
			return
		}
		if err != nil {
			c.log.ErrorContext(ctx, "falha ao reivindicar ação", slog.Any("err", err))
			return
		}
		c.process(ctx, a)
	}
}


func (c *Consumer) process(ctx context.Context, a *core.Action) {
	log := c.log.With(slog.Int64("action_id", a.ID), slog.String("type", string(a.Type)))

	exec, ok := c.registry.Get(a.Type)
	if !ok {
		log.ErrorContext(ctx, "nenhum executor registrado para o tipo")
		_ = c.q.MarkFailed(ctx, a.ID, "tipo de ação desconhecido: "+string(a.Type))
		return
	}

	log.InfoContext(ctx, "processando ação")
	result, err := exec.Execute(ctx, a)
	if err != nil {
		log.ErrorContext(ctx, "ação falhou", slog.Any("err", err))
		_ = c.q.MarkFailed(ctx, a.ID, err.Error())
		return
	}

	if err := c.q.MarkDone(ctx, a.ID, result); err != nil {
		log.ErrorContext(ctx, "falha ao marcar ação como concluída", slog.Any("err", err))
		return
	}
	log.InfoContext(ctx, "ação concluída")
}
