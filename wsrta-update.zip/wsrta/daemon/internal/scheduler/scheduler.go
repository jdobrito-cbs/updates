

package scheduler

import (
	"context"
	"log/slog"
	"time"

	"github.com/jdobrito/wsrta/daemon/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
	"github.com/jdobrito/wsrta/internal/queue"
)


type Scheduler struct {
	store    *store.Backups
	q        *queue.Queue
	sock     string
	log      *slog.Logger
	interval time.Duration
}


func New(st *store.Backups, q *queue.Queue, sock string, log *slog.Logger, interval time.Duration) *Scheduler {
	if interval <= 0 {
		interval = 30 * time.Minute
	}
	return &Scheduler{store: st, q: q, sock: sock, log: log, interval: interval}
}


func (s *Scheduler) Run(ctx context.Context) {
	t := time.NewTicker(s.interval)
	defer t.Stop()
	s.tick(ctx)
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			s.tick(ctx)
		}
	}
}

func (s *Scheduler) tick(ctx context.Context) {
	clients, err := s.store.ListScheduledBackups(ctx)
	if err != nil {
		s.log.ErrorContext(ctx, "agendador: listar clientes", slog.Any("err", err))
		return
	}
	now := time.Now()
	for _, c := range clients {
		if !due(c.Schedule, c.LastBackup, now) {
			continue
		}
		id, err := s.store.CreateBackup(ctx, c.ClientID, "agendado")
		if err != nil {
			s.log.WarnContext(ctx, "agendador: criar backup", slog.Int64("client_id", c.ClientID), slog.Any("err", err))
			continue
		}
		if _, err := s.q.Enqueue(ctx, core.ActionBackupClient,
			core.BackupClientPayload{ClientID: c.ClientID, BackupID: id}, nil); err != nil {
			s.log.WarnContext(ctx, "agendador: enfileirar backup", slog.Int64("client_id", c.ClientID), slog.Any("err", err))
			continue
		}
		queue.Nudge(s.sock)
		s.log.InfoContext(ctx, "backup agendado enfileirado",
			slog.Int64("client_id", c.ClientID), slog.String("schedule", c.Schedule))
	}
}


func due(schedule string, last *time.Time, now time.Time) bool {
	var interval time.Duration
	switch schedule {
	case "daily":
		interval = 24 * time.Hour
	case "weekly":
		interval = 7 * 24 * time.Hour
	default:
		return false
	}
	if last == nil {
		return true
	}
	return now.Sub(*last) >= interval
}
