package scheduler

import (
	"context"
	"log/slog"
	"time"

	"github.com/jdobrito/wsrta/daemon/internal/store"
	"github.com/jdobrito/wsrta/internal/core"
	"github.com/jdobrito/wsrta/internal/queue"
)


type VulnScheduler struct {
	store    *store.Vuln
	q        *queue.Queue
	sock     string
	log      *slog.Logger
	interval time.Duration
}


func NewVuln(st *store.Vuln, q *queue.Queue, sock string, log *slog.Logger, interval time.Duration) *VulnScheduler {
	if interval <= 0 {
		interval = 6 * time.Hour
	}
	return &VulnScheduler{store: st, q: q, sock: sock, log: log, interval: interval}
}


func (s *VulnScheduler) Run(ctx context.Context) {
	t := time.NewTicker(s.interval)
	defer t.Stop()
	s.tick(ctx)
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			s.tick(ctx)
		}
	}
}

func (s *VulnScheduler) tick(ctx context.Context) {
	clients, err := s.store.ListScheduled(ctx)
	if err != nil {
		s.log.ErrorContext(ctx, "agendador de scans: listar clientes", slog.Any("err", err))
		return
	}
	now := time.Now()
	for _, c := range clients {
		if !due(c.Schedule, c.LastScan, now) { 
			continue
		}
		id, err := s.store.CreateScan(ctx, c.ClientID)
		if err != nil {
			s.log.WarnContext(ctx, "agendador de scans: criar scan", slog.Int64("client_id", c.ClientID), slog.Any("err", err))
			continue
		}
		if _, err := s.q.Enqueue(ctx, core.ActionScanVulnerabilities,
			core.ScanVulnerabilitiesPayload{ClientID: c.ClientID, ScanID: id}, nil); err != nil {
			s.log.WarnContext(ctx, "agendador de scans: enfileirar", slog.Int64("client_id", c.ClientID), slog.Any("err", err))
			continue
		}
		queue.Nudge(s.sock)
		s.log.InfoContext(ctx, "scan agendado enfileirado",
			slog.Int64("client_id", c.ClientID), slog.String("schedule", c.Schedule))
	}
}
