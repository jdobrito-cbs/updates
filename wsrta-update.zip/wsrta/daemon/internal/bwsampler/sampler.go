

package bwsampler

import (
	"context"
	"log/slog"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/jdobrito/wsrta/daemon/internal/lxd"
)


type Sampler struct {
	pool *pgxpool.Pool
	lxd  lxd.Client
	log  *slog.Logger
	prev map[string][2]int64 
}


func New(pool *pgxpool.Pool, l lxd.Client, log *slog.Logger) *Sampler {
	return &Sampler{pool: pool, lxd: l, log: log, prev: map[string][2]int64{}}
}


func (s *Sampler) Run(ctx context.Context) {
	t := time.NewTicker(60 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			s.tick(ctx)
		}
	}
}

type clientRow struct {
	id        int64
	container string
	limitMB   int64
}

func (s *Sampler) tick(ctx context.Context) {
	rows, err := s.pool.Query(ctx,
		`SELECT id, lxc_container_name, bandwidth_limit_mb FROM clients WHERE status = 'active'`)
	if err != nil {
		s.log.Error("bwsampler: listar clientes", slog.Any("err", err))
		return
	}
	var clients []clientRow
	for rows.Next() {
		var c clientRow
		if err := rows.Scan(&c.id, &c.container, &c.limitMB); err == nil {
			clients = append(clients, c)
		}
	}
	rows.Close()

	for _, c := range clients {
		rx, tx, err := s.lxd.NetUsage(ctx, c.container)
		if err != nil {
			continue 
		}
		prev, seen := s.prev[c.container]
		s.prev[c.container] = [2]int64{rx, tx}
		if !seen {
			continue 
		}
		drx, dtx := rx-prev[0], tx-prev[1]
		if drx < 0 { 
			drx = rx
		}
		if dtx < 0 {
			dtx = tx
		}
		if drx == 0 && dtx == 0 {
			continue
		}
		if _, err := s.pool.Exec(ctx,
			`INSERT INTO bandwidth_client_daily (client_id, day, rx_bytes, tx_bytes)
			 VALUES ($1, CURRENT_DATE, $2, $3)
			 ON CONFLICT (client_id, day) DO UPDATE
			   SET rx_bytes = bandwidth_client_daily.rx_bytes + $2,
			       tx_bytes = bandwidth_client_daily.tx_bytes + $3`,
			c.id, drx, dtx); err != nil {
			s.log.Error("bwsampler: acumular", slog.Any("err", err))
			continue
		}
		if c.limitMB <= 0 {
			continue 
		}
		var monthBytes int64
		if err := s.pool.QueryRow(ctx,
			`SELECT COALESCE(SUM(rx_bytes + tx_bytes), 0) FROM bandwidth_client_daily
			  WHERE client_id = $1 AND day >= date_trunc('month', CURRENT_DATE)`, c.id).Scan(&monthBytes); err != nil {
			continue
		}
		if monthBytes >= c.limitMB*1024*1024 {
			s.suspend(ctx, c)
		}
	}
}


func (s *Sampler) suspend(ctx context.Context, c clientRow) {
	if err := s.lxd.Stop(ctx, c.container); err != nil {
		s.log.Warn("bwsampler: parar container (continuando)", slog.Any("err", err))
	}
	tag, err := s.pool.Exec(ctx, `UPDATE clients SET status = 'suspended' WHERE id = $1 AND status = 'active'`, c.id)
	if err != nil {
		s.log.Error("bwsampler: suspender", slog.Any("err", err))
		return
	}
	if tag.RowsAffected() > 0 {
		s.log.Warn("cliente suspenso por atingir o limite de banda",
			slog.Int64("client_id", c.id), slog.Int64("limit_mb", c.limitMB))
	}
}
