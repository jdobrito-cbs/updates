package acme

import (
	"context"
	"path/filepath"
	"sync"
)


type Fake struct {
	mu     sync.Mutex
	Issued []string 
}


func NewFake() *Fake {
	return &Fake{}
}

func (f *Fake) Issue(_ context.Context, fqdn, _ string) (Cert, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.Issued = append(f.Issued, fqdn)
	return Cert{
		CertPath: filepath.Join("/fake/certs", fqdn, "fullchain.pem"),
		KeyPath:  filepath.Join("/fake/certs", fqdn, "key.pem"),
	}, nil
}
