



package acme

import "context"


type Cert struct {
	CertPath string
	KeyPath  string
}


type Issuer interface {
	
	Issue(ctx context.Context, fqdn, webroot string) (Cert, error)
}
