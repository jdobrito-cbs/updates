package acme_test

import (
	"context"
	"testing"

	"github.com/jdobrito/wsrta/daemon/internal/acme"
)

func TestFakeIssue(t *testing.T) {
	f := acme.NewFake()
	cert, err := f.Issue(context.Background(), "exemplo.com", "/var/www/acme")
	if err != nil {
		t.Fatalf("issue: %v", err)
	}
	if cert.CertPath == "" || cert.KeyPath == "" {
		t.Fatalf("cert vazio: %+v", cert)
	}
	if len(f.Issued) != 1 || f.Issued[0] != "exemplo.com" {
		t.Fatalf("Issued = %v", f.Issued)
	}
}
