package acme

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)


type Real struct {
	acmeSh  string
	email   string
	staging bool
	certDir string
}


func NewReal(acmeSh, email string, staging bool, certDir string) *Real {
	return &Real{acmeSh: acmeSh, email: email, staging: staging, certDir: certDir}
}


func (r *Real) Issue(ctx context.Context, fqdn, webroot string) (Cert, error) {
	dir := filepath.Join(r.certDir, fqdn)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return Cert{}, fmt.Errorf("acme: criar certDir: %w", err)
	}
	cert := Cert{
		CertPath: filepath.Join(dir, "fullchain.pem"),
		KeyPath:  filepath.Join(dir, "key.pem"),
	}

	server := "letsencrypt"
	if r.staging {
		server = "letsencrypt_test"
	}

	
	issue := []string{"--issue", "-d", fqdn, "-w", webroot, "--server", server, "--keylength", "ec-256"}
	if r.email != "" {
		issue = append(issue, "--accountemail", r.email)
	}
	if err := r.run(ctx, issue); err != nil {
		return Cert{}, fmt.Errorf("acme: emitir %q: %w", fqdn, err)
	}

	
	install := []string{
		"--install-cert", "-d", fqdn, "--ecc",
		"--fullchain-file", cert.CertPath,
		"--key-file", cert.KeyPath,
		"--reloadcmd", "true",
	}
	if err := r.run(ctx, install); err != nil {
		return Cert{}, fmt.Errorf("acme: instalar cert de %q: %w", fqdn, err)
	}
	return cert, nil
}

func (r *Real) run(ctx context.Context, args []string) error {
	cmd := exec.CommandContext(ctx, r.acmeSh, args...)
	if out, err := cmd.CombinedOutput(); err != nil {
		return fmt.Errorf("%w: %s", err, strings.TrimSpace(string(out)))
	}
	return nil
}
