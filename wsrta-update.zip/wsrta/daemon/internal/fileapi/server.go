package fileapi

import (
	"context"
	"crypto/subtle"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net"
	"net/http"
	"os"

	"github.com/jdobrito/wsrta/daemon/internal/firewall"
	"github.com/jdobrito/wsrta/daemon/internal/lxd"
	"github.com/jdobrito/wsrta/daemon/internal/nginxscan"
)


var nginxScanDirs = []string{"/etc/nginx/sites-enabled", "/etc/nginx/conf.d"}



type Server struct {
	backend *Backend
	fw      firewall.Manager
	token   string
}


func NewServer(b *Backend, fw firewall.Manager, token string) *Server {
	return &Server{backend: b, fw: fw, token: token}
}


func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/list", s.auth(s.handleList))
	mux.HandleFunc("/mkdir", s.auth(s.scopeOp(s.backend.Mkdir)))
	mux.HandleFunc("/newfile", s.auth(s.scopeOp(s.backend.NewFile)))
	mux.HandleFunc("/delete", s.auth(s.scopeOp(s.backend.Delete)))
	mux.HandleFunc("/rename", s.auth(s.handleRename))
	mux.HandleFunc("/move", s.auth(s.handleMoveCopy(false)))
	mux.HandleFunc("/copy", s.auth(s.handleMoveCopy(true)))
	mux.HandleFunc("/download", s.auth(s.handleDownload))
	mux.HandleFunc("/upload", s.auth(s.handleUpload))
	mux.HandleFunc("/wp", s.auth(s.handleWP))
	mux.HandleFunc("/docker", s.auth(s.handleDocker))
	mux.HandleFunc("/fw/state", s.auth(s.handleFWState))
	mux.HandleFunc("/fw/action", s.auth(s.handleFWAction))
	mux.HandleFunc("/nginx/scan", s.auth(s.handleNginxScan))
	return mux
}

func (s *Server) handleFWState(w http.ResponseWriter, r *http.Request) {
	_ = json.NewEncoder(w).Encode(s.fw.State(r.Context()))
}


func (s *Server) handleNginxScan(w http.ResponseWriter, r *http.Request) {
	sites, err := nginxscan.Scan(nginxScanDirs)
	if err != nil {
		writeErr(w, err)
		return
	}
	if sites == nil {
		sites = []nginxscan.Site{}
	}
	_ = json.NewEncoder(w).Encode(map[string]any{"sites": sites})
}

func (s *Server) handleFWAction(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Kind    string `json:"kind"`
		IP      string `json:"ip"`
		Jail    string `json:"jail"`
		Service string `json:"service"`
		Op      string `json:"op"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeErr(w, err)
		return
	}
	var err error
	switch req.Kind {
	case "unban":
		err = s.fw.Unban(r.Context(), req.Jail, req.IP)
	case "ban":
		err = s.fw.Ban(r.Context(), req.Jail, req.IP)
	case "allow":
		err = s.fw.CSFAllow(r.Context(), req.IP)
	case "deny":
		err = s.fw.CSFDeny(r.Context(), req.IP)
	case "unblock":
		err = s.fw.CSFUnblock(r.Context(), req.IP)
	case "service":
		err = s.fw.Service(r.Context(), req.Service, req.Op)
	default:
		err = errors.New("ação de firewall desconhecida")
	}
	if err != nil {
		writeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) handleWP(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Container string   `json:"container"`
		Path      string   `json:"path"`
		Args      []string `json:"args"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeErr(w, err)
		return
	}
	stdout, stderr, exit, err := s.backend.WP(r.Context(), req.Container, req.Path, req.Args)
	if err != nil {
		writeErr(w, err)
		return
	}
	_ = json.NewEncoder(w).Encode(map[string]any{"stdout": stdout, "stderr": stderr, "exit": exit})
}

func (s *Server) handleDocker(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Container string   `json:"container"`
		Args      []string `json:"args"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeErr(w, err)
		return
	}
	stdout, stderr, exit, err := s.backend.Docker(r.Context(), req.Container, req.Args)
	if err != nil {
		writeErr(w, err)
		return
	}
	_ = json.NewEncoder(w).Encode(map[string]any{"stdout": stdout, "stderr": stderr, "exit": exit})
}

func (s *Server) auth(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if subtle.ConstantTimeCompare([]byte(r.Header.Get("X-WSRTA-Token")), []byte(s.token)) != 1 {
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		next(w, r)
	}
}

func writeErr(w http.ResponseWriter, err error) {
	code := http.StatusUnprocessableEntity
	if errors.Is(err, os.ErrNotExist) {
		code = http.StatusNotFound
	} else if errors.Is(err, errEscape) {
		code = http.StatusForbidden
	}
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(map[string]string{"error": err.Error()})
}

func (s *Server) handleList(w http.ResponseWriter, r *http.Request) {
	var sc Scope
	if err := json.NewDecoder(r.Body).Decode(&sc); err != nil {
		writeErr(w, err)
		return
	}
	entries, err := s.backend.List(r.Context(), sc)
	if err != nil {
		writeErr(w, err)
		return
	}
	if entries == nil {
		entries = []Entry{}
	}
	_ = json.NewEncoder(w).Encode(map[string]any{"entries": entries})
}

func (s *Server) scopeOp(fn func(context.Context, Scope) error) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var sc Scope
		if err := json.NewDecoder(r.Body).Decode(&sc); err != nil {
			writeErr(w, err)
			return
		}
		if err := fn(r.Context(), sc); err != nil {
			writeErr(w, err)
			return
		}
		w.WriteHeader(http.StatusNoContent)
	}
}

func (s *Server) handleRename(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Scope   Scope  `json:"scope"`
		NewName string `json:"new_name"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		writeErr(w, err)
		return
	}
	if err := s.backend.Rename(r.Context(), req.Scope, req.NewName); err != nil {
		writeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

func (s *Server) handleMoveCopy(isCopy bool) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		var req struct {
			Src    Scope  `json:"src"`
			DstDir string `json:"dst_dir"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			writeErr(w, err)
			return
		}
		var err error
		if isCopy {
			err = s.backend.Copy(r.Context(), req.Src, req.DstDir)
		} else {
			err = s.backend.Move(r.Context(), req.Src, req.DstDir)
		}
		if err != nil {
			writeErr(w, err)
			return
		}
		w.WriteHeader(http.StatusNoContent)
	}
}

func (s *Server) handleDownload(w http.ResponseWriter, r *http.Request) {
	var sc Scope
	if err := json.NewDecoder(r.Body).Decode(&sc); err != nil {
		writeErr(w, err)
		return
	}
	rc, err := s.backend.Open(r.Context(), sc)
	if err != nil {
		writeErr(w, err)
		return
	}
	defer rc.Close()
	w.Header().Set("Content-Type", "application/octet-stream")
	_, _ = io.Copy(w, rc)
}

func (s *Server) handleUpload(w http.ResponseWriter, r *http.Request) {
	q := r.URL.Query()
	sc := Scope{Mode: Mode(q.Get("mode")), Container: q.Get("container"), Path: q.Get("path")}
	if err := s.backend.Upload(r.Context(), sc, r.Body); err != nil {
		writeErr(w, err)
		return
	}
	w.WriteHeader(http.StatusNoContent)
}



func Serve(ctx context.Context, socketPath, token string, l lxd.Client, containerRoot string, fw firewall.Manager, log *slog.Logger) error {
	_ = os.Remove(socketPath)
	ln, err := net.Listen("unix", socketPath)
	if err != nil {
		return err
	}
	_ = os.Chmod(socketPath, 0o660)

	srv := &http.Server{Handler: NewServer(NewBackend(l, containerRoot), fw, token).Handler()}
	go func() {
		<-ctx.Done()
		_ = srv.Close()
		_ = os.Remove(socketPath)
	}()
	log.Info("file service ouvindo", slog.String("socket", socketPath))
	if err := srv.Serve(ln); err != nil && !errors.Is(err, http.ErrServerClosed) {
		return err
	}
	return nil
}
