




package fileapi

import (
	"context"
	"fmt"
	"io"
	"os"
	"path"
	"path/filepath"
	"sort"
	"strconv"
	"strings"

	"github.com/jdobrito/wsrta/daemon/internal/lxd"
)


type Mode string

const (
	ModeHost      Mode = "host"
	ModeContainer Mode = "container"
)


type Scope struct {
	Mode      Mode   `json:"mode"`
	Container string `json:"container"` 
	Path      string `json:"path"`      
}


type Entry struct {
	Name  string `json:"name"`
	IsDir bool   `json:"is_dir"`
	Size  int64  `json:"size"`
	MTime int64  `json:"mtime"`
}


type Backend struct {
	lxd           lxd.Client
	containerRoot string 
}


func NewBackend(l lxd.Client, containerRoot string) *Backend {
	if containerRoot == "" {
		containerRoot = "/var/www"
	}
	return &Backend{lxd: l, containerRoot: path.Clean(containerRoot)}
}

var errEscape = fmt.Errorf("caminho fora do escopo permitido")


func (b *Backend) resolve(s Scope) (string, error) {
	if s.Mode == ModeContainer {
		if s.Container == "" {
			return "", fmt.Errorf("container obrigatório")
		}
		
		full := path.Clean(path.Join(b.containerRoot, "/"+strings.TrimPrefix(s.Path, "/")))
		if full != b.containerRoot && !strings.HasPrefix(full, b.containerRoot+"/") {
			return "", errEscape
		}
		return full, nil
	}
	
	p := s.Path
	if p == "" {
		p = "/"
	}
	if !strings.HasPrefix(p, "/") {
		return "", fmt.Errorf("caminho do host deve ser absoluto")
	}
	return filepath.Clean(p), nil
}


func (b *Backend) List(ctx context.Context, s Scope) ([]Entry, error) {
	real, err := b.resolve(s)
	if err != nil {
		return nil, err
	}
	if s.Mode == ModeHost {
		des, err := os.ReadDir(real)
		if err != nil {
			return nil, err
		}
		out := make([]Entry, 0, len(des))
		for _, d := range des {
			info, err := d.Info()
			if err != nil {
				continue
			}
			out = append(out, Entry{Name: d.Name(), IsDir: d.IsDir(), Size: info.Size(), MTime: info.ModTime().Unix()})
		}
		sortEntries(out)
		return out, nil
	}
	
	res, err := b.lxd.Exec(ctx, s.Container,
		[]string{"find", real, "-maxdepth", "1", "-mindepth", "1", "-printf", "%y\\t%s\\t%T@\\t%f\\n"}, nil)
	if err != nil {
		return nil, err
	}
	if res.ExitCode != 0 {
		return nil, fmt.Errorf("listar: %s", strings.TrimSpace(res.Stderr))
	}
	var out []Entry
	for _, line := range strings.Split(strings.TrimRight(res.Stdout, "\n"), "\n") {
		if line == "" {
			continue
		}
		f := strings.SplitN(line, "\t", 4)
		if len(f) != 4 {
			continue
		}
		size, _ := strconv.ParseInt(f[1], 10, 64)
		mt, _ := strconv.ParseFloat(f[2], 64)
		out = append(out, Entry{Name: f[3], IsDir: f[0] == "d", Size: size, MTime: int64(mt)})
	}
	sortEntries(out)
	return out, nil
}


type tempReadCloser struct {
	*os.File
	name string
}

func (t *tempReadCloser) Close() error {
	err := t.File.Close()
	os.Remove(t.name)
	return err
}



func (b *Backend) Open(ctx context.Context, s Scope) (io.ReadCloser, error) {
	real, err := b.resolve(s)
	if err != nil {
		return nil, err
	}
	if s.Mode == ModeHost {
		return os.Open(real)
	}
	tmp, err := os.CreateTemp("", "wsrta-dl-*")
	if err != nil {
		return nil, err
	}
	tmp.Close()
	if err := b.lxd.PullFile(ctx, s.Container, real, tmp.Name()); err != nil {
		os.Remove(tmp.Name())
		return nil, err
	}
	f, err := os.Open(tmp.Name())
	if err != nil {
		os.Remove(tmp.Name())
		return nil, err
	}
	return &tempReadCloser{File: f, name: tmp.Name()}, nil
}


func (b *Backend) Upload(ctx context.Context, s Scope, r io.Reader) error {
	real, err := b.resolve(s)
	if err != nil {
		return err
	}
	if s.Mode == ModeHost {
		f, err := os.Create(real)
		if err != nil {
			return err
		}
		defer f.Close()
		_, err = io.Copy(f, r)
		return err
	}
	data, err := io.ReadAll(r)
	if err != nil {
		return err
	}
	if err := b.lxd.PushFile(ctx, s.Container, real, data, 0o644); err != nil {
		return err
	}
	_ = b.exec(ctx, s.Container, "chown", "www-data:www-data", real)
	return nil
}


func (b *Backend) Mkdir(ctx context.Context, s Scope) error {
	real, err := b.resolve(s)
	if err != nil {
		return err
	}
	if s.Mode == ModeHost {
		return os.MkdirAll(real, 0o755)
	}
	if err := b.exec(ctx, s.Container, "mkdir", "-p", real); err != nil {
		return err
	}
	return b.exec(ctx, s.Container, "chown", "www-data:www-data", real)
}


func (b *Backend) NewFile(ctx context.Context, s Scope) error {
	real, err := b.resolve(s)
	if err != nil {
		return err
	}
	if s.Mode == ModeHost {
		f, err := os.OpenFile(real, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0o644)
		if err != nil {
			return err
		}
		return f.Close()
	}
	return b.exec(ctx, s.Container, "touch", real)
}


func (b *Backend) Delete(ctx context.Context, s Scope) error {
	real, err := b.resolve(s)
	if err != nil {
		return err
	}
	if s.Mode == ModeContainer && real == b.containerRoot {
		return errEscape 
	}
	if s.Mode == ModeHost {
		return os.RemoveAll(real)
	}
	return b.exec(ctx, s.Container, "rm", "-rf", real)
}


func (b *Backend) Rename(ctx context.Context, s Scope, newName string) error {
	if newName == "" || strings.ContainsAny(newName, "/\\") {
		return fmt.Errorf("novo nome inválido")
	}
	real, err := b.resolve(s)
	if err != nil {
		return err
	}
	dst := path.Join(path.Dir(real), newName)
	if s.Mode == ModeHost {
		return os.Rename(real, dst)
	}
	return b.exec(ctx, s.Container, "mv", real, dst)
}


func (b *Backend) Move(ctx context.Context, src Scope, dstDir string) error {
	return b.moveOrCopy(ctx, src, dstDir, false)
}


func (b *Backend) Copy(ctx context.Context, src Scope, dstDir string) error {
	return b.moveOrCopy(ctx, src, dstDir, true)
}

func (b *Backend) moveOrCopy(ctx context.Context, src Scope, dstDir string, isCopy bool) error {
	srcReal, err := b.resolve(src)
	if err != nil {
		return err
	}
	dstReal, err := b.resolve(Scope{Mode: src.Mode, Container: src.Container, Path: dstDir})
	if err != nil {
		return err
	}
	target := path.Join(dstReal, path.Base(srcReal))
	if src.Mode == ModeHost {
		if isCopy {
			return copyHost(srcReal, target)
		}
		return os.Rename(srcReal, target)
	}
	if isCopy {
		return b.exec(ctx, src.Container, "cp", "-a", srcReal, target)
	}
	return b.exec(ctx, src.Container, "mv", srcReal, target)
}


func (b *Backend) exec(ctx context.Context, container string, args ...string) error {
	res, err := b.lxd.Exec(ctx, container, args, nil)
	if err != nil {
		return err
	}
	if res.ExitCode != 0 {
		return fmt.Errorf("%v: %s", args, strings.TrimSpace(res.Stderr))
	}
	return nil
}

func copyHost(src, dst string) error {
	info, err := os.Stat(src)
	if err != nil {
		return err
	}
	if info.IsDir() {
		if err := os.MkdirAll(dst, info.Mode()); err != nil {
			return err
		}
		des, err := os.ReadDir(src)
		if err != nil {
			return err
		}
		for _, d := range des {
			if err := copyHost(filepath.Join(src, d.Name()), filepath.Join(dst, d.Name())); err != nil {
				return err
			}
		}
		return nil
	}
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.OpenFile(dst, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, info.Mode())
	if err != nil {
		return err
	}
	defer out.Close()
	_, err = io.Copy(out, in)
	return err
}


func (b *Backend) cleanAbs(p string) (string, error) {
	c := path.Clean(p)
	if c != b.containerRoot && !strings.HasPrefix(c, b.containerRoot+"/") {
		return "", errEscape
	}
	return c, nil
}



func (b *Backend) WP(ctx context.Context, container, wpDir string, args []string) (string, string, int, error) {
	dir, err := b.cleanAbs(wpDir)
	if err != nil {
		return "", "", 0, err
	}
	full := append([]string{"wp", "--allow-root", "--path=" + dir}, args...)
	res, err := b.lxd.Exec(ctx, container, full, nil)
	if err != nil {
		return "", "", 0, err
	}
	return res.Stdout, res.Stderr, res.ExitCode, nil
}



var dockerSubcmds = map[string]bool{"ps": true, "start": true, "stop": true, "restart": true, "rm": true}


func dockerNameOK(s string) bool {
	if s == "" || len(s) > 64 {
		return false
	}
	for _, c := range s {
		if !(c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '-' || c == '_' || c == '.') {
			return false
		}
	}
	return true
}




func (b *Backend) Docker(ctx context.Context, container string, args []string) (string, string, int, error) {
	if len(args) == 0 || !dockerSubcmds[args[0]] {
		return "", "", 0, errEscape
	}
	
	
	if args[0] != "ps" {
		for _, a := range args[1:] {
			if strings.HasPrefix(a, "-") {
				continue
			}
			if !dockerNameOK(a) {
				return "", "", 0, errEscape
			}
		}
	}
	full := append([]string{"docker"}, args...)
	res, err := b.lxd.Exec(ctx, container, full, nil)
	if err != nil {
		return "", "", 0, err
	}
	return res.Stdout, res.Stderr, res.ExitCode, nil
}

func sortEntries(e []Entry) {
	sort.Slice(e, func(i, j int) bool {
		if e[i].IsDir != e[j].IsDir {
			return e[i].IsDir 
		}
		return strings.ToLower(e[i].Name) < strings.ToLower(e[j].Name)
	})
}
