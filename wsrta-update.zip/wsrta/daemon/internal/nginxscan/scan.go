





package nginxscan

import (
	"net"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
)


type Site struct {
	FQDNs        []string `json:"fqdns"`         
	UpstreamIP   string   `json:"upstream_ip"`   
	UpstreamPort int      `json:"upstream_port"` 
	ProxyTarget  string   `json:"proxy_target"`  
	Root         string   `json:"root"`          
	File         string   `json:"file"`          
}

var (
	serverNameRe = regexp.MustCompile(`(?m)^\s*server_name\s+([^;{}]+);`)
	proxyPassRe  = regexp.MustCompile(`proxy_pass\s+https?://([^;\s/]+)`)
	rootRe       = regexp.MustCompile(`(?m)^\s*root\s+([^;{}]+);`)
)



func Scan(dirs []string) ([]Site, error) {
	var sites []Site
	for _, dir := range dirs {
		entries, err := os.ReadDir(dir)
		if err != nil {
			continue
		}
		for _, e := range entries {
			if e.IsDir() {
				continue
			}
			b, err := os.ReadFile(filepath.Join(dir, e.Name()))
			if err != nil {
				continue
			}
			p := filepath.Join(dir, e.Name())
			for _, blk := range serverBlocks(string(b)) {
				if s, ok := parseBlock(blk); ok {
					s.File = p
					sites = append(sites, s)
				}
			}
		}
	}
	return sites, nil
}


var serverBlockStart = regexp.MustCompile(`(?:^|[\s};])server\s*\{`)



func serverBlocks(content string) []string {
	var blocks []string
	for i := 0; i < len(content); {
		loc := serverBlockStart.FindStringIndex(content[i:])
		if loc == nil {
			break
		}
		open := i + loc[1] - 1 
		end := matchBrace(content, open)
		if end < 0 {
			break
		}
		blocks = append(blocks, content[open+1:end])
		i = end + 1
	}
	return blocks
}


func matchBrace(s string, open int) int {
	depth := 0
	for j := open; j < len(s); j++ {
		switch s[j] {
		case '{':
			depth++
		case '}':
			depth--
			if depth == 0 {
				return j
			}
		}
	}
	return -1
}



func parseBlock(blk string) (Site, bool) {
	var s Site
	for _, m := range serverNameRe.FindAllStringSubmatch(blk, -1) {
		for _, name := range strings.Fields(m[1]) {
			name = strings.TrimSpace(name)
			if name == "" || name == "_" || strings.ContainsAny(name, "*~") {
				continue 
			}
			if net.ParseIP(name) != nil {
				continue 
			}
			s.FQDNs = append(s.FQDNs, strings.ToLower(name))
		}
	}
	if len(s.FQDNs) == 0 {
		return s, false
	}
	if m := proxyPassRe.FindStringSubmatch(blk); m != nil {
		target := m[1]
		s.ProxyTarget = target
		host, port := splitHostPort(target)
		if net.ParseIP(host) != nil {
			s.UpstreamIP = host
			s.UpstreamPort = port
		}
	}
	if m := rootRe.FindStringSubmatch(blk); m != nil {
		s.Root = strings.TrimSpace(m[1])
	}
	return s, true
}

func splitHostPort(target string) (host string, port int) {
	if h, p, err := net.SplitHostPort(target); err == nil {
		n, _ := strconv.Atoi(p)
		return h, n
	}
	return target, 0
}
