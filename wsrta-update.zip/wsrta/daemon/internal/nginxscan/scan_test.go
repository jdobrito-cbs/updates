package nginxscan

import (
	"os"
	"path/filepath"
	"testing"
)

const sampleConf = `
server {
    listen 80;
    server_name loja.exemplo.com www.loja.exemplo.com;
    location / {
        proxy_pass http://10.0.0.42:8080;
        proxy_set_header Host $host;
    }
}

server {
    listen 80 default_server;
    server_name _;
    return 404;
}

server {
    listen 80;
    server_name site.local;
    root /var/www/site.local;
    index index.php;
    location ~ \.php$ { fastcgi_pass unix:/run/php/php.sock; }
}
`

func TestScanParsesProxyAndLocal(t *testing.T) {
	dir := t.TempDir()
	if err := os.WriteFile(filepath.Join(dir, "sites.conf"), []byte(sampleConf), 0o644); err != nil {
		t.Fatal(err)
	}
	sites, err := Scan([]string{dir})
	if err != nil {
		t.Fatal(err)
	}
	
	if len(sites) != 2 {
		t.Fatalf("esperava 2 sites, veio %d: %+v", len(sites), sites)
	}

	proxy := sites[0]
	if len(proxy.FQDNs) != 2 || proxy.FQDNs[0] != "loja.exemplo.com" || proxy.FQDNs[1] != "www.loja.exemplo.com" {
		t.Errorf("server_name do proxy errado: %+v", proxy.FQDNs)
	}
	if proxy.UpstreamIP != "10.0.0.42" || proxy.UpstreamPort != 8080 {
		t.Errorf("upstream do proxy errado: ip=%q port=%d", proxy.UpstreamIP, proxy.UpstreamPort)
	}

	local := sites[1]
	if len(local.FQDNs) != 1 || local.FQDNs[0] != "site.local" {
		t.Errorf("server_name local errado: %+v", local.FQDNs)
	}
	if local.UpstreamIP != "" {
		t.Errorf("site local não deveria ter upstream: %q", local.UpstreamIP)
	}
	if local.Root != "/var/www/site.local" {
		t.Errorf("root local errado: %q", local.Root)
	}
}
