package nginx_test

import (
	"context"
	"strings"
	"testing"

	"github.com/jdobrito/wsrta/daemon/internal/nginx"
)

func TestRenderHostVHostHTTP(t *testing.T) {
	out, err := nginx.RenderHostVHost(nginx.HostVHost{
		FQDN: "exemplo.com", UpstreamIP: "10.0.0.2", UpstreamPort: 80,
		ACMEWebroot: "/var/www/acme", SSL: false,
	})
	if err != nil {
		t.Fatalf("render: %v", err)
	}
	if !strings.Contains(out, "listen 80;") {
		t.Errorf("faltou listen 80: %s", out)
	}
	if !strings.Contains(out, "proxy_pass http://10.0.0.2:80;") {
		t.Errorf("faltou proxy_pass: %s", out)
	}
	if strings.Contains(out, "listen 443") {
		t.Errorf("não deveria ter 443 sem SSL: %s", out)
	}
	if !strings.Contains(out, "/.well-known/acme-challenge/") {
		t.Errorf("faltou location do ACME: %s", out)
	}
}

func TestRenderHostVHostTLS(t *testing.T) {
	out, err := nginx.RenderHostVHost(nginx.HostVHost{
		FQDN: "exemplo.com", UpstreamIP: "10.0.0.2", UpstreamPort: 80,
		ACMEWebroot: "/var/www/acme", SSL: true,
		CertPath: "/etc/wsrta/certs/exemplo.com/fullchain.pem",
		KeyPath:  "/etc/wsrta/certs/exemplo.com/key.pem",
	})
	if err != nil {
		t.Fatalf("render: %v", err)
	}
	if !strings.Contains(out, "listen 443 ssl;") {
		t.Errorf("faltou 443 ssl: %s", out)
	}
	if !strings.Contains(out, "ssl_certificate /etc/wsrta/certs/exemplo.com/fullchain.pem;") {
		t.Errorf("faltou ssl_certificate: %s", out)
	}
	if !strings.Contains(out, "return 301 https://") {
		t.Errorf("faltou redirect HTTP->HTTPS: %s", out)
	}
}

func TestRenderContainerVHost(t *testing.T) {
	out, err := nginx.RenderContainerVHost(nginx.ContainerVHost{
		FQDN: "exemplo.com", Docroot: "/var/www/exemplo.com",
		PHPSocket: "/run/php/php8.3-fpm.sock",
	})
	if err != nil {
		t.Fatalf("render: %v", err)
	}
	if !strings.Contains(out, "root /var/www/exemplo.com;") {
		t.Errorf("faltou root: %s", out)
	}
	if !strings.Contains(out, "fastcgi_pass unix:/run/php/php8.3-fpm.sock;") {
		t.Errorf("faltou fastcgi_pass: %s", out)
	}
}

func TestFakeManager(t *testing.T) {
	f := nginx.NewFake()
	ctx := context.Background()
	if err := f.WriteVHost(ctx, "exemplo.com", "conteudo"); err != nil {
		t.Fatalf("write: %v", err)
	}
	if v, ok := f.VHost("exemplo.com"); !ok || v != "conteudo" {
		t.Fatalf("vhost incorreto: %q ok=%v", v, ok)
	}
	if err := f.Reload(ctx); err != nil {
		t.Fatalf("reload: %v", err)
	}
	if f.Reloads != 1 {
		t.Fatalf("reloads = %d, esperava 1", f.Reloads)
	}
	if err := f.RemoveVHost(ctx, "exemplo.com"); err != nil {
		t.Fatalf("remove: %v", err)
	}
	if _, ok := f.VHost("exemplo.com"); ok {
		t.Fatal("vhost deveria ter sido removido")
	}
}
