package nginx

import (
	"strings"
	"text/template"
)


type HostVHost struct {
	FQDN         string
	UpstreamIP   string 
	UpstreamPort int
	UpstreamPath string 
	ACMEWebroot  string 
	SSL          bool
	CertPath     string
	KeyPath      string
}


type ContainerVHost struct {
	FQDN      string
	Docroot   string
	PHPSocket string 
	Extra     string 
}

const hostVHostTmpl = `server {
    listen 80;
    server_name {{.FQDN}};

    location ^~ /.well-known/acme-challenge/ {
        root {{.ACMEWebroot}};
        default_type "text/plain";
    }
{{- if .SSL}}

    location / {
        return 301 https://$host$request_uri;
    }
}

server {
    listen 443 ssl;
    server_name {{.FQDN}};

    ssl_certificate {{.CertPath}};
    ssl_certificate_key {{.KeyPath}};

    include /etc/nginx/wsrta-forwards.d/{{.FQDN}}.conf;

    location / {
        proxy_pass http://{{.UpstreamIP}}:{{.UpstreamPort}}{{.UpstreamPath}};
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
{{- else}}

    include /etc/nginx/wsrta-forwards.d/{{.FQDN}}.conf;

    location / {
        proxy_pass http://{{.UpstreamIP}}:{{.UpstreamPort}}{{.UpstreamPath}};
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
{{- end}}
`

const containerVHostTmpl = `server {
    listen 80;
    server_name {{.FQDN}};
    root {{.Docroot}};
    index index.php index.html index.htm;
{{.Extra}}
    # Modo offline (manutenção/suspensão): se o marcador existir, TODA requisição (inclusive .php)
    # recebe 503 + a página offline. O marcador é escrito/removido por set_domain_offline (sem
    # re-render). O "=503" no error_page PRESERVA o status 503 ao servir a página (sem ele o nginx
    # devolveria 200); o "=503" no try_files evita loop caso a página não exista.
    error_page 503 =503 @wsrta_offline;
    location @wsrta_offline {
        add_header Retry-After 3600 always;
        try_files /.wsrta-offline.html =503;
    }

    location / {
        if (-f $document_root/.wsrta-offline.html) { return 503; }
        try_files $uri $uri/ /index.php?$args;
    }

    location ~ \.php$ {
        if (-f $document_root/.wsrta-offline.html) { return 503; }
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:{{.PHPSocket}};
    }

    location ~ /\.ht {
        deny all;
    }
}
`



type PreviewSnippet struct {
	FQDN         string
	UpstreamIP   string
	UpstreamPort int
}

const previewSnippetTmpl = `location ^~ /_preview/{{.FQDN}}/ {
    proxy_pass http://{{.UpstreamIP}}:{{.UpstreamPort}}/;
    # SEGURANÇA (F1): 'sandbox' força ORIGEM OPACA sem scripts no preview (conteúdo controlado pelo
    # cliente) — impede que um site malicioso rode JS same-origin e roube o token do admin no
    # localStorage do painel. add_header sempre (inclusive em respostas de erro do upstream).
    proxy_hide_header Content-Security-Policy;
    proxy_hide_header X-Frame-Options;
    add_header Content-Security-Policy "sandbox" always;
    add_header X-Frame-Options "DENY" always;
    # o location redefine add_header (não herda o do server) — repõe os essenciais.
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer" always;
    proxy_set_header Host {{.FQDN}};
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
}
`

var (
	hostTmpl      = template.Must(template.New("host").Parse(hostVHostTmpl))
	containerTmpl = template.Must(template.New("container").Parse(containerVHostTmpl))
	previewTmpl   = template.Must(template.New("preview").Parse(previewSnippetTmpl))
)


type Forward struct {
	Path   string
	Target string
	
	
	Host string
}



func RenderForwards(forwards []Forward) string {
	var b strings.Builder
	for _, f := range forwards {
		host := "$host"
		if f.Host != "" {
			host = f.Host
		}
		b.WriteString("location ^~ " + f.Path + " {\n")
		b.WriteString("    proxy_pass http://" + f.Target + ";\n")
		b.WriteString("    proxy_set_header Host " + host + ";\n")
		b.WriteString("    proxy_set_header X-Real-IP $remote_addr;\n")
		b.WriteString("    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;\n")
		b.WriteString("    proxy_set_header X-Forwarded-Proto $scheme;\n")
		b.WriteString("}\n")
	}
	return b.String()
}


func RenderPreviewSnippet(p PreviewSnippet) (string, error) {
	var b strings.Builder
	if err := previewTmpl.Execute(&b, p); err != nil {
		return "", err
	}
	return b.String(), nil
}


func RenderHostVHost(d HostVHost) (string, error) {
	var b strings.Builder
	if err := hostTmpl.Execute(&b, d); err != nil {
		return "", err
	}
	return b.String(), nil
}


func RenderContainerVHost(d ContainerVHost) (string, error) {
	var b strings.Builder
	if err := containerTmpl.Execute(&b, d); err != nil {
		return "", err
	}
	return b.String(), nil
}
