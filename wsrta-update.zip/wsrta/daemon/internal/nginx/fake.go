package nginx

import (
	"context"
	"sync"
)


type Fake struct {
	mu      sync.Mutex
	VHosts  map[string]string
	Reloads int
}


func NewFake() *Fake {
	return &Fake{VHosts: make(map[string]string)}
}

func (f *Fake) WriteVHost(_ context.Context, name, content string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.VHosts[name] = content
	return nil
}

func (f *Fake) RemoveVHost(_ context.Context, name string) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	delete(f.VHosts, name)
	return nil
}

func (f *Fake) WritePreviewSnippet(_ context.Context, _, _ string, _ int) error { return nil }
func (f *Fake) RemovePreviewSnippet(_ context.Context, _ string) error          { return nil }
func (f *Fake) WriteForwards(_ context.Context, _, _ string) error              { return nil }
func (f *Fake) RemoveForwards(_ context.Context, _ string) error                { return nil }

func (f *Fake) Reload(_ context.Context) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.Reloads++
	return nil
}


func (f *Fake) VHost(name string) (string, bool) {
	f.mu.Lock()
	defer f.mu.Unlock()
	v, ok := f.VHosts[name]
	return v, ok
}
