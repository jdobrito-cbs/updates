



package nginx

import "context"


type Manager interface {
	
	WriteVHost(ctx context.Context, name, content string) error
	
	RemoveVHost(ctx context.Context, name string) error
	
	
	WritePreviewSnippet(ctx context.Context, fqdn, upstreamIP string, upstreamPort int) error
	RemovePreviewSnippet(ctx context.Context, fqdn string) error
	
	
	
	WriteForwards(ctx context.Context, fqdn, content string) error
	RemoveForwards(ctx context.Context, fqdn string) error
	
	Reload(ctx context.Context) error
}
