package nginx

import (
	"strings"
	"testing"
)

func TestRenderForwards(t *testing.T) {
	out := RenderForwards([]Forward{
		{Path: "/loja", Target: "app.outro.com"},
		{Path: "/app", Target: "10.0.0.5:8080/painel"},
	})
	if !strings.Contains(out, "location ^~ /loja {") {
		t.Errorf("faltou o location de /loja: %q", out)
	}
	if !strings.Contains(out, "proxy_pass http://app.outro.com;") {
		t.Errorf("proxy_pass de /loja errado: %q", out)
	}
	if !strings.Contains(out, "proxy_pass http://10.0.0.5:8080/painel;") {
		t.Errorf("proxy_pass de /app errado: %q", out)
	}
	if RenderForwards(nil) != "" {
		t.Errorf("sem forwards deveria ser vazio, veio %q", RenderForwards(nil))
	}
}
