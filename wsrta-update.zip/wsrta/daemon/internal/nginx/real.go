package nginx

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
)


type Real struct {
	sitesDir    string
	previewDir  string 
	forwardsDir string 
	reloadCmd   []string
}


func NewReal(sitesDir, previewDir, forwardsDir, reloadCmd string) *Real {
	return &Real{sitesDir: sitesDir, previewDir: previewDir, forwardsDir: forwardsDir, reloadCmd: strings.Fields(reloadCmd)}
}


func safeName(name string) error {
	if name == "" || strings.ContainsAny(name, `/\`) || strings.Contains(name, "..") {
		return fmt.Errorf("nginx: nome de vhost inválido: %q", name)
	}
	return nil
}

func (r *Real) path(name string) string {
	return filepath.Join(r.sitesDir, name+".conf")
}

func (r *Real) WriteVHost(_ context.Context, name, content string) error {
	if err := safeName(name); err != nil {
		return err
	}
	if err := os.MkdirAll(r.sitesDir, 0o755); err != nil {
		return fmt.Errorf("nginx: criar sitesDir: %w", err)
	}
	if err := os.WriteFile(r.path(name), []byte(content), 0o644); err != nil {
		return fmt.Errorf("nginx: escrever vhost %q: %w", name, err)
	}
	return nil
}

func (r *Real) RemoveVHost(_ context.Context, name string) error {
	if err := safeName(name); err != nil {
		return err
	}
	if err := os.Remove(r.path(name)); err != nil && !os.IsNotExist(err) {
		return fmt.Errorf("nginx: remover vhost %q: %w", name, err)
	}
	return nil
}

func (r *Real) WritePreviewSnippet(_ context.Context, fqdn, upstreamIP string, upstreamPort int) error {
	if err := safeName(fqdn); err != nil {
		return err
	}
	content, err := RenderPreviewSnippet(PreviewSnippet{FQDN: fqdn, UpstreamIP: upstreamIP, UpstreamPort: upstreamPort})
	if err != nil {
		return err
	}
	if err := os.MkdirAll(r.previewDir, 0o755); err != nil {
		return fmt.Errorf("nginx: criar previewDir: %w", err)
	}
	if err := os.WriteFile(filepath.Join(r.previewDir, fqdn+".conf"), []byte(content), 0o644); err != nil {
		return fmt.Errorf("nginx: escrever preview %q: %w", fqdn, err)
	}
	return nil
}

func (r *Real) RemovePreviewSnippet(_ context.Context, fqdn string) error {
	if err := safeName(fqdn); err != nil {
		return err
	}
	if err := os.Remove(filepath.Join(r.previewDir, fqdn+".conf")); err != nil && !os.IsNotExist(err) {
		return fmt.Errorf("nginx: remover preview %q: %w", fqdn, err)
	}
	return nil
}

func (r *Real) WriteForwards(_ context.Context, fqdn, content string) error {
	if err := safeName(fqdn); err != nil {
		return err
	}
	if err := os.MkdirAll(r.forwardsDir, 0o755); err != nil {
		return fmt.Errorf("nginx: criar forwardsDir: %w", err)
	}
	if err := os.WriteFile(filepath.Join(r.forwardsDir, fqdn+".conf"), []byte(content), 0o644); err != nil {
		return fmt.Errorf("nginx: escrever forwards %q: %w", fqdn, err)
	}
	return nil
}

func (r *Real) RemoveForwards(_ context.Context, fqdn string) error {
	if err := safeName(fqdn); err != nil {
		return err
	}
	if err := os.Remove(filepath.Join(r.forwardsDir, fqdn+".conf")); err != nil && !os.IsNotExist(err) {
		return fmt.Errorf("nginx: remover forwards %q: %w", fqdn, err)
	}
	return nil
}

func (r *Real) Reload(ctx context.Context) error {
	if len(r.reloadCmd) == 0 {
		return fmt.Errorf("nginx: comando de reload vazio")
	}
	
	cmd := exec.CommandContext(ctx, r.reloadCmd[0], r.reloadCmd[1:]...)
	if out, err := cmd.CombinedOutput(); err != nil {
		return fmt.Errorf("nginx: reload: %w: %s", err, strings.TrimSpace(string(out)))
	}
	return nil
}
