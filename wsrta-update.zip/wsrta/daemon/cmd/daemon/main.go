

package main

import (
	"context"
	"log/slog"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/jdobrito/wsrta/daemon/internal/acme"
	"github.com/jdobrito/wsrta/daemon/internal/bwsampler"
	"github.com/jdobrito/wsrta/daemon/internal/consumer"
	"github.com/jdobrito/wsrta/daemon/internal/executors"
	"github.com/jdobrito/wsrta/daemon/internal/fileapi"
	"github.com/jdobrito/wsrta/daemon/internal/firewall"
	"github.com/jdobrito/wsrta/daemon/internal/hostctl"
	"github.com/jdobrito/wsrta/daemon/internal/lxd"
	"github.com/jdobrito/wsrta/daemon/internal/nginx"
	"github.com/jdobrito/wsrta/daemon/internal/pdns"
	"github.com/jdobrito/wsrta/daemon/internal/scheduler"
	"github.com/jdobrito/wsrta/daemon/internal/seccollect"
	"github.com/jdobrito/wsrta/daemon/internal/security"
	"github.com/jdobrito/wsrta/daemon/internal/store"
	"github.com/jdobrito/wsrta/internal/config"
	"github.com/jdobrito/wsrta/internal/core"
	"github.com/jdobrito/wsrta/internal/db"
	"github.com/jdobrito/wsrta/internal/queue"
)

func main() {
	cfg, err := config.Load()
	if err != nil {
		slog.Error("config", slog.Any("err", err))
		os.Exit(1)
	}

	log := slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: cfg.SlogLevel()}))
	slog.SetDefault(log)

	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	pool, err := db.Open(ctx, cfg.DatabaseURL)
	if err != nil {
		log.Error("conectar ao banco", slog.Any("err", err))
		os.Exit(1)
	}
	defer pool.Close()

	q := queue.New(pool)

	
	lxdClient, err := lxd.New(cfg.LXDDriver, lxd.Config{Socket: cfg.LXDSocket, FakeFSRoot: cfg.LXDFakeFSRoot})
	if err != nil {
		log.Error("inicializar driver LXD", slog.Any("err", err))
		os.Exit(1)
	}
	defer lxdClient.Close()

	deps := executors.Deps{
		LXD:      lxdClient,
		Store:    store.NewClients(pool),
		Log:      log,
		Image:    cfg.LXDImage,
		Pool:     cfg.LXDStoragePool,
		Network:  cfg.LXDNetwork,
		Progress: q, 
	}

	
	var nginxMgr nginx.Manager
	var acmeIssuer acme.Issuer
	if cfg.LXDDriver == "fake" {
		nginxMgr = nginx.NewFake()
		acmeIssuer = acme.NewFake()
	} else {
		nginxMgr = nginx.NewReal(cfg.NginxSitesDir, cfg.NginxPreviewDir, cfg.NginxForwardsDir, cfg.NginxReloadCmd)
		acmeIssuer = acme.NewReal(cfg.AcmeSh, cfg.AcmeEmail, cfg.AcmeStaging, cfg.AcmeCertDir)
	}
	webDeps := executors.WebDeps{
		LXD:          lxdClient,
		Nginx:        nginxMgr,
		Acme:         acmeIssuer,
		Domains:      store.NewDomains(pool),
		Log:          log,
		DocrootBase:  cfg.DomainDocrootBase,
		ACMEWebroot:  cfg.AcmeWebroot,
		UpstreamPort: 80,
		Progress:     q, 
	}

	reg := executors.NewRegistry()
	
	executors.RegisterStubs(reg, log)
	
	reg.Register(core.ActionProvisionClient, executors.NewProvisionClientExecutor(deps))
	reg.Register(core.ActionDeprovisionClient, executors.NewDeprovisionClientExecutor(deps))
	reg.Register(core.ActionSuspendClient, executors.NewSuspendClientExecutor(deps))
	reg.Register(core.ActionResumeClient, executors.NewResumeClientExecutor(deps))
	reg.Register(core.ActionPowerClient, executors.NewPowerClientExecutor(deps))
	reg.Register(core.ActionApplyLimits, executors.NewApplyLimitsExecutor(deps))
	reg.Register(core.ActionEnableSFTP, executors.NewEnableSFTPExecutor(deps))
	reg.Register(core.ActionDisableSFTP, executors.NewDisableSFTPExecutor(deps))
	reg.Register(core.ActionSetCloudflare, executors.NewSetCloudflareExecutor(deps))
	reg.Register(core.ActionControlCloudflare, executors.NewControlCloudflareExecutor(deps))
	
	reg.Register(core.ActionAddDomain, executors.NewAddDomainExecutor(webDeps))
	reg.Register(core.ActionRemoveDomain, executors.NewRemoveDomainExecutor(webDeps))
	reg.Register(core.ActionSetDomainForwards, executors.NewSetDomainForwardsExecutor(webDeps))
	reg.Register(core.ActionSetDomainPHP, executors.NewSetDomainPHPExecutor(webDeps))
	reg.Register(core.ActionSetDomainOffline, executors.NewSetDomainOfflineExecutor(webDeps))
	reg.Register(core.ActionIssueSSL, executors.NewIssueSSLExecutor(webDeps))

	
	var dnsBackend executors.DNSBackend
	if cfg.LXDDriver == "fake" {
		dnsBackend = pdns.NewFake()
	} else {
		pdnsPool, err := db.Open(ctx, cfg.PDNSDatabaseURL)
		if err != nil {
			log.Error("conectar ao banco do PowerDNS", slog.Any("err", err))
			os.Exit(1)
		}
		defer pdnsPool.Close()
		dnsBackend = pdns.NewStore(pdnsPool, pdns.ZoneConfig{
			PrimaryNS:   cfg.PDNSPrimaryNS,
			SecondaryNS: cfg.PDNSSecondaryNS,
			Hostmaster:  cfg.PDNSHostmaster,
			RecordTTL:   cfg.PDNSRecordTTL,
		})
	}
	dbDeps := executors.DBDeps{LXD: lxdClient, Store: store.NewDatabases(pool), Log: log}
	dnsDeps := executors.DNSDeps{Backend: dnsBackend, Store: store.NewDNS(pool), Log: log}
	cronDeps := executors.CronDeps{LXD: lxdClient, Store: store.NewCron(pool), Log: log, CronUser: cfg.CronUser}
	reg.Register(core.ActionCreateDatabase, executors.NewCreateDatabaseExecutor(dbDeps))
	reg.Register(core.ActionDropDatabase, executors.NewDropDatabaseExecutor(dbDeps))
	reg.Register(core.ActionResetDBPassword, executors.NewResetDBPasswordExecutor(dbDeps))
	reg.Register(core.ActionSetDNSRecord, executors.NewSetDNSRecordExecutor(dnsDeps))
	reg.Register(core.ActionDeleteDNSRecord, executors.NewDeleteDNSRecordExecutor(dnsDeps))
	reg.Register(core.ActionSetCron, executors.NewSetCronExecutor(cronDeps))
	reg.Register(core.ActionRemoveCron, executors.NewRemoveCronExecutor(cronDeps))

	
	reg.Register(core.ActionRestoreDatabase, executors.NewRestoreDatabaseExecutor(deps))
	reg.Register(core.ActionRestoreFiles, executors.NewRestoreFilesExecutor(webDeps))

	
	reg.Register(core.ActionInstallWordPress, executors.NewInstallWordPressExecutor(webDeps))
	reg.Register(core.ActionRemoveWordPress, executors.NewRemoveWordPressExecutor(webDeps))
	reg.Register(core.ActionHardenWordPress, executors.NewHardenWordPressExecutor(webDeps))
	reg.Register(core.ActionInstallPhpBB, executors.NewInstallPhpBBExecutor(webDeps))
	reg.Register(core.ActionRemovePhpBB, executors.NewRemovePhpBBExecutor(webDeps))
	reg.Register(core.ActionUpdatePhpBB, executors.NewUpdatePhpBBExecutor(webDeps))
	reg.Register(core.ActionEnableDocker, executors.NewEnableDockerExecutor(deps))
	reg.Register(core.ActionDisableDocker, executors.NewDisableDockerExecutor(deps))
	reg.Register(core.ActionInstallDockerApp, executors.NewInstallDockerAppExecutor(deps))
	reg.Register(core.ActionRemoveDockerApp, executors.NewRemoveDockerAppExecutor(deps))
	reg.Register(core.ActionUpdateDockerApp, executors.NewUpdateDockerAppExecutor(deps))

	
	reg.Register(core.ActionApplySiteRules, executors.NewApplySiteRulesExecutor(webDeps))

	
	reg.Register(core.ActionSetFastNginx, executors.NewSetFastNginxExecutor(deps))
	reg.Register(core.ActionUpdateClientPackages, executors.NewUpdateClientPackagesExecutor(deps))

	
	reg.Register(core.ActionSetRuntimes, executors.NewSetRuntimesExecutor(deps))

	
	reg.Register(core.ActionSetPostgres, executors.NewSetPostgresExecutor(deps))
	reg.Register(core.ActionSetPhpPgAdmin, executors.NewSetPhpPgAdminExecutor(executors.PPADeps{
		LXD: lxdClient, Store: deps.Store, Log: log, ConfD: cfg.PPAConfD,
	}))

	
	var secMgr security.Manager
	if cfg.LXDDriver == "fake" {
		secMgr = security.NewFake()
	} else {
		secMgr = security.NewReal(log, cfg.AcmeSh)
	}
	reg.Register(core.ActionApplySecurity, executors.NewApplySecurityExecutor(executors.SecurityDeps{Manager: secMgr, Log: log}))
	reg.Register(core.ActionSetPhpMyAdmin, executors.NewSetPhpMyAdminExecutor(executors.PMADeps{
		LXD: lxdClient, Store: deps.Store, Log: log, ConfD: cfg.PMAConfD,
	}))

	
	var hostMgr hostctl.Manager
	if cfg.LXDDriver == "fake" {
		hostMgr = hostctl.NewFake(log)
	} else {
		hostMgr = hostctl.NewReal(cfg.RepoDir, cfg.UpdateRepo)
	}
	hostDeps := executors.HostDeps{Manager: hostMgr, Log: log}
	reg.Register(core.ActionSystemUpdate, executors.NewSystemUpdateExecutor(hostDeps))
	reg.Register(core.ActionPanelUpdate, executors.NewPanelUpdateExecutor(hostDeps))
	reg.Register(core.ActionRestartService, executors.NewRestartServiceExecutor(hostDeps))

	
	backupStore := store.NewBackups(pool)
	reg.Register(core.ActionBackupClient, executors.NewBackupClientExecutor(executors.BackupDeps{
		LXD:         lxdClient,
		Store:       backupStore,
		Log:         log,
		BackupDir:   cfg.ClientBackupDir,
		DocrootBase: cfg.DomainDocrootBase,
		Progress:    q, 
	}))

	vulnStore := store.NewVuln(pool)
	reg.Register(core.ActionScanVulnerabilities, executors.NewScanVulnerabilitiesExecutor(executors.VulnDeps{
		LXD:      lxdClient,
		Store:    vulnStore,
		Log:      log,
		NiktoBin: cfg.NiktoBin, 
	}))

	log.Info("daemon iniciado",
		slog.String("lxd_driver", cfg.LXDDriver),
		slog.String("lxd_image", cfg.LXDImage),
		slog.String("socket", cfg.DaemonSocket),
	)

	
	
	if n, err := q.ReclaimRunning(ctx); err != nil {
		log.Warn("recuperar ações órfãs em running", slog.Any("err", err))
	} else if n > 0 {
		log.Info("ações órfãs recuperadas para pending (serão reprocessadas)", slog.Int64("count", n))
	}

	
	nudges := make(chan struct{}, 1)
	go func() {
		err := queue.Listen(ctx, cfg.DaemonSocket, func() {
			select {
			case nudges <- struct{}{}:
			default: 
			}
		})
		if err != nil {
			log.Error("listener do socket", slog.Any("err", err))
		}
	}()

	
	go scheduler.New(backupStore, q, cfg.DaemonSocket, log, 30*time.Minute).Run(ctx)

	
	go scheduler.NewVuln(vulnStore, q, cfg.DaemonSocket, log, 6*time.Hour).Run(ctx)

	
	go bwsampler.New(pool, lxdClient, log).Run(ctx)

	
	go seccollect.New(pool, log).Run(ctx)

	
	var fwMgr firewall.Manager
	if cfg.LXDDriver == "fake" {
		fwMgr = firewall.NewFake(log)
	} else {
		fwMgr = firewall.NewReal(log)
	}

	
	go func() {
		if err := fileapi.Serve(ctx, cfg.FileAPISocket, cfg.FileAPIToken, lxdClient, cfg.DomainDocrootBase, fwMgr, log); err != nil {
			log.Error("file service", slog.Any("err", err))
		}
	}()

	c := consumer.New(q, reg, log)
	if err := c.Run(ctx, nudges); err != nil && ctx.Err() == nil {
		log.Error("consumer", slog.Any("err", err))
		os.Exit(1)
	}
	log.Info("daemon encerrado")
}
